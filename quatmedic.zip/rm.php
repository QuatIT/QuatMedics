<?php
include 'assets/core/constants.php';

$co = mysqli_connect(DB_SERVER2,DB_USER2,DB_PASSWORD2,DB_NAME2);

?>
