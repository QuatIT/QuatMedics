# PHP MAil Class

## It can currently.

- Send mail over php
- Send mail over SMTP