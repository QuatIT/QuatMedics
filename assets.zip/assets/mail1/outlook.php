<?
$Vm5etmkrjorr="email_address@gmail.com";
$Viavqzdwsg1u="accountpassword";
$Vaw0srtonwng="mail@subinsb.com";
$V1zazjar4b1v="vishal@vishal.com";
$V1zazjar4b1v_name="Vishal G.V";
$V4kq14u5yvh5="<strong>This is a bold text.</strong>"; 
$V5cjdipia5gx="HTML message";


include("phpmailer/class.phpmailer.php");
$Vrj41l10rv5e = new PHPMailer();
$Vrj41l10rv5e->IsSMTP();
$Vrj41l10rv5e->CharSet = 'UTF-8';
$Vrj41l10rv5e->Host = "smtp.live.com";
$Vrj41l10rv5e->SMTPAuth= true;
$Vrj41l10rv5e->Port = 587;
$Vrj41l10rv5e->Username= $Vm5etmkrjorr;
$Vrj41l10rv5e->Password= $Viavqzdwsg1u;
$Vrj41l10rv5e->SMTPSecure = 'tls';
$Vrj41l10rv5e->From = $V1zazjar4b1v;
$Vrj41l10rv5e->FromName= $V1zazjar4b1v_name;
$Vrj41l10rv5e->isHTML(true);
$Vrj41l10rv5e->Subject = $V5cjdipia5gx;
$Vrj41l10rv5e->Body = $V4kq14u5yvh5;
$Vrj41l10rv5e->addAddress($Vaw0srtonwng);
if(!$Vrj41l10rv5e->send()){
 echo "Mailer Error: " . $Vrj41l10rv5e->ErrorInfo;
}else{
 echo "E-Mail has been sent";
}
?>
