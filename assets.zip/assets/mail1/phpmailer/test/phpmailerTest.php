<?php


require 'PHPUnit/Framework.php';

$Vb3s2kfmkonx = "../";

require $Vb3s2kfmkonx . 'class.phpmailer.php';
error_reporting(E_ALL);


class phpmailerTest extends PHPUnit_Framework_TestCase {
    
    var $Vk102n2lcbzp = false;

    
    var $Vflkeq31wlvj = "";

    
    var $V1wz3wxuifre = array();

     
    var $Vcqkgdn5hyas = array();

    
    function setUp() {
        global $Vb3s2kfmkonx;

	@include './testbootstrap.php'; 

        $Vvkqsaecgfirhis->Mail = new PHPMailer();

        $Vvkqsaecgfirhis->Mail->Priority = 3;
        $Vvkqsaecgfirhis->Mail->Encoding = "8bit";
        $Vvkqsaecgfirhis->Mail->CharSet = "iso-8859-1";
        if (array_key_exists('mail_from', $_REQUEST)) {
	        $Vvkqsaecgfirhis->Mail->From = $_REQUEST['mail_from'];
	    } else {
	        $Vvkqsaecgfirhis->Mail->From = 'unit_test@phpmailer.sf.net';
	    }
        $Vvkqsaecgfirhis->Mail->FromName = "Unit Tester";
        $Vvkqsaecgfirhis->Mail->Sender = "";
        $Vvkqsaecgfirhis->Mail->Subject = "Unit Test";
        $Vvkqsaecgfirhis->Mail->Body = "";
        $Vvkqsaecgfirhis->Mail->AltBody = "";
        $Vvkqsaecgfirhis->Mail->WordWrap = 0;
        if (array_key_exists('mail_host', $_REQUEST)) {
	        $Vvkqsaecgfirhis->Mail->Host = $_REQUEST['mail_host'];
	    } else {
	        $Vvkqsaecgfirhis->Mail->Host = 'mail.example.com';
	    }
        $Vvkqsaecgfirhis->Mail->Port = 25;
        $Vvkqsaecgfirhis->Mail->Helo = "localhost.localdomain";
        $Vvkqsaecgfirhis->Mail->SMTPAuth = false;
        $Vvkqsaecgfirhis->Mail->Username = "";
        $Vvkqsaecgfirhis->Mail->Password = "";
        $Vvkqsaecgfirhis->Mail->PluginDir = $Vb3s2kfmkonx;
		$Vvkqsaecgfirhis->Mail->AddReplyTo("no_reply@phpmailer.sf.net", "Reply Guy");
        $Vvkqsaecgfirhis->Mail->Sender = "unit_test@phpmailer.sf.net";

        if(strlen($Vvkqsaecgfirhis->Mail->Host) > 0) {
            $Vvkqsaecgfirhis->Mail->Mailer = "smtp";
        } else {
            $Vvkqsaecgfirhis->Mail->Mailer = "mail";
            $Vvkqsaecgfirhis->Sender = "unit_test@phpmailer.sf.net";
        }

        if (array_key_exists('mail_to', $_REQUEST)) {
	        $Vvkqsaecgfirhis->SetAddress($_REQUEST['mail_to'], 'Test User', 'to');
	    }
        if (array_key_exists('mail_cc', $_REQUEST) and strlen($_REQUEST['mail_cc']) > 0) {
	        $Vvkqsaecgfirhis->SetAddress($_REQUEST['mail_cc'], 'Carbon User', 'cc');
	    }
    }

    
    function tearDown() {
        
        $Vvkqsaecgfirhis->Mail = NULL;
        $Vvkqsaecgfirhis->ChangeLog = array();
        $Vvkqsaecgfirhis->NoteLog = array();
    }


    
    function BuildBody() {
        $Vvkqsaecgfirhis->CheckChanges();

        
        if($Vvkqsaecgfirhis->Mail->ContentType == "text/html" || strlen($Vvkqsaecgfirhis->Mail->AltBody) > 0)
        {
            $Vh52rytqvgpg = "<br/>";
            $Vmxtsjnp41pl = "<li>";
            $Vmxtsjnp41pl_start = "<ul>";
            $Vmxtsjnp41pl_end = "</ul>";
        }
        else
        {
            $Vh52rytqvgpg = "\n";
            $Vmxtsjnp41pl = " - ";
            $Vmxtsjnp41pl_start = "";
            $Vmxtsjnp41pl_end = "";
        }

        $Vihq54sjkop3 = "";

        $Vihq54sjkop3 .= "---------------------" . $Vh52rytqvgpg;
        $Vihq54sjkop3 .= "Unit Test Information" . $Vh52rytqvgpg;
        $Vihq54sjkop3 .= "---------------------" . $Vh52rytqvgpg;
        $Vihq54sjkop3 .= "phpmailer version: " . PHPMailer::VERSION . $Vh52rytqvgpg;
        $Vihq54sjkop3 .= "Content Type: " . $Vvkqsaecgfirhis->Mail->ContentType . $Vh52rytqvgpg;

        if(strlen($Vvkqsaecgfirhis->Mail->Host) > 0)
            $Vihq54sjkop3 .= "Host: " . $Vvkqsaecgfirhis->Mail->Host . $Vh52rytqvgpg;

        
        $Vhhvyg3l2sry = $Vvkqsaecgfirhis->Mail->GetAttachments();
        if(count($Vhhvyg3l2sry) > 0)
        {
            $Vihq54sjkop3 .= "Attachments:" . $Vh52rytqvgpg;
            $Vihq54sjkop3 .= $Vmxtsjnp41pl_start;
            foreach($Vhhvyg3l2sry as $Vc01mj4w34lt) {
                $Vihq54sjkop3 .= $Vmxtsjnp41pl . "Name: " . $Vc01mj4w34lt[1] . ", ";
                $Vihq54sjkop3 .= "Encoding: " . $Vc01mj4w34lt[3] . ", ";
                $Vihq54sjkop3 .= "Type: " . $Vc01mj4w34lt[4] . $Vh52rytqvgpg;
            }
            $Vihq54sjkop3 .= $Vmxtsjnp41pl_end . $Vh52rytqvgpg;
        }

        
        if(count($Vvkqsaecgfirhis->ChangeLog) > 0)
        {
            $Vihq54sjkop3 .= "Changes" . $Vh52rytqvgpg;
            $Vihq54sjkop3 .= "-------" . $Vh52rytqvgpg;

            $Vihq54sjkop3 .= $Vmxtsjnp41pl_start;
            for($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < count($Vvkqsaecgfirhis->ChangeLog); $V0ixz2v5mxzy++)
            {
                $Vihq54sjkop3 .= $Vmxtsjnp41pl . $Vvkqsaecgfirhis->ChangeLog[$V0ixz2v5mxzy][0] . " was changed to [" .
                               $Vvkqsaecgfirhis->ChangeLog[$V0ixz2v5mxzy][1] . "]" . $Vh52rytqvgpg;
            }
            $Vihq54sjkop3 .= $Vmxtsjnp41pl_end . $Vh52rytqvgpg . $Vh52rytqvgpg;
        }

        
        if(count($Vvkqsaecgfirhis->NoteLog) > 0)
        {
            $Vihq54sjkop3 .= "Notes" . $Vh52rytqvgpg;
            $Vihq54sjkop3 .= "-----" . $Vh52rytqvgpg;

            $Vihq54sjkop3 .= $Vmxtsjnp41pl_start;
            for($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < count($Vvkqsaecgfirhis->NoteLog); $V0ixz2v5mxzy++)
            {
                $Vihq54sjkop3 .= $Vmxtsjnp41pl . $Vvkqsaecgfirhis->NoteLog[$V0ixz2v5mxzy] . $Vh52rytqvgpg;
            }
            $Vihq54sjkop3 .= $Vmxtsjnp41pl_end;
        }

        
        $Vvkqsaecgfirhis->Mail->Body .= $Vh52rytqvgpg . $Vh52rytqvgpg . $Vihq54sjkop3;
    }

    
    function CheckChanges() {
        if($Vvkqsaecgfirhis->Mail->Priority != 3)
            $Vvkqsaecgfirhis->AddChange("Priority", $Vvkqsaecgfirhis->Mail->Priority);
        if($Vvkqsaecgfirhis->Mail->Encoding != "8bit")
            $Vvkqsaecgfirhis->AddChange("Encoding", $Vvkqsaecgfirhis->Mail->Encoding);
        if($Vvkqsaecgfirhis->Mail->CharSet != "iso-8859-1")
            $Vvkqsaecgfirhis->AddChange("CharSet", $Vvkqsaecgfirhis->Mail->CharSet);
        if($Vvkqsaecgfirhis->Mail->Sender != "")
            $Vvkqsaecgfirhis->AddChange("Sender", $Vvkqsaecgfirhis->Mail->Sender);
        if($Vvkqsaecgfirhis->Mail->WordWrap != 0)
            $Vvkqsaecgfirhis->AddChange("WordWrap", $Vvkqsaecgfirhis->Mail->WordWrap);
        if($Vvkqsaecgfirhis->Mail->Mailer != "mail")
            $Vvkqsaecgfirhis->AddChange("Mailer", $Vvkqsaecgfirhis->Mail->Mailer);
        if($Vvkqsaecgfirhis->Mail->Port != 25)
            $Vvkqsaecgfirhis->AddChange("Port", $Vvkqsaecgfirhis->Mail->Port);
        if($Vvkqsaecgfirhis->Mail->Helo != "localhost.localdomain")
            $Vvkqsaecgfirhis->AddChange("Helo", $Vvkqsaecgfirhis->Mail->Helo);
        if($Vvkqsaecgfirhis->Mail->SMTPAuth)
            $Vvkqsaecgfirhis->AddChange("SMTPAuth", "true");
    }

    
    function AddChange($Vtkg3s1vldrb, $V5l5nzgk3rwy) {
        $Vzy550xptt4h = count($Vvkqsaecgfirhis->ChangeLog);
        $Vvkqsaecgfirhis->ChangeLog[$Vzy550xptt4h][0] = $Vtkg3s1vldrb;
        $Vvkqsaecgfirhis->ChangeLog[$Vzy550xptt4h][1] = $V5l5nzgk3rwy;
    }

    
    function AddNote($Vbtfsafqcgf1) {
        $Vvkqsaecgfirhis->NoteLog[] = $Vbtfsafqcgf1;
    }

    
    function SetAddress($Vj1la45p2fbc, $Vtkg3s1vldrb = "", $Vxixryzxgzm1 = "to") {
        switch($Vxixryzxgzm1)
        {
            case "to":
                return $Vvkqsaecgfirhis->Mail->AddAddress($Vj1la45p2fbc, $Vtkg3s1vldrb);
            case "cc":
                return $Vvkqsaecgfirhis->Mail->AddCC($Vj1la45p2fbc, $Vtkg3s1vldrb);
            case "bcc":
                return $Vvkqsaecgfirhis->Mail->AddBCC($Vj1la45p2fbc, $Vtkg3s1vldrb);
        }
    }

    
    
    

    
    function test_WordWrap() {

        $Vvkqsaecgfirhis->Mail->WordWrap = 40;
        $Vj21nhbjy2gh = "Here is the main body of this message.  It should " .
                   "be quite a few lines.  It should be wrapped at the " .
                   "40 characters.  Make sure that it is.";
        $V3pz5gg4n1cu = strlen($Vj21nhbjy2gh);
        $Vj21nhbjy2gh .= "\n\nThis is the above body length: " . $V3pz5gg4n1cu;

        $Vvkqsaecgfirhis->Mail->Body = $Vj21nhbjy2gh;
        $Vvkqsaecgfirhis->Mail->Subject .= ": Wordwrap";

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    
    function test_Low_Priority() {

        $Vvkqsaecgfirhis->Mail->Priority = 5;
        $Vvkqsaecgfirhis->Mail->Body = "Here is the main body.  There should be " .
                            "a reply to address in this message.";
        $Vvkqsaecgfirhis->Mail->Subject .= ": Low Priority";
        $Vvkqsaecgfirhis->Mail->AddReplyTo("nobody@nobody.com", "Nobody (Unit Test)");

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    
    function test_Multiple_Plain_FileAttachment() {

        $Vvkqsaecgfirhis->Mail->Body = "Here is the text body";
        $Vvkqsaecgfirhis->Mail->Subject .= ": Plain + Multiple FileAttachments";

        if(!$Vvkqsaecgfirhis->Mail->AddAttachment("test.png"))
        {
            $Vvkqsaecgfirhis->assertTrue(false, $Vvkqsaecgfirhis->Mail->ErrorInfo);
            return;
        }

        if(!$Vvkqsaecgfirhis->Mail->AddAttachment(__FILE__, "test.txt"))
        {
            $Vvkqsaecgfirhis->assertTrue(false, $Vvkqsaecgfirhis->Mail->ErrorInfo);
            return;
        }

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    
    function test_Plain_StringAttachment() {

        $Vvkqsaecgfirhis->Mail->Body = "Here is the text body";
        $Vvkqsaecgfirhis->Mail->Subject .= ": Plain + StringAttachment";

        $Vfxxgh254wbd = "These characters are the content of the " .
                       "string attachment.\nThis might be taken from a ".
                       "database or some other such thing. ";

        $Vvkqsaecgfirhis->Mail->AddStringAttachment($Vfxxgh254wbd, "string_attach.txt");

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    
    function test_Quoted_Printable() {

        $Vvkqsaecgfirhis->Mail->Body = "Here is the main body";
        $Vvkqsaecgfirhis->Mail->Subject .= ": Plain + Quoted-printable";
        $Vvkqsaecgfirhis->Mail->Encoding = "quoted-printable";

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);

	
	$Vvkqsaecgfir = substr(file_get_contents(__FILE__), 0, 1024); 
	$Vvkqsaecgfirhis->assertEquals($Vvkqsaecgfir, quoted_printable_decode($Vvkqsaecgfirhis->Mail->EncodeQP($Vvkqsaecgfir)), 'QP encoding round-trip failed');
        

    }

    
    function test_Html() {

        $Vvkqsaecgfirhis->Mail->IsHTML(true);
        $Vvkqsaecgfirhis->Mail->Subject .= ": HTML only";

        $Vvkqsaecgfirhis->Mail->Body = "This is a <b>test message</b> written in HTML. </br>" .
                            "Go to <a href=\"http://phpmailer.sourceforge.net/\">" .
                            "http://phpmailer.sourceforge.net/</a> for new versions of " .
                            "phpmailer.  <p/> Thank you!";

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    
    function test_HTML_Attachment() {

        $Vvkqsaecgfirhis->Mail->Body = "This is the <b>HTML</b> part of the email.";
        $Vvkqsaecgfirhis->Mail->Subject .= ": HTML + Attachment";
        $Vvkqsaecgfirhis->Mail->IsHTML(true);

        if(!$Vvkqsaecgfirhis->Mail->AddAttachment(__FILE__, "test_attach.txt"))
        {
            $Vvkqsaecgfirhis->assertTrue(false, $Vvkqsaecgfirhis->Mail->ErrorInfo);
            return;
        }

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    
    function test_Embedded_Image() {

        $Vvkqsaecgfirhis->Mail->Body = "Embedded Image: <img alt=\"phpmailer\" src=\"cid:my-attach\">" .
                     "Here is an image!</a>";
        $Vvkqsaecgfirhis->Mail->Subject .= ": Embedded Image";
        $Vvkqsaecgfirhis->Mail->IsHTML(true);

        if(!$Vvkqsaecgfirhis->Mail->AddEmbeddedImage("test.png", "my-attach", "test.png",
                                          "base64", "image/png"))
        {
            $Vvkqsaecgfirhis->assertTrue(false, $Vvkqsaecgfirhis->Mail->ErrorInfo);
            return;
        }

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
	
	$Vvkqsaecgfirhis->Mail->AddEmbeddedImage('thisfiledoesntexist', 'xyz'); 
	$Vvkqsaecgfirhis->Mail->AddEmbeddedImage(__FILE__, '123'); 

    }

    
    function test_Multi_Embedded_Image() {

        $Vvkqsaecgfirhis->Mail->Body = "Embedded Image: <img alt=\"phpmailer\" src=\"cid:my-attach\">" .
                     "Here is an image!</a>";
        $Vvkqsaecgfirhis->Mail->Subject .= ": Embedded Image + Attachment";
        $Vvkqsaecgfirhis->Mail->IsHTML(true);

        if(!$Vvkqsaecgfirhis->Mail->AddEmbeddedImage("test.png", "my-attach", "test.png",
                                          "base64", "image/png"))
        {
            $Vvkqsaecgfirhis->assertTrue(false, $Vvkqsaecgfirhis->Mail->ErrorInfo);
            return;
        }

        if(!$Vvkqsaecgfirhis->Mail->AddAttachment(__FILE__, "test.txt"))
        {
            $Vvkqsaecgfirhis->assertTrue(false, $Vvkqsaecgfirhis->Mail->ErrorInfo);
            return;
        }

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    
    function test_AltBody() {

        $Vvkqsaecgfirhis->Mail->Body = "This is the <b>HTML</b> part of the email.";
        $Vvkqsaecgfirhis->Mail->AltBody = "Here is the text body of this message.  " .
                   "It should be quite a few lines.  It should be wrapped at the " .
                   "40 characters.  Make sure that it is.";
        $Vvkqsaecgfirhis->Mail->WordWrap = 40;
        $Vvkqsaecgfirhis->AddNote("This is a mulipart alternative email");
        $Vvkqsaecgfirhis->Mail->Subject .= ": AltBody + Word Wrap";

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    
    function test_AltBody_Attachment() {

        $Vvkqsaecgfirhis->Mail->Body = "This is the <b>HTML</b> part of the email.";
        $Vvkqsaecgfirhis->Mail->AltBody = "This is the text part of the email.";
        $Vvkqsaecgfirhis->Mail->Subject .= ": AltBody + Attachment";
        $Vvkqsaecgfirhis->Mail->IsHTML(true);

        if(!$Vvkqsaecgfirhis->Mail->AddAttachment(__FILE__, "test_attach.txt"))
        {
            $Vvkqsaecgfirhis->assertTrue(false, $Vvkqsaecgfirhis->Mail->ErrorInfo);
            return;
        }

        $Vvkqsaecgfirhis->BuildBody();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
        if (is_writable('.')) {
            file_put_contents('message.txt', $Vvkqsaecgfirhis->Mail->CreateHeader() . $Vvkqsaecgfirhis->Mail->CreateBody());
        } else {
            $Vvkqsaecgfirhis->assertTrue(false, 'Could not write local file - check permissions');
        }
    }

    function test_MultipleSend() {
        $Vvkqsaecgfirhis->Mail->Body = "Sending two messages without keepalive";
        $Vvkqsaecgfirhis->BuildBody();
        $V5cjdipia5gx = $Vvkqsaecgfirhis->Mail->Subject;

        $Vvkqsaecgfirhis->Mail->Subject = $V5cjdipia5gx . ": SMTP 1";
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);

        $Vvkqsaecgfirhis->Mail->Subject = $V5cjdipia5gx . ": SMTP 2";
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    function test_SendmailSend() {
        $Vvkqsaecgfirhis->Mail->Body = "Sending via sendmail";
        $Vvkqsaecgfirhis->BuildBody();
        $V5cjdipia5gx = $Vvkqsaecgfirhis->Mail->Subject;

        $Vvkqsaecgfirhis->Mail->Subject = $V5cjdipia5gx . ": sendmail";
	$Vvkqsaecgfirhis->Mail->IsSendmail();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    function test_MailSend() {
        $Vvkqsaecgfirhis->Mail->Body = "Sending via mail()";
        $Vvkqsaecgfirhis->BuildBody();
        $V5cjdipia5gx = $Vvkqsaecgfirhis->Mail->Subject;

        $Vvkqsaecgfirhis->Mail->Subject = $V5cjdipia5gx . ": mail()";
	$Vvkqsaecgfirhis->Mail->IsMail();
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

    function test_SmtpKeepAlive() {
        $Vvkqsaecgfirhis->Mail->Body = "This was done using the SMTP keep-alive.";
        $Vvkqsaecgfirhis->BuildBody();
        $V5cjdipia5gx = $Vvkqsaecgfirhis->Mail->Subject;

        $Vvkqsaecgfirhis->Mail->SMTPKeepAlive = true;
        $Vvkqsaecgfirhis->Mail->Subject = $V5cjdipia5gx . ": SMTP keep-alive 1";
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);

        $Vvkqsaecgfirhis->Mail->Subject = $V5cjdipia5gx . ": SMTP keep-alive 2";
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
        $Vvkqsaecgfirhis->Mail->SmtpClose();
    }

    
    function test_DenialOfServiceAttack() {
        $Vvkqsaecgfirhis->Mail->Body = "This should no longer cause a denial of service.";
        $Vvkqsaecgfirhis->BuildBody();

        $Vvkqsaecgfirhis->Mail->Subject = str_repeat("A", 998);
        $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), $Vvkqsaecgfirhis->Mail->ErrorInfo);
    }

	function test_Error() {
		$Vvkqsaecgfirhis->Mail->Subject .= ": This should be sent";
		$Vvkqsaecgfirhis->BuildBody();
		$Vvkqsaecgfirhis->Mail->ClearAllRecipients(); 
		$Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->IsError() == false, "Error found");
		$Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send() == false, "Send succeeded");
		$Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->IsError(), "No error found");
		$Vvkqsaecgfirhis->assertEquals('You must provide at least one recipient email address.', $Vvkqsaecgfirhis->Mail->ErrorInfo);
		$Vvkqsaecgfirhis->Mail->AddAddress($_REQUEST['mail_to']);
		$Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->Send(), "Send failed");
	}

	function test_Addressing() {
		$Vvkqsaecgfirhis->assertFalse($Vvkqsaecgfirhis->Mail->AddAddress('a@example..com'), 'Invalid address accepted');
		$Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->AddAddress('a@example.com'), 'Addressing failed');
		$Vvkqsaecgfirhis->assertFalse($Vvkqsaecgfirhis->Mail->AddAddress('a@example.com'), 'Duplicate addressing failed');
		$Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->AddCC('b@example.com'), 'CC addressing failed');
		$Vvkqsaecgfirhis->assertFalse($Vvkqsaecgfirhis->Mail->AddCC('b@example.com'), 'CC duplicate addressing failed');
		$Vvkqsaecgfirhis->assertFalse($Vvkqsaecgfirhis->Mail->AddCC('a@example.com'), 'CC duplicate addressing failed (2)');
		$Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->AddBCC('c@example.com'), 'BCC addressing failed');
		$Vvkqsaecgfirhis->assertFalse($Vvkqsaecgfirhis->Mail->AddBCC('c@example.com'), 'BCC duplicate addressing failed');
		$Vvkqsaecgfirhis->assertFalse($Vvkqsaecgfirhis->Mail->AddBCC('a@example.com'), 'BCC duplicate addressing failed (2)');
		$Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->AddReplyTo('a@example.com'), 'Replyto Addressing failed');
		$Vvkqsaecgfirhis->assertFalse($Vvkqsaecgfirhis->Mail->AddReplyTo('a@example..com'), 'Invalid Replyto address accepted');
		$Vvkqsaecgfirhis->Mail->ClearAddresses();
		$Vvkqsaecgfirhis->Mail->ClearCCs();
		$Vvkqsaecgfirhis->Mail->ClearBCCs();
		$Vvkqsaecgfirhis->Mail->ClearReplyTos();
	}

	
	function test_Translations() {
		$Vvkqsaecgfirhis->Mail->SetLanguage('en');
		$Varl0dkqgqvf = $Vvkqsaecgfirhis->Mail->GetTranslations();
		foreach (new DirectoryIterator('../language') as $Vgddytw4hbcg) {
			if($Vgddytw4hbcg->isDot()) continue;
			$Vgvt1cvsrlfv = array();
			
			if (preg_match('/^phpmailer\.lang-([a-z_]{2,})\.php$/', $Vgddytw4hbcg->getFilename(), $Vgvt1cvsrlfv)) {
				$V2jyqaowtche = $Vgvt1cvsrlfv[1]; 
				$Vdsumqyouvr2 = array(); 
				include $Vgddytw4hbcg->getPathname(); 
				$Vt3ttrakybqg = array_diff(array_keys($Varl0dkqgqvf), array_keys($Vdsumqyouvr2));
				$Vbrljndkewhx = array_diff(array_keys($Vdsumqyouvr2), array_keys($Varl0dkqgqvf));
				$Vvkqsaecgfirhis->assertTrue(empty($Vt3ttrakybqg), "Missing translations in $V2jyqaowtche: ". implode(', ', $Vt3ttrakybqg));
				$Vvkqsaecgfirhis->assertTrue(empty($Vbrljndkewhx), "Extra translations in $V2jyqaowtche: ". implode(', ', $Vbrljndkewhx));
			}
		}
	}

	
	function test_Encodings() {
	    $Vvkqsaecgfirhis->Mail->Charset = 'iso-8859-1';
	    $Vvkqsaecgfirhis->assertEquals('=A1Hola!_Se=F1or!', $Vvkqsaecgfirhis->Mail->EncodeQ('�Hola! Se�or!', 'text'), 'Q Encoding (text) failed');
	    $Vvkqsaecgfirhis->assertEquals('=A1Hola!_Se=F1or!', $Vvkqsaecgfirhis->Mail->EncodeQ('�Hola! Se�or!', 'comment'), 'Q Encoding (comment) failed');
	    $Vvkqsaecgfirhis->assertEquals('=A1Hola!_Se=F1or!', $Vvkqsaecgfirhis->Mail->EncodeQ('�Hola! Se�or!', 'phrase'), 'Q Encoding (phrase) failed');
	}

	
	function test_Signing() {
	    $Vvkqsaecgfirhis->Mail->Sign('certfile.txt', 'keyfile.txt', 'password'); 
	}

	
	function test_Miscellaneous() {
	    $Vvkqsaecgfirhis->assertEquals('application/pdf', PHPMailer::_mime_types('pdf') , 'MIME TYPE lookup failed');
	    $Vvkqsaecgfirhis->Mail->AddCustomHeader('SomeHeader: Some Value');
	    $Vvkqsaecgfirhis->Mail->ClearCustomHeaders();
	    $Vvkqsaecgfirhis->Mail->ClearAttachments();
	    $Vvkqsaecgfirhis->Mail->IsHTML(false);
	    $Vvkqsaecgfirhis->Mail->IsSMTP();
	    $Vvkqsaecgfirhis->Mail->IsMail();
	    $Vvkqsaecgfirhis->Mail->IsSendMail();
   	    $Vvkqsaecgfirhis->Mail->IsQmail();
	    $Vvkqsaecgfirhis->Mail->SetLanguage('fr');
	    $Vvkqsaecgfirhis->Mail->Sender = '';
	    $Vvkqsaecgfirhis->Mail->CreateHeader();
	    $Vvkqsaecgfirhis->assertFalse($Vvkqsaecgfirhis->Mail->set('x', 'y'), 'Invalid property set succeeded');
	    $Vvkqsaecgfirhis->assertTrue($Vvkqsaecgfirhis->Mail->set('Timeout', 11), 'Valid property set failed');
	    $Vvkqsaecgfirhis->Mail->getFile(__FILE__);
	}
}



?>
