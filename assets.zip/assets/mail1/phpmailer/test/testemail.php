<?php


require '../class.phpmailer.php';

try {
	$Vrj41l10rv5e = new PHPMailer(true); 

	$Vw2bgil42wyb             = file_get_contents('contents.html');
	$Vw2bgil42wyb             = preg_replace('/\\\\/','', $Vw2bgil42wyb); 

	$Vrj41l10rv5e->IsSMTP();                           
	$Vrj41l10rv5e->SMTPAuth   = true;                  
	$Vrj41l10rv5e->Port       = 25;                    
	$Vrj41l10rv5e->Host       = "mail.yourdomain.com"; 
	$Vrj41l10rv5e->Username   = "name@domain.com";     
	$Vrj41l10rv5e->Password   = "password";            

	$Vrj41l10rv5e->IsSendmail();  

	$Vrj41l10rv5e->AddReplyTo("name@domain.com","First Last");

	$Vrj41l10rv5e->From       = "name@domain.com";
	$Vrj41l10rv5e->FromName   = "First Last";

	$Vaw0srtonwng = "someone@example...com";

	$Vrj41l10rv5e->AddAddress($Vaw0srtonwng);

	$Vrj41l10rv5e->Subject  = "First PHPMailer Message";

	$Vrj41l10rv5e->AltBody    = "To view the message, please use an HTML compatible email viewer!"; 
	$Vrj41l10rv5e->WordWrap   = 80; 

	$Vrj41l10rv5e->MsgHTML($Vw2bgil42wyb);

	$Vrj41l10rv5e->IsHTML(true); 

	$Vrj41l10rv5e->Send();
	echo 'Message has been sent.';
} catch (phpmailerException $Vqfltxpxjekk) {
	echo $Vqfltxpxjekk->errorMessage();
}
?>
