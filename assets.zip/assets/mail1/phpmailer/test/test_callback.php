<html>
<head>
<title>PHPMailer Lite - DKIM and Callback Function test</title>
</head>
<body>

<?php



function callbackAction ($Vji4j1ie4mwl, $Vaw0srtonwng, $Vq4kynn12tv2, $Vt02fqg21zsq, $V5cjdipia5gx, $Vw2bgil42wyb) {
  
  $Vaw0srtonwng  = cleanEmails($Vaw0srtonwng,'to');
  $Vq4kynn12tv2  = cleanEmails($Vq4kynn12tv2[0],'cc');
  $Vt02fqg21zsq = cleanEmails($Vt02fqg21zsq[0],'cc');
  echo $Vji4j1ie4mwl . "\tTo: "  . $Vaw0srtonwng['Name'] . "\tTo: "  . $Vaw0srtonwng['Email'] . "\tCc: "  . $Vq4kynn12tv2['Name'] . "\tCc: "  . $Vq4kynn12tv2['Email'] . "\tBcc: "  . $Vt02fqg21zsq['Name'] . "\tBcc: "  . $Vt02fqg21zsq['Email'] . "\t"  . $V5cjdipia5gx . "<br />\n";
  return true;
}

$Verkiujhekqs = false;

if ($Verkiujhekqs) {
  require_once '../class.phpmailer-lite.php';
  $Vrj41l10rv5e = new PHPMailerLite();
} else {
  require_once '../class.phpmailer.php';
  $Vrj41l10rv5e = new PHPMailer();
}

try {
  $Vrj41l10rv5e->IsMail(); 
  $Vrj41l10rv5e->SetFrom('you@yourdomain.com', 'Your Name');
  $Vrj41l10rv5e->AddAddress('another@yourdomain.com', 'John Doe');
  $Vrj41l10rv5e->Subject = 'PHPMailer Lite Test Subject via Mail()';
  $Vrj41l10rv5e->AltBody = 'To view the message, please use an HTML compatible email viewer!'; 
  $Vrj41l10rv5e->MsgHTML(file_get_contents('contents.html'));
  $Vrj41l10rv5e->AddAttachment('images/phpmailer.gif');      
  $Vrj41l10rv5e->AddAttachment('images/phpmailer_mini.gif'); 
  $Vrj41l10rv5e->action_function = 'callbackAction';
  $Vrj41l10rv5e->Send();
  echo "Message Sent OK</p>\n";
} catch (phpmailerException $Vqfltxpxjekk) {
  echo $Vqfltxpxjekk->errorMessage(); 
} catch (Exception $Vqfltxpxjekk) {
  echo $Vqfltxpxjekk->getMessage(); 
}

function cleanEmails($Vu5vpgek1hmh,$Vky1xzjrvbn4) {
  if ($Vky1xzjrvbn4 == 'cc') {
    $Vscoo154ll3p['Email'] = $Vu5vpgek1hmh[0];
    $Vscoo154ll3p['Name']  = $Vu5vpgek1hmh[1];
    return $Vscoo154ll3p;
  }
  if (!strstr($Vu5vpgek1hmh, ' <')) {
    $Vscoo154ll3p['Name']  = '';
    $Vscoo154ll3p['Email'] = $Vscoo154ll3p;
    return $Vscoo154ll3p;
  }
  $Vscoo154ll3pArr = explode(' <', $Vu5vpgek1hmh);
  if (substr($Vscoo154ll3pArr[1],-1) == '>') {
    $Vscoo154ll3pArr[1] = substr($Vscoo154ll3pArr[1],0,-1);
  }
  $Vscoo154ll3p['Name']  = $Vscoo154ll3pArr[0];
  $Vscoo154ll3p['Email'] = $Vscoo154ll3pArr[1];
  $Vscoo154ll3p['Email'] = str_replace('@', '&#64;', $Vscoo154ll3p['Email']);
  return $Vscoo154ll3p;
}

?>
</body>
</html>
