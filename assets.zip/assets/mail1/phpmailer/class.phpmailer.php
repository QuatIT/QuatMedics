<?php




if (version_compare(PHP_VERSION, '5.0.0', '<') ) exit("Sorry, this version of PHPMailer will only run on PHP version 5 or greater!\n");

class PHPMailer {

  
  
  

  
  public $Vfkogsgxm00h          = 3;

  
  public $Vfqcao1ugwat           = 'iso-8859-1';

  
  public $Voyhzzrq11m2       = 'text/plain';

  
  public $Vnppf54nddoy          = '8bit';

  
  public $V3pti4i1xibm         = '';

  
  public $Vhgeu0otzr3b              = 'root@localhost';

  
  public $Vhgeu0otzr3bName          = 'Root User';

  
  public $Vwzvvx5ycaks            = '';

  
  public $Vnjcbmctg2z0           = '';

  
  public $Vnvvgp2ueyxn              = '';

  
  public $V2nbbfcqck4f           = '';

  
  public $Vsfhqgqu1caj          = 0;

  
  public $Vyjyotu4d5io            = 'mail';

  
  public $Vkstjzgntq0q          = '/usr/sbin/sendmail';

  
  public $Vihf0tp3a5k1         = '';

  
  public $V1i1ps0gtchy  = '';

  
  public $Vnwfjl0izrfe          = '';

  
  public $V1ec3gsrwajq         = '';

  
  
  

  
  public $Vflkeq31wlvj          = 'localhost';

  
  public $Vqy514h0scgi          = 25;

  
  public $Vc3uqtyopmrt          = '';

  
  public $Vzahd5fbaqmu    = '';

  
  public $Vbe0q1re3pq4      = false;

  
  public $Vchuwzgvrvwm      = '';

  
  public $Vxoueyrwdujl      = '';

  
  public $Vksx2o3oksxd       = 10;

  
  public $V0oz1l30qwaj     = false;

  
  public $Vpupuy2xpshx = false;

  
  public $Vuztavulmg1k      = false;

   
  public $Vuztavulmg1kArray = array();

 
  public $Vena3ta3sbfs              = "\n";

  
  public $Vtxj45wet25r   = 'phpmailer';

  
  public $Vx2ds1oitz52   = '';

  
  public $Vxibebkb4mxs     = '';

  
  public $Vfudpl3qbsot    = '';

  
  public $Vminzbtcjar4 = ''; 

  
  public $Vfaghbcas35q         = '5.1';

  
  
  

  private   $Vmo3qfnejixy           = NULL;
  private   $Vaw0srtonwng             = array();
  private   $Vq4kynn12tv2             = array();
  private   $Vt02fqg21zsq            = array();
  private   $Vtmr1f43umai        = array();
  private   $Vgx5pyutwhkv = array();
  private   $Vc01mj4w34lt     = array();
  private   $Vxgetejh2v1w   = array();
  private   $Voehtbmgwvgp   = '';
  private   $Vwffj4z3vsg3       = array();
  protected $Vjyjuwwpt304       = array();
  private   $V0ghkqoeka02    = 0;
  private   $Vwjzxjvnwo3o = "";
  private   $Vdw4r0hppegf  = "";
  private   $Vhkz01tls0vc  = "";
  private   $Vw0wlv12z1hq     = false;

  
  
  

  const STOP_MESSAGE  = 0; 
  const STOP_CONTINUE = 1; 
  const STOP_CRITICAL = 2; 

  
  
  

  
  public function __construct($Vw0wlv12z1hq = false) {
    $Vvkqsaecgfirhis->exceptions = ($Vw0wlv12z1hq == true);
  }

  
  public function IsHTML($Viw5wro4mtyt = true) {
    if ($Viw5wro4mtyt) {
      $Vvkqsaecgfirhis->ContentType = 'text/html';
    } else {
      $Vvkqsaecgfirhis->ContentType = 'text/plain';
    }
  }

  
  public function IsSMTP() {
    $Vvkqsaecgfirhis->Mailer = 'smtp';
  }

  
  public function IsMail() {
    $Vvkqsaecgfirhis->Mailer = 'mail';
  }

  
  public function IsSendmail() {
    if (!stristr(ini_get('sendmail_path'), 'sendmail')) {
      $Vvkqsaecgfirhis->Sendmail = '/var/qmail/bin/sendmail';
    }
    $Vvkqsaecgfirhis->Mailer = 'sendmail';
  }

  
  public function IsQmail() {
    if (stristr(ini_get('sendmail_path'), 'qmail')) {
      $Vvkqsaecgfirhis->Sendmail = '/var/qmail/bin/sendmail';
    }
    $Vvkqsaecgfirhis->Mailer = 'sendmail';
  }

  
  
  

  
  public function AddAddress($Vzbgitt3jgp3, $Vreuchxnm2nm = '') {
    return $Vvkqsaecgfirhis->AddAnAddress('to', $Vzbgitt3jgp3, $Vreuchxnm2nm);
  }

  
  public function AddCC($Vzbgitt3jgp3, $Vreuchxnm2nm = '') {
    return $Vvkqsaecgfirhis->AddAnAddress('cc', $Vzbgitt3jgp3, $Vreuchxnm2nm);
  }

  
  public function AddBCC($Vzbgitt3jgp3, $Vreuchxnm2nm = '') {
    return $Vvkqsaecgfirhis->AddAnAddress('bcc', $Vzbgitt3jgp3, $Vreuchxnm2nm);
  }

  
  public function AddReplyTo($Vzbgitt3jgp3, $Vreuchxnm2nm = '') {
    return $Vvkqsaecgfirhis->AddAnAddress('ReplyTo', $Vzbgitt3jgp3, $Vreuchxnm2nm);
  }

  
  private function AddAnAddress($Vjij0woxvstj, $Vzbgitt3jgp3, $Vreuchxnm2nm = '') {
    if (!preg_match('/^(to|cc|bcc|ReplyTo)$/', $Vjij0woxvstj)) {
      echo 'Invalid recipient array: ' . kind;
      return false;
    }
    $Vzbgitt3jgp3 = trim($Vzbgitt3jgp3);
    $Vreuchxnm2nm = trim(preg_replace('/[\r\n]+/', '', $Vreuchxnm2nm)); 
    if (!self::ValidateAddress($Vzbgitt3jgp3)) {
      $Vvkqsaecgfirhis->SetError($Vvkqsaecgfirhis->Lang('invalid_address').': '. $Vzbgitt3jgp3);
      if ($Vvkqsaecgfirhis->exceptions) {
        throw new phpmailerException($Vvkqsaecgfirhis->Lang('invalid_address').': '.$Vzbgitt3jgp3);
      }
      echo $Vvkqsaecgfirhis->Lang('invalid_address').': '.$Vzbgitt3jgp3;
      return false;
    }
    if ($Vjij0woxvstj != 'ReplyTo') {
      if (!isset($Vvkqsaecgfirhis->all_recipients[strtolower($Vzbgitt3jgp3)])) {
        array_push($Vvkqsaecgfirhis->$Vjij0woxvstj, array($Vzbgitt3jgp3, $Vreuchxnm2nm));
        $Vvkqsaecgfirhis->all_recipients[strtolower($Vzbgitt3jgp3)] = true;
        return true;
      }
    } else {
      if (!array_key_exists(strtolower($Vzbgitt3jgp3), $Vvkqsaecgfirhis->ReplyTo)) {
        $Vvkqsaecgfirhis->ReplyTo[strtolower($Vzbgitt3jgp3)] = array($Vzbgitt3jgp3, $Vreuchxnm2nm);
      return true;
    }
  }
  return false;
}


  public function SetFrom($Vzbgitt3jgp3, $Vreuchxnm2nm = '',$Vzlllkt4ixym=1) {
    $Vzbgitt3jgp3 = trim($Vzbgitt3jgp3);
    $Vreuchxnm2nm = trim(preg_replace('/[\r\n]+/', '', $Vreuchxnm2nm)); 
    if (!self::ValidateAddress($Vzbgitt3jgp3)) {
      $Vvkqsaecgfirhis->SetError($Vvkqsaecgfirhis->Lang('invalid_address').': '. $Vzbgitt3jgp3);
      if ($Vvkqsaecgfirhis->exceptions) {
        throw new phpmailerException($Vvkqsaecgfirhis->Lang('invalid_address').': '.$Vzbgitt3jgp3);
      }
      echo $Vvkqsaecgfirhis->Lang('invalid_address').': '.$Vzbgitt3jgp3;
      return false;
    }
    $Vvkqsaecgfirhis->From = $Vzbgitt3jgp3;
    $Vvkqsaecgfirhis->FromName = $Vreuchxnm2nm;
    if ($Vzlllkt4ixym) {
      if (empty($Vvkqsaecgfirhis->ReplyTo)) {
        $Vvkqsaecgfirhis->AddAnAddress('ReplyTo', $Vzbgitt3jgp3, $Vreuchxnm2nm);
      }
      if (empty($Vvkqsaecgfirhis->Sender)) {
        $Vvkqsaecgfirhis->Sender = $Vzbgitt3jgp3;
      }
    }
    return true;
  }

  
  public static function ValidateAddress($Vzbgitt3jgp3) {
    if (function_exists('filter_var')) { 
      if(filter_var($Vzbgitt3jgp3, FILTER_VALIDATE_EMAIL) === FALSE) {
        return false;
      } else {
        return true;
      }
    } else {
      return preg_match('/^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9_](?:[a-zA-Z0-9_\-](?!\.)){0,61}[a-zA-Z0-9_-]?\.)+[a-zA-Z0-9_](?:[a-zA-Z0-9_\-](?!$)){0,61}[a-zA-Z0-9_]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/', $Vzbgitt3jgp3);
    }
  }

  
  
  

  
  public function Send() {
    try {
      if ((count($Vvkqsaecgfirhis->to) + count($Vvkqsaecgfirhis->cc) + count($Vvkqsaecgfirhis->bcc)) < 1) {
        throw new phpmailerException($Vvkqsaecgfirhis->Lang('provide_address'), self::STOP_CRITICAL);
      }

      
      if(!empty($Vvkqsaecgfirhis->AltBody)) {
        $Vvkqsaecgfirhis->ContentType = 'multipart/alternative';
      }

      $Vvkqsaecgfirhis->error_count = 0; 
      $Vvkqsaecgfirhis->SetMessageType();
      $Vkwhjduzezf4 = $Vvkqsaecgfirhis->CreateHeader();
      $Vw2bgil42wyb = $Vvkqsaecgfirhis->CreateBody();

      if (empty($Vvkqsaecgfirhis->Body)) {
        throw new phpmailerException($Vvkqsaecgfirhis->Lang('empty_message'), self::STOP_CRITICAL);
      }

      
      if ($Vvkqsaecgfirhis->DKIM_domain && $Vvkqsaecgfirhis->DKIM_private) {
        $Vkwhjduzezf4_dkim = $Vvkqsaecgfirhis->DKIM_Add($Vkwhjduzezf4,$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
        $Vkwhjduzezf4 = str_replace("\r\n","\n",$Vkwhjduzezf4_dkim) . $Vkwhjduzezf4;
      }

      
      switch($Vvkqsaecgfirhis->Mailer) {
        case 'sendmail':
          return $Vvkqsaecgfirhis->SendmailSend($Vkwhjduzezf4, $Vw2bgil42wyb);
        case 'smtp':
          return $Vvkqsaecgfirhis->SmtpSend($Vkwhjduzezf4, $Vw2bgil42wyb);
        default:
          return $Vvkqsaecgfirhis->MailSend($Vkwhjduzezf4, $Vw2bgil42wyb);
      }

    } catch (phpmailerException $Vqfltxpxjekk) {
      $Vvkqsaecgfirhis->SetError($Vqfltxpxjekk->getMessage());
      if ($Vvkqsaecgfirhis->exceptions) {
        throw $Vqfltxpxjekk;
      }
      echo $Vqfltxpxjekk->getMessage()."\n";
      return false;
    }
  }

  
  protected function SendmailSend($Vkwhjduzezf4, $Vw2bgil42wyb) {
    if ($Vvkqsaecgfirhis->Sender != '') {
      $Vzh5udgmxtxe = sprintf("%s -oi -f %s -t", escapeshellcmd($Vvkqsaecgfirhis->Sendmail), escapeshellarg($Vvkqsaecgfirhis->Sender));
    } else {
      $Vzh5udgmxtxe = sprintf("%s -oi -t", escapeshellcmd($Vvkqsaecgfirhis->Sendmail));
    }
    if ($Vvkqsaecgfirhis->SingleTo === true) {
      foreach ($Vvkqsaecgfirhis->SingleToArray as $Vbd2mxirzq2d => $Vso3o0kfkstx) {
        if(!@$Vrj41l10rv5e = popen($Vzh5udgmxtxe, 'w')) {
          throw new phpmailerException($Vvkqsaecgfirhis->Lang('execute') . $Vvkqsaecgfirhis->Sendmail, self::STOP_CRITICAL);
        }
        fputs($Vrj41l10rv5e, "To: " . $Vso3o0kfkstx . "\n");
        fputs($Vrj41l10rv5e, $Vkwhjduzezf4);
        fputs($Vrj41l10rv5e, $Vw2bgil42wyb);
        $Vji4j1ie4mwl = pclose($Vrj41l10rv5e);
        
        $Vrqlni1kqgsu = ($Vji4j1ie4mwl == 0) ? 1 : 0;
        $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,$Vso3o0kfkstx,$Vvkqsaecgfirhis->cc,$Vvkqsaecgfirhis->bcc,$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
        if($Vji4j1ie4mwl != 0) {
          throw new phpmailerException($Vvkqsaecgfirhis->Lang('execute') . $Vvkqsaecgfirhis->Sendmail, self::STOP_CRITICAL);
        }
      }
    } else {
      if(!@$Vrj41l10rv5e = popen($Vzh5udgmxtxe, 'w')) {
        throw new phpmailerException($Vvkqsaecgfirhis->Lang('execute') . $Vvkqsaecgfirhis->Sendmail, self::STOP_CRITICAL);
      }
      fputs($Vrj41l10rv5e, $Vkwhjduzezf4);
      fputs($Vrj41l10rv5e, $Vw2bgil42wyb);
      $Vji4j1ie4mwl = pclose($Vrj41l10rv5e);
      
      $Vrqlni1kqgsu = ($Vji4j1ie4mwl == 0) ? 1 : 0;
      $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,$Vvkqsaecgfirhis->to,$Vvkqsaecgfirhis->cc,$Vvkqsaecgfirhis->bcc,$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
      if($Vji4j1ie4mwl != 0) {
        throw new phpmailerException($Vvkqsaecgfirhis->Lang('execute') . $Vvkqsaecgfirhis->Sendmail, self::STOP_CRITICAL);
      }
    }
    return true;
  }

  
  protected function MailSend($Vkwhjduzezf4, $Vw2bgil42wyb) {
    $Vaw0srtonwngArr = array();
    foreach($Vvkqsaecgfirhis->to as $Vvkqsaecgfir) {
      $Vaw0srtonwngArr[] = $Vvkqsaecgfirhis->AddrFormat($Vvkqsaecgfir);
    }
    $Vaw0srtonwng = implode(', ', $Vaw0srtonwngArr);

    $Vpzpk4keb40k = sprintf("-oi -f %s", $Vvkqsaecgfirhis->Sender);
    if ($Vvkqsaecgfirhis->Sender != '' && strlen(ini_get('safe_mode'))< 1) {
      $Vp4f0b02otvn = ini_get('sendmail_from');
      ini_set('sendmail_from', $Vvkqsaecgfirhis->Sender);
      if ($Vvkqsaecgfirhis->SingleTo === true && count($Vaw0srtonwngArr) > 1) {
        foreach ($Vaw0srtonwngArr as $Vbd2mxirzq2d => $Vso3o0kfkstx) {
          $Vsncau3iubft = @mail($Vso3o0kfkstx, $Vvkqsaecgfirhis->EncodeHeader($Vvkqsaecgfirhis->SecureHeader($Vvkqsaecgfirhis->Subject)), $Vw2bgil42wyb, $Vkwhjduzezf4, $Vpzpk4keb40k);
          
          $Vrqlni1kqgsu = ($Vsncau3iubft == 1) ? 1 : 0;
          $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,$Vso3o0kfkstx,$Vvkqsaecgfirhis->cc,$Vvkqsaecgfirhis->bcc,$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
        }
      } else {
        $Vsncau3iubft = @mail($Vaw0srtonwng, $Vvkqsaecgfirhis->EncodeHeader($Vvkqsaecgfirhis->SecureHeader($Vvkqsaecgfirhis->Subject)), $Vw2bgil42wyb, $Vkwhjduzezf4, $Vpzpk4keb40k);
        
        $Vrqlni1kqgsu = ($Vsncau3iubft == 1) ? 1 : 0;
        $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,$Vaw0srtonwng,$Vvkqsaecgfirhis->cc,$Vvkqsaecgfirhis->bcc,$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
      }
    } else {
      if ($Vvkqsaecgfirhis->SingleTo === true && count($Vaw0srtonwngArr) > 1) {
        foreach ($Vaw0srtonwngArr as $Vbd2mxirzq2d => $Vso3o0kfkstx) {
          $Vsncau3iubft = @mail($Vso3o0kfkstx, $Vvkqsaecgfirhis->EncodeHeader($Vvkqsaecgfirhis->SecureHeader($Vvkqsaecgfirhis->Subject)), $Vw2bgil42wyb, $Vkwhjduzezf4, $Vpzpk4keb40k);
          
          $Vrqlni1kqgsu = ($Vsncau3iubft == 1) ? 1 : 0;
          $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,$Vso3o0kfkstx,$Vvkqsaecgfirhis->cc,$Vvkqsaecgfirhis->bcc,$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
        }
      } else {
        $Vsncau3iubft = @mail($Vaw0srtonwng, $Vvkqsaecgfirhis->EncodeHeader($Vvkqsaecgfirhis->SecureHeader($Vvkqsaecgfirhis->Subject)), $Vw2bgil42wyb, $Vkwhjduzezf4);
        
        $Vrqlni1kqgsu = ($Vsncau3iubft == 1) ? 1 : 0;
        $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,$Vaw0srtonwng,$Vvkqsaecgfirhis->cc,$Vvkqsaecgfirhis->bcc,$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
      }
    }
    if (isset($Vp4f0b02otvn)) {
      ini_set('sendmail_from', $Vp4f0b02otvn);
    }
    if(!$Vsncau3iubft) {
      throw new phpmailerException($Vvkqsaecgfirhis->Lang('instantiate'), self::STOP_CRITICAL);
    }
    return true;
  }

  
  protected function SmtpSend($Vkwhjduzezf4, $Vw2bgil42wyb) {
    require_once $Vvkqsaecgfirhis->PluginDir . 'class.smtp.php';
    $Vjhuxhp4slxk = array();

    if(!$Vvkqsaecgfirhis->SmtpConnect()) {
      throw new phpmailerException($Vvkqsaecgfirhis->Lang('smtp_connect_failed'), self::STOP_CRITICAL);
    }
    $Vmo3qfnejixy_from = ($Vvkqsaecgfirhis->Sender == '') ? $Vvkqsaecgfirhis->From : $Vvkqsaecgfirhis->Sender;
    if(!$Vvkqsaecgfirhis->smtp->Mail($Vmo3qfnejixy_from)) {
      throw new phpmailerException($Vvkqsaecgfirhis->Lang('from_failed') . $Vmo3qfnejixy_from, self::STOP_CRITICAL);
    }

    
    foreach($Vvkqsaecgfirhis->to as $Vaw0srtonwng) {
      if (!$Vvkqsaecgfirhis->smtp->Recipient($Vaw0srtonwng[0])) {
        $Vjhuxhp4slxk[] = $Vaw0srtonwng[0];
        
        $Vrqlni1kqgsu = 0;
        $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,$Vaw0srtonwng[0],'','',$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
      } else {
        
        $Vrqlni1kqgsu = 1;
        $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,$Vaw0srtonwng[0],'','',$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
      }
    }
    foreach($Vvkqsaecgfirhis->cc as $Vq4kynn12tv2) {
      if (!$Vvkqsaecgfirhis->smtp->Recipient($Vq4kynn12tv2[0])) {
        $Vjhuxhp4slxk[] = $Vq4kynn12tv2[0];
        
        $Vrqlni1kqgsu = 0;
        $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,'',$Vq4kynn12tv2[0],'',$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
      } else {
        
        $Vrqlni1kqgsu = 1;
        $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,'',$Vq4kynn12tv2[0],'',$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
      }
    }
    foreach($Vvkqsaecgfirhis->bcc as $Vt02fqg21zsq) {
      if (!$Vvkqsaecgfirhis->smtp->Recipient($Vt02fqg21zsq[0])) {
        $Vjhuxhp4slxk[] = $Vt02fqg21zsq[0];
        
        $Vrqlni1kqgsu = 0;
        $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,'','',$Vt02fqg21zsq[0],$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
      } else {
        
        $Vrqlni1kqgsu = 1;
        $Vvkqsaecgfirhis->doCallback($Vrqlni1kqgsu,'','',$Vt02fqg21zsq[0],$Vvkqsaecgfirhis->Subject,$Vw2bgil42wyb);
      }
    }


    if (count($Vjhuxhp4slxk) > 0 ) { 
      $Vbksqmhano0s = implode(', ', $Vjhuxhp4slxk);
      throw new phpmailerException($Vvkqsaecgfirhis->Lang('recipients_failed') . $Vbksqmhano0s);
    }
    if(!$Vvkqsaecgfirhis->smtp->Data($Vkwhjduzezf4 . $Vw2bgil42wyb)) {
      throw new phpmailerException($Vvkqsaecgfirhis->Lang('data_not_accepted'), self::STOP_CRITICAL);
    }
    if($Vvkqsaecgfirhis->SMTPKeepAlive == true) {
      $Vvkqsaecgfirhis->smtp->Reset();
    }
    return true;
  }

  
  public function SmtpConnect() {
    if(is_null($Vvkqsaecgfirhis->smtp)) {
      $Vvkqsaecgfirhis->smtp = new SMTP();
    }

    $Vvkqsaecgfirhis->smtp->do_debug = $Vvkqsaecgfirhis->SMTPDebug;
    $Vqyqwceq3eci = explode(';', $Vvkqsaecgfirhis->Host);
    $Vlx0mspyqviq = 0;
    $Vpirdxme5ozt = $Vvkqsaecgfirhis->smtp->Connected();

    
    try {
      while($Vlx0mspyqviq < count($Vqyqwceq3eci) && !$Vpirdxme5ozt) {
        $Vfvmuhdqrutz = array();
        if (preg_match('/^(.+):([0-9]+)$/', $Vqyqwceq3eci[$Vlx0mspyqviq], $Vfvmuhdqrutz)) {
          $Vskypresjwem = $Vfvmuhdqrutz[1];
          $Vjplrupk4awe = $Vfvmuhdqrutz[2];
        } else {
          $Vskypresjwem = $Vqyqwceq3eci[$Vlx0mspyqviq];
          $Vjplrupk4awe = $Vvkqsaecgfirhis->Port;
        }

        $Vvkqsaecgfirls = ($Vvkqsaecgfirhis->SMTPSecure == 'tls');
        $V3fah52rkhgw = ($Vvkqsaecgfirhis->SMTPSecure == 'ssl');

        if ($Vvkqsaecgfirhis->smtp->Connect(($V3fah52rkhgw ? 'ssl://':'').$Vskypresjwem, $Vjplrupk4awe, $Vvkqsaecgfirhis->Timeout)) {

          $V0xuoqhnn3ls = ($Vvkqsaecgfirhis->Helo != '' ? $Vvkqsaecgfirhis->Helo : $Vvkqsaecgfirhis->ServerHostname());
          $Vvkqsaecgfirhis->smtp->Hello($V0xuoqhnn3ls);

          if ($Vvkqsaecgfirls) {
            if (!$Vvkqsaecgfirhis->smtp->StartTLS()) {
              throw new phpmailerException($Vvkqsaecgfirhis->Lang('tls'));
            }

            
            $Vvkqsaecgfirhis->smtp->Hello($V0xuoqhnn3ls);
          }

          $Vpirdxme5ozt = true;
          if ($Vvkqsaecgfirhis->SMTPAuth) {
            if (!$Vvkqsaecgfirhis->smtp->Authenticate($Vvkqsaecgfirhis->Username, $Vvkqsaecgfirhis->Password)) {
              throw new phpmailerException($Vvkqsaecgfirhis->Lang('authenticate'));
            }
          }
        }
        $Vlx0mspyqviq++;
        if (!$Vpirdxme5ozt) {
          throw new phpmailerException($Vvkqsaecgfirhis->Lang('connect_host'));
        }
      }
    } catch (phpmailerException $Vqfltxpxjekk) {
      $Vvkqsaecgfirhis->smtp->Reset();
      throw $Vqfltxpxjekk;
    }
    return true;
  }

  
  public function SmtpClose() {
    if(!is_null($Vvkqsaecgfirhis->smtp)) {
      if($Vvkqsaecgfirhis->smtp->Connected()) {
        $Vvkqsaecgfirhis->smtp->Quit();
        $Vvkqsaecgfirhis->smtp->Close();
      }
    }
  }

  
  function SetLanguage($Vl5swbhgwjyj = 'en', $Vqp2vjcd4gfy = 'language/') {
    
    $Vdsumqyouvr2 = array(
      'provide_address' => 'You must provide at least one recipient email address.',
      'mailer_not_supported' => ' mailer is not supported.',
      'execute' => 'Could not execute: ',
      'instantiate' => 'Could not instantiate mail function.',
      'authenticate' => 'SMTP Error: Could not authenticate.',
      'from_failed' => 'The following From address failed: ',
      'recipients_failed' => 'SMTP Error: The following recipients failed: ',
      'data_not_accepted' => 'SMTP Error: Data not accepted.',
      'connect_host' => 'SMTP Error: Could not connect to SMTP host.',
      'file_access' => 'Could not access file: ',
      'file_open' => 'File Error: Could not open file: ',
      'encoding' => 'Unknown encoding: ',
      'signing' => 'Signing Error: ',
      'smtp_error' => 'SMTP server error: ',
      'empty_message' => 'Message body empty',
      'invalid_address' => 'Invalid address',
      'variable_set' => 'Cannot set or reset variable: '
    );
    
    $V3fvqcsh5wgl = true;
    if ($Vl5swbhgwjyj != 'en') { 
      $V3fvqcsh5wgl = @include $Vqp2vjcd4gfy.'phpmailer.lang-'.$Vl5swbhgwjyj.'.php';
    }
    $Vvkqsaecgfirhis->language = $Vdsumqyouvr2;
    return ($V3fvqcsh5wgl == true); 
  }

  
  public function GetTranslations() {
    return $Vvkqsaecgfirhis->language;
  }

  
  
  

  
  public function AddrAppend($Vvkqsaecgfirype, $Vj4dphco2ku5) {
    $Vj4dphco2ku5_str = $Vvkqsaecgfirype . ': ';
    $Vzbgitt3jgp3es = array();
    foreach ($Vj4dphco2ku5 as $V4dkbhpdu11q) {
      $Vzbgitt3jgp3es[] = $Vvkqsaecgfirhis->AddrFormat($V4dkbhpdu11q);
    }
    $Vj4dphco2ku5_str .= implode(', ', $Vzbgitt3jgp3es);
    $Vj4dphco2ku5_str .= $Vvkqsaecgfirhis->LE;

    return $Vj4dphco2ku5_str;
  }

  
  public function AddrFormat($Vj4dphco2ku5) {
    if (empty($Vj4dphco2ku5[1])) {
      return $Vvkqsaecgfirhis->SecureHeader($Vj4dphco2ku5[0]);
    } else {
      return $Vvkqsaecgfirhis->EncodeHeader($Vvkqsaecgfirhis->SecureHeader($Vj4dphco2ku5[1]), 'phrase') . " <" . $Vvkqsaecgfirhis->SecureHeader($Vj4dphco2ku5[0]) . ">";
    }
  }

  
  public function WrapText($V1ocy1gakxau, $V3fvqcsh5wglength, $Vj0f2n12uwo4 = false) {
    $Vrtkwlo5gdv1 = ($Vj0f2n12uwo4) ? sprintf(" =%s", $Vvkqsaecgfirhis->LE) : $Vvkqsaecgfirhis->LE;
    
    
    $V0qndeik4wqt = (strtolower($Vvkqsaecgfirhis->CharSet) == "utf-8");

    $V1ocy1gakxau = $Vvkqsaecgfirhis->FixEOL($V1ocy1gakxau);
    if (substr($V1ocy1gakxau, -1) == $Vvkqsaecgfirhis->LE) {
      $V1ocy1gakxau = substr($V1ocy1gakxau, 0, -1);
    }

    $V3fvqcsh5wgline = explode($Vvkqsaecgfirhis->LE, $V1ocy1gakxau);
    $V1ocy1gakxau = '';
    for ($V0ixz2v5mxzy=0 ;$V0ixz2v5mxzy < count($V3fvqcsh5wgline); $V0ixz2v5mxzy++) {
      $V3fvqcsh5wgline_part = explode(' ', $V3fvqcsh5wgline[$V0ixz2v5mxzy]);
      $Vgqttqft1lbw = '';
      for ($Vqfltxpxjekk = 0; $Vqfltxpxjekk<count($V3fvqcsh5wgline_part); $Vqfltxpxjekk++) {
        $V0oby33effyr = $V3fvqcsh5wgline_part[$Vqfltxpxjekk];
        if ($Vj0f2n12uwo4 and (strlen($V0oby33effyr) > $V3fvqcsh5wglength)) {
          $Vbra5rgp5xsz = $V3fvqcsh5wglength - strlen($Vgqttqft1lbw) - 1;
          if ($Vqfltxpxjekk != 0) {
            if ($Vbra5rgp5xsz > 20) {
              $V3fvqcsh5wglen = $Vbra5rgp5xsz;
              if ($V0qndeik4wqt) {
                $V3fvqcsh5wglen = $Vvkqsaecgfirhis->UTF8CharBoundary($V0oby33effyr, $V3fvqcsh5wglen);
              } elseif (substr($V0oby33effyr, $V3fvqcsh5wglen - 1, 1) == "=") {
                $V3fvqcsh5wglen--;
              } elseif (substr($V0oby33effyr, $V3fvqcsh5wglen - 2, 1) == "=") {
                $V3fvqcsh5wglen -= 2;
              }
              $V2v5fxvh4bil = substr($V0oby33effyr, 0, $V3fvqcsh5wglen);
              $V0oby33effyr = substr($V0oby33effyr, $V3fvqcsh5wglen);
              $Vgqttqft1lbw .= ' ' . $V2v5fxvh4bil;
              $V1ocy1gakxau .= $Vgqttqft1lbw . sprintf("=%s", $Vvkqsaecgfirhis->LE);
            } else {
              $V1ocy1gakxau .= $Vgqttqft1lbw . $Vrtkwlo5gdv1;
            }
            $Vgqttqft1lbw = '';
          }
          while (strlen($V0oby33effyr) > 0) {
            $V3fvqcsh5wglen = $V3fvqcsh5wglength;
            if ($V0qndeik4wqt) {
              $V3fvqcsh5wglen = $Vvkqsaecgfirhis->UTF8CharBoundary($V0oby33effyr, $V3fvqcsh5wglen);
            } elseif (substr($V0oby33effyr, $V3fvqcsh5wglen - 1, 1) == "=") {
              $V3fvqcsh5wglen--;
            } elseif (substr($V0oby33effyr, $V3fvqcsh5wglen - 2, 1) == "=") {
              $V3fvqcsh5wglen -= 2;
            }
            $V2v5fxvh4bil = substr($V0oby33effyr, 0, $V3fvqcsh5wglen);
            $V0oby33effyr = substr($V0oby33effyr, $V3fvqcsh5wglen);

            if (strlen($V0oby33effyr) > 0) {
              $V1ocy1gakxau .= $V2v5fxvh4bil . sprintf("=%s", $Vvkqsaecgfirhis->LE);
            } else {
              $Vgqttqft1lbw = $V2v5fxvh4bil;
            }
          }
        } else {
          $Vgqttqft1lbw_o = $Vgqttqft1lbw;
          $Vgqttqft1lbw .= ($Vqfltxpxjekk == 0) ? $V0oby33effyr : (' ' . $V0oby33effyr);

          if (strlen($Vgqttqft1lbw) > $V3fvqcsh5wglength and $Vgqttqft1lbw_o != '') {
            $V1ocy1gakxau .= $Vgqttqft1lbw_o . $Vrtkwlo5gdv1;
            $Vgqttqft1lbw = $V0oby33effyr;
          }
        }
      }
      $V1ocy1gakxau .= $Vgqttqft1lbw . $Vvkqsaecgfirhis->LE;
    }

    return $V1ocy1gakxau;
  }

  
  public function UTF8CharBoundary($VqfltxpxjekkncodedText, $Vzbm4k1alj31) {
    $Vae30kylp4kx = false;
    $V3fvqcsh5wglookBack = 3;
    while (!$Vae30kylp4kx) {
      $V3fvqcsh5wglastChunk = substr($VqfltxpxjekkncodedText, $Vzbm4k1alj31 - $V3fvqcsh5wglookBack, $V3fvqcsh5wglookBack);
      $VqfltxpxjekkncodedCharPos = strpos($V3fvqcsh5wglastChunk, "=");
      if ($VqfltxpxjekkncodedCharPos !== false) {
        
        
        $Vhf40vq4bysn = substr($VqfltxpxjekkncodedText, $Vzbm4k1alj31 - $V3fvqcsh5wglookBack + $VqfltxpxjekkncodedCharPos + 1, 2);
        $Vya0vkc4q5ip = hexdec($Vhf40vq4bysn);
        if ($Vya0vkc4q5ip < 128) { 
          
          
          $Vzbm4k1alj31 = ($VqfltxpxjekkncodedCharPos == 0) ? $Vzbm4k1alj31 :
          $Vzbm4k1alj31 - ($V3fvqcsh5wglookBack - $VqfltxpxjekkncodedCharPos);
          $Vae30kylp4kx = true;
        } elseif ($Vya0vkc4q5ip >= 192) { 
          
          $Vzbm4k1alj31 = $Vzbm4k1alj31 - ($V3fvqcsh5wglookBack - $VqfltxpxjekkncodedCharPos);
          $Vae30kylp4kx = true;
        } elseif ($Vya0vkc4q5ip < 192) { 
          $V3fvqcsh5wglookBack += 3;
        }
      } else {
        
        $Vae30kylp4kx = true;
      }
    }
    return $Vzbm4k1alj31;
  }


  
  public function SetWordWrap() {
    if($Vvkqsaecgfirhis->WordWrap < 1) {
      return;
    }

    switch($Vvkqsaecgfirhis->message_type) {
      case 'alt':
      case 'alt_attachments':
        $Vvkqsaecgfirhis->AltBody = $Vvkqsaecgfirhis->WrapText($Vvkqsaecgfirhis->AltBody, $Vvkqsaecgfirhis->WordWrap);
        break;
      default:
        $Vvkqsaecgfirhis->Body = $Vvkqsaecgfirhis->WrapText($Vvkqsaecgfirhis->Body, $Vvkqsaecgfirhis->WordWrap);
        break;
    }
  }

  
  public function CreateHeader() {
    $Vji4j1ie4mwl = '';

    
    $Vsc4tiqq0yeu = md5(uniqid(time()));
    $Vvkqsaecgfirhis->boundary[1] = 'b1_' . $Vsc4tiqq0yeu;
    $Vvkqsaecgfirhis->boundary[2] = 'b2_' . $Vsc4tiqq0yeu;

    $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Date', self::RFCDate());
    if($Vvkqsaecgfirhis->Sender == '') {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Return-Path', trim($Vvkqsaecgfirhis->From));
    } else {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Return-Path', trim($Vvkqsaecgfirhis->Sender));
    }

    
    if($Vvkqsaecgfirhis->Mailer != 'mail') {
      if ($Vvkqsaecgfirhis->SingleTo === true) {
        foreach($Vvkqsaecgfirhis->to as $Vvkqsaecgfir) {
          $Vvkqsaecgfirhis->SingleToArray[] = $Vvkqsaecgfirhis->AddrFormat($Vvkqsaecgfir);
        }
      } else {
        if(count($Vvkqsaecgfirhis->to) > 0) {
          $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->AddrAppend('To', $Vvkqsaecgfirhis->to);
        } elseif (count($Vvkqsaecgfirhis->cc) == 0) {
          $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('To', 'undisclosed-recipients:;');
        }
      }
    }

    $V1zazjar4b1v = array();
    $V1zazjar4b1v[0][0] = trim($Vvkqsaecgfirhis->From);
    $V1zazjar4b1v[0][1] = $Vvkqsaecgfirhis->FromName;
    $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->AddrAppend('From', $V1zazjar4b1v);

    
    if(count($Vvkqsaecgfirhis->cc) > 0) {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->AddrAppend('Cc', $Vvkqsaecgfirhis->cc);
    }

    
    if((($Vvkqsaecgfirhis->Mailer == 'sendmail') || ($Vvkqsaecgfirhis->Mailer == 'mail')) && (count($Vvkqsaecgfirhis->bcc) > 0)) {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->AddrAppend('Bcc', $Vvkqsaecgfirhis->bcc);
    }

    if(count($Vvkqsaecgfirhis->ReplyTo) > 0) {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->AddrAppend('Reply-to', $Vvkqsaecgfirhis->ReplyTo);
    }

    
    if($Vvkqsaecgfirhis->Mailer != 'mail') {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Subject', $Vvkqsaecgfirhis->EncodeHeader($Vvkqsaecgfirhis->SecureHeader($Vvkqsaecgfirhis->Subject)));
    }

    if($Vvkqsaecgfirhis->MessageID != '') {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Message-ID',$Vvkqsaecgfirhis->MessageID);
    } else {
      $Vji4j1ie4mwl .= sprintf("Message-ID: <%s@%s>%s", $Vsc4tiqq0yeu, $Vvkqsaecgfirhis->ServerHostname(), $Vvkqsaecgfirhis->LE);
    }
    $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('X-Priority', $Vvkqsaecgfirhis->Priority);
    $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('X-Mailer', 'PHPMailer '.$Vvkqsaecgfirhis->Version.' (phpmailer.sourceforge.net)');

    if($Vvkqsaecgfirhis->ConfirmReadingTo != '') {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Disposition-Notification-To', '<' . trim($Vvkqsaecgfirhis->ConfirmReadingTo) . '>');
    }

    
    for($Vlx0mspyqviq = 0; $Vlx0mspyqviq < count($Vvkqsaecgfirhis->CustomHeader); $Vlx0mspyqviq++) {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine(trim($Vvkqsaecgfirhis->CustomHeader[$Vlx0mspyqviq][0]), $Vvkqsaecgfirhis->EncodeHeader(trim($Vvkqsaecgfirhis->CustomHeader[$Vlx0mspyqviq][1])));
    }
    if (!$Vvkqsaecgfirhis->sign_key_file) {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('MIME-Version', '1.0');
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->GetMailMIME();
    }

    return $Vji4j1ie4mwl;
  }

  
  public function GetMailMIME() {
    $Vji4j1ie4mwl = '';
    switch($Vvkqsaecgfirhis->message_type) {
      case 'plain':
        $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Content-Transfer-Encoding', $Vvkqsaecgfirhis->Encoding);
        $Vji4j1ie4mwl .= sprintf("Content-Type: %s; charset=\"%s\"", $Vvkqsaecgfirhis->ContentType, $Vvkqsaecgfirhis->CharSet);
        break;
      case 'attachments':
      case 'alt_attachments':
        if($Vvkqsaecgfirhis->InlineImageExists()){
          $Vji4j1ie4mwl .= sprintf("Content-Type: %s;%s\ttype=\"text/html\";%s\tboundary=\"%s\"%s", 'multipart/related', $Vvkqsaecgfirhis->LE, $Vvkqsaecgfirhis->LE, $Vvkqsaecgfirhis->boundary[1], $Vvkqsaecgfirhis->LE);
        } else {
          $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Content-Type', 'multipart/mixed;');
          $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->TextLine("\tboundary=\"" . $Vvkqsaecgfirhis->boundary[1] . '"');
        }
        break;
      case 'alt':
        $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Content-Type', 'multipart/alternative;');
        $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->TextLine("\tboundary=\"" . $Vvkqsaecgfirhis->boundary[1] . '"');
        break;
    }

    if($Vvkqsaecgfirhis->Mailer != 'mail') {
      $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->LE.$Vvkqsaecgfirhis->LE;
    }

    return $Vji4j1ie4mwl;
  }

  
  public function CreateBody() {
    $Vw2bgil42wyb = '';

    if ($Vvkqsaecgfirhis->sign_key_file) {
      $Vw2bgil42wyb .= $Vvkqsaecgfirhis->GetMailMIME();
    }

    $Vvkqsaecgfirhis->SetWordWrap();

    switch($Vvkqsaecgfirhis->message_type) {
      case 'alt':
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->GetBoundary($Vvkqsaecgfirhis->boundary[1], '', 'text/plain', '');
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->EncodeString($Vvkqsaecgfirhis->AltBody, $Vvkqsaecgfirhis->Encoding);
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->LE.$Vvkqsaecgfirhis->LE;
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->GetBoundary($Vvkqsaecgfirhis->boundary[1], '', 'text/html', '');
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->EncodeString($Vvkqsaecgfirhis->Body, $Vvkqsaecgfirhis->Encoding);
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->LE.$Vvkqsaecgfirhis->LE;
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->EndBoundary($Vvkqsaecgfirhis->boundary[1]);
        break;
      case 'plain':
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->EncodeString($Vvkqsaecgfirhis->Body, $Vvkqsaecgfirhis->Encoding);
        break;
      case 'attachments':
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->GetBoundary($Vvkqsaecgfirhis->boundary[1], '', '', '');
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->EncodeString($Vvkqsaecgfirhis->Body, $Vvkqsaecgfirhis->Encoding);
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->LE;
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->AttachAll();
        break;
      case 'alt_attachments':
        $Vw2bgil42wyb .= sprintf("--%s%s", $Vvkqsaecgfirhis->boundary[1], $Vvkqsaecgfirhis->LE);
        $Vw2bgil42wyb .= sprintf("Content-Type: %s;%s" . "\tboundary=\"%s\"%s", 'multipart/alternative', $Vvkqsaecgfirhis->LE, $Vvkqsaecgfirhis->boundary[2], $Vvkqsaecgfirhis->LE.$Vvkqsaecgfirhis->LE);
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->GetBoundary($Vvkqsaecgfirhis->boundary[2], '', 'text/plain', '') . $Vvkqsaecgfirhis->LE; 
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->EncodeString($Vvkqsaecgfirhis->AltBody, $Vvkqsaecgfirhis->Encoding);
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->LE.$Vvkqsaecgfirhis->LE;
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->GetBoundary($Vvkqsaecgfirhis->boundary[2], '', 'text/html', '') . $Vvkqsaecgfirhis->LE; 
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->EncodeString($Vvkqsaecgfirhis->Body, $Vvkqsaecgfirhis->Encoding);
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->LE.$Vvkqsaecgfirhis->LE;
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->EndBoundary($Vvkqsaecgfirhis->boundary[2]);
        $Vw2bgil42wyb .= $Vvkqsaecgfirhis->AttachAll();
        break;
    }

    if ($Vvkqsaecgfirhis->IsError()) {
      $Vw2bgil42wyb = '';
    } elseif ($Vvkqsaecgfirhis->sign_key_file) {
      try {
        $Voheucoc3jxv = tempnam('', 'mail');
        file_put_contents($Voheucoc3jxv, $Vw2bgil42wyb); 
        $Vwftmotmrln4 = tempnam("", "signed");
        if (@openssl_pkcs7_sign($Voheucoc3jxv, $Vwftmotmrln4, "file://".$Vvkqsaecgfirhis->sign_cert_file, array("file://".$Vvkqsaecgfirhis->sign_key_file, $Vvkqsaecgfirhis->sign_key_pass), NULL)) {
          @unlink($Voheucoc3jxv);
          @unlink($Vwftmotmrln4);
          $Vw2bgil42wyb = file_get_contents($Vwftmotmrln4);
        } else {
          @unlink($Voheucoc3jxv);
          @unlink($Vwftmotmrln4);
          throw new phpmailerException($Vvkqsaecgfirhis->Lang("signing").openssl_error_string());
        }
      } catch (phpmailerException $Vqfltxpxjekk) {
        $Vw2bgil42wyb = '';
        if ($Vvkqsaecgfirhis->exceptions) {
          throw $Vqfltxpxjekk;
        }
      }
    }

    return $Vw2bgil42wyb;
  }

  
  private function GetBoundary($Vwffj4z3vsg3, $V00i3yr1oo5e, $Vcwtrqlvncxl, $Vqfltxpxjekkncoding) {
    $Vji4j1ie4mwl = '';
    if($V00i3yr1oo5e == '') {
      $V00i3yr1oo5e = $Vvkqsaecgfirhis->CharSet;
    }
    if($Vcwtrqlvncxl == '') {
      $Vcwtrqlvncxl = $Vvkqsaecgfirhis->ContentType;
    }
    if($Vqfltxpxjekkncoding == '') {
      $Vqfltxpxjekkncoding = $Vvkqsaecgfirhis->Encoding;
    }
    $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->TextLine('--' . $Vwffj4z3vsg3);
    $Vji4j1ie4mwl .= sprintf("Content-Type: %s; charset = \"%s\"", $Vcwtrqlvncxl, $V00i3yr1oo5e);
    $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->LE;
    $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->HeaderLine('Content-Transfer-Encoding', $Vqfltxpxjekkncoding);
    $Vji4j1ie4mwl .= $Vvkqsaecgfirhis->LE;

    return $Vji4j1ie4mwl;
  }

  
  private function EndBoundary($Vwffj4z3vsg3) {
    return $Vvkqsaecgfirhis->LE . '--' . $Vwffj4z3vsg3 . '--' . $Vvkqsaecgfirhis->LE;
  }

  
  private function SetMessageType() {
    if(count($Vvkqsaecgfirhis->attachment) < 1 && strlen($Vvkqsaecgfirhis->AltBody) < 1) {
      $Vvkqsaecgfirhis->message_type = 'plain';
    } else {
      if(count($Vvkqsaecgfirhis->attachment) > 0) {
        $Vvkqsaecgfirhis->message_type = 'attachments';
      }
      if(strlen($Vvkqsaecgfirhis->AltBody) > 0 && count($Vvkqsaecgfirhis->attachment) < 1) {
        $Vvkqsaecgfirhis->message_type = 'alt';
      }
      if(strlen($Vvkqsaecgfirhis->AltBody) > 0 && count($Vvkqsaecgfirhis->attachment) > 0) {
        $Vvkqsaecgfirhis->message_type = 'alt_attachments';
      }
    }
  }

  
  public function HeaderLine($Vreuchxnm2nm, $Vso3o0kfkstxue) {
    return $Vreuchxnm2nm . ': ' . $Vso3o0kfkstxue . $Vvkqsaecgfirhis->LE;
  }

  
  public function TextLine($Vso3o0kfkstxue) {
    return $Vso3o0kfkstxue . $Vvkqsaecgfirhis->LE;
  }

  
  
  

  
  public function AddAttachment($Vt321vu1jwdw, $Vreuchxnm2nm = '', $Vqfltxpxjekkncoding = 'base64', $Vvkqsaecgfirype = 'application/octet-stream') {
    try {
      if ( !@is_file($Vt321vu1jwdw) ) {
        throw new phpmailerException($Vvkqsaecgfirhis->Lang('file_access') . $Vt321vu1jwdw, self::STOP_CONTINUE);
      }
      $Voheucoc3jxvname = basename($Vt321vu1jwdw);
      if ( $Vreuchxnm2nm == '' ) {
        $Vreuchxnm2nm = $Voheucoc3jxvname;
      }

      $Vvkqsaecgfirhis->attachment[] = array(
        0 => $Vt321vu1jwdw,
        1 => $Voheucoc3jxvname,
        2 => $Vreuchxnm2nm,
        3 => $Vqfltxpxjekkncoding,
        4 => $Vvkqsaecgfirype,
        5 => false,  
        6 => 'attachment',
        7 => 0
      );

    } catch (phpmailerException $Vqfltxpxjekk) {
      $Vvkqsaecgfirhis->SetError($Vqfltxpxjekk->getMessage());
      if ($Vvkqsaecgfirhis->exceptions) {
        throw $Vqfltxpxjekk;
      }
      echo $Vqfltxpxjekk->getMessage()."\n";
      if ( $Vqfltxpxjekk->getCode() == self::STOP_CRITICAL ) {
        return false;
      }
    }
    return true;
  }

  
  public function GetAttachments() {
    return $Vvkqsaecgfirhis->attachment;
  }

  
  private function AttachAll() {
    
    $Vcdhhottre4e = array();
    $V13xrcums4ag = array();
    $V0ixz2v5mxzyncl = array();

    
    foreach ($Vvkqsaecgfirhis->attachment as $Vc01mj4w34lt) {
      
      $Vylr3bspzj1z = $Vc01mj4w34lt[5];
      if ($Vylr3bspzj1z) {
        $Vo3pamb05rqg = $Vc01mj4w34lt[0];
      } else {
        $Vt321vu1jwdw = $Vc01mj4w34lt[0];
      }

      if (in_array($Vc01mj4w34lt[0], $V0ixz2v5mxzyncl)) { continue; }
      $Voheucoc3jxvname    = $Vc01mj4w34lt[1];
      $Vreuchxnm2nm        = $Vc01mj4w34lt[2];
      $Vqfltxpxjekkncoding    = $Vc01mj4w34lt[3];
      $Vvkqsaecgfirype        = $Vc01mj4w34lt[4];
      $Vrl5bryr1cyi = $Vc01mj4w34lt[6];
      $Vonrbka2saaq         = $Vc01mj4w34lt[7];
      $V0ixz2v5mxzyncl[]      = $Vc01mj4w34lt[0];
      if ( $Vrl5bryr1cyi == 'inline' && isset($V13xrcums4ag[$Vonrbka2saaq]) ) { continue; }
      $V13xrcums4ag[$Vonrbka2saaq] = true;

      $Vcdhhottre4e[] = sprintf("--%s%s", $Vvkqsaecgfirhis->boundary[1], $Vvkqsaecgfirhis->LE);
      $Vcdhhottre4e[] = sprintf("Content-Type: %s; name=\"%s\"%s", $Vvkqsaecgfirype, $Vvkqsaecgfirhis->EncodeHeader($Vvkqsaecgfirhis->SecureHeader($Vreuchxnm2nm)), $Vvkqsaecgfirhis->LE);
      $Vcdhhottre4e[] = sprintf("Content-Transfer-Encoding: %s%s", $Vqfltxpxjekkncoding, $Vvkqsaecgfirhis->LE);

      if($Vrl5bryr1cyi == 'inline') {
        $Vcdhhottre4e[] = sprintf("Content-ID: <%s>%s", $Vonrbka2saaq, $Vvkqsaecgfirhis->LE);
      }

      $Vcdhhottre4e[] = sprintf("Content-Disposition: %s; filename=\"%s\"%s", $Vrl5bryr1cyi, $Vvkqsaecgfirhis->EncodeHeader($Vvkqsaecgfirhis->SecureHeader($Vreuchxnm2nm)), $Vvkqsaecgfirhis->LE.$Vvkqsaecgfirhis->LE);

      
      if($Vylr3bspzj1z) {
        $Vcdhhottre4e[] = $Vvkqsaecgfirhis->EncodeString($Vo3pamb05rqg, $Vqfltxpxjekkncoding);
        if($Vvkqsaecgfirhis->IsError()) {
          return '';
        }
        $Vcdhhottre4e[] = $Vvkqsaecgfirhis->LE.$Vvkqsaecgfirhis->LE;
      } else {
        $Vcdhhottre4e[] = $Vvkqsaecgfirhis->EncodeFile($Vt321vu1jwdw, $Vqfltxpxjekkncoding);
        if($Vvkqsaecgfirhis->IsError()) {
          return '';
        }
        $Vcdhhottre4e[] = $Vvkqsaecgfirhis->LE.$Vvkqsaecgfirhis->LE;
      }
    }

    $Vcdhhottre4e[] = sprintf("--%s--%s", $Vvkqsaecgfirhis->boundary[1], $Vvkqsaecgfirhis->LE);

    return join('', $Vcdhhottre4e);
  }

  
  private function EncodeFile($Vt321vu1jwdw, $Vqfltxpxjekkncoding = 'base64') {
    try {
      if (!is_readable($Vt321vu1jwdw)) {
        throw new phpmailerException($Vvkqsaecgfirhis->Lang('file_open') . $Vt321vu1jwdw, self::STOP_CONTINUE);
      }
      if (function_exists('get_magic_quotes')) {
        function get_magic_quotes() {
          return false;
        }
      }
      if (PHP_VERSION < 6) {
        $Vmpx2c3ej2ax = get_magic_quotes_runtime();
        set_magic_quotes_runtime(0);
      }
      $Voheucoc3jxv_buffer  = file_get_contents($Vt321vu1jwdw);
      $Voheucoc3jxv_buffer  = $Vvkqsaecgfirhis->EncodeString($Voheucoc3jxv_buffer, $Vqfltxpxjekkncoding);
      if (PHP_VERSION < 6) { set_magic_quotes_runtime($Vmpx2c3ej2ax); }
      return $Voheucoc3jxv_buffer;
    } catch (Exception $Vqfltxpxjekk) {
      $Vvkqsaecgfirhis->SetError($Vqfltxpxjekk->getMessage());
      return '';
    }
  }

  
  public function EncodeString ($Vu5vpgek1hmh, $Vqfltxpxjekkncoding = 'base64') {
    $Vqfltxpxjekkncoded = '';
    switch(strtolower($Vqfltxpxjekkncoding)) {
      case 'base64':
        $Vqfltxpxjekkncoded = chunk_split(base64_encode($Vu5vpgek1hmh), 76, $Vvkqsaecgfirhis->LE);
        break;
      case '7bit':
      case '8bit':
        $Vqfltxpxjekkncoded = $Vvkqsaecgfirhis->FixEOL($Vu5vpgek1hmh);
        
        if (substr($Vqfltxpxjekkncoded, -(strlen($Vvkqsaecgfirhis->LE))) != $Vvkqsaecgfirhis->LE)
          $Vqfltxpxjekkncoded .= $Vvkqsaecgfirhis->LE;
        break;
      case 'binary':
        $Vqfltxpxjekkncoded = $Vu5vpgek1hmh;
        break;
      case 'quoted-printable':
        $Vqfltxpxjekkncoded = $Vvkqsaecgfirhis->EncodeQP($Vu5vpgek1hmh);
        break;
      default:
        $Vvkqsaecgfirhis->SetError($Vvkqsaecgfirhis->Lang('encoding') . $Vqfltxpxjekkncoding);
        break;
    }
    return $Vqfltxpxjekkncoded;
  }

  
  public function EncodeHeader($Vu5vpgek1hmh, $Vhyprn5v4f3y = 'text') {
    $Vmm2pe5l4str = 0;

    switch (strtolower($Vhyprn5v4f3y)) {
      case 'phrase':
        if (!preg_match('/[\200-\377]/', $Vu5vpgek1hmh)) {
          
          $Vqfltxpxjekkncoded = addcslashes($Vu5vpgek1hmh, "\0..\37\177\\\"");
          if (($Vu5vpgek1hmh == $Vqfltxpxjekkncoded) && !preg_match('/[^A-Za-z0-9!#$%&\'*+\/=?^_`{|}~ -]/', $Vu5vpgek1hmh)) {
            return ($Vqfltxpxjekkncoded);
          } else {
            return ("\"$Vqfltxpxjekkncoded\"");
          }
        }
        $Vmm2pe5l4str = preg_match_all('/[^\040\041\043-\133\135-\176]/', $Vu5vpgek1hmh, $Vgvt1cvsrlfv);
        break;
      case 'comment':
        $Vmm2pe5l4str = preg_match_all('/[()"]/', $Vu5vpgek1hmh, $Vgvt1cvsrlfv);
        
      case 'text':
      default:
        $Vmm2pe5l4str += preg_match_all('/[\000-\010\013\014\016-\037\177-\377]/', $Vu5vpgek1hmh, $Vgvt1cvsrlfv);
        break;
    }

    if ($Vmm2pe5l4str == 0) {
      return ($Vu5vpgek1hmh);
    }

    $Vb5ff4xceqnu = 75 - 7 - strlen($Vvkqsaecgfirhis->CharSet);
    
    if (strlen($Vu5vpgek1hmh)/3 < $Vmm2pe5l4str) {
      $Vqfltxpxjekkncoding = 'B';
      if (function_exists('mb_strlen') && $Vvkqsaecgfirhis->HasMultiBytes($Vu5vpgek1hmh)) {
        
        
        $Vqfltxpxjekkncoded = $Vvkqsaecgfirhis->Base64EncodeWrapMB($Vu5vpgek1hmh);
      } else {
        $Vqfltxpxjekkncoded = base64_encode($Vu5vpgek1hmh);
        $Vb5ff4xceqnu -= $Vb5ff4xceqnu % 4;
        $Vqfltxpxjekkncoded = trim(chunk_split($Vqfltxpxjekkncoded, $Vb5ff4xceqnu, "\n"));
      }
    } else {
      $Vqfltxpxjekkncoding = 'Q';
      $Vqfltxpxjekkncoded = $Vvkqsaecgfirhis->EncodeQ($Vu5vpgek1hmh, $Vhyprn5v4f3y);
      $Vqfltxpxjekkncoded = $Vvkqsaecgfirhis->WrapText($Vqfltxpxjekkncoded, $Vb5ff4xceqnu, true);
      $Vqfltxpxjekkncoded = str_replace('='.$Vvkqsaecgfirhis->LE, "\n", trim($Vqfltxpxjekkncoded));
    }

    $Vqfltxpxjekkncoded = preg_replace('/^(.*)$/m', " =?".$Vvkqsaecgfirhis->CharSet."?$Vqfltxpxjekkncoding?\\1?=", $Vqfltxpxjekkncoded);
    $Vqfltxpxjekkncoded = trim(str_replace("\n", $Vvkqsaecgfirhis->LE, $Vqfltxpxjekkncoded));

    return $Vqfltxpxjekkncoded;
  }

  
  public function HasMultiBytes($Vu5vpgek1hmh) {
    if (function_exists('mb_strlen')) {
      return (strlen($Vu5vpgek1hmh) > mb_strlen($Vu5vpgek1hmh, $Vvkqsaecgfirhis->CharSet));
    } else { 
      return false;
    }
  }

  
  public function Base64EncodeWrapMB($Vu5vpgek1hmh) {
    $Vyaw1hu5o3zh = "=?".$Vvkqsaecgfirhis->CharSet."?B?";
    $Vqfltxpxjekknd = "?=";
    $Vqfltxpxjekkncoded = "";

    $Vnpxbyypqfyh = mb_strlen($Vu5vpgek1hmh, $Vvkqsaecgfirhis->CharSet);
    
    $V3fvqcsh5wglength = 75 - strlen($Vyaw1hu5o3zh) - strlen($Vqfltxpxjekknd);
    
    $V4j2ohhe2azc = $Vnpxbyypqfyh / strlen($Vu5vpgek1hmh);
    
    $Veatxxxrhqpk = $V4dkbhpdu11qvgLength = floor($V3fvqcsh5wglength * $V4j2ohhe2azc * .75);

    for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vnpxbyypqfyh; $V0ixz2v5mxzy += $Veatxxxrhqpk) {
      $V3fvqcsh5wglookBack = 0;

      do {
        $Veatxxxrhqpk = $V4dkbhpdu11qvgLength - $V3fvqcsh5wglookBack;
        $Vazpohjmmx04 = mb_substr($Vu5vpgek1hmh, $V0ixz2v5mxzy, $Veatxxxrhqpk, $Vvkqsaecgfirhis->CharSet);
        $Vazpohjmmx04 = base64_encode($Vazpohjmmx04);
        $V3fvqcsh5wglookBack++;
      }
      while (strlen($Vazpohjmmx04) > $V3fvqcsh5wglength);

      $Vqfltxpxjekkncoded .= $Vazpohjmmx04 . $Vvkqsaecgfirhis->LE;
    }

    
    $Vqfltxpxjekkncoded = substr($Vqfltxpxjekkncoded, 0, -strlen($Vvkqsaecgfirhis->LE));
    return $Vqfltxpxjekkncoded;
  }

  
  public function EncodeQPphp( $V0ixz2v5mxzynput = '', $V3fvqcsh5wgline_max = 76, $Vezjwxqxsryr = false) {
    $Vhf40vq4bysn = array('0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F');
    $V3fvqcsh5wglines = preg_split('/(?:\r\n|\r|\n)/', $V0ixz2v5mxzynput);
    $Vqfltxpxjekkol = "\r\n";
    $Vqfltxpxjekkscape = '=';
    $V0yfgnjkoueh = '';
    while( list(, $V3fvqcsh5wgline) = each($V3fvqcsh5wglines) ) {
      $V3fvqcsh5wglinlen = strlen($V3fvqcsh5wgline);
      $Vel2rjhk4yfl = '';
      for($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $V3fvqcsh5wglinlen; $V0ixz2v5mxzy++) {
        $Vdiqkcy1hsm4 = substr( $V3fvqcsh5wgline, $V0ixz2v5mxzy, 1 );
        $Vya0vkc4q5ip = ord( $Vdiqkcy1hsm4 );
        if ( ( $V0ixz2v5mxzy == 0 ) && ( $Vya0vkc4q5ip == 46 ) ) { 
          $Vdiqkcy1hsm4 = '=2E';
        }
        if ( $Vya0vkc4q5ip == 32 ) {
          if ( $V0ixz2v5mxzy == ( $V3fvqcsh5wglinlen - 1 ) ) { 
            $Vdiqkcy1hsm4 = '=20';
          } else if ( $Vezjwxqxsryr ) {
            $Vdiqkcy1hsm4 = '=20';
          }
        } elseif ( ($Vya0vkc4q5ip == 61) || ($Vya0vkc4q5ip < 32 ) || ($Vya0vkc4q5ip > 126) ) { 
          $Vvfvdfwr2qp4 = floor($Vya0vkc4q5ip/16);
          $Vwwadbbrruf5 = floor($Vya0vkc4q5ip%16);
          $Vdiqkcy1hsm4 = $Vqfltxpxjekkscape.$Vhf40vq4bysn[$Vvfvdfwr2qp4].$Vhf40vq4bysn[$Vwwadbbrruf5];
        }
        if ( (strlen($Vel2rjhk4yfl) + strlen($Vdiqkcy1hsm4)) >= $V3fvqcsh5wgline_max ) { 
          $V0yfgnjkoueh .= $Vel2rjhk4yfl.$Vqfltxpxjekkscape.$Vqfltxpxjekkol; 
          $Vel2rjhk4yfl = '';
          
          if ( $Vya0vkc4q5ip == 46 ) {
            $Vdiqkcy1hsm4 = '=2E';
          }
        }
        $Vel2rjhk4yfl .= $Vdiqkcy1hsm4;
      } 
      $V0yfgnjkoueh .= $Vel2rjhk4yfl.$Vqfltxpxjekkol;
    } 
    return $V0yfgnjkoueh;
  }

  
  public function EncodeQP($Vo3pamb05rqg, $V3fvqcsh5wgline_max = 76, $Vezjwxqxsryr = false) {
    if (function_exists('quoted_printable_encode')) { 
      return quoted_printable_encode($Vo3pamb05rqg);
    }
    $V2zsmfpec2xt = stream_get_filters();
    if (!in_array('convert.*', $V2zsmfpec2xt)) { 
      return $Vvkqsaecgfirhis->EncodeQPphp($Vo3pamb05rqg, $V3fvqcsh5wgline_max, $Vezjwxqxsryr); 
    }
    $Vugzuamwr2xd = fopen('php://temp/', 'r+');
    $Vo3pamb05rqg = preg_replace('/\r\n?/', $Vvkqsaecgfirhis->LE, $Vo3pamb05rqg); 
    $Vpzpk4keb40k = array('line-length' => $V3fvqcsh5wgline_max, 'line-break-chars' => $Vvkqsaecgfirhis->LE);
    $V500t5q0ulgs = stream_filter_append($Vugzuamwr2xd, 'convert.quoted-printable-encode', STREAM_FILTER_READ, $Vpzpk4keb40k);
    fputs($Vugzuamwr2xd, $Vo3pamb05rqg);
    rewind($Vugzuamwr2xd);
    $Vpsxy0jjygm1 = stream_get_contents($Vugzuamwr2xd);
    stream_filter_remove($V500t5q0ulgs);
    $Vpsxy0jjygm1 = preg_replace('/^\./m', '=2E', $Vpsxy0jjygm1); 
    fclose($Vugzuamwr2xd);
    return $Vpsxy0jjygm1;
  }

  
  public function EncodeQ ($Vu5vpgek1hmh, $Vhyprn5v4f3y = 'text') {
    
    $Vqfltxpxjekkncoded = preg_replace('/[\r\n]*/', '', $Vu5vpgek1hmh);

    switch (strtolower($Vhyprn5v4f3y)) {
      case 'phrase':
        $Vqfltxpxjekkncoded = preg_replace("/([^A-Za-z0-9!*+\/ -])/e", "'='.sprintf('%02X', ord('\\1'))", $Vqfltxpxjekkncoded);
        break;
      case 'comment':
        $Vqfltxpxjekkncoded = preg_replace("/([\(\)\"])/e", "'='.sprintf('%02X', ord('\\1'))", $Vqfltxpxjekkncoded);
      case 'text':
      default:
        
        
        $Vqfltxpxjekkncoded = preg_replace('/([\000-\011\013\014\016-\037\075\077\137\177-\377])/e',
              "'='.sprintf('%02X', ord('\\1'))", $Vqfltxpxjekkncoded);
        break;
    }

    
    $Vqfltxpxjekkncoded = str_replace(' ', '_', $Vqfltxpxjekkncoded);

    return $Vqfltxpxjekkncoded;
  }

  
  public function AddStringAttachment($Vo3pamb05rqg, $Voheucoc3jxvname, $Vqfltxpxjekkncoding = 'base64', $Vvkqsaecgfirype = 'application/octet-stream') {
    
    $Vvkqsaecgfirhis->attachment[] = array(
      0 => $Vo3pamb05rqg,
      1 => $Voheucoc3jxvname,
      2 => basename($Voheucoc3jxvname),
      3 => $Vqfltxpxjekkncoding,
      4 => $Vvkqsaecgfirype,
      5 => true,  
      6 => 'attachment',
      7 => 0
    );
  }

  
  public function AddEmbeddedImage($Vt321vu1jwdw, $Vonrbka2saaq, $Vreuchxnm2nm = '', $Vqfltxpxjekkncoding = 'base64', $Vvkqsaecgfirype = 'application/octet-stream') {

    if ( !@is_file($Vt321vu1jwdw) ) {
      $Vvkqsaecgfirhis->SetError($Vvkqsaecgfirhis->Lang('file_access') . $Vt321vu1jwdw);
      return false;
    }

    $Voheucoc3jxvname = basename($Vt321vu1jwdw);
    if ( $Vreuchxnm2nm == '' ) {
      $Vreuchxnm2nm = $Voheucoc3jxvname;
    }

    
    $Vvkqsaecgfirhis->attachment[] = array(
      0 => $Vt321vu1jwdw,
      1 => $Voheucoc3jxvname,
      2 => $Vreuchxnm2nm,
      3 => $Vqfltxpxjekkncoding,
      4 => $Vvkqsaecgfirype,
      5 => false,  
      6 => 'inline',
      7 => $Vonrbka2saaq
    );

    return true;
  }

  
  public function InlineImageExists() {
    foreach($Vvkqsaecgfirhis->attachment as $Vc01mj4w34lt) {
      if ($Vc01mj4w34lt[6] == 'inline') {
        return true;
      }
    }
    return false;
  }

  
  
  

  
  public function ClearAddresses() {
    foreach($Vvkqsaecgfirhis->to as $Vaw0srtonwng) {
      unset($Vvkqsaecgfirhis->all_recipients[strtolower($Vaw0srtonwng[0])]);
    }
    $Vvkqsaecgfirhis->to = array();
  }

  
  public function ClearCCs() {
    foreach($Vvkqsaecgfirhis->cc as $Vq4kynn12tv2) {
      unset($Vvkqsaecgfirhis->all_recipients[strtolower($Vq4kynn12tv2[0])]);
    }
    $Vvkqsaecgfirhis->cc = array();
  }

  
  public function ClearBCCs() {
    foreach($Vvkqsaecgfirhis->bcc as $Vt02fqg21zsq) {
      unset($Vvkqsaecgfirhis->all_recipients[strtolower($Vt02fqg21zsq[0])]);
    }
    $Vvkqsaecgfirhis->bcc = array();
  }

  
  public function ClearReplyTos() {
    $Vvkqsaecgfirhis->ReplyTo = array();
  }

  
  public function ClearAllRecipients() {
    $Vvkqsaecgfirhis->to = array();
    $Vvkqsaecgfirhis->cc = array();
    $Vvkqsaecgfirhis->bcc = array();
    $Vvkqsaecgfirhis->all_recipients = array();
  }

  
  public function ClearAttachments() {
    $Vvkqsaecgfirhis->attachment = array();
  }

  
  public function ClearCustomHeaders() {
    $Vvkqsaecgfirhis->CustomHeader = array();
  }

  
  
  

  
  protected function SetError($V4kq14u5yvh5) {
    $Vvkqsaecgfirhis->error_count++;
    if ($Vvkqsaecgfirhis->Mailer == 'smtp' and !is_null($Vvkqsaecgfirhis->smtp)) {
      $V3fvqcsh5wglasterror = $Vvkqsaecgfirhis->smtp->getError();
      if (!empty($V3fvqcsh5wglasterror) and array_key_exists('smtp_msg', $V3fvqcsh5wglasterror)) {
        $V4kq14u5yvh5 .= '<p>' . $Vvkqsaecgfirhis->Lang('smtp_error') . $V3fvqcsh5wglasterror['smtp_msg'] . "</p>\n";
      }
    }
    $Vvkqsaecgfirhis->ErrorInfo = $V4kq14u5yvh5;
  }

  
  public static function RFCDate() {
    $Vvkqsaecgfirz = date('Z');
    $Vvkqsaecgfirzs = ($Vvkqsaecgfirz < 0) ? '-' : '+';
    $Vvkqsaecgfirz = abs($Vvkqsaecgfirz);
    $Vvkqsaecgfirz = (int)($Vvkqsaecgfirz/3600)*100 + ($Vvkqsaecgfirz%3600)/60;
    $Vji4j1ie4mwl = sprintf("%s %s%04d", date('D, j M Y H:i:s'), $Vvkqsaecgfirzs, $Vvkqsaecgfirz);

    return $Vji4j1ie4mwl;
  }

  
  private function ServerHostname() {
    if (!empty($Vvkqsaecgfirhis->Hostname)) {
      $Vji4j1ie4mwl = $Vvkqsaecgfirhis->Hostname;
    } elseif (isset($_SERVER['SERVER_NAME'])) {
      $Vji4j1ie4mwl = $_SERVER['SERVER_NAME'];
    } else {
      $Vji4j1ie4mwl = 'localhost.localdomain';
    }

    return $Vji4j1ie4mwl;
  }

  
  private function Lang($Vbd2mxirzq2d) {
    if(count($Vvkqsaecgfirhis->language) < 1) {
      $Vvkqsaecgfirhis->SetLanguage('en'); 
    }

    if(isset($Vvkqsaecgfirhis->language[$Vbd2mxirzq2d])) {
      return $Vvkqsaecgfirhis->language[$Vbd2mxirzq2d];
    } else {
      return 'Language string failed to load: ' . $Vbd2mxirzq2d;
    }
  }

  
  public function IsError() {
    return ($Vvkqsaecgfirhis->error_count > 0);
  }

  
  private function FixEOL($Vu5vpgek1hmh) {
    $Vu5vpgek1hmh = str_replace("\r\n", "\n", $Vu5vpgek1hmh);
    $Vu5vpgek1hmh = str_replace("\r", "\n", $Vu5vpgek1hmh);
    $Vu5vpgek1hmh = str_replace("\n", $Vvkqsaecgfirhis->LE, $Vu5vpgek1hmh);
    return $Vu5vpgek1hmh;
  }

  
  public function AddCustomHeader($Vdiqkcy1hsm4ustom_header) {
    $Vvkqsaecgfirhis->CustomHeader[] = explode(':', $Vdiqkcy1hsm4ustom_header, 2);
  }

  
  public function MsgHTML($V1ocy1gakxau, $V5vuwfn5kscz = '') {
    preg_match_all("/(src|background)=\"(.*)\"/Ui", $V1ocy1gakxau, $V0ixz2v5mxzymages);
    if(isset($V0ixz2v5mxzymages[2])) {
      foreach($V0ixz2v5mxzymages[2] as $V0ixz2v5mxzy => $Vop22rgf5euu) {
        
        if (!preg_match('#^[A-z]+://#',$Vop22rgf5euu)) {
          $Voheucoc3jxvname = basename($Vop22rgf5euu);
          $Vmcylazx3pdy = dirname($Vop22rgf5euu);
          ($Vmcylazx3pdy == '.')?$Vmcylazx3pdy='':'';
          $Vonrbka2saaq = 'cid:' . md5($Voheucoc3jxvname);
          $Vqfltxpxjekkxt = pathinfo($Voheucoc3jxvname, PATHINFO_EXTENSION);
          $Vcdhhottre4eType  = self::_mime_types($Vqfltxpxjekkxt);
          if ( strlen($V5vuwfn5kscz) > 1 && substr($V5vuwfn5kscz,-1) != '/') { $V5vuwfn5kscz .= '/'; }
          if ( strlen($Vmcylazx3pdy) > 1 && substr($Vmcylazx3pdy,-1) != '/') { $Vmcylazx3pdy .= '/'; }
          if ( $Vvkqsaecgfirhis->AddEmbeddedImage($V5vuwfn5kscz.$Vmcylazx3pdy.$Voheucoc3jxvname, md5($Voheucoc3jxvname), $Voheucoc3jxvname, 'base64',$Vcdhhottre4eType) ) {
            $V1ocy1gakxau = preg_replace("/".$V0ixz2v5mxzymages[1][$V0ixz2v5mxzy]."=\"".preg_quote($Vop22rgf5euu, '/')."\"/Ui", $V0ixz2v5mxzymages[1][$V0ixz2v5mxzy]."=\"".$Vonrbka2saaq."\"", $V1ocy1gakxau);
          }
        }
      }
    }
    $Vvkqsaecgfirhis->IsHTML(true);
    $Vvkqsaecgfirhis->Body = $V1ocy1gakxau;
    $VvkqsaecgfirextMsg = trim(strip_tags(preg_replace('/<(head|title|style|script)[^>]*>.*?<\/\\1>/s','',$V1ocy1gakxau)));
    if (!empty($VvkqsaecgfirextMsg) && empty($Vvkqsaecgfirhis->AltBody)) {
      $Vvkqsaecgfirhis->AltBody = html_entity_decode($VvkqsaecgfirextMsg);
    }
    if (empty($Vvkqsaecgfirhis->AltBody)) {
      $Vvkqsaecgfirhis->AltBody = 'To view this email message, open it in a program that understands HTML!' . "\n\n";
    }
  }

  
  public static function _mime_types($Vqfltxpxjekkxt = '') {
    $Vcdhhottre4es = array(
      'hqx'   =>  'application/mac-binhex40',
      'cpt'   =>  'application/mac-compactpro',
      'doc'   =>  'application/msword',
      'bin'   =>  'application/macbinary',
      'dms'   =>  'application/octet-stream',
      'lha'   =>  'application/octet-stream',
      'lzh'   =>  'application/octet-stream',
      'exe'   =>  'application/octet-stream',
      'class' =>  'application/octet-stream',
      'psd'   =>  'application/octet-stream',
      'so'    =>  'application/octet-stream',
      'sea'   =>  'application/octet-stream',
      'dll'   =>  'application/octet-stream',
      'oda'   =>  'application/oda',
      'pdf'   =>  'application/pdf',
      'ai'    =>  'application/postscript',
      'eps'   =>  'application/postscript',
      'ps'    =>  'application/postscript',
      'smi'   =>  'application/smil',
      'smil'  =>  'application/smil',
      'mif'   =>  'application/vnd.mif',
      'xls'   =>  'application/vnd.ms-excel',
      'ppt'   =>  'application/vnd.ms-powerpoint',
      'wbxml' =>  'application/vnd.wap.wbxml',
      'wmlc'  =>  'application/vnd.wap.wmlc',
      'dcr'   =>  'application/x-director',
      'dir'   =>  'application/x-director',
      'dxr'   =>  'application/x-director',
      'dvi'   =>  'application/x-dvi',
      'gtar'  =>  'application/x-gtar',
      'php'   =>  'application/x-httpd-php',
      'php4'  =>  'application/x-httpd-php',
      'php3'  =>  'application/x-httpd-php',
      'phtml' =>  'application/x-httpd-php',
      'phps'  =>  'application/x-httpd-php-source',
      'js'    =>  'application/x-javascript',
      'swf'   =>  'application/x-shockwave-flash',
      'sit'   =>  'application/x-stuffit',
      'tar'   =>  'application/x-tar',
      'tgz'   =>  'application/x-tar',
      'xhtml' =>  'application/xhtml+xml',
      'xht'   =>  'application/xhtml+xml',
      'zip'   =>  'application/zip',
      'mid'   =>  'audio/midi',
      'midi'  =>  'audio/midi',
      'mpga'  =>  'audio/mpeg',
      'mp2'   =>  'audio/mpeg',
      'mp3'   =>  'audio/mpeg',
      'aif'   =>  'audio/x-aiff',
      'aiff'  =>  'audio/x-aiff',
      'aifc'  =>  'audio/x-aiff',
      'ram'   =>  'audio/x-pn-realaudio',
      'rm'    =>  'audio/x-pn-realaudio',
      'rpm'   =>  'audio/x-pn-realaudio-plugin',
      'ra'    =>  'audio/x-realaudio',
      'rv'    =>  'video/vnd.rn-realvideo',
      'wav'   =>  'audio/x-wav',
      'bmp'   =>  'image/bmp',
      'gif'   =>  'image/gif',
      'jpeg'  =>  'image/jpeg',
      'jpg'   =>  'image/jpeg',
      'jpe'   =>  'image/jpeg',
      'png'   =>  'image/png',
      'tiff'  =>  'image/tiff',
      'tif'   =>  'image/tiff',
      'css'   =>  'text/css',
      'html'  =>  'text/html',
      'htm'   =>  'text/html',
      'shtml' =>  'text/html',
      'txt'   =>  'text/plain',
      'text'  =>  'text/plain',
      'log'   =>  'text/plain',
      'rtx'   =>  'text/richtext',
      'rtf'   =>  'text/rtf',
      'xml'   =>  'text/xml',
      'xsl'   =>  'text/xml',
      'mpeg'  =>  'video/mpeg',
      'mpg'   =>  'video/mpeg',
      'mpe'   =>  'video/mpeg',
      'qt'    =>  'video/quicktime',
      'mov'   =>  'video/quicktime',
      'avi'   =>  'video/x-msvideo',
      'movie' =>  'video/x-sgi-movie',
      'doc'   =>  'application/msword',
      'word'  =>  'application/msword',
      'xl'    =>  'application/excel',
      'eml'   =>  'message/rfc822'
    );
    return (!isset($Vcdhhottre4es[strtolower($Vqfltxpxjekkxt)])) ? 'application/octet-stream' : $Vcdhhottre4es[strtolower($Vqfltxpxjekkxt)];
  }

  
  public function set($Vreuchxnm2nm, $Vso3o0kfkstxue = '') {
    try {
      if (isset($Vvkqsaecgfirhis->$Vreuchxnm2nm) ) {
        $Vvkqsaecgfirhis->$Vreuchxnm2nm = $Vso3o0kfkstxue;
      } else {
        throw new phpmailerException($Vvkqsaecgfirhis->Lang('variable_set') . $Vreuchxnm2nm, self::STOP_CRITICAL);
      }
    } catch (Exception $Vqfltxpxjekk) {
      $Vvkqsaecgfirhis->SetError($Vqfltxpxjekk->getMessage());
      if ($Vqfltxpxjekk->getCode() == self::STOP_CRITICAL) {
        return false;
      }
    }
    return true;
  }

  
  public function SecureHeader($Vu5vpgek1hmh) {
    $Vu5vpgek1hmh = str_replace("\r", '', $Vu5vpgek1hmh);
    $Vu5vpgek1hmh = str_replace("\n", '', $Vu5vpgek1hmh);
    return trim($Vu5vpgek1hmh);
  }

  
  public function Sign($Vdiqkcy1hsm4ert_filename, $Vbd2mxirzq2d_filename, $Vbd2mxirzq2d_pass) {
    $Vvkqsaecgfirhis->sign_cert_file = $Vdiqkcy1hsm4ert_filename;
    $Vvkqsaecgfirhis->sign_key_file = $Vbd2mxirzq2d_filename;
    $Vvkqsaecgfirhis->sign_key_pass = $Vbd2mxirzq2d_pass;
  }

  
  public function DKIM_QP($Vvkqsaecgfirxt) {
    $Vvkqsaecgfirmp="";
    $V3fvqcsh5wgline="";
    for ($V0ixz2v5mxzy=0;$V0ixz2v5mxzy<strlen($Vvkqsaecgfirxt);$V0ixz2v5mxzy++) {
      $V4ktwlfiijzf=ord($Vvkqsaecgfirxt[$V0ixz2v5mxzy]);
      if ( ((0x21 <= $V4ktwlfiijzf) && ($V4ktwlfiijzf <= 0x3A)) || $V4ktwlfiijzf == 0x3C || ((0x3E <= $V4ktwlfiijzf) && ($V4ktwlfiijzf <= 0x7E)) ) {
        $V3fvqcsh5wgline.=$Vvkqsaecgfirxt[$V0ixz2v5mxzy];
      } else {
        $V3fvqcsh5wgline.="=".sprintf("%02X",$V4ktwlfiijzf);
      }
    }
    return $V3fvqcsh5wgline;
  }

  
  public function DKIM_Sign($V500t5q0ulgs) {
    $Vbohfpamcjrv = file_get_contents($Vvkqsaecgfirhis->DKIM_private);
    if ($Vvkqsaecgfirhis->DKIM_passphrase!='') {
      $Vn5yx2kxdx42 = openssl_pkey_get_private($Vbohfpamcjrv,$Vvkqsaecgfirhis->DKIM_passphrase);
    } else {
      $Vn5yx2kxdx42 = $Vbohfpamcjrv;
    }
    if (openssl_sign($V500t5q0ulgs, $V500t5q0ulgsignature, $Vn5yx2kxdx42)) {
      return base64_encode($V500t5q0ulgsignature);
    }
  }

  
  public function DKIM_HeaderC($V500t5q0ulgs) {
    $V500t5q0ulgs=preg_replace("/\r\n\s+/"," ",$V500t5q0ulgs);
    $V3fvqcsh5wglines=explode("\r\n",$V500t5q0ulgs);
    foreach ($V3fvqcsh5wglines as $Vbd2mxirzq2d=>$V3fvqcsh5wgline) {
      list($Vipqx32bpinm,$Vso3o0kfkstxue)=explode(":",$V3fvqcsh5wgline,2);
      $Vipqx32bpinm=strtolower($Vipqx32bpinm);
      $Vso3o0kfkstxue=preg_replace("/\s+/"," ",$Vso3o0kfkstxue) ; 
      $V3fvqcsh5wglines[$Vbd2mxirzq2d]=$Vipqx32bpinm.":".trim($Vso3o0kfkstxue) ; 
    }
    $V500t5q0ulgs=implode("\r\n",$V3fvqcsh5wglines);
    return $V500t5q0ulgs;
  }

  
  public function DKIM_BodyC($Vw2bgil42wyb) {
    if ($Vw2bgil42wyb == '') return "\r\n";
    
    $Vw2bgil42wyb=str_replace("\r\n","\n",$Vw2bgil42wyb);
    $Vw2bgil42wyb=str_replace("\n","\r\n",$Vw2bgil42wyb);
    
    while (substr($Vw2bgil42wyb,strlen($Vw2bgil42wyb)-4,4) == "\r\n\r\n") {
      $Vw2bgil42wyb=substr($Vw2bgil42wyb,0,strlen($Vw2bgil42wyb)-2);
    }
    return $Vw2bgil42wyb;
  }

  
  public function DKIM_Add($Vkwhjduzezf4s_line,$V500t5q0ulgsubject,$Vw2bgil42wyb) {
    $Vyxjx1cl5quf    = 'rsa-sha1'; 
    $Vckzhkypcula = 'relaxed/simple'; 
    $Vv1uc45gylvd            = 'dns/txt'; 
    $Vzv3qwxwktis             = time() ; 
    $V500t5q0ulgsubject_header       = "Subject: $V500t5q0ulgsubject";
    $Vkwhjduzezf4s              = explode("\r\n",$Vkwhjduzezf4s_line);
    foreach($Vkwhjduzezf4s as $Vkwhjduzezf4) {
      if (strpos($Vkwhjduzezf4,'From:') === 0) {
        $V1zazjar4b1v_header=$Vkwhjduzezf4;
      } elseif (strpos($Vkwhjduzezf4,'To:') === 0) {
        $Vaw0srtonwng_header=$Vkwhjduzezf4;
      }
    }
    $V1zazjar4b1v     = str_replace('|','=7C',$Vvkqsaecgfirhis->DKIM_QP($V1zazjar4b1v_header));
    $Vaw0srtonwng       = str_replace('|','=7C',$Vvkqsaecgfirhis->DKIM_QP($Vaw0srtonwng_header));
    $V500t5q0ulgsubject  = str_replace('|','=7C',$Vvkqsaecgfirhis->DKIM_QP($V500t5q0ulgsubject_header)) ; 
    $Vw2bgil42wyb     = $Vvkqsaecgfirhis->DKIM_BodyC($Vw2bgil42wyb);
    $Valiprkom4he  = strlen($Vw2bgil42wyb) ; 
    $Vl5mnabcsaoy  = base64_encode(pack("H*", sha1($Vw2bgil42wyb))) ; 
    $V0ixz2v5mxzydent    = ($Vvkqsaecgfirhis->DKIM_identity == '')? '' : " i=" . $Vvkqsaecgfirhis->DKIM_identity . ";";
    $Vzocmgtfnrfz = "DKIM-Signature: v=1; a=" . $Vyxjx1cl5quf . "; q=" . $Vv1uc45gylvd . "; l=" . $Valiprkom4he . "; s=" . $Vvkqsaecgfirhis->DKIM_selector . ";\r\n".
                "\tt=" . $Vzv3qwxwktis . "; c=" . $Vckzhkypcula . ";\r\n".
                "\th=From:To:Subject;\r\n".
                "\td=" . $Vvkqsaecgfirhis->DKIM_domain . ";" . $V0ixz2v5mxzydent . "\r\n".
                "\tz=$V1zazjar4b1v\r\n".
                "\t|$Vaw0srtonwng\r\n".
                "\t|$V500t5q0ulgsubject;\r\n".
                "\tbh=" . $Vl5mnabcsaoy . ";\r\n".
                "\tb=";
    $Vaw0srtonwngSign   = $Vvkqsaecgfirhis->DKIM_HeaderC($V1zazjar4b1v_header . "\r\n" . $Vaw0srtonwng_header . "\r\n" . $V500t5q0ulgsubject_header . "\r\n" . $Vzocmgtfnrfz);
    $Vwftmotmrln4   = $Vvkqsaecgfirhis->DKIM_Sign($Vaw0srtonwngSign);
    return "X-PHPMAILER-DKIM: phpmailer.worxware.com\r\n".$Vzocmgtfnrfz.$Vwftmotmrln4."\r\n";
  }

  protected function doCallback($Vrqlni1kqgsu,$Vaw0srtonwng,$Vq4kynn12tv2,$Vt02fqg21zsq,$V500t5q0ulgsubject,$Vw2bgil42wyb) {
    if (!empty($Vvkqsaecgfirhis->action_function) && function_exists($Vvkqsaecgfirhis->action_function)) {
      $Vpzpk4keb40k = array($Vrqlni1kqgsu,$Vaw0srtonwng,$Vq4kynn12tv2,$Vt02fqg21zsq,$V500t5q0ulgsubject,$Vw2bgil42wyb);
      call_user_func_array($Vvkqsaecgfirhis->action_function,$Vpzpk4keb40k);
    }
  }
}

class phpmailerException extends Exception {
  public function errorMessage() {
    $VqfltxpxjekkrrorMsg = '<strong>' . $Vvkqsaecgfirhis->getMessage() . "</strong><br />\n";
    return $VqfltxpxjekkrrorMsg;
  }
}
?>
