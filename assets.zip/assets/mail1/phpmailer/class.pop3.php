<?php






class POP3 {
  
  public $Vntcz4y21gro = 110;

  
  public $Vwyjo0ggrdtx = 30;

  
  public $V3kfetfnsqwf = "\r\n";

  
  public $V0ecyjuspiub = 2;

  
  public $Vskypresjwem;

  
  public $Vjplrupk4awe;

  
  public $Vjrv00kwie5w;

  
  public $Vd1oxshydqwu;

  
  public $Viavqzdwsg1u;

  
  
  

  private $Va2qgu1wbj0p;
  private $Vg0upg5hb255;
  private $Vropiebcst33;     

  
  public function __construct() {
    $this->pop_conn  = 0;
    $this->connected = false;
    $this->error     = null;
  }

  
  public function Authorise ($Vskypresjwem, $Vjplrupk4awe = false, $Vjrv00kwie5w = false, $Vd1oxshydqwu, $Viavqzdwsg1u, $Vkvfwzzpugka = 0) {
    $this->host = $Vskypresjwem;

    
    if ($Vjplrupk4awe == false) {
      $this->port = $this->POP3_PORT;
    } else {
      $this->port = $Vjplrupk4awe;
    }

    
    if ($Vjrv00kwie5w == false) {
      $this->tval = $this->POP3_TIMEOUT;
    } else {
      $this->tval = $Vjrv00kwie5w;
    }

    $this->do_debug = $Vkvfwzzpugka;
    $this->username = $Vd1oxshydqwu;
    $this->password = $Viavqzdwsg1u;

    
    $this->error = null;

    
    $Vji4j1ie4mwl = $this->Connect($this->host, $this->port, $this->tval);

    if ($Vji4j1ie4mwl) {
      $Vsoopxav3jux = $this->Login($this->username, $this->password);

      if ($Vsoopxav3jux) {
        $this->Disconnect();

        return true;
      }

    }

    
    $this->Disconnect();

    return false;
  }

  
  public function Connect ($Vskypresjwem, $Vjplrupk4awe = false, $Vjrv00kwie5w = 30) {
    
    if ($this->connected) {
      return true;
    }

    

    set_error_handler(array(&$this, 'catchWarning'));

    
    $this->pop_conn = fsockopen($Vskypresjwem,    
                  $Vjplrupk4awe,    
                  $Vrctdhiixpl5,   
                  $Vpkkloai3uad,  
                  $Vjrv00kwie5w);   

    
    restore_error_handler();

    
    if ($this->error && $this->do_debug >= 1) {
      $this->displayErrors();
    }

    
    if ($this->pop_conn == false) {
      
      $this->error = array(
        'error' => "Failed to connect to server $Vskypresjwem on port $Vjplrupk4awe",
        'errno' => $Vrctdhiixpl5,
        'errstr' => $Vpkkloai3uad
      );

      if ($this->do_debug >= 1) {
        $this->displayErrors();
      }

      return false;
    }

    

    
    if (version_compare(phpversion(), '5.0.0', 'ge')) {
      stream_set_timeout($this->pop_conn, $Vjrv00kwie5w, 0);
    } else {
      
      if (substr(PHP_OS, 0, 3) !== 'WIN') {
        socket_set_timeout($this->pop_conn, $Vjrv00kwie5w, 0);
      }
    }

    
    $Vqkhpzv01kk2 = $this->getResponse();

    
    if ($this->checkResponse($Vqkhpzv01kk2)) {
    
    $this->connected = true;
      return true;
    }

  }

  
  public function Login ($Vd1oxshydqwu = '', $Viavqzdwsg1u = '') {
    if ($this->connected == false) {
      $this->error = 'Not connected to POP3 server';

      if ($this->do_debug >= 1) {
        $this->displayErrors();
      }
    }

    if (empty($Vd1oxshydqwu)) {
      $Vd1oxshydqwu = $this->username;
    }

    if (empty($Viavqzdwsg1u)) {
      $Viavqzdwsg1u = $this->password;
    }

    $Vqlm5nxvadli = "USER $Vd1oxshydqwu" . $this->CRLF;
    $V2j0toc1gmis = "PASS $Viavqzdwsg1u" . $this->CRLF;

    
    $this->sendString($Vqlm5nxvadli);
    $Vqkhpzv01kk2 = $this->getResponse();

    if ($this->checkResponse($Vqkhpzv01kk2)) {
      
      $this->sendString($V2j0toc1gmis);
      $Vqkhpzv01kk2 = $this->getResponse();

      if ($this->checkResponse($Vqkhpzv01kk2)) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  
  public function Disconnect () {
    $this->sendString('QUIT');

    fclose($this->pop_conn);
  }

  
  
  

  
  private function getResponse ($Vkgj34o34uaw = 128) {
    $Vqkhpzv01kk2 = fgets($this->pop_conn, $Vkgj34o34uaw);

    return $Vqkhpzv01kk2;
  }

  
  private function sendString ($Vo3pamb05rqg) {
    $Vt5jdtyahgbw = fwrite($this->pop_conn, $Vo3pamb05rqg, strlen($Vo3pamb05rqg));

    return $Vt5jdtyahgbw;
  }

  
  private function checkResponse ($Vo3pamb05rqg) {
    if (substr($Vo3pamb05rqg, 0, 3) !== '+OK') {
      $this->error = array(
        'error' => "Server reported an error: $Vo3pamb05rqg",
        'errno' => 0,
        'errstr' => ''
      );

      if ($this->do_debug >= 1) {
        $this->displayErrors();
      }

      return false;
    } else {
      return true;
    }

  }

  
  private function displayErrors () {
    echo '<pre>';

    foreach ($this->error as $Vaoiccglnwtm) {
      print_r($Vaoiccglnwtm);
    }

    echo '</pre>';
  }

  
  private function catchWarning ($Vrctdhiixpl5, $Vpkkloai3uad, $Vzj3cy533ndl, $Vtqat0kvwffg) {
    $this->error[] = array(
      'error' => "Connecting to the POP3 server raised a PHP warning: ",
      'errno' => $Vrctdhiixpl5,
      'errstr' => $Vpkkloai3uad
    );
  }

  
}
?>
