<?php


$Vdsumqyouvr2['authenticate'] = 'SMTP 错误：身份验证失败。';
$Vdsumqyouvr2['connect_host'] = 'SMTP 错误: 不能连接SMTP主机。';
$Vdsumqyouvr2['data_not_accepted'] = 'SMTP 错误: 数据不可接受。';

$Vdsumqyouvr2['encoding'] = '未知编码：';
$Vdsumqyouvr2['execute'] = '不能执行: ';
$Vdsumqyouvr2['file_access'] = '不能访问文件：';
$Vdsumqyouvr2['file_open'] = '文件错误：不能打开文件：';
$Vdsumqyouvr2['from_failed'] = '下面的发送地址邮件发送失败了： ';
$Vdsumqyouvr2['instantiate'] = '不能实现mail方法。';

$Vdsumqyouvr2['mailer_not_supported'] = ' 您所选择的发送邮件的方法并不支持。';
$Vdsumqyouvr2['provide_address'] = '您必须提供至少一个 收信人的email地址。';
$Vdsumqyouvr2['recipients_failed'] = 'SMTP 错误： 下面的 收件人失败了： ';




?>
