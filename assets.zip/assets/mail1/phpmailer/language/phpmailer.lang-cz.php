<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP Error: Chyba autentikace.';
$Vdsumqyouvr2['connect_host']         = 'SMTP Error: Nelze navázat spojení se SMTP serverem.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP Error: Data nebyla pøijata';

$Vdsumqyouvr2['encoding']             = 'Neznámé kódování: ';
$Vdsumqyouvr2['execute']              = 'Nelze provést: ';
$Vdsumqyouvr2['file_access']          = 'Soubor nenalezen: ';
$Vdsumqyouvr2['file_open']            = 'File Error: Nelze otevøít soubor pro ètení: ';
$Vdsumqyouvr2['from_failed']          = 'Následující adresa From je nesprávná: ';
$Vdsumqyouvr2['instantiate']          = 'Nelze vytvoøit instanci emailové funkce.';

$Vdsumqyouvr2['mailer_not_supported'] = ' mailový klient není podporován.';
$Vdsumqyouvr2['provide_address']      = 'Musíte zadat alespoò jednu emailovou adresu pøíjemce.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP Error: Adresy pøíjemcù nejsou správné ';




?>
