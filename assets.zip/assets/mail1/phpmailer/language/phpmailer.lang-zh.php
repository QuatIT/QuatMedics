<?php


$Vdsumqyouvr2['authenticate'] = 'SMTP 錯誤：登錄失敗。';
$Vdsumqyouvr2['connect_host'] = 'SMTP 錯誤：無法連接到 SMTP 主機。';
$Vdsumqyouvr2['data_not_accepted'] = 'SMTP 錯誤：數據不被接受。';

$Vdsumqyouvr2['encoding'] = '未知編碼: ';
$Vdsumqyouvr2['file_access'] = '無法訪問文件：';
$Vdsumqyouvr2['file_open'] = '文件錯誤：無法打開文件：';
$Vdsumqyouvr2['from_failed'] = '發送地址錯誤：';
$Vdsumqyouvr2['execute'] = '無法執行：';
$Vdsumqyouvr2['instantiate'] = '未知函數調用。';

$Vdsumqyouvr2['provide_address'] = '必須提供至少一個收件人地址。';
$Vdsumqyouvr2['mailer_not_supported'] = '發信客戶端不被支持。';
$Vdsumqyouvr2['recipients_failed'] = 'SMTP 錯誤：收件人地址錯誤：';




?>
