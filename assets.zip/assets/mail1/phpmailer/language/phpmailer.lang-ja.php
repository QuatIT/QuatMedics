<?php


$Vdsumqyouvr2['authenticate'] = 'SMTPエラー: 認証できませんでした。';
$Vdsumqyouvr2['connect_host'] = 'SMTPエラー: SMTPホストに接続できませんでした。';
$Vdsumqyouvr2['data_not_accepted'] = 'SMTPエラー: データが受け付けられませんでした。';

$Vdsumqyouvr2['encoding'] = '不明なエンコーディング: ';
$Vdsumqyouvr2['execute'] = '実行できませんでした: ';
$Vdsumqyouvr2['file_access'] = 'ファイルにアクセスできません: ';
$Vdsumqyouvr2['file_open'] = 'ファイルエラー: ファイルを開けません: ';
$Vdsumqyouvr2['from_failed'] = '次のFromアドレスに間違いがあります: ';
$Vdsumqyouvr2['instantiate'] = 'メール関数が正常に動作しませんでした。';

$Vdsumqyouvr2['provide_address'] = '少なくとも1つメールアドレスを 指定する必要があります。';
$Vdsumqyouvr2['mailer_not_supported'] = ' メーラーがサポートされていません。';
$Vdsumqyouvr2['recipients_failed'] = 'SMTPエラー: 次の受信者アドレスに 間違いがあります: ';




?>
