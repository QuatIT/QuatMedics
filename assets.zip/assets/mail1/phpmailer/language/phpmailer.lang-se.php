<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP fel: Kunde inte autentisera.';
$Vdsumqyouvr2['connect_host']         = 'SMTP fel: Kunde inte ansluta till SMTP-server.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP fel: Data accepterades inte.';

$Vdsumqyouvr2['encoding']             = 'Okänt encode-format: ';
$Vdsumqyouvr2['execute']              = 'Kunde inte köra: ';
$Vdsumqyouvr2['file_access']          = 'Ingen åtkomst till fil: ';
$Vdsumqyouvr2['file_open']            = 'Fil fel: Kunde inte öppna fil: ';
$Vdsumqyouvr2['from_failed']          = 'Följande avsändaradress är felaktig: ';
$Vdsumqyouvr2['instantiate']          = 'Kunde inte initiera e-postfunktion.';

$Vdsumqyouvr2['provide_address']      = 'Du måste ange minst en mottagares e-postadress.';
$Vdsumqyouvr2['mailer_not_supported'] = ' mailer stöds inte.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP fel: Följande mottagare är felaktig: ';




?>
