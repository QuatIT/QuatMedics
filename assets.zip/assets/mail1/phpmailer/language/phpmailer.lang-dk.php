<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP fejl: Kunne ikke logge på.';
$Vdsumqyouvr2['connect_host']         = 'SMTP fejl: Kunne ikke tilslutte SMTP serveren.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP fejl: Data kunne ikke accepteres.';

$Vdsumqyouvr2['encoding']             = 'Ukendt encode-format: ';
$Vdsumqyouvr2['execute']              = 'Kunne ikke køre: ';
$Vdsumqyouvr2['file_access']          = 'Ingen adgang til fil: ';
$Vdsumqyouvr2['file_open']            = 'Fil fejl: Kunne ikke åbne filen: ';
$Vdsumqyouvr2['from_failed']          = 'Følgende afsenderadresse er forkert: ';
$Vdsumqyouvr2['instantiate']          = 'Kunne ikke initialisere email funktionen.';

$Vdsumqyouvr2['mailer_not_supported'] = ' mailer understøttes ikke.';
$Vdsumqyouvr2['provide_address']      = 'Du skal indtaste mindst en modtagers emailadresse.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP fejl: Følgende modtagere er forkerte: ';




?>
