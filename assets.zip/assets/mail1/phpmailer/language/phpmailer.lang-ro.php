<?php


$Vdsumqyouvr2['authenticate']         = 'Eroare SMTP: Nu a functionat autentificarea.';
$Vdsumqyouvr2['connect_host']         = 'Eroare SMTP: Nu m-am putut conecta la adresa SMTP.';
$Vdsumqyouvr2['data_not_accepted']    = 'Eroare SMTP: Continutul mailului nu a fost acceptat.';

$Vdsumqyouvr2['encoding']             = 'Encodare necunoscuta: ';
$Vdsumqyouvr2['execute']              = 'Nu pot executa:  ';
$Vdsumqyouvr2['file_access']          = 'Nu pot accesa fisierul: ';
$Vdsumqyouvr2['file_open']            = 'Eroare de fisier: Nu pot deschide fisierul: ';
$Vdsumqyouvr2['from_failed']          = 'Urmatoarele adrese From au dat eroare: ';
$Vdsumqyouvr2['instantiate']          = 'Nu am putut instantia functia mail.';

$Vdsumqyouvr2['mailer_not_supported'] = ' mailer nu este suportat.';
$Vdsumqyouvr2['provide_address']      = 'Trebuie sa adaugati cel putin un recipient (adresa de mail).';
$Vdsumqyouvr2['recipients_failed']    = 'Eroare SMTP: Urmatoarele adrese de mail au dat eroare: ';




?>
