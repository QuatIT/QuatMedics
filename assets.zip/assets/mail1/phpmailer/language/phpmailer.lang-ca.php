<?php


$Vdsumqyouvr2['authenticate']         = 'Error SMTP: No s\'hapogut autenticar.';
$Vdsumqyouvr2['connect_host']         = 'Error SMTP: No es pot connectar al servidor SMTP.';
$Vdsumqyouvr2['data_not_accepted']    = 'Error SMTP: Dades no acceptades.';

$Vdsumqyouvr2['encoding']             = 'Codificació desconeguda: ';
$Vdsumqyouvr2['execute']              = 'No es pot executar: ';
$Vdsumqyouvr2['file_access']          = 'No es pot accedir a l\'arxiu: ';
$Vdsumqyouvr2['file_open']            = 'Error d\'Arxiu: No es pot obrir l\'arxiu: ';
$Vdsumqyouvr2['from_failed']          = 'La(s) següent(s) adreces de remitent han fallat: ';
$Vdsumqyouvr2['instantiate']          = 'No s\'ha pogut crear una instància de la funció Mail.';

$Vdsumqyouvr2['mailer_not_supported'] = ' mailer no està suportat';
$Vdsumqyouvr2['provide_address']      = 'S\'ha de proveir almenys una adreça d\'email com a destinatari.';
$Vdsumqyouvr2['recipients_failed']    = 'Error SMTP: Els següents destinataris han fallat: ';




?>
