<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP Fehler: Authentifizierung fehlgeschlagen.';
$Vdsumqyouvr2['connect_host']         = 'SMTP Fehler: Konnte keine Verbindung zum SMTP-Host herstellen.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP Fehler: Daten werden nicht akzeptiert.';
$Vdsumqyouvr2['empty_message']        = 'E-Mail Inhalt ist leer.';
$Vdsumqyouvr2['encoding']             = 'Unbekanntes Encoding-Format: ';
$Vdsumqyouvr2['execute']              = 'Konnte folgenden Befehl nicht ausführen: ';
$Vdsumqyouvr2['file_access']          = 'Zugriff auf folgende Datei fehlgeschlagen: ';
$Vdsumqyouvr2['file_open']            = 'Datei Fehler: konnte folgende Datei nicht öffnen: ';
$Vdsumqyouvr2['from_failed']          = 'Die folgende Absenderadresse ist nicht korrekt: ';
$Vdsumqyouvr2['instantiate']          = 'Mail Funktion konnte nicht initialisiert werden.';
$Vdsumqyouvr2['invalid_email']        = 'E-Mail wird nicht gesendet, die Adresse ist ungültig.';
$Vdsumqyouvr2['mailer_not_supported'] = ' mailer wird nicht unterstützt.';
$Vdsumqyouvr2['provide_address']      = 'Bitte geben Sie mindestens eine Empfänger E-Mailadresse an.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP Fehler: Die folgenden Empfänger sind nicht korrekt: ';
$Vdsumqyouvr2['signing']              = 'Fehler beim Signieren: ';
$Vdsumqyouvr2['smtp_connect_failed']  = 'Verbindung zu SMTP Server fehlgeschlagen.';
$Vdsumqyouvr2['smtp_error']           = 'Fehler vom SMTP Server: ';
$Vdsumqyouvr2['variable_set']         = 'Kann Variable nicht setzen oder zurücksetzen: ';
?>
