<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP Feil: Kunne ikke authentisere.';
$Vdsumqyouvr2['connect_host']         = 'SMTP Feil: Kunne ikke koble til SMTP host.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP Feil: Data ble ikke akseptert.';

$Vdsumqyouvr2['encoding']             = 'Ukjent encoding: ';
$Vdsumqyouvr2['execute']              = 'Kunne ikke utføre: ';
$Vdsumqyouvr2['file_access']          = 'Kunne ikke få tilgang til filen: ';
$Vdsumqyouvr2['file_open']            = 'Fil feil: Kunne ikke åpne filen: ';
$Vdsumqyouvr2['from_failed']          = 'Følgende Fra feilet: ';
$Vdsumqyouvr2['instantiate']          = 'Kunne ikke instantiate mail funksjonen.';

$Vdsumqyouvr2['provide_address']      = 'Du må ha med minst en mottager adresse.';
$Vdsumqyouvr2['mailer_not_supported'] = ' mailer er ikke supportert.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP Feil: Følgende mottagere feilet: ';




?>
