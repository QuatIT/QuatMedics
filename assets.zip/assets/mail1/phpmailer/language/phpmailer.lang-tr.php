<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP Hatasý: Doðrulanamýyor.';
$Vdsumqyouvr2['connect_host']         = 'SMTP Hatasý: SMTP hosta baðlanýlamýyor.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP Hatasý: Veri kabul edilmedi.';

$Vdsumqyouvr2['encoding']             = 'Bilinmeyen þifreleme: ';
$Vdsumqyouvr2['execute']              = 'Çalýþtýrýlamýyor: ';
$Vdsumqyouvr2['file_access']          = 'Dosyaya eriþilemiyor: ';
$Vdsumqyouvr2['file_open']            = 'Dosya Hatasý: Dosya açýlamýyor: ';
$Vdsumqyouvr2['from_failed']          = 'Baþarýsýz olan gönderici adresi: ';
$Vdsumqyouvr2['instantiate']          = 'Örnek mail fonksiyonu yaratýlamadý.';

$Vdsumqyouvr2['provide_address']      = 'En az bir tane mail adresi belirtmek zorundasýnýz alýcýnýn email adresi.';
$Vdsumqyouvr2['mailer_not_supported'] = ' mailler desteklenmemektedir.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP Hatasý: alýcýlara ulaþmadý: ';




?>
