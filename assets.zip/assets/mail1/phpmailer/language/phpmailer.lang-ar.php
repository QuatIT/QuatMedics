<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP Error: لم نستطع تأكيد الهوية.';
$Vdsumqyouvr2['connect_host']         = 'SMTP Error: لم نستطع الاتصال بمخدم SMTP.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP Error: لم يتم قبول المعلومات .';

$Vdsumqyouvr2['encoding']             = 'ترميز غير معروف: ';
$Vdsumqyouvr2['execute']              = 'لم أستطع تنفيذ : ';
$Vdsumqyouvr2['file_access']          = 'لم نستطع الوصول للملف: ';
$Vdsumqyouvr2['file_open']            = 'File Error: لم نستطع فتح الملف: ';
$Vdsumqyouvr2['from_failed']          = 'البريد التالي لم نستطع ارسال البريد له : ';
$Vdsumqyouvr2['instantiate']          = 'لم نستطع توفير خدمة البريد.';

$Vdsumqyouvr2['mailer_not_supported'] = ' mailer غير مدعوم.';

$Vdsumqyouvr2['recipients_failed']    = 'SMTP Error: الأخطاء التالية ' .
                                          'فشل في الارسال لكل من : ';
$Vdsumqyouvr2['signing']              = 'خطأ في التوقيع: ';



?>
