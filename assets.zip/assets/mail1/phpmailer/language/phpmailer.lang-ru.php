<?php


$Vdsumqyouvr2['authenticate']         = 'Ошибка SMTP: ошибка авторизации.';
$Vdsumqyouvr2['connect_host']         = 'Ошибка SMTP: не удается подключиться к серверу SMTP.';
$Vdsumqyouvr2['data_not_accepted']    = 'Ошибка SMTP: данные не приняты.';

$Vdsumqyouvr2['encoding']             = 'Неизвестный вид кодировки: ';
$Vdsumqyouvr2['execute']              = 'Невозможно выполнить команду: ';
$Vdsumqyouvr2['file_access']          = 'Нет доступа к файлу: ';
$Vdsumqyouvr2['file_open']            = 'Файловая ошибка: не удается открыть файл: ';
$Vdsumqyouvr2['from_failed']          = 'Неверный адрес отправителя: ';
$Vdsumqyouvr2['instantiate']          = 'Невозможно запустить функцию mail.';

$Vdsumqyouvr2['provide_address']      = 'Пожалуйста, введите хотя бы один адрес e-mail получателя.';
$Vdsumqyouvr2['mailer_not_supported'] = ' - почтовый сервер не поддерживается.';
$Vdsumqyouvr2['recipients_failed']    = 'Ошибка SMTP: отправка по следующим адресам получателей не удалась: ';




?>
