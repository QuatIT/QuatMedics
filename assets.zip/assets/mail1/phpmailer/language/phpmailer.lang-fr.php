<?php


$Vdsumqyouvr2['authenticate']         = 'Erreur SMTP : Echec de l\'authentification.';
$Vdsumqyouvr2['connect_host']         = 'Erreur SMTP : Impossible de se connecter au serveur SMTP.';
$Vdsumqyouvr2['data_not_accepted']    = 'Erreur SMTP : Données incorrects.';
$Vdsumqyouvr2['empty_message']        = 'Corps de message vide';
$Vdsumqyouvr2['encoding']             = 'Encodage inconnu : ';
$Vdsumqyouvr2['execute']              = 'Impossible de lancer l\'exécution : ';
$Vdsumqyouvr2['file_access']          = 'Impossible d\'accéder au fichier : ';
$Vdsumqyouvr2['file_open']            = 'Erreur Fichier : ouverture impossible : ';
$Vdsumqyouvr2['from_failed']          = 'L\'adresse d\'expéditeur suivante a échouée : ';
$Vdsumqyouvr2['instantiate']          = 'Impossible d\'instancier la fonction mail.';

$Vdsumqyouvr2['mailer_not_supported'] = ' client de messagerie non supporté.';
$Vdsumqyouvr2['provide_address']      = 'Vous devez fournir au moins une adresse de destinataire.';
$Vdsumqyouvr2['recipients_failed']    = 'Erreur SMTP : Les destinataires suivants sont en erreur : ';




?>
