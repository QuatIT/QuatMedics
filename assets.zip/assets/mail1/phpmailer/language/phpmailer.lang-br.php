<?php


$Vdsumqyouvr2['authenticate']         = 'Erro de SMTP: Não foi possível autenticar.';
$Vdsumqyouvr2['connect_host']         = 'Erro de SMTP: Não foi possível conectar com o servidor SMTP.';
$Vdsumqyouvr2['data_not_accepted']    = 'Erro de SMTP: Dados não aceitos.';

$Vdsumqyouvr2['encoding']             = 'Codificação desconhecida: ';
$Vdsumqyouvr2['execute']              = 'Não foi possível executar: ';
$Vdsumqyouvr2['file_access']          = 'Não foi possível acessar o arquivo: ';
$Vdsumqyouvr2['file_open']            = 'Erro de Arquivo: Não foi possível abrir o arquivo: ';
$Vdsumqyouvr2['from_failed']          = 'Os endereços de rementente a seguir falharam: ';
$Vdsumqyouvr2['instantiate']          = 'Não foi possível instanciar a função mail.';

$Vdsumqyouvr2['mailer_not_supported'] = ' mailer não suportado.';
$Vdsumqyouvr2['provide_address']      = 'Você deve fornecer pelo menos um endereço de destinatário de email.';
$Vdsumqyouvr2['recipients_failed']    = 'Erro de SMTP: Os endereços de destinatário a seguir falharam: ';




?>
