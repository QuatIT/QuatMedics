<?php


$Vdsumqyouvr2['authenticate']         = 'Error SMTP: No se pudo autentificar.';
$Vdsumqyouvr2['connect_host']         = 'Error SMTP: No puedo conectar al servidor SMTP.';
$Vdsumqyouvr2['data_not_accepted']    = 'Error SMTP: Datos no aceptados.';

$Vdsumqyouvr2['encoding']             = 'Codificación desconocida: ';
$Vdsumqyouvr2['execute']              = 'No puedo ejecutar: ';
$Vdsumqyouvr2['file_access']          = 'No puedo acceder al archivo: ';
$Vdsumqyouvr2['file_open']            = 'Error de Archivo: No puede abrir el archivo: ';
$Vdsumqyouvr2['from_failed']          = 'La(s) siguiente(s) direcciones de remitente fallaron: ';
$Vdsumqyouvr2['instantiate']          = 'No pude crear una instancia de la función Mail.';

$Vdsumqyouvr2['mailer_not_supported'] = ' mailer no está soportado.';
$Vdsumqyouvr2['provide_address']      = 'Debe proveer al menos una dirección de email como destinatario.';
$Vdsumqyouvr2['recipients_failed']    = 'Error SMTP: Los siguientes destinatarios fallaron: ';
$Vdsumqyouvr2['signing']              = 'Error al firmar: ';



?>
