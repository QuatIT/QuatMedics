<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP Viga: Autoriseerimise viga.';
$Vdsumqyouvr2['connect_host']         = 'SMTP Viga: Ei õnnestunud luua ühendust SMTP serveriga.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP Viga: Vigased andmed.';

$Vdsumqyouvr2['encoding']             = 'Tundmatu Unknown kodeering: ';
$Vdsumqyouvr2['execute']              = 'Tegevus ebaõnnestus: ';
$Vdsumqyouvr2['file_access']          = 'Pole piisavalt õiguseid järgneva faili avamiseks: ';
$Vdsumqyouvr2['file_open']            = 'Faili Viga: Faili avamine ebaõnnestus: ';
$Vdsumqyouvr2['from_failed']          = 'Järgnev saatja e-posti aadress on vigane: ';
$Vdsumqyouvr2['instantiate']          = 'mail funktiooni käivitamine ebaõnnestus.';

$Vdsumqyouvr2['provide_address']      = 'Te peate määrama vähemalt ühe saaja e-posti aadressi.';
$Vdsumqyouvr2['mailer_not_supported'] = ' maileri tugi puudub.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP Viga: Järgnevate saajate e-posti aadressid on vigased: ';




?>
