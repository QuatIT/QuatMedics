<?php


$Vdsumqyouvr2['authenticate'] = 'SMTP 错误：登录失败。';
$Vdsumqyouvr2['connect_host'] = 'SMTP 错误：无法连接到 SMTP 主机。';
$Vdsumqyouvr2['data_not_accepted'] = 'SMTP 错误：数据不被接受。';

$Vdsumqyouvr2['encoding'] = '未知编码: ';
$Vdsumqyouvr2['execute'] = '无法执行：';
$Vdsumqyouvr2['file_access'] = '无法访问文件：';
$Vdsumqyouvr2['file_open'] = '文件错误：无法打开文件：';
$Vdsumqyouvr2['from_failed'] = '发送地址错误：';
$Vdsumqyouvr2['instantiate'] = '未知函数调用。';

$Vdsumqyouvr2['mailer_not_supported'] = '发信客户端不被支持。';
$Vdsumqyouvr2['provide_address'] = '必须提供至少一个收件人地址。';
$Vdsumqyouvr2['recipients_failed'] = 'SMTP 错误：收件人地址错误：';




?>
