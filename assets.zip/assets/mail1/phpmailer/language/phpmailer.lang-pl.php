<?php


$Vdsumqyouvr2['authenticate'] = 'Błąd SMTP: Nie można przeprowadzić autentykacji.';
$Vdsumqyouvr2['connect_host'] = 'Błąd SMTP: Nie można połączyć się z wybranym hostem.';
$Vdsumqyouvr2['data_not_accepted'] = 'Błąd SMTP: Dane nie zostały przyjęte.';

$Vdsumqyouvr2['encoding'] = 'Nieznany sposób kodowania znaków: ';
$Vdsumqyouvr2['execute'] = 'Nie można uruchomić: ';
$Vdsumqyouvr2['file_access'] = 'Brak dostępu do pliku: ';
$Vdsumqyouvr2['file_open'] = 'Nie można otworzyć pliku: ';
$Vdsumqyouvr2['from_failed'] = 'Następujący adres Nadawcy jest jest nieprawidłowy: ';
$Vdsumqyouvr2['instantiate'] = 'Nie można wywołać funkcji mail(). Sprawdź konfigurację serwera.';

$Vdsumqyouvr2['provide_address'] = 'Należy podać prawidłowy adres email Odbiorcy.';
$Vdsumqyouvr2['mailer_not_supported'] = 'Wybrana metoda wysyłki wiadomości nie jest obsługiwana.';
$Vdsumqyouvr2['recipients_failed'] = 'Błąd SMTP: Następujący odbiorcy są nieprawidłowi: ';




?>
