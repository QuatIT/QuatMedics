<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP Fout: authenticatie mislukt.';
$Vdsumqyouvr2['connect_host']         = 'SMTP Fout: Kon niet verbinden met SMTP host.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP Fout: Data niet geaccepteerd.';

$Vdsumqyouvr2['encoding']             = 'Onbekende codering: ';
$Vdsumqyouvr2['execute']              = 'Kon niet uitvoeren: ';
$Vdsumqyouvr2['file_access']          = 'Kreeg geen toegang tot bestand: ';
$Vdsumqyouvr2['file_open']            = 'Bestandsfout: Kon bestand niet openen: ';
$Vdsumqyouvr2['from_failed']          = 'De volgende afzender adressen zijn mislukt: ';
$Vdsumqyouvr2['instantiate']          = 'Kon mail functie niet initialiseren.';

$Vdsumqyouvr2['provide_address']      = 'Er moet tenmiste één ontvanger emailadres opgegeven worden.';
$Vdsumqyouvr2['mailer_not_supported'] = ' mailer wordt niet ondersteund.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP Fout: De volgende ontvangers zijn mislukt: ';




?>
