<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP Error: Impossibile autenticarsi.';
$Vdsumqyouvr2['connect_host']         = 'SMTP Error: Impossibile connettersi all\'host SMTP.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP Error: Data non accettati dal server.';

$Vdsumqyouvr2['encoding']             = 'Encoding set dei caratteri sconosciuto: ';
$Vdsumqyouvr2['execute']              = 'Impossibile eseguire l\'operazione: ';
$Vdsumqyouvr2['file_access']          = 'Impossibile accedere al file: ';
$Vdsumqyouvr2['file_open']            = 'File Error: Impossibile aprire il file: ';
$Vdsumqyouvr2['from_failed']          = 'I seguenti indirizzi mittenti hanno generato errore: ';
$Vdsumqyouvr2['instantiate']          = 'Impossibile istanziare la funzione mail';

$Vdsumqyouvr2['provide_address']      = 'Deve essere fornito almeno un indirizzo ricevente';
$Vdsumqyouvr2['mailer_not_supported'] = 'Mailer non supportato';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP Error: I seguenti indirizzi destinatari hanno generato errore: ';




?>
