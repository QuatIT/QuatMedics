<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP feilur: Kundi ikki góðkenna.';
$Vdsumqyouvr2['connect_host']         = 'SMTP feilur: Kundi ikki knýta samband við SMTP vert.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP feilur: Data ikki góðkent.';

$Vdsumqyouvr2['encoding']             = 'Ókend encoding: ';
$Vdsumqyouvr2['execute']              = 'Kundi ikki útføra: ';
$Vdsumqyouvr2['file_access']          = 'Kundi ikki tilganga fílu: ';
$Vdsumqyouvr2['file_open']            = 'Fílu feilur: Kundi ikki opna fílu: ';
$Vdsumqyouvr2['from_failed']          = 'fylgjandi Frá/From adressa miseydnaðist: ';
$Vdsumqyouvr2['instantiate']          = 'Kuni ikki instantiera mail funktión.';

$Vdsumqyouvr2['mailer_not_supported'] = ' er ikki supporterað.';
$Vdsumqyouvr2['provide_address']      = 'Tú skal uppgeva minst móttakara-emailadressu(r).';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP Feilur: Fylgjandi móttakarar miseydnaðust: ';




?>
