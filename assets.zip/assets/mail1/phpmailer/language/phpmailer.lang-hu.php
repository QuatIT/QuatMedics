<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP Hiba: Sikertelen autentikáció.';
$Vdsumqyouvr2['connect_host']         = 'SMTP Hiba: Nem tudtam csatlakozni az SMTP host-hoz.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP Hiba: Nem elfogadható adat.';

$Vdsumqyouvr2['encoding']             = 'Ismeretlen kódolás: ';
$Vdsumqyouvr2['execute']              = 'Nem tudtam végrehajtani: ';
$Vdsumqyouvr2['file_access']          = 'Nem sikerült elérni a következõ fájlt: ';
$Vdsumqyouvr2['file_open']            = 'Fájl Hiba: Nem sikerült megnyitni a következõ fájlt: ';
$Vdsumqyouvr2['from_failed']          = 'Az alábbi Feladó cím hibás: ';
$Vdsumqyouvr2['instantiate']          = 'Nem sikerült példányosítani a mail funkciót.';

$Vdsumqyouvr2['provide_address']      = 'Meg kell adnod legalább egy címzett email címet.';
$Vdsumqyouvr2['mailer_not_supported'] = ' levelezõ nem támogatott.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP Hiba: Az alábbi címzettek hibásak: ';




?>
