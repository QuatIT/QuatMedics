<?php


$Vdsumqyouvr2['authenticate']         = 'SMTP-virhe: käyttäjätunnistus epäonnistui.';
$Vdsumqyouvr2['connect_host']         = 'SMTP-virhe: yhteys palvelimeen ei onnistu.';
$Vdsumqyouvr2['data_not_accepted']    = 'SMTP-virhe: data on virheellinen.';

$Vdsumqyouvr2['encoding']             = 'Tuntematon koodaustyyppi: ';
$Vdsumqyouvr2['execute']              = 'Suoritus epäonnistui: ';
$Vdsumqyouvr2['file_access']          = 'Seuraavaan tiedostoon ei ole oikeuksia: ';
$Vdsumqyouvr2['file_open']            = 'Tiedostovirhe: Ei voida avata tiedostoa: ';
$Vdsumqyouvr2['from_failed']          = 'Seuraava lähettäjän osoite on virheellinen: ';
$Vdsumqyouvr2['instantiate']          = 'mail-funktion luonti epäonnistui.';

$Vdsumqyouvr2['mailer_not_supported'] = 'postivälitintyyppiä ei tueta.';
$Vdsumqyouvr2['provide_address']      = 'Aseta vähintään yksi vastaanottajan sähk&ouml;postiosoite.';
$Vdsumqyouvr2['recipients_failed']    = 'SMTP-virhe: seuraava vastaanottaja osoite on virheellinen.';
$Vdsumqyouvr2['encoding']             = 'Tuntematon koodaustyyppi: ';




?>
