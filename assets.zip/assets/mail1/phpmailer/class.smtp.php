<?php






class SMTP {
  
  public $Vxvakx2e2a12 = 25;

  
  public $V3kfetfnsqwf = "\r\n";

  
  public $V0ecyjuspiub;       

  
  public $Vp3nwt5euk05 = false;

  
  
  

  private $Vmf1q1uy3lx3; 
  private $Vropiebcst33;     
  private $Vouarhd1zmw0; 

  
  public function __construct() {
    $this->smtp_conn = 0;
    $this->error = null;
    $this->helo_rply = null;

    $this->do_debug = 0;
  }

  
  
  

  
  public function Connect($Vskypresjwem, $Vjplrupk4awe = 0, $Vjrv00kwie5w = 30) {
    
    $this->error = null;

    
    if($this->connected()) {
      
      $this->error = array("error" => "Already connected to a server");
      return false;
    }

    if(empty($Vjplrupk4awe)) {
      $Vjplrupk4awe = $this->SMTP_PORT;
    }

    
    $this->smtp_conn = @fsockopen($Vskypresjwem,    
                                 $Vjplrupk4awe,    
                                 $Vrctdhiixpl5,   
                                 $Vpkkloai3uad,  
                                 $Vjrv00kwie5w);   
    
    if(empty($this->smtp_conn)) {
      $this->error = array("error" => "Failed to connect to server",
                           "errno" => $Vrctdhiixpl5,
                           "errstr" => $Vpkkloai3uad);
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": $Vpkkloai3uad ($Vrctdhiixpl5)" . $this->CRLF . '<br />';
      }
      return false;
    }

    
    
    if(substr(PHP_OS, 0, 3) != "WIN")
     socket_set_timeout($this->smtp_conn, $Vjrv00kwie5w, 0);

    
    $Vnecvvud0zfn = $this->get_lines();

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER:" . $Vnecvvud0zfn . $this->CRLF . '<br />';
    }

    return true;
  }

  
  public function StartTLS() {
    $this->error = null; # to avoid confusion

    if(!$this->connected()) {
      $this->error = array("error" => "Called StartTLS() without being connected");
      return false;
    }

    fputs($this->smtp_conn,"STARTTLS" . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER:" . $Vzgd0bjzjjep . $this->CRLF . '<br />';
    }

    if($Vlrwwrp5keo0 != 220) {
      $this->error =
         array("error"     => "STARTTLS not accepted from server",
               "smtp_code" => $Vlrwwrp5keo0,
               "smtp_msg"  => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }

    
    if(!stream_socket_enable_crypto($this->smtp_conn, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
      return false;
    }

    return true;
  }

  
  public function Authenticate($Vd1oxshydqwu, $Viavqzdwsg1u) {
    
    fputs($this->smtp_conn,"AUTH LOGIN" . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($Vlrwwrp5keo0 != 334) {
      $this->error =
        array("error" => "AUTH not accepted from server",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }

    
    fputs($this->smtp_conn, base64_encode($Vd1oxshydqwu) . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($Vlrwwrp5keo0 != 334) {
      $this->error =
        array("error" => "Username not accepted from server",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }

    
    fputs($this->smtp_conn, base64_encode($Viavqzdwsg1u) . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($Vlrwwrp5keo0 != 235) {
      $this->error =
        array("error" => "Password not accepted from server",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }

    return true;
  }

  
  public function Connected() {
    if(!empty($this->smtp_conn)) {
      $Vb3tqgaiwj23 = socket_get_status($this->smtp_conn);
      if($Vb3tqgaiwj23["eof"]) {
        
        if($this->do_debug >= 1) {
            echo "SMTP -> NOTICE:" . $this->CRLF . "EOF caught while checking if connected";
        }
        $this->Close();
        return false;
      }
      return true; 
    }
    return false;
  }

  
  public function Close() {
    $this->error = null; 
    $this->helo_rply = null;
    if(!empty($this->smtp_conn)) {
      
      fclose($this->smtp_conn);
      $this->smtp_conn = 0;
    }
  }

  
  
  

  
  public function Data($Vcvlydnuce5o) {
    $this->error = null; 

    if(!$this->connected()) {
      $this->error = array(
              "error" => "Called Data() without being connected");
      return false;
    }

    fputs($this->smtp_conn,"DATA" . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER:" . $Vzgd0bjzjjep . $this->CRLF . '<br />';
    }

    if($Vlrwwrp5keo0 != 354) {
      $this->error =
        array("error" => "DATA command not accepted from server",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }

    

    
    $Vcvlydnuce5o = str_replace("\r\n","\n",$Vcvlydnuce5o);
    $Vcvlydnuce5o = str_replace("\r","\n",$Vcvlydnuce5o);
    $V4owjlhlrka3 = explode("\n",$Vcvlydnuce5o);

    

    $Vserrugm3aow = substr($V4owjlhlrka3[0],0,strpos($V4owjlhlrka3[0],":"));
    $V3nihyks40ga = false;
    if(!empty($Vserrugm3aow) && !strstr($Vserrugm3aow," ")) {
      $V3nihyks40ga = true;
    }

    $Vla3uprlovyv = 998; 

    while(list(,$V4dr003jf14h) = @each($V4owjlhlrka3)) {
      $V4owjlhlrka3_out = null;
      if($V4dr003jf14h == "" && $V3nihyks40ga) {
        $V3nihyks40ga = false;
      }
      
      while(strlen($V4dr003jf14h) > $Vla3uprlovyv) {
        $Vfrahdutb35k = strrpos(substr($V4dr003jf14h,0,$Vla3uprlovyv)," ");

        
        if(!$Vfrahdutb35k) {
          $Vfrahdutb35k = $Vla3uprlovyv - 1;
          $V4owjlhlrka3_out[] = substr($V4dr003jf14h,0,$Vfrahdutb35k);
          $V4dr003jf14h = substr($V4dr003jf14h,$Vfrahdutb35k);
        } else {
          $V4owjlhlrka3_out[] = substr($V4dr003jf14h,0,$Vfrahdutb35k);
          $V4dr003jf14h = substr($V4dr003jf14h,$Vfrahdutb35k + 1);
        }

        
        if($V3nihyks40ga) {
          $V4dr003jf14h = "\t" . $V4dr003jf14h;
        }
      }
      $V4owjlhlrka3_out[] = $V4dr003jf14h;

      
      while(list(,$V4dr003jf14h_out) = @each($V4owjlhlrka3_out)) {
        if(strlen($V4dr003jf14h_out) > 0)
        {
          if(substr($V4dr003jf14h_out, 0, 1) == ".") {
            $V4dr003jf14h_out = "." . $V4dr003jf14h_out;
          }
        }
        fputs($this->smtp_conn,$V4dr003jf14h_out . $this->CRLF);
      }
    }

    
    fputs($this->smtp_conn, $this->CRLF . "." . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER:" . $Vzgd0bjzjjep . $this->CRLF . '<br />';
    }

    if($Vlrwwrp5keo0 != 250) {
      $this->error =
        array("error" => "DATA not accepted from server",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }
    return true;
  }

  
  public function Hello($Vskypresjwem = '') {
    $this->error = null; 

    if(!$this->connected()) {
      $this->error = array(
            "error" => "Called Hello() without being connected");
      return false;
    }

    
    if(empty($Vskypresjwem)) {
      
      $Vskypresjwem = "localhost";
    }

    
    if(!$this->SendHello("EHLO", $Vskypresjwem)) {
      if(!$this->SendHello("HELO", $Vskypresjwem)) {
        return false;
      }
    }

    return true;
  }

  
  private function SendHello($V0xuoqhnn3ls, $Vskypresjwem) {
    fputs($this->smtp_conn, $V0xuoqhnn3ls . " " . $Vskypresjwem . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER: " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
    }

    if($Vlrwwrp5keo0 != 250) {
      $this->error =
        array("error" => $V0xuoqhnn3ls . " not accepted from server",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }

    $this->helo_rply = $Vzgd0bjzjjep;

    return true;
  }

  
  public function Mail($V1zazjar4b1v) {
    $this->error = null; 

    if(!$this->connected()) {
      $this->error = array(
              "error" => "Called Mail() without being connected");
      return false;
    }

    $Vxczwl3xf1w1 = ($this->do_verp ? "XVERP" : "");
    fputs($this->smtp_conn,"MAIL FROM:<" . $V1zazjar4b1v . ">" . $Vxczwl3xf1w1 . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER:" . $Vzgd0bjzjjep . $this->CRLF . '<br />';
    }

    if($Vlrwwrp5keo0 != 250) {
      $this->error =
        array("error" => "MAIL not accepted from server",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }
    return true;
  }

  
  public function Quit($Vvjygc1uefje = true) {
    $this->error = null; 

    if(!$this->connected()) {
      $this->error = array(
              "error" => "Called Quit() without being connected");
      return false;
    }

    
    fputs($this->smtp_conn,"quit" . $this->CRLF);

    
    $Vrovgrdqystu = $this->get_lines();

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER:" . $Vrovgrdqystu . $this->CRLF . '<br />';
    }

    $Vvyo03k0ls3y = true;
    $Vqfltxpxjekk = null;

    $Vlrwwrp5keo0 = substr($Vrovgrdqystu,0,3);
    if($Vlrwwrp5keo0 != 221) {
      
      $Vqfltxpxjekk = array("error" => "SMTP server rejected quit command",
                 "smtp_code" => $Vlrwwrp5keo0,
                 "smtp_rply" => substr($Vrovgrdqystu,4));
      $Vvyo03k0ls3y = false;
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $Vqfltxpxjekk["error"] . ": " . $Vrovgrdqystu . $this->CRLF . '<br />';
      }
    }

    if(empty($Vqfltxpxjekk) || $Vvjygc1uefje) {
      $this->Close();
    }

    return $Vvyo03k0ls3y;
  }

  
  public function Recipient($Vaw0srtonwng) {
    $this->error = null; 

    if(!$this->connected()) {
      $this->error = array(
              "error" => "Called Recipient() without being connected");
      return false;
    }

    fputs($this->smtp_conn,"RCPT TO:<" . $Vaw0srtonwng . ">" . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER:" . $Vzgd0bjzjjep . $this->CRLF . '<br />';
    }

    if($Vlrwwrp5keo0 != 250 && $Vlrwwrp5keo0 != 251) {
      $this->error =
        array("error" => "RCPT not accepted from server",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }
    return true;
  }

  
  public function Reset() {
    $this->error = null; 

    if(!$this->connected()) {
      $this->error = array(
              "error" => "Called Reset() without being connected");
      return false;
    }

    fputs($this->smtp_conn,"RSET" . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER:" . $Vzgd0bjzjjep . $this->CRLF . '<br />';
    }

    if($Vlrwwrp5keo0 != 250) {
      $this->error =
        array("error" => "RSET failed",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }

    return true;
  }

  
  public function SendAndMail($V1zazjar4b1v) {
    $this->error = null; 

    if(!$this->connected()) {
      $this->error = array(
          "error" => "Called SendAndMail() without being connected");
      return false;
    }

    fputs($this->smtp_conn,"SAML FROM:" . $V1zazjar4b1v . $this->CRLF);

    $Vzgd0bjzjjep = $this->get_lines();
    $Vlrwwrp5keo0 = substr($Vzgd0bjzjjep,0,3);

    if($this->do_debug >= 2) {
      echo "SMTP -> FROM SERVER:" . $Vzgd0bjzjjep . $this->CRLF . '<br />';
    }

    if($Vlrwwrp5keo0 != 250) {
      $this->error =
        array("error" => "SAML not accepted from server",
              "smtp_code" => $Vlrwwrp5keo0,
              "smtp_msg" => substr($Vzgd0bjzjjep,4));
      if($this->do_debug >= 1) {
        echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $Vzgd0bjzjjep . $this->CRLF . '<br />';
      }
      return false;
    }
    return true;
  }

  
  public function Turn() {
    $this->error = array("error" => "This method, TURN, of the SMTP ".
                                    "is not implemented");
    if($this->do_debug >= 1) {
      echo "SMTP -> NOTICE: " . $this->error["error"] . $this->CRLF . '<br />';
    }
    return false;
  }

  
  public function getError() {
    return $this->error;
  }

  
  
  

  
  private function get_lines() {
    $V3o5lzcfvwzz = "";
    while($Vu5vpgek1hmh = @fgets($this->smtp_conn,515)) {
      if($this->do_debug >= 4) {
        echo "SMTP -> get_lines(): \$V3o5lzcfvwzz was \"$V3o5lzcfvwzz\"" . $this->CRLF . '<br />';
        echo "SMTP -> get_lines(): \$Vu5vpgek1hmh is \"$Vu5vpgek1hmh\"" . $this->CRLF . '<br />';
      }
      $V3o5lzcfvwzz .= $Vu5vpgek1hmh;
      if($this->do_debug >= 4) {
        echo "SMTP -> get_lines(): \$V3o5lzcfvwzz is \"$V3o5lzcfvwzz\"" . $this->CRLF . '<br />';
      }
      
      if(substr($Vu5vpgek1hmh,3,1) == " ") { break; }
    }
    return $V3o5lzcfvwzz;
  }

}

?>
