<html>
<head>
<title>PHPMailer - SMTP advanced test with no authentication</title>
</head>
<body>

<?php
require_once('../class.phpmailer.php');


$Vrj41l10rv5e = new PHPMailer(true); 

$Vrj41l10rv5e->IsSMTP(); 

try {
  $Vrj41l10rv5e->Host       = "mail.yourdomain.com"; 
  $Vrj41l10rv5e->SMTPDebug  = 2;                     
  $Vrj41l10rv5e->AddReplyTo('name@yourdomain.com', 'First Last');
  $Vrj41l10rv5e->AddAddress('whoto@otherdomain.com', 'John Doe');
  $Vrj41l10rv5e->SetFrom('name@yourdomain.com', 'First Last');
  $Vrj41l10rv5e->AddReplyTo('name@yourdomain.com', 'First Last');
  $Vrj41l10rv5e->Subject = 'PHPMailer Test Subject via mail(), advanced';
  $Vrj41l10rv5e->AltBody = 'To view the message, please use an HTML compatible email viewer!'; 
  $Vrj41l10rv5e->MsgHTML(file_get_contents('contents.html'));
  $Vrj41l10rv5e->AddAttachment('images/phpmailer.gif');      
  $Vrj41l10rv5e->AddAttachment('images/phpmailer_mini.gif'); 
  $Vrj41l10rv5e->Send();
  echo "Message Sent OK</p>\n";
} catch (phpmailerException $Vqfltxpxjekk) {
  echo $Vqfltxpxjekk->errorMessage(); 
} catch (Exception $Vqfltxpxjekk) {
  echo $Vqfltxpxjekk->getMessage(); 
}
?>

</body>
</html>
