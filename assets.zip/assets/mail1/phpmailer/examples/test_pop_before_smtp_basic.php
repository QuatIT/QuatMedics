<html>
<head>
<title>POP before SMTP Test</title>
</head>
<body>

<?php
require_once('../class.phpmailer.php');
require_once('../class.pop3.php'); 

$Vrcxo04mmz20 = new POP3();
$Vrcxo04mmz20->Authorise('pop3.yourdomain.com', 110, 30, 'username', 'password', 1);

$Vrj41l10rv5e = new PHPMailer();

$Vw2bgil42wyb             = file_get_contents('contents.html');
$Vw2bgil42wyb             = eregi_replace("[\]",'',$Vw2bgil42wyb);

$Vrj41l10rv5e->IsSMTP();
$Vrj41l10rv5e->SMTPDebug = 2;
$Vrj41l10rv5e->Host     = 'pop3.yourdomain.com';

$Vrj41l10rv5e->SetFrom('name@yourdomain.com', 'First Last');

$Vrj41l10rv5e->AddReplyTo("name@yourdomain.com","First Last");

$Vrj41l10rv5e->Subject    = "PHPMailer Test Subject via POP before SMTP, basic";

$Vrj41l10rv5e->AltBody    = "To view the message, please use an HTML compatible email viewer!"; 

$Vrj41l10rv5e->MsgHTML($Vw2bgil42wyb);

$Vzbgitt3jgp3 = "whoto@otherdomain.com";
$Vrj41l10rv5e->AddAddress($Vzbgitt3jgp3, "John Doe");

$Vrj41l10rv5e->AddAttachment("images/phpmailer.gif");      
$Vrj41l10rv5e->AddAttachment("images/phpmailer_mini.gif"); 


if(!$Vrj41l10rv5e->Send()) {
  echo "Mailer Error: " . $Vrj41l10rv5e->ErrorInfo;
} else {
  echo "Message sent!";
}

?>

</body>
</html>
