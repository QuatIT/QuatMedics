<html>
<head>
<title>PHPMailer - Sendmail basic test</title>
</head>
<body>

<?php

require_once('../class.phpmailer.php');

$Vrj41l10rv5e             = new PHPMailer(); 

$Vrj41l10rv5e->IsSendmail(); 

$Vw2bgil42wyb             = file_get_contents('contents.html');
$Vw2bgil42wyb             = eregi_replace("[\]",'',$Vw2bgil42wyb);

$Vrj41l10rv5e->AddReplyTo("name@yourdomain.com","First Last");

$Vrj41l10rv5e->SetFrom('name@yourdomain.com', 'First Last');

$Vrj41l10rv5e->AddReplyTo("name@yourdomain.com","First Last");

$Vzbgitt3jgp3 = "whoto@otherdomain.com";
$Vrj41l10rv5e->AddAddress($Vzbgitt3jgp3, "John Doe");

$Vrj41l10rv5e->Subject    = "PHPMailer Test Subject via Sendmail, basic";

$Vrj41l10rv5e->AltBody    = "To view the message, please use an HTML compatible email viewer!"; 

$Vrj41l10rv5e->MsgHTML($Vw2bgil42wyb);

$Vrj41l10rv5e->AddAttachment("images/phpmailer.gif");      
$Vrj41l10rv5e->AddAttachment("images/phpmailer_mini.gif"); 

if(!$Vrj41l10rv5e->Send()) {
  echo "Mailer Error: " . $Vrj41l10rv5e->ErrorInfo;
} else {
  echo "Message sent!";
}

?>

</body>
</html>
