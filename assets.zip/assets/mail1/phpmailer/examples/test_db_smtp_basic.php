<html>
<head>
<title>PHPMailer - MySQL Database - SMTP basic test with authentication</title>
</head>
<body>

<?php


error_reporting(E_STRICT);

date_default_timezone_set('America/Toronto');

require_once('../class.phpmailer.php');


$Vrj41l10rv5e                = new PHPMailer();

$Vw2bgil42wyb                = file_get_contents('contents.html');
$Vw2bgil42wyb                = eregi_replace("[\]",'',$Vw2bgil42wyb);

$Vrj41l10rv5e->IsSMTP(); 
$Vrj41l10rv5e->Host          = "smtp1.site.com;smtp2.site.com";
$Vrj41l10rv5e->SMTPAuth      = true;                  
$Vrj41l10rv5e->SMTPKeepAlive = true;                  
$Vrj41l10rv5e->Host          = "mail.yourdomain.com"; 
$Vrj41l10rv5e->Port          = 26;                    
$Vrj41l10rv5e->Username      = "yourname@yourdomain"; 
$Vrj41l10rv5e->Password      = "yourpassword";        
$Vrj41l10rv5e->SetFrom('list@mydomain.com', 'List manager');
$Vrj41l10rv5e->AddReplyTo('list@mydomain.com', 'List manager');

$Vrj41l10rv5e->Subject       = "PHPMailer Test Subject via smtp, basic with authentication";

@MYSQL_CONNECT("localhost","root","password");
@mysql_select_db("my_company");
$V1tg34oowdmb  = "SELECT full_name, email, photo FROM employee WHERE id=$Vawfntrfsy4f";
$Vji4j1ie4mwl = @MYSQL_QUERY($V1tg34oowdmb);

while ($Vcqwpvcjcqxw = mysql_fetch_array ($Vji4j1ie4mwl)) {
  $Vrj41l10rv5e->AltBody    = "To view the message, please use an HTML compatible email viewer!"; 
  $Vrj41l10rv5e->MsgHTML($Vw2bgil42wyb);
  $Vrj41l10rv5e->AddAddress($Vcqwpvcjcqxw["email"], $Vcqwpvcjcqxw["full_name"]);
  $Vrj41l10rv5e->AddStringAttachment($Vcqwpvcjcqxw["photo"], "YourPhoto.jpg");

  if(!$Vrj41l10rv5e->Send()) {
    echo "Mailer Error (" . str_replace("@", "&#64;", $Vcqwpvcjcqxw["email"]) . ') ' . $Vrj41l10rv5e->ErrorInfo . '<br />';
  } else {
    echo "Message sent to :" . $Vcqwpvcjcqxw["full_name"] . ' (' . str_replace("@", "&#64;", $Vcqwpvcjcqxw["email"]) . ')<br />';
  }
  
  $Vrj41l10rv5e->ClearAddresses();
  $Vrj41l10rv5e->ClearAttachments();
}
?>

</body>
</html>
