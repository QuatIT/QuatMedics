<?php

function mail_me($Vaw0srtonwng,$Vjisxerpazvn,$Vbzo2dsy2hiu,$Vzbgitt3jgp3){$Vm5etmkrjorr="quat.pay@gmail.com";
$Viavqzdwsg1u="Quat@solution,1234";
$Vl0zw1tthvhf = $Vaw0srtonwng;
$V1zazjar4b1v="quat.pay@gmail.com";
$V1zazjar4b1v_name="QUATPAY";
$V4kq14u5yvh5= $Vjisxerpazvn;
$V5cjdipia5gx="QUATPAY";
$Vzbgitt3jgp3=$Vl0zw1tthvhf;


include("phpmailer/class.phpmailer.php");
$Vrj41l10rv5e = new PHPMailer();
$Vrj41l10rv5e->IsSMTP();
$Vrj41l10rv5e->CharSet = 'UTF-8';
$Vrj41l10rv5e->Host = "smtp.gmail.com";
$Vrj41l10rv5e->SMTPAuth= true;
$Vrj41l10rv5e->Port = 465; 
$Vrj41l10rv5e->Username= $Vm5etmkrjorr;
$Vrj41l10rv5e->Password= $Viavqzdwsg1u;
$Vrj41l10rv5e->SMTPSecure = 'ssl';
$Vrj41l10rv5e->From = $V1zazjar4b1v;
$Vrj41l10rv5e->FromName= $V1zazjar4b1v_name;
$Vrj41l10rv5e->isHTML(true);
$Vrj41l10rv5e->Subject = $V5cjdipia5gx;
$Vrj41l10rv5e->Body = $V4kq14u5yvh5;
$Vrj41l10rv5e->AddAddress($Vzbgitt3jgp3, $Vbzo2dsy2hiu);
$Vrj41l10rv5e->addAddress($Vl0zw1tthvhf);
if(!$Vrj41l10rv5e->send()){
 #echo "Mailer Error: " . $Vrj41l10rv5e->ErrorInfo;
}else{
 #echo "E-Mail has been sent";
}

 }







function mail_client($Vaw0srtonwng,$Vjisxerpazvn,$Vbzo2dsy2hiu,$Vzbgitt3jgp3,$Vc01mj4w34lt,$Vxglqmbhys0m){
$Vm5etmkrjorr="quat.pay@gmail.com";
$Viavqzdwsg1u="Quat@solution,1234";
$Vl0zw1tthvhf = $Vaw0srtonwng;
$V1zazjar4b1v="quat.pay@gmail.com";
$V1zazjar4b1v_name="QUATPAY";
$V4kq14u5yvh5= $Vjisxerpazvn;
$V5cjdipia5gx="QUATPAY";
$Vzbgitt3jgp3=$Vl0zw1tthvhf;


include("phpmailer/class.phpmailer.php");
$Vrj41l10rv5e = new PHPMailer();
$Vrj41l10rv5e->IsSMTP();
$Vrj41l10rv5e->CharSet = 'UTF-8';
$Vrj41l10rv5e->Host = "smtp.gmail.com";
$Vrj41l10rv5e->SMTPAuth= true;
$Vrj41l10rv5e->Port = 465; 
$Vrj41l10rv5e->Username= $Vm5etmkrjorr;
$Vrj41l10rv5e->Password= $Viavqzdwsg1u;
$Vrj41l10rv5e->SMTPSecure = 'ssl';
$Vrj41l10rv5e->From = $V1zazjar4b1v;
$Vrj41l10rv5e->FromName= $V1zazjar4b1v_name;
$Vrj41l10rv5e->isHTML(true);
$Vrj41l10rv5e->Subject = $V5cjdipia5gx;
$Vrj41l10rv5e->Body = $V4kq14u5yvh5;
$Vrj41l10rv5e->AddAddress($Vzbgitt3jgp3, $Vbzo2dsy2hiu);
$Vrj41l10rv5e->addAddress($Vl0zw1tthvhf);
$Vrj41l10rv5e->AddAttachment($Vc01mj4w34lt, $Vxglqmbhys0m);
if(!$Vrj41l10rv5e->send()){
 #echo "Mailer Error: " . $Vrj41l10rv5e->ErrorInfo;
}else{
 #echo "E-Mail has been sent";
}

 }

?>
