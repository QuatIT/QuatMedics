<?php

namespace Dompdf\Image;

use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception\ImageException;


class Cache
{
    
    protected static $Vipb02wbylb1 = array();

    
    public static $Vnnsqq0ncoc0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABABAMAAABYR2ztAAAAA3NCSVQICAjb4U/gAAAAHlBMVEWZmZn////g4OCkpKS1tbXv7++9vb2tra3m5ub5+fkFnN6oAAAACXBIWXMAAAsSAAALEgHS3X78AAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1M0BrLToAAAABZ0RVh0Q3JlYXRpb24gVGltZQAwNC8xMi8xMRPnI58AAAGZSURBVEiJhZbPasMwDMbTw2DHKhDQcbDQPsEge4BAjg0Mxh5gkBcY7Niwkpx32PvOjv9JspX60It/+fxJsqxW1b11gN11rA7N3v6vAd5nfR9fDYCTDiyzAeA6qgKd9QDNoAtsAKyKCxzAAfhdBuyHGwC3oovNvQOaxxJwnSNg3ZQFAlBy4ax7AG6ZBLrgA5Cn038SAPgREiaJHJASwXYEhEQQIACyikTTCWCBJJoANBfpPAKQdBLHFMBYkctcBKIE9lAGggt6gRjgA2GV44CL7m1WgS08fAAdsPHxyyMAIyHujgRwEldHArCKy5cBz90+gNOyf8TTyKOUQN2LPEmgnWWPcKD+sr+rnuqTK1avAcHfRSv3afTgVAbqmCPiggLtGM8aSkBNOidVjADrmIDYebT1PoGsWJEE8Oc0b96aZoe4iMBZPiADB6RAzEUA2vwRmyiAL3Lfv6MBSEmUEg7ALt/3LhxwLgj4QNw4UCbKEsaBNpPsyRbgVRASFig78BIGyJNIJQyQTwIi0RvgT98H+Mi6W67j3X8H/427u5bfpQGVAAAAAElFTkSuQmCC";

    public static $Vhrm0xtxymrx = "Image not found or type unknown";

    
    protected static $V3zitx0n32g4;

    
    static function resolve_url($Vop22rgf5euu, $Vz2fphjg3555, $Vskypresjwem, $Vjzg0yr1b2nq, Dompdf $Vodc45cwlwwh)
    {
        self::$V3zitx0n32g4 = $Vodc45cwlwwh;

        $Vz2fphjg3555 = mb_strtolower($Vz2fphjg3555);
        $Vv3mazk3ltvx = Helpers::explode_url($Vop22rgf5euu);
        $V1ocy1gakxau = null;

        $Vrh1tnqgv3us = ($Vz2fphjg3555 && $Vz2fphjg3555 !== "file://") || ($Vv3mazk3ltvx['protocol'] != "");

        $Vy5ir01oay0q = strpos($Vv3mazk3ltvx['protocol'], "data:") === 0;
        $Vxyksauuidou = null;
        $Vm2lsuigfyk0 = $Vodc45cwlwwh->getOptions()->getIsRemoteEnabled();

        try {

            
            if (!$Vm2lsuigfyk0 && $Vrh1tnqgv3us && !$Vy5ir01oay0q) {
                throw new ImageException("Remote file access is disabled.", E_WARNING);
            } 
            else {
                if ($Vm2lsuigfyk0 && $Vrh1tnqgv3us || $Vy5ir01oay0q) {
                    
                    $Vxyksauuidou = Helpers::build_url($Vz2fphjg3555, $Vskypresjwem, $Vjzg0yr1b2nq, $Vop22rgf5euu);

                    
                    if (isset(self::$Vipb02wbylb1[$Vxyksauuidou])) {
                        $Vwgokusxqpst = self::$Vipb02wbylb1[$Vxyksauuidou];
                    } 
                    else {
                        $V3h3ilzzwl20 = $Vodc45cwlwwh->getOptions()->getTempDir();
                        $Vwgokusxqpst = tempnam($V3h3ilzzwl20, "ca_dompdf_img_");
                        $Vsc2xappb1ws = "";

                        if ($Vy5ir01oay0q) {
                            if ($Vimojdqfh1lm = Helpers::parse_data_uri($Vop22rgf5euu)) {
                                $Vsc2xappb1ws = $Vimojdqfh1lm['data'];
                            }
                        } else {
                            list($Vsc2xappb1ws, $http_response_header) = Helpers::getFileContent($Vxyksauuidou, $Vodc45cwlwwh->getHttpContext());
                        }

                        
                        if (strlen($Vsc2xappb1ws) == 0) {
                            $V4kq14u5yvh5 = ($Vy5ir01oay0q ? "Data-URI could not be parsed" : "Image not found");
                            throw new ImageException($V4kq14u5yvh5, E_WARNING);
                        } 
                        else {
                            
                            
                            
                            
                            
                            file_put_contents($Vwgokusxqpst, $Vsc2xappb1ws);
                        }
                    }
                } 
                else {
                    $Vwgokusxqpst = Helpers::build_url($Vz2fphjg3555, $Vskypresjwem, $Vjzg0yr1b2nq, $Vop22rgf5euu);
                }
            }

            
            if (!is_readable($Vwgokusxqpst) || !filesize($Vwgokusxqpst)) {
                throw new ImageException("Image not readable or empty", E_WARNING);
            } 
            else {
                list($Vtt4kvdwuqqh, $Vxtfrabd3i5r, $Vky1xzjrvbn4) = Helpers::dompdf_getimagesize($Vwgokusxqpst, $Vodc45cwlwwh->getHttpContext());

                
                if ($Vtt4kvdwuqqh && $Vxtfrabd3i5r && in_array($Vky1xzjrvbn4, array("gif", "png", "jpeg", "bmp", "svg"))) {
                    
                    
                    if ($Vm2lsuigfyk0 && $Vrh1tnqgv3us || $Vy5ir01oay0q) {
                        self::$Vipb02wbylb1[$Vxyksauuidou] = $Vwgokusxqpst;
                    }
                } 
                else {
                    throw new ImageException("Image type unknown", E_WARNING);
                }
            }
        } catch (ImageException $Vqfltxpxjekk) {
            $Vwgokusxqpst = self::$Vnnsqq0ncoc0;
            $Vky1xzjrvbn4 = "png";
            $V1ocy1gakxau = self::$Vhrm0xtxymrx;
            Helpers::record_warnings($Vqfltxpxjekk->getCode(), $Vqfltxpxjekk->getMessage() . " \n $Vop22rgf5euu", $Vqfltxpxjekk->getFile(), $Vqfltxpxjekk->getLine());
        }

        return array($Vwgokusxqpst, $Vky1xzjrvbn4, $V1ocy1gakxau);
    }

    
    static function clear()
    {
        if (empty(self::$Vipb02wbylb1) || self::$V3zitx0n32g4->getOptions()->getDebugKeepTemp()) {
            return;
        }

        foreach (self::$Vipb02wbylb1 as $Voheucoc3jxv) {
            if (self::$V3zitx0n32g4->getOptions()->getDebugPng()) {
                print "[clear unlink $Voheucoc3jxv]";
            }
            unlink($Voheucoc3jxv);
        }

        self::$Vipb02wbylb1 = array();
    }

    static function detect_type($Voheucoc3jxv, $Vamhuzg5mfpy = null)
    {
        list(, , $Vky1xzjrvbn4) = Helpers::dompdf_getimagesize($Voheucoc3jxv, $Vamhuzg5mfpy);

        return $Vky1xzjrvbn4;
    }

    static function is_broken($Vop22rgf5euu)
    {
        return $Vop22rgf5euu === self::$Vnnsqq0ncoc0;
    }
}

if (file_exists(realpath(__DIR__ . "/../../lib/res/broken_image.png"))) {
    Cache::$Vnnsqq0ncoc0 = realpath(__DIR__ . "/../../lib/res/broken_image.png");
}
