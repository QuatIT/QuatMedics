<?php


namespace Dompdf\Positioner;

use Dompdf\FrameDecorator\AbstractFrameDecorator;
use Dompdf\FrameDecorator\Inline as InlineFrameDecorator;
use Dompdf\Exception;


class Inline extends AbstractPositioner
{

    
    function position(AbstractFrameDecorator $Vexjfacrc1d4)
    {
        
        $V2d1s45w0hjo = $Vexjfacrc1d4->find_block_parent();

        

        
        
        

        

        if (!$V2d1s45w0hjo) {
            throw new Exception("No block-level parent found.  Not good.");
        }

        $Vtmlsxxw3ne1 = $Vexjfacrc1d4;

        $Ve0njdrnxyyx = $Vtmlsxxw3ne1->get_containing_block();
        $V4dr003jf14h = $V2d1s45w0hjo->get_current_line_box();

        
        $Vrbuzje3griu = false;
        while ($Vtmlsxxw3ne1 = $Vtmlsxxw3ne1->get_parent()) {
            if ($Vtmlsxxw3ne1->get_style()->position === "fixed") {
                $Vrbuzje3griu = true;
                break;
            }
        }

        $Vtmlsxxw3ne1 = $Vexjfacrc1d4;

        if (!$Vrbuzje3griu && $Vtmlsxxw3ne1->get_parent() &&
            $Vtmlsxxw3ne1->get_parent() instanceof InlineFrameDecorator &&
            $Vtmlsxxw3ne1->is_text_node()
        ) {
            $Vvdw1t1mpmex = $Vtmlsxxw3ne1->get_reflower()->get_min_max_width();

            
            if ($Vvdw1t1mpmex["min"] > ($Ve0njdrnxyyx["w"] - $V4dr003jf14h->left - $V4dr003jf14h->w - $V4dr003jf14h->right)) {
                $V2d1s45w0hjo->add_line();
            }
        }

        $Vtmlsxxw3ne1->set_position($Ve0njdrnxyyx["x"] + $V4dr003jf14h->w, $V4dr003jf14h->y);
    }
}
