<?php


namespace Dompdf\Positioner;

use Dompdf\FrameDecorator\AbstractFrameDecorator;


class TableRow extends AbstractPositioner
{

    
    function position(AbstractFrameDecorator $Vexjfacrc1d4)
    {
        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();
        $V2d1s45w0hjo = $Vexjfacrc1d4->get_prev_sibling();

        if ($V2d1s45w0hjo) {
            $Vuua0v2znlr5 = $V2d1s45w0hjo->get_position("y") + $V2d1s45w0hjo->get_margin_height();
        } else {
            $Vuua0v2znlr5 = $Ve0njdrnxyyx["y"];
        }
        $Vexjfacrc1d4->set_position($Ve0njdrnxyyx["x"], $Vuua0v2znlr5);
    }
}
