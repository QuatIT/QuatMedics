<?php


namespace Dompdf\Positioner;

use Dompdf\FrameDecorator\AbstractFrameDecorator;
use Dompdf\FrameDecorator\Table;


class TableCell extends AbstractPositioner
{

    
    function position(AbstractFrameDecorator $Vexjfacrc1d4)
    {
        $Vp5rpvpxnb43 = Table::find_parent_table($Vexjfacrc1d4);
        $V5hlwkutan5t = $Vp5rpvpxnb43->get_cellmap();
        $Vexjfacrc1d4->set_position($V5hlwkutan5t->get_frame_position($Vexjfacrc1d4));
    }
}
