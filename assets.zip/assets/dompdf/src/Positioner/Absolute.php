<?php


namespace Dompdf\Positioner;

use Dompdf\FrameDecorator\AbstractFrameDecorator;


class Absolute extends AbstractPositioner
{

    
    function position(AbstractFrameDecorator $Vexjfacrc1d4)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        $V2d1s45w0hjo = $Vexjfacrc1d4->find_positionned_parent();

        list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vexjfacrc1d4->get_containing_block();

        $Vzn5k4lefp5v = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->top, $V2pgp3ppbjsi);
        $Vqswkdbtte35 = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->right, $V5ymvwogwh5y);
        $V3xygetcwtmz = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->bottom, $V2pgp3ppbjsi);
        $Vb5dthqtenbv = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->left, $V5ymvwogwh5y);

        if ($V2d1s45w0hjo && !($Vb5dthqtenbv === "auto" && $Vqswkdbtte35 === "auto")) {
            
            list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $V2d1s45w0hjo->get_padding_box();
        }

        list($V5ymvwogwh5yidth, $V2pgp3ppbjsieight) = array($Vexjfacrc1d4->get_margin_width(), $Vexjfacrc1d4->get_margin_height());

        $Vbcrj2f5ypbf = $Vexjfacrc1d4->get_original_style();
        $Vlsuifyl3kns = $Vbcrj2f5ypbf->width;
        $V0jhfvxfzy42 = $Vbcrj2f5ypbf->height;

        

        if ($Vb5dthqtenbv === "auto") {
            if ($Vqswkdbtte35 === "auto") {
                
                $Vmm2pe5l4str = $Vmm2pe5l4str + $Vexjfacrc1d4->find_block_parent()->get_current_line_box()->w;
            } else {
                if ($Vlsuifyl3kns === "auto") {
                    
                    $Vmm2pe5l4str += $V5ymvwogwh5y - $V5ymvwogwh5yidth - $Vqswkdbtte35;
                } else {
                    
                    $Vmm2pe5l4str += $V5ymvwogwh5y - $V5ymvwogwh5yidth - $Vqswkdbtte35;
                }
            }
        } else {
            if ($Vqswkdbtte35 === "auto") {
                
                $Vmm2pe5l4str += (float)$Vb5dthqtenbv;
            } else {
                if ($Vlsuifyl3kns === "auto") {
                    
                    $Vmm2pe5l4str += (float)$Vb5dthqtenbv;
                } else {
                    
                    $Vmm2pe5l4str += (float)$Vb5dthqtenbv;
                }
            }
        }

        
        if ($Vzn5k4lefp5v === "auto") {
            if ($V3xygetcwtmz === "auto") {
                
                $Vuua0v2znlr5 = $Vexjfacrc1d4->find_block_parent()->get_current_line_box()->y;
            } else {
                if ($V0jhfvxfzy42 === "auto") {
                    
                    $Vuua0v2znlr5 += (float)$V2pgp3ppbjsi - $V2pgp3ppbjsieight - (float)$V3xygetcwtmz;
                } else {
                    
                    $Vuua0v2znlr5 += (float)$V2pgp3ppbjsi - $V2pgp3ppbjsieight - (float)$V3xygetcwtmz;
                }
            }
        } else {
            if ($V3xygetcwtmz === "auto") {
                
                $Vuua0v2znlr5 += (float)$Vzn5k4lefp5v;
            } else {
                if ($V0jhfvxfzy42 === "auto") {
                    
                    $Vuua0v2znlr5 += (float)$Vzn5k4lefp5v;
                } else {
                    
                    $Vuua0v2znlr5 += (float)$Vzn5k4lefp5v;
                }
            }
        }

        $Vexjfacrc1d4->set_position($Vmm2pe5l4str, $Vuua0v2znlr5);
    }
}
