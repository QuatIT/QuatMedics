<?php


namespace Dompdf\Positioner;

use Dompdf\FrameDecorator\AbstractFrameDecorator;


class Fixed extends AbstractPositioner
{

    
    function position(AbstractFrameDecorator $Vexjfacrc1d4)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_original_style();
        $Vfqvundqbe4u = $Vexjfacrc1d4->get_root();
        $Vrkecfnw0yon = $Vfqvundqbe4u->get_containing_block();
        $Vrkecfnw0yon_style = $Vfqvundqbe4u->get_style();

        $V2d1s45w0hjo = $Vexjfacrc1d4->find_block_parent();
        if ($V2d1s45w0hjo) {
            $V2d1s45w0hjo->add_line();
        }

        
        $Vmq2wkw5npmk = (float)$Vrkecfnw0yon_style->length_in_pt($Vrkecfnw0yon_style->margin_top, $Vrkecfnw0yon["h"]);
        $Vjp2zywc3plp = (float)$Vrkecfnw0yon_style->length_in_pt($Vrkecfnw0yon_style->margin_right, $Vrkecfnw0yon["w"]);
        $Vt1knyxiv2uq = (float)$Vrkecfnw0yon_style->length_in_pt($Vrkecfnw0yon_style->margin_bottom, $Vrkecfnw0yon["h"]);
        $Vs2wi0uctfln = (float)$Vrkecfnw0yon_style->length_in_pt($Vrkecfnw0yon_style->margin_left, $Vrkecfnw0yon["w"]);

        
        $Vxtfrabd3i5r = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->height, $Vrkecfnw0yon["h"]);
        $Vtt4kvdwuqqh = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->width, $Vrkecfnw0yon["w"]);

        $Vzn5k4lefp5v = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->top, $Vrkecfnw0yon["h"]);
        $Vqswkdbtte35 = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->right, $Vrkecfnw0yon["w"]);
        $V3xygetcwtmz = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->bottom, $Vrkecfnw0yon["h"]);
        $Vb5dthqtenbv = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->left, $Vrkecfnw0yon["w"]);

        $Vuua0v2znlr5 = $Vmq2wkw5npmk;
        if (isset($Vzn5k4lefp5v)) {
            $Vuua0v2znlr5 = (float)$Vzn5k4lefp5v + $Vmq2wkw5npmk;
            if ($Vzn5k4lefp5v === "auto") {
                $Vuua0v2znlr5 = $Vmq2wkw5npmk;
                if (isset($V3xygetcwtmz) && $V3xygetcwtmz !== "auto") {
                    $Vuua0v2znlr5 = $Vrkecfnw0yon["h"] - $V3xygetcwtmz - $Vt1knyxiv2uq;
                    if ($Vexjfacrc1d4->is_auto_height()) {
                        $Vuua0v2znlr5 -= $Vxtfrabd3i5r;
                    } else {
                        $Vuua0v2znlr5 -= $Vexjfacrc1d4->get_margin_height();
                    }
                }
            }
        }

        $Vmm2pe5l4str = $Vs2wi0uctfln;
        if (isset($Vb5dthqtenbv)) {
            $Vmm2pe5l4str = (float)$Vb5dthqtenbv + $Vs2wi0uctfln;
            if ($Vb5dthqtenbv === "auto") {
                $Vmm2pe5l4str = $Vs2wi0uctfln;
                if (isset($Vqswkdbtte35) && $Vqswkdbtte35 !== "auto") {
                    $Vmm2pe5l4str = $Vrkecfnw0yon["w"] - $Vqswkdbtte35 - $Vjp2zywc3plp;
                    if ($Vexjfacrc1d4->is_auto_width()) {
                        $Vmm2pe5l4str -= $Vtt4kvdwuqqh;
                    } else {
                        $Vmm2pe5l4str -= $Vexjfacrc1d4->get_margin_width();
                    }
                }
            }
        }

        $Vexjfacrc1d4->set_position($Vmm2pe5l4str, $Vuua0v2znlr5);

        $Vzi1s4z0nu10 = $Vexjfacrc1d4->get_children();
        foreach ($Vzi1s4z0nu10 as $V0mqc4rbglqu) {
            $V0mqc4rbglqu->set_position($Vmm2pe5l4str, $Vuua0v2znlr5);
        }
    }
}
