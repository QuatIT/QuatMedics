<?php


namespace Dompdf\Positioner;

use Dompdf\FrameDecorator\AbstractFrameDecorator;


class ListBullet extends AbstractPositioner
{

    
    function position(AbstractFrameDecorator $Vexjfacrc1d4)
    {

        
        
        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();

        
        
        $Vmm2pe5l4str = $Ve0njdrnxyyx["x"] - $Vexjfacrc1d4->get_width();

        $V2d1s45w0hjo = $Vexjfacrc1d4->find_block_parent();

        $Vuua0v2znlr5 = $V2d1s45w0hjo->get_current_line_box()->y;

        
        $Vu440l53e414 = $Vexjfacrc1d4->get_next_sibling();
        if ($Vu440l53e414) {
            $Vkvw5zjrwkdm = $Vu440l53e414->get_style();
            $Vpoaseiviesy = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->line_height, $Vkvw5zjrwkdm->get_font_size());
            $Veatxxxrhqpk = (float)$Vkvw5zjrwkdm->length_in_pt($Vpoaseiviesy, $Vu440l53e414->get_containing_block("h")) - $Vexjfacrc1d4->get_height();
            $Vuua0v2znlr5 += $Veatxxxrhqpk / 2;
        }

        
        
        
        

        
        
        

        
        
        
        
        
        

        
        

        

        
        $Vexjfacrc1d4->set_position($Vmm2pe5l4str, $Vuua0v2znlr5);
    }
}
