<?php


namespace Dompdf\Positioner;

use Dompdf\FrameDecorator\AbstractFrameDecorator;


class Block extends AbstractPositioner {

    function position(AbstractFrameDecorator $Vexjfacrc1d4)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();
        $V2d1s45w0hjo = $Vexjfacrc1d4->find_block_parent();

        if ($V2d1s45w0hjo) {
            $Va2mt4xafrx1 = $Vkvw5zjrwkdm->float;

            if (!$Va2mt4xafrx1 || $Va2mt4xafrx1 === "none") {
                $V2d1s45w0hjo->add_line(true);
            }
            $Vuua0v2znlr5 = $V2d1s45w0hjo->get_current_line_box()->y;

        } else {
            $Vuua0v2znlr5 = $Ve0njdrnxyyx["y"];
        }

        $Vmm2pe5l4str = $Ve0njdrnxyyx["x"];

        
        if ($Vkvw5zjrwkdm->position === "relative") {
            $Vzn5k4lefp5v = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->top, $Ve0njdrnxyyx["h"]);
            
            
            $Vb5dthqtenbv = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->left, $Ve0njdrnxyyx["w"]);

            $Vmm2pe5l4str += $Vb5dthqtenbv;
            $Vuua0v2znlr5 += $Vzn5k4lefp5v;
        }

        $Vexjfacrc1d4->set_position($Vmm2pe5l4str, $Vuua0v2znlr5);
    }
}
