<?php


namespace Dompdf\Positioner;

use Dompdf\FrameDecorator\AbstractFrameDecorator;


abstract class AbstractPositioner
{

    
    abstract function position(AbstractFrameDecorator $Vexjfacrc1d4);

    
    function move(AbstractFrameDecorator $Vexjfacrc1d4, $Vcsv3vgxrfld, $Vc0f3vxui34y, $V3wcfu0fufa2 = false)
    {
        list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vexjfacrc1d4->get_position();

        if (!$V3wcfu0fufa2) {
            $Vexjfacrc1d4->set_position($Vmm2pe5l4str + $Vcsv3vgxrfld, $Vuua0v2znlr5 + $Vc0f3vxui34y);
        }

        foreach ($Vexjfacrc1d4->get_children() as $V0mqc4rbglqu) {
            $V0mqc4rbglqu->move($Vcsv3vgxrfld, $Vc0f3vxui34y);
        }
    }
}
