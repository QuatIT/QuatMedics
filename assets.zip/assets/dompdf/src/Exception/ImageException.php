<?php

namespace Dompdf\Exception;

use Dompdf\Exception;


class ImageException extends Exception
{

    
    function __construct($V1ocy1gakxau = null, $Vlrwwrp5keo0 = 0)
    {
        parent::__construct($V1ocy1gakxau, $Vlrwwrp5keo0);
    }

}
