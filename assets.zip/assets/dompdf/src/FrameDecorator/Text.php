<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Dompdf;
use Dompdf\Frame;
use Dompdf\Exception;


class Text extends AbstractFrameDecorator
{

    
    protected $Vmryxg4u1dov;

    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        if (!$Vexjfacrc1d4->is_text_node()) {
            throw new Exception("Text_Decorator can only be applied to #text nodes.");
        }

        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);
        $this->_text_spacing = null;
    }

    function reset()
    {
        parent::reset();
        $this->_text_spacing = null;
    }

    

    
    function get_text_spacing()
    {
        return $this->_text_spacing;
    }

    
    function get_text()
    {
        













        return $this->_frame->get_node()->data;
    }

    

    
    function get_margin_height()
    {
        
        
        
        $Vkvw5zjrwkdm = $this->get_parent()->get_style();
        $Vfsinbbqzbga = $Vkvw5zjrwkdm->font_family;
        $Vkgj34o34uaw = $Vkvw5zjrwkdm->font_size;

        

        return ($Vkvw5zjrwkdm->line_height / ($Vkgj34o34uaw > 0 ? $Vkgj34o34uaw : 1)) * $this->_dompdf->getFontMetrics()->getFontHeight($Vfsinbbqzbga, $Vkgj34o34uaw);
    }

    
    function get_padding_box()
    {
        $Vl5irysabalf = $this->_frame->get_padding_box();
        $Vl5irysabalf[3] = $Vl5irysabalf["h"] = $this->_frame->get_style()->height;

        return $Vl5irysabalf;
    }

    
    function set_text_spacing($Vd1hiq0tzl4w)
    {
        $Vkvw5zjrwkdm = $this->_frame->get_style();

        $this->_text_spacing = $Vd1hiq0tzl4w;
        $Vymiqxxasoom = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->letter_spacing);

        
        $Vkvw5zjrwkdm->width = $this->_dompdf->getFontMetrics()->getTextWidth($this->get_text(), $Vkvw5zjrwkdm->font_family, $Vkvw5zjrwkdm->font_size, $Vd1hiq0tzl4w, $Vymiqxxasoom);
    }

    
    function recalculate_width()
    {
        $Vkvw5zjrwkdm = $this->get_style();
        $Vnjapcj4bkpc = $this->get_text();
        $Vkgj34o34uaw = $Vkvw5zjrwkdm->font_size;
        $Vfsinbbqzbga = $Vkvw5zjrwkdm->font_family;
        $Vwvfvnewm3zv = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->word_spacing);
        $Vymiqxxasoom = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->letter_spacing);

        return $Vkvw5zjrwkdm->width = $this->_dompdf->getFontMetrics()->getTextWidth($Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);
    }

    

    
    function split_text($Veatxxxrhqpk)
    {
        if ($Veatxxxrhqpk == 0) {
            return null;
        }

        $Vfcj4ou0pasv = $this->_frame->get_node()->splitText($Veatxxxrhqpk);

        $Vwhoam4hhp4h = $this->copy($Vfcj4ou0pasv);

        $V2d1s45w0hjo = $this->get_parent();
        $V2d1s45w0hjo->insert_child_after($Vwhoam4hhp4h, $this, false);

        if ($V2d1s45w0hjo instanceof Inline) {
            $V2d1s45w0hjo->split($Vwhoam4hhp4h);
        }

        return $Vwhoam4hhp4h;
    }

    
    function delete_text($Veatxxxrhqpk, $V4wukmcy3ij2)
    {
        $this->_frame->get_node()->deleteData($Veatxxxrhqpk, $V4wukmcy3ij2);
    }

    
    function set_text($Vnjapcj4bkpc)
    {
        $this->_frame->get_node()->data = $Vnjapcj4bkpc;
    }
}
