<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Dompdf;
use Dompdf\Frame;
use Dompdf\LineBox;


class Block extends AbstractFrameDecorator
{
    
    protected $Vevqfc1s2a20;

    
    protected $Vf4jlbbnd4dc;

    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);

        $this->_line_boxes = array(new LineBox($this));
        $this->_cl = 0;
    }

    
    function reset()
    {
        parent::reset();

        $this->_line_boxes = array(new LineBox($this));
        $this->_cl = 0;
    }

    
    function get_current_line_box()
    {
        return $this->_line_boxes[$this->_cl];
    }

    
    function get_current_line_number()
    {
        return $this->_cl;
    }

    
    function get_line_boxes()
    {
        return $this->_line_boxes;
    }

    
    function set_current_line_number($Vlp0davv4thm)
    {
        $V3gzf05ynm1o = count($this->_line_boxes);
        $Vg1db0hhmotj = max(min($Vlp0davv4thm, $V3gzf05ynm1o), 0);
        return ($this->_cl = $Vg1db0hhmotj);
    }

    
    function clear_line($V0ixz2v5mxzy)
    {
        if (isset($this->_line_boxes[$V0ixz2v5mxzy])) {
            unset($this->_line_boxes[$V0ixz2v5mxzy]);
        }
    }

    
    function add_frame_to_line(Frame $Vexjfacrc1d4)
    {
        if (!$Vexjfacrc1d4->is_in_flow()) {
            return;
        }

        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        $Vexjfacrc1d4->set_containing_line($this->_line_boxes[$this->_cl]);

        

        
        if ($Vexjfacrc1d4 instanceof Inline) {
            
            if ($Vexjfacrc1d4->get_node()->nodeName === "br") {
                $this->maximize_line_height($Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->line_height), $Vexjfacrc1d4);
                $this->add_line(true);
            }

            return;
        }

        
        
        if ($this->get_current_line_box()->w == 0 &&
            $Vexjfacrc1d4->is_text_node() &&
            !$Vexjfacrc1d4->is_pre()
        ) {
            $Vexjfacrc1d4->set_text(ltrim($Vexjfacrc1d4->get_text()));
            $Vexjfacrc1d4->recalculate_width();
        }

        $V5ymvwogwh5y = $Vexjfacrc1d4->get_margin_width();

        
        
        if ($V5ymvwogwh5y == 0 && $Vexjfacrc1d4->get_node()->nodeName !== "hr") {
            return;
        }

        
        
        

        $V4dr003jf14h = $this->_line_boxes[$this->_cl];
        if ($V4dr003jf14h->left + $V4dr003jf14h->w + $V4dr003jf14h->right + $V5ymvwogwh5y > $this->get_containing_block("w")) {
            $this->add_line();
        }

        $Vexjfacrc1d4->position();

        $V3sydlnnnoip = $this->_line_boxes[$this->_cl];
        $V3sydlnnnoip->add_frame($Vexjfacrc1d4);

        if ($Vexjfacrc1d4->is_text_node()) {
            $V3sydlnnnoip->wc += count(preg_split("/\s+/", trim($Vexjfacrc1d4->get_text())));
        }

        $this->increase_line_width($V5ymvwogwh5y);

        $this->maximize_line_height($Vexjfacrc1d4->get_margin_height(), $Vexjfacrc1d4);
    }

    
    function remove_frames_from_line(Frame $Vexjfacrc1d4)
    {
        
        $V0ixz2v5mxzy = $this->_cl;
        $Vy4wtqjehnh5 = null;

        while ($V0ixz2v5mxzy >= 0) {
            if (($Vy4wtqjehnh5 = in_array($Vexjfacrc1d4, $this->_line_boxes[$V0ixz2v5mxzy]->get_frames(), true)) !== false) {
                break;
            }

            $V0ixz2v5mxzy--;
        }

        if ($Vy4wtqjehnh5 === false) {
            return;
        }

        
        while ($Vy4wtqjehnh5 < count($this->_line_boxes[$V0ixz2v5mxzy]->get_frames())) {
            $Vexjfacrc1d4s = $this->_line_boxes[$V0ixz2v5mxzy]->get_frames();
            $Vtmlsxxw3ne1 = $Vexjfacrc1d4s[$Vy4wtqjehnh5];
            $Vexjfacrc1d4s[$Vy4wtqjehnh5] = null;
            unset($Vexjfacrc1d4s[$Vy4wtqjehnh5]);
            $Vy4wtqjehnh5++;
            $this->_line_boxes[$V0ixz2v5mxzy]->w -= $Vtmlsxxw3ne1->get_margin_width();
        }

        
        $V2pgp3ppbjsi = 0;
        foreach ($this->_line_boxes[$V0ixz2v5mxzy]->get_frames() as $Vtmlsxxw3ne1) {
            $V2pgp3ppbjsi = max($V2pgp3ppbjsi, $Vtmlsxxw3ne1->get_margin_height());
        }

        $this->_line_boxes[$V0ixz2v5mxzy]->h = $V2pgp3ppbjsi;

        
        while ($this->_cl > $V0ixz2v5mxzy) {
            $this->_line_boxes[$this->_cl] = null;
            unset($this->_line_boxes[$this->_cl]);
            $this->_cl--;
        }
    }

    
    function increase_line_width($V5ymvwogwh5y)
    {
        $this->_line_boxes[$this->_cl]->w += $V5ymvwogwh5y;
    }

    
    function maximize_line_height($Vso3o0kfkstx, Frame $Vexjfacrc1d4)
    {
        if ($Vso3o0kfkstx > $this->_line_boxes[$this->_cl]->h) {
            $this->_line_boxes[$this->_cl]->tallest_frame = $Vexjfacrc1d4;
            $this->_line_boxes[$this->_cl]->h = $Vso3o0kfkstx;
        }
    }

    
    function add_line($Vbwp1e1ru2dj = false)
    {




        $this->_line_boxes[$this->_cl]->br = $Vbwp1e1ru2dj;
        $Vuua0v2znlr5 = $this->_line_boxes[$this->_cl]->y + $this->_line_boxes[$this->_cl]->h;

        $Vb04p3h5i5nc = new LineBox($this, $Vuua0v2znlr5);

        $this->_line_boxes[++$this->_cl] = $Vb04p3h5i5nc;
    }

    
}
