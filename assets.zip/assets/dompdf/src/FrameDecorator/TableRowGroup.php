<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Dompdf;
use Dompdf\Frame;


class TableRowGroup extends AbstractFrameDecorator
{

    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);
    }

    
    function split(Frame $V0mqc4rbglqu = null, $Vptkg4lgmmwq = false)
    {
        if (is_null($V0mqc4rbglqu)) {
            parent::split();
            return;
        }

        
        $V5hlwkutan5t = $this->get_parent()->get_cellmap();
        $Vrlw4pv311lc = $V0mqc4rbglqu;

        while ($Vrlw4pv311lc) {
            $V5hlwkutan5t->remove_row($Vrlw4pv311lc);
            $Vrlw4pv311lc = $Vrlw4pv311lc->get_next_sibling();
        }

        
        
        if ($V0mqc4rbglqu === $this->get_first_child()) {
            $V5hlwkutan5t->remove_row_group($this);
            parent::split();
            return;
        }

        $V5hlwkutan5t->update_row_group($this, $V0mqc4rbglqu->get_prev_sibling());
        parent::split($V0mqc4rbglqu);
    }
}

