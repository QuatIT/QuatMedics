<?php

namespace Dompdf\FrameDecorator;

use DOMElement;
use DOMNode;
use DOMText;
use Dompdf\Helpers;
use Dompdf\Dompdf;
use Dompdf\Frame;
use Dompdf\Frame\FrameTreeList;
use Dompdf\Frame\Factory;
use Dompdf\FrameReflower\AbstractFrameReflower;
use Dompdf\Css\Style;
use Dompdf\Positioner\AbstractPositioner;
use Dompdf\Exception;




abstract class AbstractFrameDecorator extends Frame
{
    const DEFAULT_COUNTER = "-dompdf-default-counter";

    public $Vca0svovlv0w = array(); 

    
    protected $Vebl3bww3mws;

    
    protected $Vzyb2djzba42;

    
    protected $Vtftq2arvezm;

    
    protected $Vgk54oph3jsu;

    
    protected $V3zitx0n32g4;

    
    private $Vnacorns3rpz;

    
    private $Vbo5iy5klroe;

    
    private $Vkqmstor3vdp;

    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        $this->_frame = $Vexjfacrc1d4;
        $this->_root = null;
        $this->_dompdf = $Vodc45cwlwwh;
        $Vexjfacrc1d4->set_decorator($this);
    }

    
    function dispose($Vii3tktgpo24 = false)
    {
        if ($Vii3tktgpo24) {
            while ($V0mqc4rbglqu = $this->get_first_child()) {
                $V0mqc4rbglqu->dispose(true);
            }
        }

        $this->_root = null;
        unset($this->_root);

        $this->_frame->dispose(true);
        $this->_frame = null;
        unset($this->_frame);

        $this->_positioner = null;
        unset($this->_positioner);

        $this->_reflower = null;
        unset($this->_reflower);
    }

    
    function copy(DOMNode $Vivp5mmrkfpz)
    {
        $Vexjfacrc1d4 = new Frame($Vivp5mmrkfpz);
        $Vexjfacrc1d4->set_style(clone $this->_frame->get_original_style());

        return Factory::decorate_frame($Vexjfacrc1d4, $this->_dompdf, $this->_root);
    }

    
    function deep_copy()
    {
        $Vivp5mmrkfpz = $this->_frame->get_node();

        if ($Vivp5mmrkfpz instanceof DOMElement && $Vivp5mmrkfpz->hasAttribute("id")) {
            $Vivp5mmrkfpz->setAttribute("data-dompdf-original-id", $Vivp5mmrkfpz->getAttribute("id"));
            $Vivp5mmrkfpz->removeAttribute("id");
        }

        $Vexjfacrc1d4 = new Frame($Vivp5mmrkfpz->cloneNode());
        $Vexjfacrc1d4->set_style(clone $this->_frame->get_original_style());

        $Vwhoam4hhp4h = Factory::decorate_frame($Vexjfacrc1d4, $this->_dompdf, $this->_root);

        foreach ($this->get_children() as $V0mqc4rbglqu) {
            $Vwhoam4hhp4h->append_child($V0mqc4rbglqu->deep_copy());
        }

        return $Vwhoam4hhp4h;
    }

    
    function reset()
    {
        $this->_frame->reset();

        $this->_counters = array();

        $this->_cached_parent = null; 

        
        foreach ($this->get_children() as $V0mqc4rbglqu) {
            $V0mqc4rbglqu->reset();
        }
    }

    

    
    function get_id()
    {
        return $this->_frame->get_id();
    }

    
    function get_frame()
    {
        return $this->_frame;
    }

    
    function get_node()
    {
        return $this->_frame->get_node();
    }

    
    function get_style()
    {
        return $this->_frame->get_style();
    }

    
    function get_original_style()
    {
        return $this->_frame->get_original_style();
    }

    
    function get_containing_block($V0ixz2v5mxzy = null)
    {
        return $this->_frame->get_containing_block($V0ixz2v5mxzy);
    }

    
    function get_position($V0ixz2v5mxzy = null)
    {
        return $this->_frame->get_position($V0ixz2v5mxzy);
    }

    
    function get_dompdf()
    {
        return $this->_dompdf;
    }

    
    function get_margin_height()
    {
        return $this->_frame->get_margin_height();
    }

    
    function get_margin_width()
    {
        return $this->_frame->get_margin_width();
    }

    
    function get_content_box()
    {
        return $this->_frame->get_content_box();
    }

    
    function get_padding_box()
    {
        return $this->_frame->get_padding_box();
    }

    
    function get_border_box()
    {
        return $this->_frame->get_border_box();
    }

    
    function set_id($V0ixz2v5mxzyd)
    {
        $this->_frame->set_id($V0ixz2v5mxzyd);
    }

    
    function set_style(Style $Vkvw5zjrwkdm)
    {
        $this->_frame->set_style($Vkvw5zjrwkdm);
    }

    
    function set_containing_block($Vmm2pe5l4str = null, $Vuua0v2znlr5 = null, $V5ymvwogwh5y = null, $V2pgp3ppbjsi = null)
    {
        $this->_frame->set_containing_block($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
    }

    
    function set_position($Vmm2pe5l4str = null, $Vuua0v2znlr5 = null)
    {
        $this->_frame->set_position($Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    
    function is_auto_height()
    {
        return $this->_frame->is_auto_height();
    }

    
    function is_auto_width()
    {
        return $this->_frame->is_auto_width();
    }

    
    function __toString()
    {
        return $this->_frame->__toString();
    }

    
    function prepend_child(Frame $V0mqc4rbglqu, $Vki3dyk1gmh5 = true)
    {
        while ($V0mqc4rbglqu instanceof AbstractFrameDecorator) {
            $V0mqc4rbglqu = $V0mqc4rbglqu->_frame;
        }

        $this->_frame->prepend_child($V0mqc4rbglqu, $Vki3dyk1gmh5);
    }

    
    function append_child(Frame $V0mqc4rbglqu, $Vki3dyk1gmh5 = true)
    {
        while ($V0mqc4rbglqu instanceof AbstractFrameDecorator) {
            $V0mqc4rbglqu = $V0mqc4rbglqu->_frame;
        }

        $this->_frame->append_child($V0mqc4rbglqu, $Vki3dyk1gmh5);
    }

    
    function insert_child_before(Frame $Ved1ducby00s, Frame $Va3fv30cr5cz, $Vki3dyk1gmh5 = true)
    {
        while ($Ved1ducby00s instanceof AbstractFrameDecorator) {
            $Ved1ducby00s = $Ved1ducby00s->_frame;
        }

        if ($Va3fv30cr5cz instanceof AbstractFrameDecorator) {
            $Va3fv30cr5cz = $Va3fv30cr5cz->_frame;
        }

        $this->_frame->insert_child_before($Ved1ducby00s, $Va3fv30cr5cz, $Vki3dyk1gmh5);
    }

    
    function insert_child_after(Frame $Ved1ducby00s, Frame $Va3fv30cr5cz, $Vki3dyk1gmh5 = true)
    {
        $V0ixz2v5mxzynsert_frame = $Ved1ducby00s;
        while ($V0ixz2v5mxzynsert_frame instanceof AbstractFrameDecorator) {
            $V0ixz2v5mxzynsert_frame = $V0ixz2v5mxzynsert_frame->_frame;
        }

        $Va3fv30cr5czerence_frame = $Va3fv30cr5cz;
        while ($Va3fv30cr5czerence_frame instanceof AbstractFrameDecorator) {
            $Va3fv30cr5czerence_frame = $Va3fv30cr5czerence_frame->_frame;
        }

        $this->_frame->insert_child_after($V0ixz2v5mxzynsert_frame, $Va3fv30cr5czerence_frame, $Vki3dyk1gmh5);
    }

    
    function remove_child(Frame $V0mqc4rbglqu, $Vki3dyk1gmh5 = true)
    {
        while ($V0mqc4rbglqu instanceof AbstractFrameDecorator) {
            $V0mqc4rbglqu = $V0mqc4rbglqu->_frame;
        }

        return $this->_frame->remove_child($V0mqc4rbglqu, $Vki3dyk1gmh5);
    }

    
    function get_parent($V0oofmmokvcv = true)
    {
        if ($V0oofmmokvcv && $this->_cached_parent) {
            return $this->_cached_parent;
        }
        $V2d1s45w0hjo = $this->_frame->get_parent();
        if ($V2d1s45w0hjo && $Vwhoam4hhp4h = $V2d1s45w0hjo->get_decorator()) {
            while ($Vj0eqma35tbv = $Vwhoam4hhp4h->get_decorator()) {
                $Vwhoam4hhp4h = $Vj0eqma35tbv;
            }

            return $this->_cached_parent = $Vwhoam4hhp4h;
        } else {
            return $this->_cached_parent = $V2d1s45w0hjo;
        }
    }

    
    function get_first_child()
    {
        $Vdiqkcy1hsm4 = $this->_frame->get_first_child();
        if ($Vdiqkcy1hsm4 && $Vwhoam4hhp4h = $Vdiqkcy1hsm4->get_decorator()) {
            while ($Vj0eqma35tbv = $Vwhoam4hhp4h->get_decorator()) {
                $Vwhoam4hhp4h = $Vj0eqma35tbv;
            }

            return $Vwhoam4hhp4h;
        } else {
            if ($Vdiqkcy1hsm4) {
                return $Vdiqkcy1hsm4;
            }
        }

        return null;
    }

    
    function get_last_child()
    {
        $Vdiqkcy1hsm4 = $this->_frame->get_last_child();
        if ($Vdiqkcy1hsm4 && $Vwhoam4hhp4h = $Vdiqkcy1hsm4->get_decorator()) {
            while ($Vj0eqma35tbv = $Vwhoam4hhp4h->get_decorator()) {
                $Vwhoam4hhp4h = $Vj0eqma35tbv;
            }

            return $Vwhoam4hhp4h;
        } else {
            if ($Vdiqkcy1hsm4) {
                return $Vdiqkcy1hsm4;
            }
        }

        return null;
    }

    
    function get_prev_sibling()
    {
        $V500t5q0ulgs = $this->_frame->get_prev_sibling();
        if ($V500t5q0ulgs && $Vwhoam4hhp4h = $V500t5q0ulgs->get_decorator()) {
            while ($Vj0eqma35tbv = $Vwhoam4hhp4h->get_decorator()) {
                $Vwhoam4hhp4h = $Vj0eqma35tbv;
            }

            return $Vwhoam4hhp4h;
        } else {
            if ($V500t5q0ulgs) {
                return $V500t5q0ulgs;
            }
        }

        return null;
    }

    
    function get_next_sibling()
    {
        $V500t5q0ulgs = $this->_frame->get_next_sibling();
        if ($V500t5q0ulgs && $Vwhoam4hhp4h = $V500t5q0ulgs->get_decorator()) {
            while ($Vj0eqma35tbv = $Vwhoam4hhp4h->get_decorator()) {
                $Vwhoam4hhp4h = $Vj0eqma35tbv;
            }

            return $Vwhoam4hhp4h;
        } else {
            if ($V500t5q0ulgs) {
                return $V500t5q0ulgs;
            }
        }

        return null;
    }

    
    function get_subtree()
    {
        return new FrameTreeList($this);
    }

    function set_positioner(AbstractPositioner $V2d1s45w0hjoosn)
    {
        $this->_positioner = $V2d1s45w0hjoosn;
        if ($this->_frame instanceof AbstractFrameDecorator) {
            $this->_frame->set_positioner($V2d1s45w0hjoosn);
        }
    }

    function set_reflower(AbstractFrameReflower $Va3fv30cr5czlower)
    {
        $this->_reflower = $Va3fv30cr5czlower;
        if ($this->_frame instanceof AbstractFrameDecorator) {
            $this->_frame->set_reflower($Va3fv30cr5czlower);
        }
    }

    
    function get_reflower()
    {
        return $this->_reflower;
    }

    
    function set_root(Frame $Vfqvundqbe4u)
    {
        $this->_root = $Vfqvundqbe4u;

        if ($this->_frame instanceof AbstractFrameDecorator) {
            $this->_frame->set_root($Vfqvundqbe4u);
        }
    }

    
    function get_root()
    {
        return $this->_root;
    }

    
    function find_block_parent()
    {
        
        $V2d1s45w0hjo = $this->get_parent();

        while ($V2d1s45w0hjo) {
            if ($V2d1s45w0hjo->is_block()) {
                break;
            }

            $V2d1s45w0hjo = $V2d1s45w0hjo->get_parent();
        }

        return $this->_block_parent = $V2d1s45w0hjo;
    }

    
    function find_positionned_parent()
    {
        
        $V2d1s45w0hjo = $this->get_parent();
        while ($V2d1s45w0hjo) {
            if ($V2d1s45w0hjo->is_positionned()) {
                break;
            }

            $V2d1s45w0hjo = $V2d1s45w0hjo->get_parent();
        }

        if (!$V2d1s45w0hjo) {
            $V2d1s45w0hjo = $this->_root->get_first_child(); 
        }

        return $this->_positionned_parent = $V2d1s45w0hjo;
    }

    
    function split(Frame $V0mqc4rbglqu = null, $Vptkg4lgmmwq = false)
    {
        
        $Vkvw5zjrwkdm = $this->_frame->get_style();
        if (
            $this->_frame->get_node()->nodeName !== "body" &&
            $Vkvw5zjrwkdm->counter_increment &&
            ($Vglcwhqijcxu = $Vkvw5zjrwkdm->counter_increment) !== "none"
        ) {
            $this->decrement_counters($Vglcwhqijcxu);
        }

        if (is_null($V0mqc4rbglqu)) {
            
            
            
            if (!$this->is_text_node() && $this->get_node()->hasAttribute("dompdf_before_frame_id")) {
                foreach ($this->_frame->get_children() as $V0mqc4rbglqu) {
                    if (
                        $this->get_node()->getAttribute("dompdf_before_frame_id") == $V0mqc4rbglqu->get_id() &&
                        $V0mqc4rbglqu->get_position('x') !== null
                    ) {
                        $Vkvw5zjrwkdm = $V0mqc4rbglqu->get_style();
                        if ($Vkvw5zjrwkdm->counter_increment && ($Vglcwhqijcxu = $Vkvw5zjrwkdm->counter_increment) !== "none") {
                            $this->decrement_counters($Vglcwhqijcxu);
                        }
                    }
                }
            }
            $this->get_parent()->split($this, $Vptkg4lgmmwq);

            return;
        }

        if ($V0mqc4rbglqu->get_parent() !== $this) {
            throw new Exception("Unable to split: frame is not a child of this one.");
        }

        $Vivp5mmrkfpz = $this->_frame->get_node();

        if ($Vivp5mmrkfpz instanceof DOMElement && $Vivp5mmrkfpz->hasAttribute("id")) {
            $Vivp5mmrkfpz->setAttribute("data-dompdf-original-id", $Vivp5mmrkfpz->getAttribute("id"));
            $Vivp5mmrkfpz->removeAttribute("id");
        }

        $V500t5q0ulgsplit = $this->copy($Vivp5mmrkfpz->cloneNode());
        $V500t5q0ulgsplit->reset();
        $V500t5q0ulgsplit->get_original_style()->text_indent = 0;
        $V500t5q0ulgsplit->_splitted = true;
        $V500t5q0ulgsplit->_already_pushed = true;

        
        if ($Vivp5mmrkfpz->nodeName !== "body") {
            
            $Vkvw5zjrwkdm = $this->_frame->get_style();
            $Vkvw5zjrwkdm->margin_bottom = 0;
            $Vkvw5zjrwkdm->padding_bottom = 0;
            $Vkvw5zjrwkdm->border_bottom = 0;

            
            $Vbcrj2f5ypbf = $V500t5q0ulgsplit->get_original_style();
            $Vbcrj2f5ypbf->text_indent = 0;
            $Vbcrj2f5ypbf->margin_top = 0;
            $Vbcrj2f5ypbf->padding_top = 0;
            $Vbcrj2f5ypbf->border_top = 0;
            $Vbcrj2f5ypbf->page_break_before = "auto";
        }

        
        $this->get_parent()->insert_child_after($V500t5q0ulgsplit, $this);
        if ($this instanceof Block) {
            foreach ($this->get_line_boxes() as $V0ixz2v5mxzyndex => $V2sd5a4r2ikr) {
                $V2sd5a4r2ikr->get_float_offsets();
            }
        }

        
        $V0ixz2v5mxzyter = $V0mqc4rbglqu;
        while ($V0ixz2v5mxzyter) {
            $Vexjfacrc1d4 = $V0ixz2v5mxzyter;
            $V0ixz2v5mxzyter = $V0ixz2v5mxzyter->get_next_sibling();
            $Vexjfacrc1d4->reset();
            $Vexjfacrc1d4->_parent = $V500t5q0ulgsplit;
            $V500t5q0ulgsplit->append_child($Vexjfacrc1d4);

            
            if ($Vexjfacrc1d4 instanceof Block) {
                foreach ($Vexjfacrc1d4->get_line_boxes() as $V0ixz2v5mxzyndex => $V2sd5a4r2ikr) {
                    $V2sd5a4r2ikr->get_float_offsets();
                }
            }
        }

        $this->get_parent()->split($V500t5q0ulgsplit, $Vptkg4lgmmwq);

        
        if ($Vkvw5zjrwkdm->counter_reset && ($Voebzkq0mr0z = $Vkvw5zjrwkdm->counter_reset) !== "none") {
            $Vuuqvgibroyo = preg_split('/\s+/', trim($Voebzkq0mr0z), 2);
            $V500t5q0ulgsplit->_counters['__' . $Vuuqvgibroyo[0]] = $this->lookup_counter_frame($Vuuqvgibroyo[0])->_counters[$Vuuqvgibroyo[0]];
        }
    }

    
    function reset_counter($V0ixz2v5mxzyd = self::DEFAULT_COUNTER, $Veugw2h43vxz = 0)
    {
        $this->get_parent()->_counters[$V0ixz2v5mxzyd] = intval($Veugw2h43vxz);
    }

    
    function decrement_counters($Vdiqkcy1hsm4ounters)
    {
        foreach ($Vdiqkcy1hsm4ounters as $V0ixz2v5mxzyd => $V0ixz2v5mxzyncrement) {
            $this->increment_counter($V0ixz2v5mxzyd, intval($V0ixz2v5mxzyncrement) * -1);
        }
    }

    
    function increment_counters($Vdiqkcy1hsm4ounters)
    {
        foreach ($Vdiqkcy1hsm4ounters as $V0ixz2v5mxzyd => $V0ixz2v5mxzyncrement) {
            $this->increment_counter($V0ixz2v5mxzyd, intval($V0ixz2v5mxzyncrement));
        }
    }

    
    function increment_counter($V0ixz2v5mxzyd = self::DEFAULT_COUNTER, $V0ixz2v5mxzyncrement = 1)
    {
        $Vdiqkcy1hsm4ounter_frame = $this->lookup_counter_frame($V0ixz2v5mxzyd);

        if ($Vdiqkcy1hsm4ounter_frame) {
            if (!isset($Vdiqkcy1hsm4ounter_frame->_counters[$V0ixz2v5mxzyd])) {
                $Vdiqkcy1hsm4ounter_frame->_counters[$V0ixz2v5mxzyd] = 0;
            }

            $Vdiqkcy1hsm4ounter_frame->_counters[$V0ixz2v5mxzyd] += $V0ixz2v5mxzyncrement;
        }
    }

    
    function lookup_counter_frame($V0ixz2v5mxzyd = self::DEFAULT_COUNTER)
    {
        $Vtmlsxxw3ne1 = $this->get_parent();

        while ($Vtmlsxxw3ne1) {
            if (isset($Vtmlsxxw3ne1->_counters[$V0ixz2v5mxzyd])) {
                return $Vtmlsxxw3ne1;
            }
            $Vtmlsxxw3ne1p = $Vtmlsxxw3ne1->get_parent();

            if (!$Vtmlsxxw3ne1p) {
                return $Vtmlsxxw3ne1;
            }

            $Vtmlsxxw3ne1 = $Vtmlsxxw3ne1p;
        }

        return null;
    }

    
    function counter_value($V0ixz2v5mxzyd = self::DEFAULT_COUNTER, $Vky1xzjrvbn4 = "decimal")
    {
        $Vky1xzjrvbn4 = mb_strtolower($Vky1xzjrvbn4);

        if (!isset($this->_counters[$V0ixz2v5mxzyd])) {
            $this->_counters[$V0ixz2v5mxzyd] = 0;
        }

        $Veugw2h43vxz = $this->_counters[$V0ixz2v5mxzyd];

        switch ($Vky1xzjrvbn4) {
            default:
            case "decimal":
                return $Veugw2h43vxz;

            case "decimal-leading-zero":
                return str_pad($Veugw2h43vxz, 2, "0", STR_PAD_LEFT);

            case "lower-roman":
                return Helpers::dec2roman($Veugw2h43vxz);

            case "upper-roman":
                return mb_strtoupper(Helpers::dec2roman($Veugw2h43vxz));

            case "lower-latin":
            case "lower-alpha":
                return chr(($Veugw2h43vxz % 26) + ord('a') - 1);

            case "upper-latin":
            case "upper-alpha":
                return chr(($Veugw2h43vxz % 26) + ord('A') - 1);

            case "lower-greek":
                return Helpers::unichr($Veugw2h43vxz + 944);

            case "upper-greek":
                return Helpers::unichr($Veugw2h43vxz + 912);
        }
    }

    
    final function position()
    {
        $this->_positioner->position($this);
    }

    
    final function move($Vcsv3vgxrfld, $Vc0f3vxui34y, $V0ixz2v5mxzygnore_self = false)
    {
        $this->_positioner->move($this, $Vcsv3vgxrfld, $Vc0f3vxui34y, $V0ixz2v5mxzygnore_self);
    }

    
    final function reflow(Block $Vynts1bqvpvb = null)
    {
        
        
        
        $this->_reflower->reflow($Vynts1bqvpvb);
    }

    
    final function get_min_max_width()
    {
        return $this->_reflower->get_min_max_width();
    }

    
    final function calculate_auto_width()
    {
        return $this->_reflower->calculate_auto_width();
    }
}
