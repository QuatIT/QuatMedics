<?php

namespace Dompdf\FrameDecorator;

use DOMElement;
use Dompdf\Dompdf;
use Dompdf\Frame;
use Dompdf\Exception;


class Inline extends AbstractFrameDecorator
{

    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);
    }

    
    function split(Frame $Vexjfacrc1d4 = null, $Vptkg4lgmmwq = false)
    {
        if (is_null($Vexjfacrc1d4)) {
            $this->get_parent()->split($this, $Vptkg4lgmmwq);
            return;
        }

        if ($Vexjfacrc1d4->get_parent() !== $this) {
            throw new Exception("Unable to split: frame is not a child of this one.");
        }

        $Vivp5mmrkfpz = $this->_frame->get_node();

        if ($Vivp5mmrkfpz instanceof DOMElement && $Vivp5mmrkfpz->hasAttribute("id")) {
            $Vivp5mmrkfpz->setAttribute("data-dompdf-original-id", $Vivp5mmrkfpz->getAttribute("id"));
            $Vivp5mmrkfpz->removeAttribute("id");
        }

        $Vfcj4ou0pasv = $this->copy($Vivp5mmrkfpz->cloneNode());
        
        if ($Vfcj4ou0pasv->get_node()->nodeName == "dompdf_generated") {
            $Vfcj4ou0pasv->get_style()->content = "normal";
        }
        $this->get_parent()->insert_child_after($Vfcj4ou0pasv, $this);

        
        $Vkvw5zjrwkdm = $this->_frame->get_style();
        $Vkvw5zjrwkdm->margin_right = 0;
        $Vkvw5zjrwkdm->padding_right = 0;
        $Vkvw5zjrwkdm->border_right_width = 0;

        
        
        $Vkvw5zjrwkdm = $Vfcj4ou0pasv->get_style();
        $Vkvw5zjrwkdm->margin_left = 0;
        $Vkvw5zjrwkdm->padding_left = 0;
        $Vkvw5zjrwkdm->border_left_width = 0;

        
        
        
        if (($Vop22rgf5euu = $Vkvw5zjrwkdm->background_image) && $Vop22rgf5euu !== "none"
            && ($Vf41t341wqpb = $Vkvw5zjrwkdm->background_repeat) && $Vf41t341wqpb !== "repeat" && $Vf41t341wqpb !== "repeat-y"
        ) {
            $Vkvw5zjrwkdm->background_image = "none";
        }

        
        $Vrlw4pv311lc = $Vexjfacrc1d4;
        while ($Vrlw4pv311lc) {
            $Vexjfacrc1d4 = $Vrlw4pv311lc;
            $Vrlw4pv311lc = $Vrlw4pv311lc->get_next_sibling();
            $Vexjfacrc1d4->reset();
            $Vfcj4ou0pasv->append_child($Vexjfacrc1d4);
        }

        $Vv2hkri1jd3p = array("always", "left", "right");
        $Vexjfacrc1d4_style = $Vexjfacrc1d4->get_style();
        if ($Vptkg4lgmmwq ||
            in_array($Vexjfacrc1d4_style->page_break_before, $Vv2hkri1jd3p) ||
            in_array($Vexjfacrc1d4_style->page_break_after, $Vv2hkri1jd3p)
        ) {
            $this->get_parent()->split($Vfcj4ou0pasv, true);
        }
    }

}
