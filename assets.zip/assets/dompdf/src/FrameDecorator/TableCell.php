<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Dompdf;
use Dompdf\Frame;
use Dompdf\FrameDecorator\Block as BlockFrameDecorator;


class TableCell extends BlockFrameDecorator
{

    protected $Vh5kxtubkpp5;
    protected $Vxdnwgy4rvik;

    

    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);
        $this->_resolved_borders = array();
        $this->_content_height = 0;
    }

    

    function reset()
    {
        parent::reset();
        $this->_resolved_borders = array();
        $this->_content_height = 0;
        $this->_frame->reset();
    }

    
    function get_content_height()
    {
        return $this->_content_height;
    }

    
    function set_content_height($Vxtfrabd3i5r)
    {
        $this->_content_height = $Vxtfrabd3i5r;
    }

    
    function set_cell_height($Vxtfrabd3i5r)
    {
        $Vkvw5zjrwkdm = $this->get_style();
        $Ve2xvg5x3d3q = (float)$Vkvw5zjrwkdm->length_in_pt(
            array(
                $Vkvw5zjrwkdm->margin_top,
                $Vkvw5zjrwkdm->padding_top,
                $Vkvw5zjrwkdm->border_top_width,
                $Vkvw5zjrwkdm->border_bottom_width,
                $Vkvw5zjrwkdm->padding_bottom,
                $Vkvw5zjrwkdm->margin_bottom
            ),
            (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->height)
        );

        $V0szsvgefcc2 = $Vxtfrabd3i5r - $Ve2xvg5x3d3q;
        $Vkvw5zjrwkdm->height = $V0szsvgefcc2;

        if ($V0szsvgefcc2 > $this->_content_height) {
            $Vnaokt1s1vzq = 0;

            
            switch ($Vkvw5zjrwkdm->vertical_align) {
                default:
                case "baseline":
                    

                case "top":
                    
                    return;

                case "middle":
                    $Vnaokt1s1vzq = ($V0szsvgefcc2 - $this->_content_height) / 2;
                    break;

                case "bottom":
                    $Vnaokt1s1vzq = $V0szsvgefcc2 - $this->_content_height;
                    break;
            }

            if ($Vnaokt1s1vzq) {
                
                foreach ($this->get_line_boxes() as $V4dr003jf14h) {
                    foreach ($V4dr003jf14h->get_frames() as $Vexjfacrc1d4) {
                        $Vexjfacrc1d4->move(0, $Vnaokt1s1vzq);
                    }
                }
            }
        }
    }

    
    function set_resolved_border($Vcxi3be0s51c, $V5bfp4hxgu3a)
    {
        $this->_resolved_borders[$Vcxi3be0s51c] = $V5bfp4hxgu3a;
    }

    
    function get_resolved_border($Vcxi3be0s51c)
    {
        return $this->_resolved_borders[$Vcxi3be0s51c];
    }

    
    function get_resolved_borders()
    {
        return $this->_resolved_borders;
    }
}
