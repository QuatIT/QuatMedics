<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Cellmap;
use DOMNode;
use Dompdf\Dompdf;
use Dompdf\Frame;
use Dompdf\Frame\Factory;


class Table extends AbstractFrameDecorator
{
    public static $Voqtprocxlmi = array(
        "table-row-group",
        "table-row",
        "table-header-group",
        "table-footer-group",
        "table-column",
        "table-column-group",
        "table-caption",
        "table-cell"
    );

    public static $V420otj4lzb1 = array(
        'table-row-group',
        'table-header-group',
        'table-footer-group'
    );

    
    protected $Vkonrtp55cfr;

    
    protected $Viopuzjlmwfa;

    
    protected $V50bz2bu4hza;

    
    protected $Vq2fr53hsq5z;

    
    protected $Vputngjruifg;

    
    public function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);
        $this->_cellmap = new Cellmap($this);

        if ($Vexjfacrc1d4->get_style()->table_layout === "fixed") {
            $this->_cellmap->set_layout_fixed(true);
        }

        $this->_min_width = null;
        $this->_max_width = null;
        $this->_headers = array();
        $this->_footers = array();
    }

    public function reset()
    {
        parent::reset();
        $this->_cellmap->reset();
        $this->_min_width = null;
        $this->_max_width = null;
        $this->_headers = array();
        $this->_footers = array();
        $this->_reflower->reset();
    }

    

    
    public function split(Frame $V0mqc4rbglqu = null, $Vptkg4lgmmwq = false)
    {
        if (is_null($V0mqc4rbglqu)) {
            parent::split();

            return;
        }

        
        
        if (count($this->_headers) && !in_array($V0mqc4rbglqu, $this->_headers, true) &&
            !in_array($V0mqc4rbglqu->get_prev_sibling(), $this->_headers, true)
        ) {
            $Vtrjqqdmofyy = null;

            
            foreach ($this->_headers as $Vkwhjduzezf4) {

                $Vbwd33ic3fcs = $Vkwhjduzezf4->deep_copy();

                if (is_null($Vtrjqqdmofyy)) {
                    $Vtrjqqdmofyy = $Vbwd33ic3fcs;
                }

                $this->insert_child_before($Vbwd33ic3fcs, $V0mqc4rbglqu);
            }

            parent::split($Vtrjqqdmofyy);

        } elseif (in_array($V0mqc4rbglqu->get_style()->display, self::$V420otj4lzb1)) {

            
            parent::split($V0mqc4rbglqu);

        } else {

            $Vrlw4pv311lc = $V0mqc4rbglqu;

            while ($Vrlw4pv311lc) {
                $this->_cellmap->remove_row($Vrlw4pv311lc);
                $Vrlw4pv311lc = $Vrlw4pv311lc->get_next_sibling();
            }

            parent::split($V0mqc4rbglqu);
        }
    }

    
    public function copy(DOMNode $Vivp5mmrkfpz)
    {
        $Vwhoam4hhp4h = parent::copy($Vivp5mmrkfpz);

        
        $Vwhoam4hhp4h->_cellmap->set_columns($this->_cellmap->get_columns());
        $Vwhoam4hhp4h->_cellmap->lock_columns();

        return $Vwhoam4hhp4h;
    }

    
    public static function find_parent_table(Frame $Vexjfacrc1d4)
    {
        while ($Vexjfacrc1d4 = $Vexjfacrc1d4->get_parent()) {
            if ($Vexjfacrc1d4->is_table()) {
                break;
            }
        }

        return $Vexjfacrc1d4;
    }

    
    public function get_cellmap()
    {
        return $this->_cellmap;
    }

    
    public function get_min_width()
    {
        return $this->_min_width;
    }

    
    public function get_max_width()
    {
        return $this->_max_width;
    }

    
    public function set_min_width($Vtt4kvdwuqqh)
    {
        $this->_min_width = $Vtt4kvdwuqqh;
    }

    
    public function set_max_width($Vtt4kvdwuqqh)
    {
        $this->_max_width = $Vtt4kvdwuqqh;
    }

    
    public function normalise()
    {
        
        $Vnaq20kbhsei = array();
        $Vs1pmb2xng45 = false;
        $Vrlw4pv311lc = $this->get_first_child();
        while ($Vrlw4pv311lc) {
            $V0mqc4rbglqu = $Vrlw4pv311lc;
            $Vrlw4pv311lc = $Vrlw4pv311lc->get_next_sibling();

            $Vqzifj31psr1 = $V0mqc4rbglqu->get_style()->display;

            if ($Vs1pmb2xng45) {

                if ($Vqzifj31psr1 === "table-row") {
                    
                    $this->insert_child_before($Vhrwpjwvf5uz, $V0mqc4rbglqu);

                    $Vhrwpjwvf5uz->normalise();
                    $V0mqc4rbglqu->normalise();
                    $this->_cellmap->add_row();
                    $Vs1pmb2xng45 = false;
                    continue;
                }

                
                $Vhrwpjwvf5uz->append_child($V0mqc4rbglqu);
                continue;

            } else {

                if ($Vqzifj31psr1 === "table-row") {
                    $V0mqc4rbglqu->normalise();
                    continue;
                }

                if ($Vqzifj31psr1 === "table-cell") {
                    $Vezwmkkcp5ez = $this->get_style()->get_stylesheet();

                    
                    $Vj2ywqr0lj2f = $this->get_node()->ownerDocument->createElement("tbody");

                    $Vexjfacrc1d4 = new Frame($Vj2ywqr0lj2f);

                    $Vkvw5zjrwkdm = $Vezwmkkcp5ez->create_style();
                    $Vkvw5zjrwkdm->inherit($this->get_style());

                    
                    
                    
                    if ($Vj2ywqr0lj2f_style = $Vezwmkkcp5ez->lookup("tbody")) {
                        $Vkvw5zjrwkdm->merge($Vj2ywqr0lj2f_style);
                    }
                    $Vkvw5zjrwkdm->display = 'table-row-group';

                    
                    
                    $Vexjfacrc1d4->set_style($Vkvw5zjrwkdm);
                    $Vhrwpjwvf5uz_group = Factory::decorate_frame($Vexjfacrc1d4, $this->_dompdf, $this->_root);

                    
                    $Vkfno1tgq5nc = $this->get_node()->ownerDocument->createElement("tr");

                    $Vexjfacrc1d4 = new Frame($Vkfno1tgq5nc);

                    $Vkvw5zjrwkdm = $Vezwmkkcp5ez->create_style();
                    $Vkvw5zjrwkdm->inherit($this->get_style());

                    
                    
                    
                    if ($Vkfno1tgq5nc_style = $Vezwmkkcp5ez->lookup("tr")) {
                        $Vkvw5zjrwkdm->merge($Vkfno1tgq5nc_style);
                    }
                    $Vkvw5zjrwkdm->display = 'table-row';

                    
                    
                    $Vexjfacrc1d4->set_style(clone $Vkvw5zjrwkdm);
                    $Vhrwpjwvf5uz = Factory::decorate_frame($Vexjfacrc1d4, $this->_dompdf, $this->_root);

                    
                    $Vhrwpjwvf5uz->append_child($V0mqc4rbglqu, true);

                    
                    $Vhrwpjwvf5uz_group->append_child($Vhrwpjwvf5uz, true);

                    $Vs1pmb2xng45 = true;
                    continue;
                }

                if (!in_array($Vqzifj31psr1, self::$Voqtprocxlmi)) {
                    $Vnaq20kbhsei[] = $V0mqc4rbglqu;
                    continue;
                }

                
                foreach ($V0mqc4rbglqu->get_children() as $V113omc5zuqd) {
                    if ($V113omc5zuqd->get_style()->display === "table-row") {
                        $V113omc5zuqd->normalise();
                    }
                }

                
                if ($Vqzifj31psr1 === "table-header-group") {
                    $this->_headers[] = $V0mqc4rbglqu;
                } elseif ($Vqzifj31psr1 === "table-footer-group") {
                    $this->_footers[] = $V0mqc4rbglqu;
                }
            }
        }

        if ($Vs1pmb2xng45 && $Vhrwpjwvf5uz_group instanceof AbstractFrameDecorator) {
            
            $this->_frame->append_child($Vhrwpjwvf5uz_group->_frame);
            $Vhrwpjwvf5uz->normalise();
        }

        foreach ($Vnaq20kbhsei as $Vexjfacrc1d4) {
            $this->move_after($Vexjfacrc1d4);
        }
    }

    

    
    public function move_after(Frame $Vexjfacrc1d4)
    {
        $this->get_parent()->insert_child_after($Vexjfacrc1d4, $this);
    }
}
