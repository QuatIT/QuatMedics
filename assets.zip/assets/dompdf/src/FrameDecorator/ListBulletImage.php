<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Dompdf;
use Dompdf\Frame;
use Dompdf\Helpers;


class ListBulletImage extends AbstractFrameDecorator
{

    
    protected $Vdsq4tkubjau;

    
    protected $Vxc0qtxc1w0o;

    
    protected $Vhuqn53j4zao;

    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Vop22rgf5euu = $Vkvw5zjrwkdm->list_style_image;
        $Vexjfacrc1d4->get_node()->setAttribute("src", $Vop22rgf5euu);
        $this->_img = new Image($Vexjfacrc1d4, $Vodc45cwlwwh);
        parent::__construct($this->_img, $Vodc45cwlwwh);
        list($Vtt4kvdwuqqh, $Vxtfrabd3i5r) = Helpers::dompdf_getimagesize($this->_img->get_image_url(), $Vodc45cwlwwh->getHttpContext());

        
        
        
        $Vfwb1n1yh3ll = $this->_dompdf->getOptions()->getDpi();
        $this->_width = ((float)rtrim($Vtt4kvdwuqqh, "px") * 72) / $Vfwb1n1yh3ll;
        $this->_height = ((float)rtrim($Vxtfrabd3i5r, "px") * 72) / $Vfwb1n1yh3ll;

        
        
        
        
        
        
        
        
        
        
        
    }

    
    function get_width()
    {
        
        
        
        
        return $this->_frame->get_style()->get_font_size() * ListBullet::BULLET_SIZE +
        2 * ListBullet::BULLET_PADDING;
    }

    
    function get_height()
    {
        
        return $this->_height;
    }

    
    function get_margin_width()
    {
        
        
        
        
        
        

        
        
        if ($this->_frame->get_style()->list_style_position === "outside" || $this->_width == 0) {
            return 0;
        }
        
        
        
        
        
        return $this->_width + 2 * ListBullet::BULLET_PADDING;
    }

    
    function get_margin_height()
    {
        
        
        return $this->_height + 2 * ListBullet::BULLET_PADDING;
    }

    
    function get_image_url()
    {
        return $this->_img->get_image_url();
    }

}
