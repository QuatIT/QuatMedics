<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Dompdf;
use Dompdf\Frame;
use Dompdf\Image\Cache;


class Image extends AbstractFrameDecorator
{

    
    protected $Vdfjna551rlr;

    
    protected $Vhhmvnscxpka;

    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);
        $Vop22rgf5euu = $Vexjfacrc1d4->get_node()->getAttribute("src");

        $Vjq1be2z1jmc = $Vodc45cwlwwh->getOptions()->getDebugPng();
        if ($Vjq1be2z1jmc) {
            print '[__construct ' . $Vop22rgf5euu . ']';
        }

        list($this->_image_url, , $this->_image_msg) = Cache::resolve_url(
            $Vop22rgf5euu,
            $Vodc45cwlwwh->getProtocol(),
            $Vodc45cwlwwh->getBaseHost(),
            $Vodc45cwlwwh->getBasePath(),
            $Vodc45cwlwwh
        );

        if (Cache::is_broken($this->_image_url) &&
            $Vximyhzisgt3 = $Vexjfacrc1d4->get_node()->getAttribute("alt")
        ) {
            $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
            $Vkvw5zjrwkdm->width = (4 / 3) * $Vodc45cwlwwh->getFontMetrics()->getTextWidth($Vximyhzisgt3, $Vkvw5zjrwkdm->font_family, $Vkvw5zjrwkdm->font_size, $Vkvw5zjrwkdm->word_spacing);
            $Vkvw5zjrwkdm->height = $Vodc45cwlwwh->getFontMetrics()->getFontHeight($Vkvw5zjrwkdm->font_family, $Vkvw5zjrwkdm->font_size);
        }
    }

    
    function get_image_url()
    {
        return $this->_image_url;
    }

    
    function get_image_msg()
    {
        return $this->_image_msg;
    }

}
