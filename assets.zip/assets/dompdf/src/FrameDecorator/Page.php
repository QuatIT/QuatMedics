<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Css\Style;
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Frame;
use Dompdf\Renderer;


class Page extends AbstractFrameDecorator
{

    
    protected $V5ijlkwomr5o;

    
    protected $V4nw3ekqbitj;

    
    protected $Vt54i2dwieuz;

    
    protected $Vg5vn1tp1a4f;

    
    protected $Viqyqo2ytit4 = array();

    

    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);
        $this->_page_full = false;
        $this->_in_table = 0;
        $this->_bottom_page_margin = null;
    }

    
    function set_renderer($Vjhyoifb3001)
    {
        $this->_renderer = $Vjhyoifb3001;
    }

    
    function get_renderer()
    {
        return $this->_renderer;
    }

    
    function set_containing_block($Vmm2pe5l4str = null, $Vuua0v2znlr5 = null, $V5ymvwogwh5y = null, $V2pgp3ppbjsi = null)
    {
        parent::set_containing_block($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        
        if (isset($V2pgp3ppbjsi)) {
            $this->_bottom_page_margin = $V2pgp3ppbjsi;
        } 
    }

    
    function is_full()
    {
        return $this->_page_full;
    }

    
    function next_page()
    {
        $this->_floating_frames = array();
        $this->_renderer->new_page();
        $this->_page_full = false;
    }

    
    function table_reflow_start()
    {
        $this->_in_table++;
    }

    
    function table_reflow_end()
    {
        $this->_in_table--;
    }

    
    function in_nested_table()
    {
        return $this->_in_table > 1;
    }

    
    function check_forced_page_break(Frame $Vexjfacrc1d4)
    {

        
        if ($this->_page_full) {
            return null;
        }

        $Vnxfzf1vwkgl = array("block", "list-item", "table", "inline");
        $Vv2hkri1jd3p = array("always", "left", "right");

        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        if (!in_array($Vkvw5zjrwkdm->display, $Vnxfzf1vwkgl)) {
            return false;
        }

        
        $V2aw0vm5jxg0 = $Vexjfacrc1d4->get_prev_sibling();

        while ($V2aw0vm5jxg0 && !in_array($V2aw0vm5jxg0->get_style()->display, $Vnxfzf1vwkgl)) {
            $V2aw0vm5jxg0 = $V2aw0vm5jxg0->get_prev_sibling();
        }

        if (in_array($Vkvw5zjrwkdm->page_break_before, $Vv2hkri1jd3p)) {
            
            $Vexjfacrc1d4->split(null, true);
            
            
            $Vexjfacrc1d4->get_style()->page_break_before = "auto";
            $this->_page_full = true;

            return true;
        }

        if ($V2aw0vm5jxg0 && in_array($V2aw0vm5jxg0->get_style()->page_break_after, $Vv2hkri1jd3p)) {
            
            $Vexjfacrc1d4->split(null, true);
            $V2aw0vm5jxg0->get_style()->page_break_after = "auto";
            $this->_page_full = true;

            return true;
        }

        if ($V2aw0vm5jxg0 && $V2aw0vm5jxg0->get_last_child() && $Vexjfacrc1d4->get_node()->nodeName != "body") {
            $V2aw0vm5jxg0_last_child = $V2aw0vm5jxg0->get_last_child();
            if (in_array($V2aw0vm5jxg0_last_child->get_style()->page_break_after, $Vv2hkri1jd3p)) {
                $Vexjfacrc1d4->split(null, true);
                $V2aw0vm5jxg0_last_child->get_style()->page_break_after = "auto";
                $this->_page_full = true;

                return true;
            }
        }

        return false;
    }

    
    protected function _page_break_allowed(Frame $Vexjfacrc1d4)
    {
        $Vnxfzf1vwkgl = array("block", "list-item", "table", "-dompdf-image");
        Helpers::dompdf_debug("page-break", "_page_break_allowed(" . $Vexjfacrc1d4->get_node()->nodeName . ")");
        $Vqzifj31psr1 = $Vexjfacrc1d4->get_style()->display;

        
        if (in_array($Vqzifj31psr1, $Vnxfzf1vwkgl)) {

            
            if ($this->_in_table) {
                Helpers::dompdf_debug("page-break", "In table: " . $this->_in_table);

                return false;
            }

            

            if ($Vexjfacrc1d4->get_style()->page_break_before === "avoid") {
                Helpers::dompdf_debug("page-break", "before: avoid");

                return false;
            }

            
            $V2aw0vm5jxg0 = $Vexjfacrc1d4->get_prev_sibling();
            while ($V2aw0vm5jxg0 && !in_array($V2aw0vm5jxg0->get_style()->display, $Vnxfzf1vwkgl)) {
                $V2aw0vm5jxg0 = $V2aw0vm5jxg0->get_prev_sibling();
            }

            
            if ($V2aw0vm5jxg0 && $V2aw0vm5jxg0->get_style()->page_break_after === "avoid") {
                Helpers::dompdf_debug("page-break", "after: avoid");

                return false;
            }

            
            
            $Vhbd3bset2hu = $Vexjfacrc1d4->get_parent();
            if ($V2aw0vm5jxg0 && $Vhbd3bset2hu && $Vhbd3bset2hu->get_style()->page_break_inside === "avoid") {
                Helpers::dompdf_debug("page-break", "parent inside: avoid");

                return false;
            }

            
            
            
            if ($Vhbd3bset2hu->get_node()->nodeName === "body" && !$V2aw0vm5jxg0) {
                
                Helpers::dompdf_debug("page-break", "Body's first child.");

                return false;
            }

            
            
            if (!$V2aw0vm5jxg0 && $Vhbd3bset2hu) {
                return $this->_page_break_allowed($Vhbd3bset2hu);
            }

            Helpers::dompdf_debug("page-break", "block: break allowed");

            return true;

        } 
        else {
            if (in_array($Vqzifj31psr1, Style::$Vumjaagcajbo)) {

                
                if ($this->_in_table) {
                    Helpers::dompdf_debug("page-break", "In table: " . $this->_in_table);

                    return false;
                }

                
                $Vv13ijvgqv22 = $Vexjfacrc1d4->find_block_parent();
                if (count($Vv13ijvgqv22->get_line_boxes()) < $Vexjfacrc1d4->get_style()->orphans) {
                    Helpers::dompdf_debug("page-break", "orphans");

                    return false;
                }

                
                

                
                $V2d1s45w0hjo = $Vv13ijvgqv22;
                while ($V2d1s45w0hjo) {
                    if ($V2d1s45w0hjo->get_style()->page_break_inside === "avoid") {
                        Helpers::dompdf_debug("page-break", "parent->inside: avoid");

                        return false;
                    }
                    $V2d1s45w0hjo = $V2d1s45w0hjo->find_block_parent();
                }

                
                
                
                $V2aw0vm5jxg0 = $Vexjfacrc1d4->get_prev_sibling();
                while ($V2aw0vm5jxg0 && ($V2aw0vm5jxg0->is_text_node() && trim($V2aw0vm5jxg0->get_node()->nodeValue) == "")) {
                    $V2aw0vm5jxg0 = $V2aw0vm5jxg0->get_prev_sibling();
                }

                if ($Vv13ijvgqv22->get_node()->nodeName === "body" && !$V2aw0vm5jxg0) {
                    
                    Helpers::dompdf_debug("page-break", "Body's first child.");

                    return false;
                }

                
                if ($Vexjfacrc1d4->is_text_node() && $Vexjfacrc1d4->get_node()->nodeValue == "") {
                    return false;
                }

                Helpers::dompdf_debug("page-break", "inline: break allowed");

                return true;

            
            } else {
                if ($Vqzifj31psr1 === "table-row") {
                    
                    
                    $Vp5rpvpxnb43 = Table::find_parent_table($Vexjfacrc1d4);

                    $V2d1s45w0hjo = $Vp5rpvpxnb43;
                    while ($V2d1s45w0hjo) {
                        if ($V2d1s45w0hjo->get_style()->page_break_inside === "avoid") {
                            Helpers::dompdf_debug("page-break", "parent->inside: avoid");

                            return false;
                        }
                        $V2d1s45w0hjo = $V2d1s45w0hjo->find_block_parent();
                    }

                    
                    if ($Vp5rpvpxnb43 && $Vp5rpvpxnb43->get_first_child() === $Vexjfacrc1d4 || $Vp5rpvpxnb43->get_first_child()->get_first_child() === $Vexjfacrc1d4) {
                        Helpers::dompdf_debug("page-break", "table: first-row");

                        return false;
                    }

                    
                    if ($this->_in_table > 1) {
                        Helpers::dompdf_debug("page-break", "table: nested table");

                        return false;
                    }

                    Helpers::dompdf_debug("page-break", "table-row/row-groups: break allowed");

                    return true;
                } else {
                    if (in_array($Vqzifj31psr1, Table::$V420otj4lzb1)) {

                        
                        return false;

                    } else {
                        Helpers::dompdf_debug("page-break", "? " . $Vexjfacrc1d4->get_style()->display . "");

                        return false;
                    }
                }
            }
        }

    }

    
    function check_page_break(Frame $Vexjfacrc1d4)
    {
        
        $V2d1s45w0hjo = $Vexjfacrc1d4;
        $Vldxr0zzd234 = false;
        while ($V2d1s45w0hjo) {
            if ($V2d1s45w0hjo->is_table()) { $Vldxr0zzd234 = true; break; }
            $V2d1s45w0hjo = $V2d1s45w0hjo->get_parent();
        }
        
        
        if ($Vldxr0zzd234) {
            if ($this->_page_full && $Vexjfacrc1d4->_already_pushed) {
                return false;
            }
        } elseif ($this->_page_full || $Vexjfacrc1d4->_already_pushed) {
            return false;
        }

        
        if ($Vldxr0zzd234 && $Vexjfacrc1d4->_already_pushed) {
            return false;
        }
        $V2d1s45w0hjo = $Vexjfacrc1d4;
        do {
            $Vqzifj31psr1 = $V2d1s45w0hjo->get_style()->display;
            if ($Vqzifj31psr1 == "table-row") {
                if ($V2d1s45w0hjo->_already_pushed) { return false; }
            }
        } while ($V2d1s45w0hjo = $V2d1s45w0hjo->get_parent());

        
        $V2d1s45w0hjo = $Vexjfacrc1d4;
        do {
            if ($V2d1s45w0hjo->is_absolute()) {
                return false;
            }

            
            
            $Vqzifj31psr1 = $V2d1s45w0hjo->get_style()->display;
            if ($Vqzifj31psr1 === "table-row"
                && !$V2d1s45w0hjo->get_prev_sibling()
                && $V2d1s45w0hjo->get_margin_height() > $this->get_margin_height()
            ) {
                return false;
            }
        } while ($V2d1s45w0hjo = $V2d1s45w0hjo->get_parent());

        $V1u3k1hfhcrq = $Vexjfacrc1d4->get_margin_height();

        
        $Vj1znqyv2b3k = (float)$Vexjfacrc1d4->get_position("y") + $V1u3k1hfhcrq;

        
        
        $V2d1s45w0hjo = $Vexjfacrc1d4->get_parent();
        while ($V2d1s45w0hjo) {
            $Vj1znqyv2b3k += $V2d1s45w0hjo->get_style()->computed_bottom_spacing();
            $V2d1s45w0hjo = $V2d1s45w0hjo->get_parent();
        }


        
        if ($Vj1znqyv2b3k <= $this->_bottom_page_margin) {
            
            return false;
        }

        Helpers::dompdf_debug("page-break", "check_page_break");
        Helpers::dompdf_debug("page-break", "in_table: " . $this->_in_table);

        
        $Vrlw4pv311lc = $Vexjfacrc1d4;
        $Vn3tmhuisebf = false;

        $Vldxr0zzd234 = $this->_in_table;

        Helpers::dompdf_debug("page-break", "Starting search");
        while ($Vrlw4pv311lc) {
            
            if ($Vrlw4pv311lc === $this) {
                Helpers::dompdf_debug("page-break", "reached root.");
                
                break;
            }

            if ($this->_page_break_allowed($Vrlw4pv311lc)) {
                Helpers::dompdf_debug("page-break", "break allowed, splitting.");
                $Vrlw4pv311lc->split(null, true);
                $this->_page_full = true;
                $this->_in_table = $Vldxr0zzd234;
                $Vexjfacrc1d4->_already_pushed = true;

                return true;
            }

            if (!$Vn3tmhuisebf && $Ve3fliainba2 = $Vrlw4pv311lc->get_last_child()) {
                Helpers::dompdf_debug("page-break", "following last child.");

                if ($Ve3fliainba2->is_table()) {
                    $this->_in_table++;
                }

                $Vrlw4pv311lc = $Ve3fliainba2;
                continue;
            }

            if ($Ve3fliainba2 = $Vrlw4pv311lc->get_prev_sibling()) {
                Helpers::dompdf_debug("page-break", "following prev sibling.");

                if ($Ve3fliainba2->is_table() && !$Vrlw4pv311lc->is_table()) {
                    $this->_in_table++;
                } else if (!$Ve3fliainba2->is_table() && $Vrlw4pv311lc->is_table()) {
                    $this->_in_table--;
                }

                $Vrlw4pv311lc = $Ve3fliainba2;
                $Vn3tmhuisebf = false;
                continue;
            }

            if ($Ve3fliainba2 = $Vrlw4pv311lc->get_parent()) {
                Helpers::dompdf_debug("page-break", "following parent.");

                if ($Vrlw4pv311lc->is_table()) {
                    $this->_in_table--;
                }

                $Vrlw4pv311lc = $Ve3fliainba2;
                $Vn3tmhuisebf = true;
                continue;
            }

            break;
        }

        $this->_in_table = $Vldxr0zzd234;

        
        Helpers::dompdf_debug("page-break", "no valid break found, just splitting.");

        
        if ($this->_in_table) {
            $Vrlw4pv311lc = $Vexjfacrc1d4;
            while ($Vrlw4pv311lc && $Vrlw4pv311lc->get_style()->display !== "table-row" && $Vrlw4pv311lc->get_style()->display !== 'table-row-group' && $Vrlw4pv311lc->_already_pushed === false) {
                $Vrlw4pv311lc = $Vrlw4pv311lc->get_parent();
            }

            if ($Vrlw4pv311lc) {
                $Vrlw4pv311lc->split(null, true);
            } else {
                return false;
            }
        } else {
            $Vexjfacrc1d4->split(null, true);
        }

        $this->_page_full = true;
        $Vexjfacrc1d4->_already_pushed = true;

        return true;
    }

    

    
    function split(Frame $Vexjfacrc1d4 = null, $Vptkg4lgmmwq = false)
    {
        
    }

    
    function add_floating_frame(Frame $Vexjfacrc1d4)
    {
        array_unshift($this->_floating_frames, $Vexjfacrc1d4);
    }

    
    function get_floating_frames()
    {
        return $this->_floating_frames;
    }

    
    public function remove_floating_frame($Vbd2mxirzq2d)
    {
        unset($this->_floating_frames[$Vbd2mxirzq2d]);
    }

    
    public function get_lowest_float_offset(Frame $V0mqc4rbglqu)
    {
        $Vkvw5zjrwkdm = $V0mqc4rbglqu->get_style();
        $Vcxi3be0s51c = $Vkvw5zjrwkdm->clear;
        $Va2mt4xafrx1 = $Vkvw5zjrwkdm->float;

        $Vuua0v2znlr5 = 0;

        if ($Va2mt4xafrx1 === "none") {
            foreach ($this->_floating_frames as $Vbd2mxirzq2d => $Vexjfacrc1d4) {
                if ($Vcxi3be0s51c === "both" || $Vexjfacrc1d4->get_style()->float === $Vcxi3be0s51c) {
                    $Vuua0v2znlr5 = max($Vuua0v2znlr5, $Vexjfacrc1d4->get_position("y") + $Vexjfacrc1d4->get_margin_height());
                }
                $this->remove_floating_frame($Vbd2mxirzq2d);
            }
        }

        if ($Vuua0v2znlr5 > 0) {
            $Vuua0v2znlr5++; 
        }

        return $Vuua0v2znlr5;
    }
}
