<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Dompdf;
use Dompdf\Frame;
use Dompdf\FrameDecorator\Table as TableFrameDecorator;


class TableRow extends AbstractFrameDecorator
{
    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);
    }

    

    
    function normalise()
    {
        
        $V2d1s45w0hjo = TableFrameDecorator::find_parent_table($this);

        $Vnaq20kbhsei = array();
        foreach ($this->get_children() as $V0mqc4rbglqu) {
            $Vqzifj31psr1 = $V0mqc4rbglqu->get_style()->display;

            if ($Vqzifj31psr1 !== "table-cell") {
                $Vnaq20kbhsei[] = $V0mqc4rbglqu;
            }
        }

        
        foreach ($Vnaq20kbhsei as $Vexjfacrc1d4) {
            $V2d1s45w0hjo->move_after($Vexjfacrc1d4);
        }
    }

    function split(Frame $V0mqc4rbglqu = null, $Vptkg4lgmmwq = false)
    {
        $this->_already_pushed = true;

        if (is_null($V0mqc4rbglqu)) {
            parent::split();
            return;
        }

        parent::split($V0mqc4rbglqu, $Vptkg4lgmmwq);
    }
}
