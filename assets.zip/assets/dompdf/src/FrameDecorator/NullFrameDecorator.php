<?php

namespace Dompdf\FrameDecorator;

use Dompdf\Dompdf;
use Dompdf\Frame;


class NullFrameDecorator extends AbstractFrameDecorator
{
    
    function __construct(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh)
    {
        parent::__construct($Vexjfacrc1d4, $Vodc45cwlwwh);
        $Vkvw5zjrwkdm = $this->_frame->get_style();
        $Vkvw5zjrwkdm->width = 0;
        $Vkvw5zjrwkdm->height = 0;
        $Vkvw5zjrwkdm->margin = 0;
        $Vkvw5zjrwkdm->padding = 0;
    }
}
