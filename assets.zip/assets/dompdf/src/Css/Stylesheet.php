<?php

namespace Dompdf\Css;

use DOMElement;
use DOMXPath;
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception;
use Dompdf\FontMetrics;
use Dompdf\Frame\FrameTree;


class Stylesheet
{
    
    const DEFAULT_STYLESHEET = "/lib/res/html.css";

    
    const ORIG_UA = 1;

    
    const ORIG_USER = 2;

    
    const ORIG_AUTHOR = 3;

    
    private static $Vo0brpbtjxa2 = array(
        self::ORIG_UA => 0x00000000, 
        self::ORIG_USER => 0x10000000, 
        self::ORIG_AUTHOR => 0x30000000, 
    );

    
    const SPEC_NON_CSS = 0x20000000;

    
    private $V3zitx0n32g4;

    
    private $Vs30qhqfy1xu;

    
    private $Vbh5gbac21lo;

    
    private $Vkh0fjd1rda5;

    
    private $Vev2e5m05olo;

    
    private $V3jhkwo0ebyf;

    
    private $Vrgglumnzfrd;

    
    private $Vd4jvstb3ngr = self::ORIG_UA;

    
    static $Vkcm2yfuoaub = "print";
    static $V0puti5o3dds = array("all", "static", "visual", "bitmap", "paged", "dompdf");
    static $Vwjaxztm30ih = array("all", "aural", "bitmap", "braille", "dompdf", "embossed", "handheld", "paged", "print", "projection", "screen", "speech", "static", "tty", "tv", "visual");

    
    private $Vnl1binwcwye;

    
    function __construct(Dompdf $Vodc45cwlwwh)
    {
        $this->_dompdf = $Vodc45cwlwwh;
        $this->setFontMetrics($Vodc45cwlwwh->getFontMetrics());
        $this->_styles = array();
        $this->_loaded_files = array();
        list($this->_protocol, $this->_base_host, $this->_base_path) = Helpers::explode_url($_SERVER["SCRIPT_FILENAME"]);
        $this->_page_styles = array("base" => null);
    }

    
    function set_protocol($Vz2fphjg3555)
    {
        $this->_protocol = $Vz2fphjg3555;
    }

    
    function set_host($Vskypresjwem)
    {
        $this->_base_host = $Vskypresjwem;
    }

    
    function set_base_path($Vt321vu1jwdw)
    {
        $this->_base_path = $Vt321vu1jwdw;
    }

    
    function get_dompdf()
    {
        return $this->_dompdf;
    }

    
    function get_protocol()
    {
        return $this->_protocol;
    }

    
    function get_host()
    {
        return $this->_base_host;
    }

    
    function get_base_path()
    {
        return $this->_base_path;
    }

    
    function get_page_styles()
    {
        return $this->_page_styles;
    }

    
    function add_style($Vbd2mxirzq2d, Style $Vkvw5zjrwkdm)
    {
        if (!is_string($Vbd2mxirzq2d)) {
            throw new Exception("CSS rule must be keyed by a string.");
        }

        if (!isset($this->_styles[$Vbd2mxirzq2d])) {
            $this->_styles[$Vbd2mxirzq2d] = array();
        }
        $Vrgaijtp2xnn = clone $Vkvw5zjrwkdm;
        $Vrgaijtp2xnn->set_origin($this->_current_origin);
        $this->_styles[$Vbd2mxirzq2d][] = $Vrgaijtp2xnn;
    }

    
    function lookup($Vbd2mxirzq2d)
    {
        if (!isset($this->_styles[$Vbd2mxirzq2d])) {
            return null;
        }

        return $this->_styles[$Vbd2mxirzq2d];
    }

    
    function create_style(Style $Vhbd3bset2hu = null)
    {
        return new Style($this, $this->_current_origin);
    }

    
    function load_css(&$Vezwmkkcp5ez, $Vys1hksmqmvt = self::ORIG_AUTHOR)
    {
        if ($Vys1hksmqmvt) {
            $this->_current_origin = $Vys1hksmqmvt;
        }
        $this->_parse_css($Vezwmkkcp5ez);
    }


    
    function load_css_file($Voheucoc3jxv, $Vys1hksmqmvt = self::ORIG_AUTHOR)
    {
        if ($Vys1hksmqmvt) {
            $this->_current_origin = $Vys1hksmqmvt;
        }

        
        if (isset($this->_loaded_files[$Voheucoc3jxv])) {
            return;
        }

        $this->_loaded_files[$Voheucoc3jxv] = true;

        if (strpos($Voheucoc3jxv, "data:") === 0) {
            $V45k3lamsnfi = Helpers::parse_data_uri($Voheucoc3jxv);
            $Vezwmkkcp5ez = $V45k3lamsnfi["data"];
        } else {
            $V45k3lamsnfi_url = Helpers::explode_url($Voheucoc3jxv);

            list($this->_protocol, $this->_base_host, $this->_base_path, $Voheucoc3jxvname) = $V45k3lamsnfi_url;

            
            if ($this->_protocol == "") {
                $Voheucoc3jxv = $this->_base_path . $Voheucoc3jxvname;
            } else {
                $Voheucoc3jxv = Helpers::build_url($this->_protocol, $this->_base_host, $this->_base_path, $Voheucoc3jxvname);
            }

            list($Vezwmkkcp5ez, $http_response_header) = Helpers::getFileContent($Voheucoc3jxv, $this->_dompdf->getHttpContext());

            $V2e5grgcuzf4 = true;

            
            if (isset($http_response_header) && !$this->_dompdf->getQuirksmode()) {
                foreach ($http_response_header as $Vvm0vapw4lkp) {
                    if (preg_match("@Content-Type:\s*([\w/]+)@i", $Vvm0vapw4lkp, $Vgvt1cvsrlfv) &&
                        ($Vgvt1cvsrlfv[1] !== "text/css")
                    ) {
                        $V2e5grgcuzf4 = false;
                    }
                }
            }

            if (!$V2e5grgcuzf4 || $Vezwmkkcp5ez == "") {
                Helpers::record_warnings(E_USER_WARNING, "Unable to load css file $Voheucoc3jxv", __FILE__, __LINE__);
                return;
            }
        }

        $this->_parse_css($Vezwmkkcp5ez);
    }

    
    private function _specificity($Vvevoq3s1gg5, $Vys1hksmqmvt = self::ORIG_AUTHOR)
    {
        
        
        

        $V4dkbhpdu11q = ($Vvevoq3s1gg5 === "!attr") ? 1 : 0;

        $Vkbvefdrfvxh = min(mb_substr_count($Vvevoq3s1gg5, "#"), 255);

        $Vdiqkcy1hsm4 = min(mb_substr_count($Vvevoq3s1gg5, ".") +
            mb_substr_count($Vvevoq3s1gg5, "["), 255);

        $Vngrhfhlmiyg = min(mb_substr_count($Vvevoq3s1gg5, " ") +
            mb_substr_count($Vvevoq3s1gg5, ">") +
            mb_substr_count($Vvevoq3s1gg5, "+"), 255);

        
        
        
        
        

        if (!in_array($Vvevoq3s1gg5[0], array(" ", ">", ".", "#", "+", ":", "[")) && $Vvevoq3s1gg5 !== "*") {
            $Vngrhfhlmiyg++;
        }

        if ($this->_dompdf->getOptions()->getDebugCss()) {
            
            print "<pre>\n";
            
            printf("_specificity(): 0x%08x \"%s\"\n", self::$Vo0brpbtjxa2[$Vys1hksmqmvt] + (($V4dkbhpdu11q << 24) | ($Vkbvefdrfvxh << 16) | ($Vdiqkcy1hsm4 << 8) | ($Vngrhfhlmiyg)), $Vvevoq3s1gg5);
            
            print "</pre>";
        }

        return self::$Vo0brpbtjxa2[$Vys1hksmqmvt] + (($V4dkbhpdu11q << 24) | ($Vkbvefdrfvxh << 16) | ($Vdiqkcy1hsm4 << 8) | ($Vngrhfhlmiyg));
    }

    
    private function _css_selector_to_xpath($Vvevoq3s1gg5, $Vydqhq5tikyr = false)
    {

        
        
        
        

        
        $V1tg34oowdmb = "//";

        
        $V4prumnhy1oq = array();

        
        $V43xy23rdgv5 = array();

        
        

        $Vngrhfhlmiygelimiters = array(" ", ">", ".", "#", "+", ":", "[", "(");

        
        
        if ($Vvevoq3s1gg5[0] === "[") {
            $Vvevoq3s1gg5 = "*$Vvevoq3s1gg5";
        }

        
        
        if (!in_array($Vvevoq3s1gg5[0], $Vngrhfhlmiygelimiters)) {
            $Vvevoq3s1gg5 = " $Vvevoq3s1gg5";
        }

        $Vh321hkmpvfe = "";
        $Vukikbvg40ol = mb_strlen($Vvevoq3s1gg5);
        $V0ixz2v5mxzy = 0;

        while ($V0ixz2v5mxzy < $Vukikbvg40ol) {

            $V500t5q0ulgs = $Vvevoq3s1gg5[$V0ixz2v5mxzy];
            $V0ixz2v5mxzy++;

            
            $Vh321hkmpvfe = "";
            $V0ixz2v5mxzyn_attr = false;
            $V0ixz2v5mxzyn_func = false;

            while ($V0ixz2v5mxzy < $Vukikbvg40ol) {
                $Vdiqkcy1hsm4 = $Vvevoq3s1gg5[$V0ixz2v5mxzy];
                $Vdiqkcy1hsm4_prev = $Vvevoq3s1gg5[$V0ixz2v5mxzy - 1];

                if (!$V0ixz2v5mxzyn_func && !$V0ixz2v5mxzyn_attr && in_array($Vdiqkcy1hsm4, $Vngrhfhlmiygelimiters) && !(($Vdiqkcy1hsm4 == $Vdiqkcy1hsm4_prev) == ":")) {
                    break;
                }

                if ($Vdiqkcy1hsm4_prev === "[") {
                    $V0ixz2v5mxzyn_attr = true;
                }
                if ($Vdiqkcy1hsm4_prev === "(") {
                    $V0ixz2v5mxzyn_func = true;
                }

                $Vh321hkmpvfe .= $Vvevoq3s1gg5[$V0ixz2v5mxzy++];

                if ($V0ixz2v5mxzyn_attr && $Vdiqkcy1hsm4 === "]") {
                    $V0ixz2v5mxzyn_attr = false;
                    break;
                }
                if ($V0ixz2v5mxzyn_func && $Vdiqkcy1hsm4 === ")") {
                    $V0ixz2v5mxzyn_func = false;
                    break;
                }
            }

            switch ($V500t5q0ulgs) {

                case " ":
                case ">":
                    
                    
                    $Vhfikobxkau0 = $V500t5q0ulgs === " " ? "descendant" : "child";

                    if (mb_substr($V1tg34oowdmb, -1, 1) !== "/") {
                        $V1tg34oowdmb .= "/";
                    }

                    
                    $Vh321hkmpvfe = strtolower($Vh321hkmpvfe);

                    if (!$Vh321hkmpvfe) {
                        $Vh321hkmpvfe = "*";
                    }

                    $V1tg34oowdmb .= "$Vhfikobxkau0::$Vh321hkmpvfe";
                    $Vh321hkmpvfe = "";
                    break;

                case ".":
                case "#":
                    
                    

                    $V4dkbhpdu11qttr = $V500t5q0ulgs === "." ? "class" : "id";

                    
                    if (mb_substr($V1tg34oowdmb, -1, 1) === "/") {
                        $V1tg34oowdmb .= "*";
                    }

                    
                    
                    

                    
                    

                    
                    $V1tg34oowdmb .= "[contains(concat(' ', @$V4dkbhpdu11qttr, ' '), concat(' ', '$Vh321hkmpvfe', ' '))]";
                    $Vh321hkmpvfe = "";
                    break;

                case "+":
                    
                    if (mb_substr($V1tg34oowdmb, -1, 1) !== "/") {
                        $V1tg34oowdmb .= "/";
                    }

                    $V1tg34oowdmb .= "following-sibling::$Vh321hkmpvfe";
                    $Vh321hkmpvfe = "";
                    break;

                case ":":
                    $V0ixz2v5mxzy2 = $V0ixz2v5mxzy - strlen($Vh321hkmpvfe) - 2; 
                    if (($V0ixz2v5mxzy2 < 0 || !isset($Vvevoq3s1gg5[$V0ixz2v5mxzy2]) || (in_array($Vvevoq3s1gg5[$V0ixz2v5mxzy2], $Vngrhfhlmiygelimiters) && $Vvevoq3s1gg5[$V0ixz2v5mxzy2] != ":")) && substr($V1tg34oowdmb, -1) != "*") {
                        $V1tg34oowdmb .= "*";
                    }

                    $Vjfygc2xspsp = false;

                    
                    switch ($Vh321hkmpvfe) {

                        case "first-child":
                            $V1tg34oowdmb .= "[1]";
                            $Vh321hkmpvfe = "";
                            break;

                        case "last-child":
                            $V1tg34oowdmb .= "[not(following-sibling::*)]";
                            $Vh321hkmpvfe = "";
                            break;

                        case "first-of-type":
                            $V1tg34oowdmb .= "[position() = 1]";
                            $Vh321hkmpvfe = "";
                            break;

                        case "last-of-type":
                            $V1tg34oowdmb .= "[position() = last()]";
                            $Vh321hkmpvfe = "";
                            break;

                        
                        
                        case "nth-last-of-type":
                            $Vjfygc2xspsp = true;
                        case "nth-of-type":
                            
                            $Vngrhfhlmiygescendant_delimeter = strrpos($V1tg34oowdmb, "::");
                            $V0ixz2v5mxzysChild = substr($V1tg34oowdmb, $Vngrhfhlmiygescendant_delimeter-5, 5) == "child";
                            $Vxutiqdcpozi = substr($V1tg34oowdmb, $Vngrhfhlmiygescendant_delimeter+2);
                            $V1tg34oowdmb = substr($V1tg34oowdmb, 0, strrpos($V1tg34oowdmb, "/")) . ($V0ixz2v5mxzysChild ? "/" : "//") . $Vxutiqdcpozi;

                            $V43xy23rdgv5[$Vh321hkmpvfe] = true;
                            $V2d1s45w0hjo = $V0ixz2v5mxzy + 1;
                            $Vvba5nqexjjg = trim(mb_substr($Vvevoq3s1gg5, $V2d1s45w0hjo, strpos($Vvevoq3s1gg5, ")", $V0ixz2v5mxzy) - $V2d1s45w0hjo));

                            
                            if (preg_match("/^\d+$/", $Vvba5nqexjjg)) {
                                $Vdiqkcy1hsm4ondition = "position() = $Vvba5nqexjjg";
                            } 
                            elseif ($Vvba5nqexjjg === "odd") {
                                $Vdiqkcy1hsm4ondition = "(position() mod 2) = 1";
                            } 
                            elseif ($Vvba5nqexjjg === "even") {
                                $Vdiqkcy1hsm4ondition = "(position() mod 2) = 0";
                            } 
                            else {
                                $Vdiqkcy1hsm4ondition = $this->_selector_an_plus_b($Vvba5nqexjjg, $Vjfygc2xspsp);
                            }

                            $V1tg34oowdmb .= "[$Vdiqkcy1hsm4ondition]";
                            $Vh321hkmpvfe = "";
                            break;
                        
                        case "nth-last-child":
                            $Vjfygc2xspsp = true;
                        case "nth-child":
                            
                            $Vngrhfhlmiygescendant_delimeter = strrpos($V1tg34oowdmb, "::");
                            $V0ixz2v5mxzysChild = substr($V1tg34oowdmb, $Vngrhfhlmiygescendant_delimeter-5, 5) == "child";
                            $Vxutiqdcpozi = substr($V1tg34oowdmb, $Vngrhfhlmiygescendant_delimeter+2);
                            $V1tg34oowdmb = substr($V1tg34oowdmb, 0, strrpos($V1tg34oowdmb, "/")) . ($V0ixz2v5mxzysChild ? "/" : "//") . "*";

                            $V43xy23rdgv5[$Vh321hkmpvfe] = true;
                            $V2d1s45w0hjo = $V0ixz2v5mxzy + 1;
                            $Vvba5nqexjjg = trim(mb_substr($Vvevoq3s1gg5, $V2d1s45w0hjo, strpos($Vvevoq3s1gg5, ")", $V0ixz2v5mxzy) - $V2d1s45w0hjo));

                            
                            if (preg_match("/^\d+$/", $Vvba5nqexjjg)) {
                                $Vdiqkcy1hsm4ondition = "position() = $Vvba5nqexjjg";
                            } 
                            elseif ($Vvba5nqexjjg === "odd") {
                                $Vdiqkcy1hsm4ondition = "(position() mod 2) = 1";
                            } 
                            elseif ($Vvba5nqexjjg === "even") {
                                $Vdiqkcy1hsm4ondition = "(position() mod 2) = 0";
                            } 
                            else {
                                $Vdiqkcy1hsm4ondition = $this->_selector_an_plus_b($Vvba5nqexjjg, $Vjfygc2xspsp);
                            }

                            $V1tg34oowdmb .= "[$Vdiqkcy1hsm4ondition]";
                            if ($Vxutiqdcpozi != "*") {
                                $V1tg34oowdmb .= "[name() = '$Vxutiqdcpozi']";
                            }
                            $Vh321hkmpvfe = "";
                            break;

                        
                        case "matches":
                            $V43xy23rdgv5[$Vh321hkmpvfe] = true;
                            $V2d1s45w0hjo = $V0ixz2v5mxzy + 1;
                            $V5et3zjwxzok = trim(mb_substr($Vvevoq3s1gg5, $V2d1s45w0hjo, strpos($Vvevoq3s1gg5, ")", $V0ixz2v5mxzy) - $V2d1s45w0hjo));

                            
                            $Vxutiqdcpoziements = array_map("trim", explode(",", strtolower($V5et3zjwxzok)));
                            foreach ($Vxutiqdcpoziements as &$Vxutiqdcpoziement) {
                                $Vxutiqdcpoziement = "name() = '$Vxutiqdcpoziement'";
                            }

                            $V1tg34oowdmb .= "[" . implode(" or ", $Vxutiqdcpoziements) . "]";
                            $Vh321hkmpvfe = "";
                            break;

                        case "link":
                            $V1tg34oowdmb .= "[@href]";
                            $Vh321hkmpvfe = "";
                            break;

                        case "first-line":
                        case ":first-line":
                        case "first-letter":
                        case ":first-letter":
                            
                            $Vxutiqdcpozi = trim($Vh321hkmpvfe, ":");
                            $V4prumnhy1oq[$Vxutiqdcpozi] = true;
                            break;

                            
                        case "focus":
                        case "active":
                        case "hover":
                        case "visited":
                            $V1tg34oowdmb .= "[false()]";
                            $Vh321hkmpvfe = "";
                            break;

                        
                        case "before":
                        case ":before":
                        case "after":
                        case ":after":
                            $V2d1s45w0hjoos = trim($Vh321hkmpvfe, ":");
                            $V4prumnhy1oq[$V2d1s45w0hjoos] = true;
                            if (!$Vydqhq5tikyr) {
                                $V1tg34oowdmb .= "/*[@$V2d1s45w0hjoos]";
                            }

                            $Vh321hkmpvfe = "";
                            break;

                        case "empty":
                            $V1tg34oowdmb .= "[not(*) and not(normalize-space())]";
                            $Vh321hkmpvfe = "";
                            break;

                        case "disabled":
                        case "checked":
                            $V1tg34oowdmb .= "[@$Vh321hkmpvfe]";
                            $Vh321hkmpvfe = "";
                            break;

                        case "enabled":
                            $V1tg34oowdmb .= "[not(@disabled)]";
                            $Vh321hkmpvfe = "";
                            break;

                        
                        default:
                            $V1tg34oowdmb = "/../.."; 
                            $Vh321hkmpvfe = "";
                            break;
                    }

                    break;

                case "[":
                    
                    $V4dkbhpdu11qttr_delimiters = array("=", "]", "~", "|", "$", "^", "*");
                    $Vh321hkmpvfe_len = mb_strlen($Vh321hkmpvfe);
                    $Vy4wtqjehnh5 = 0;

                    $V4dkbhpdu11qttr = "";
                    $V4trseai5dul = "";
                    $Veugw2h43vxz = "";

                    while ($Vy4wtqjehnh5 < $Vh321hkmpvfe_len) {
                        if (in_array($Vh321hkmpvfe[$Vy4wtqjehnh5], $V4dkbhpdu11qttr_delimiters)) {
                            break;
                        }
                        $V4dkbhpdu11qttr .= $Vh321hkmpvfe[$Vy4wtqjehnh5++];
                    }

                    switch ($Vh321hkmpvfe[$Vy4wtqjehnh5]) {

                        case "~":
                        case "|":
                        case "$":
                        case "^":
                        case "*":
                            $V4trseai5dul .= $Vh321hkmpvfe[$Vy4wtqjehnh5++];

                            if ($Vh321hkmpvfe[$Vy4wtqjehnh5] !== "=") {
                                throw new Exception("Invalid CSS selector syntax: invalid attribute selector: $Vvevoq3s1gg5");
                            }

                            $V4trseai5dul .= $Vh321hkmpvfe[$Vy4wtqjehnh5];
                            break;

                        case "=":
                            $V4trseai5dul = "=";
                            break;

                    }

                    
                    if ($V4trseai5dul != "") {
                        $Vy4wtqjehnh5++;
                        while ($Vy4wtqjehnh5 < $Vh321hkmpvfe_len) {
                            if ($Vh321hkmpvfe[$Vy4wtqjehnh5] === "]") {
                                break;
                            }
                            $Veugw2h43vxz .= $Vh321hkmpvfe[$Vy4wtqjehnh5++];
                        }
                    }

                    if ($V4dkbhpdu11qttr == "") {
                        throw new Exception("Invalid CSS selector syntax: missing attribute name");
                    }

                    $Veugw2h43vxz = trim($Veugw2h43vxz, "\"'");

                    switch ($V4trseai5dul) {

                        case "":
                            $V1tg34oowdmb .= "[@$V4dkbhpdu11qttr]";
                            break;

                        case "=":
                            $V1tg34oowdmb .= "[@$V4dkbhpdu11qttr=\"$Veugw2h43vxz\"]";
                            break;

                        case "~=":
                            
                            
                            $Veugw2h43vxzs = explode(" ", $Veugw2h43vxz);
                            $V1tg34oowdmb .= "[";

                            foreach ($Veugw2h43vxzs as $Vso3o0kfkstx) {
                                $V1tg34oowdmb .= "@$V4dkbhpdu11qttr=\"$Vso3o0kfkstx\" or ";
                            }

                            $V1tg34oowdmb = rtrim($V1tg34oowdmb, " or ") . "]";
                            break;

                        case "|=":
                            $Veugw2h43vxzs = explode("-", $Veugw2h43vxz);
                            $V1tg34oowdmb .= "[";

                            foreach ($Veugw2h43vxzs as $Vso3o0kfkstx) {
                                $V1tg34oowdmb .= "starts-with(@$V4dkbhpdu11qttr, \"$Vso3o0kfkstx\") or ";
                            }

                            $V1tg34oowdmb = rtrim($V1tg34oowdmb, " or ") . "]";
                            break;

                        case "$=":
                            $V1tg34oowdmb .= "[substring(@$V4dkbhpdu11qttr, string-length(@$V4dkbhpdu11qttr)-" . (strlen($Veugw2h43vxz) - 1) . ")=\"$Veugw2h43vxz\"]";
                            break;

                        case "^=":
                            $V1tg34oowdmb .= "[starts-with(@$V4dkbhpdu11qttr,\"$Veugw2h43vxz\")]";
                            break;

                        case "*=":
                            $V1tg34oowdmb .= "[contains(@$V4dkbhpdu11qttr,\"$Veugw2h43vxz\")]";
                            break;
                    }

                    break;
            }
        }
        $V0ixz2v5mxzy++;






















        
        if (mb_strlen($V1tg34oowdmb) > 2) {
            $V1tg34oowdmb = rtrim($V1tg34oowdmb, "/");
        }

        return array("query" => $V1tg34oowdmb, "pseudo_elements" => $V4prumnhy1oq);
    }

    
    protected function _selector_an_plus_b($Vhfikobxkau0, $Vjfygc2xspsp = false)
    {
        $Vhfikobxkau0 = preg_replace("/\s/", "", $Vhfikobxkau0);
        if (!preg_match("/^(?P<a>-?[0-9]*)?n(?P<b>[-+]?[0-9]+)?$/", $Vhfikobxkau0, $Vgvt1cvsrlfv)) {
            return "false()";
        }

        $V4dkbhpdu11q = ((isset($Vgvt1cvsrlfv["a"]) && $Vgvt1cvsrlfv["a"] !== "") ? intval($Vgvt1cvsrlfv["a"]) : 1);
        $Vkbvefdrfvxh = ((isset($Vgvt1cvsrlfv["b"]) && $Vgvt1cvsrlfv["b"] !== "") ? intval($Vgvt1cvsrlfv["b"]) : 0);

        $V2d1s45w0hjoosition = ($Vjfygc2xspsp ? "(last()-position()+1)" : "position()");

        if ($Vkbvefdrfvxh == 0) {
            return "($V2d1s45w0hjoosition mod $V4dkbhpdu11q) = 0";
        } else {
            $Vdiqkcy1hsm4ompare = (($V4dkbhpdu11q < 0) ? "<=" : ">=");
            $Vkbvefdrfvxh2 = -$Vkbvefdrfvxh;
            if ($Vkbvefdrfvxh2 >= 0) {
                $Vkbvefdrfvxh2 = "+$Vkbvefdrfvxh2";
            }
            return "($V2d1s45w0hjoosition $Vdiqkcy1hsm4ompare $Vkbvefdrfvxh) and ((($V2d1s45w0hjoosition $Vkbvefdrfvxh2) mod " . abs($V4dkbhpdu11q) . ") = 0)";
        }
    }

    
    function apply_styles(FrameTree $Vq4fqdfuymzg)
    {
        
        
        
        
        

        
        
        

        

        $Vkvw5zjrwkdms = array();
        $V1szhjz3ctsp = new DOMXPath($Vq4fqdfuymzg->get_dom());
        $Vogaw3hbey3g = $this->_dompdf->getOptions()->getDebugCss();

        
        foreach ($this->_styles as $Vvevoq3s1gg5 => $Vvevoq3s1gg5_styles) {
            
            foreach ($Vvevoq3s1gg5_styles as $Vkvw5zjrwkdm) {
                if (strpos($Vvevoq3s1gg5, ":before") === false && strpos($Vvevoq3s1gg5, ":after") === false) {
                    continue;
                }

                $V1tg34oowdmb = $this->_css_selector_to_xpath($Vvevoq3s1gg5, true);

                
                
                $Vi4j3o5jnxwy = @$V1szhjz3ctsp->query('.' . $V1tg34oowdmb["query"]);
                if ($Vi4j3o5jnxwy == null) {
                    Helpers::record_warnings(E_USER_WARNING, "The CSS selector '$Vvevoq3s1gg5' is not valid", __FILE__, __LINE__);
                    continue;
                }

                
                foreach ($Vi4j3o5jnxwy as $Vivp5mmrkfpz) {
                    
                    if ($Vivp5mmrkfpz->nodeType != XML_ELEMENT_NODE) {
                        continue;
                    }

                    foreach (array_keys($V1tg34oowdmb["pseudo_elements"], true, true) as $V2d1s45w0hjoos) {
                        
                        if ($Vivp5mmrkfpz->hasAttribute("dompdf_{$V2d1s45w0hjoos}_frame_id")) {
                            continue;
                        }

                        if (($V500t5q0ulgsrc = $this->_image($Vkvw5zjrwkdm->get_prop('content'))) !== "none") {
                            $Vl3r53fzd05f = $Vivp5mmrkfpz->ownerDocument->createElement("img_generated");
                            $Vl3r53fzd05f->setAttribute("src", $V500t5q0ulgsrc);
                        } else {
                            $Vl3r53fzd05f = $Vivp5mmrkfpz->ownerDocument->createElement("dompdf_generated");
                        }

                        $Vl3r53fzd05f->setAttribute($V2d1s45w0hjoos, $V2d1s45w0hjoos);
                        $Visqu4borzoo = $Vq4fqdfuymzg->insert_node($Vivp5mmrkfpz, $Vl3r53fzd05f, $V2d1s45w0hjoos);
                        $Vivp5mmrkfpz->setAttribute("dompdf_{$V2d1s45w0hjoos}_frame_id", $Visqu4borzoo);
                    }
                }
            }
        }

        
        foreach ($this->_styles as $Vvevoq3s1gg5 => $Vvevoq3s1gg5_styles) {
            
            foreach ($Vvevoq3s1gg5_styles as $Vkvw5zjrwkdm) {
                $V1tg34oowdmb = $this->_css_selector_to_xpath($Vvevoq3s1gg5);

                
                $Vi4j3o5jnxwy = @$V1szhjz3ctsp->query($V1tg34oowdmb["query"]);
                if ($Vi4j3o5jnxwy == null) {
                    Helpers::record_warnings(E_USER_WARNING, "The CSS selector '$Vvevoq3s1gg5' is not valid", __FILE__, __LINE__);
                    continue;
                }

                $V500t5q0ulgspec = $this->_specificity($Vvevoq3s1gg5, $Vkvw5zjrwkdm->get_origin());

                foreach ($Vi4j3o5jnxwy as $Vivp5mmrkfpz) {
                    
                    
                    if ($Vivp5mmrkfpz->nodeType != XML_ELEMENT_NODE) {
                        continue;
                    }

                    $V0ixz2v5mxzyd = $Vivp5mmrkfpz->getAttribute("frame_id");

                    
                    $Vkvw5zjrwkdms[$V0ixz2v5mxzyd][$V500t5q0ulgspec][] = $Vkvw5zjrwkdm;
                }
            }
        }

        
        $Vdiqkcy1hsm4anvas = $this->_dompdf->getCanvas();
        $V2d1s45w0hjoaper_width = $Vdiqkcy1hsm4anvas->get_width();
        $V2d1s45w0hjoaper_height = $Vdiqkcy1hsm4anvas->get_height();
        $V2d1s45w0hjoaper_orientation = ($V2d1s45w0hjoaper_width > $V2d1s45w0hjoaper_height ? "landscape" : "portrait");

        if ($this->_page_styles["base"] && is_array($this->_page_styles["base"]->size)) {
            $V2d1s45w0hjoaper_width = $this->_page_styles['base']->size[0];
            $V2d1s45w0hjoaper_height = $this->_page_styles['base']->size[1];
            $V2d1s45w0hjoaper_orientation = ($V2d1s45w0hjoaper_width > $V2d1s45w0hjoaper_height ? "landscape" : "portrait");
        }

        
        
        $V131zbcz0qfq = false;
        foreach ($Vq4fqdfuymzg->get_frames() as $Vexjfacrc1d4) {
            
            if (!$V131zbcz0qfq && $this->_page_styles["base"]) {
                $Vkvw5zjrwkdm = $this->_page_styles["base"];
            } else {
                $Vkvw5zjrwkdm = $this->create_style();
            }

            
            $V2d1s45w0hjo = $Vexjfacrc1d4;
            while ($V2d1s45w0hjo = $V2d1s45w0hjo->get_parent()) {
                if ($V2d1s45w0hjo->get_node()->nodeType == XML_ELEMENT_NODE) {
                    break;
                }
            }

            
            
            if ($Vexjfacrc1d4->get_node()->nodeType != XML_ELEMENT_NODE) {
                if ($V2d1s45w0hjo) {
                    $Vkvw5zjrwkdm->inherit($V2d1s45w0hjo->get_style());
                }

                $Vexjfacrc1d4->set_style($Vkvw5zjrwkdm);
                continue;
            }

            $V0ixz2v5mxzyd = $Vexjfacrc1d4->get_id();

            
            AttributeTranslator::translate_attributes($Vexjfacrc1d4);
            if (($V500t5q0ulgstr = $Vexjfacrc1d4->get_node()->getAttribute(AttributeTranslator::$Vbmhvvjvqbtt)) !== "") {
                $Vkvw5zjrwkdms[$V0ixz2v5mxzyd][self::SPEC_NON_CSS][] = $this->_parse_properties($V500t5q0ulgstr);
            }

            
            if (($V500t5q0ulgstr = $Vexjfacrc1d4->get_node()->getAttribute("style")) !== "") {
                
                $V500t5q0ulgstr = preg_replace("'/\*.*?\*/'si", "", $V500t5q0ulgstr);

                $V500t5q0ulgspec = $this->_specificity("!attr", self::ORIG_AUTHOR);
                $Vkvw5zjrwkdms[$V0ixz2v5mxzyd][$V500t5q0ulgspec][] = $this->_parse_properties($V500t5q0ulgstr);
            }

            
            if (isset($Vkvw5zjrwkdms[$V0ixz2v5mxzyd])) {

                
                $V4dkbhpdu11qpplied_styles = $Vkvw5zjrwkdms[$Vexjfacrc1d4->get_id()];

                
                ksort($V4dkbhpdu11qpplied_styles);

                if ($Vogaw3hbey3g) {
                    $Vngrhfhlmiygebug_nodename = $Vexjfacrc1d4->get_node()->nodeName;
                    print "<pre>\n[$Vngrhfhlmiygebug_nodename\n";
                    foreach ($V4dkbhpdu11qpplied_styles as $V500t5q0ulgspec => $V4dkbhpdu11qrr) {
                        printf("specificity: 0x%08x\n", $V500t5q0ulgspec);
                        
                        foreach ($V4dkbhpdu11qrr as $V500t5q0ulgs) {
                            print "[\n";
                            $V500t5q0ulgs->debug_print();
                            print "]\n";
                        }
                    }
                }

                
                $V4dkbhpdu11qcceptedmedia = self::$V0puti5o3dds;
                $V4dkbhpdu11qcceptedmedia[] = $this->_dompdf->getOptions()->getDefaultMediaType();
                foreach ($V4dkbhpdu11qpplied_styles as $V4dkbhpdu11qrr) {
                    
                    foreach ($V4dkbhpdu11qrr as $V500t5q0ulgs) {
                        $Vtzoteyx4chw = $V500t5q0ulgs->get_media_queries();
                        foreach ($Vtzoteyx4chw as $Vr15q1qrbafs) {
                            list($Vr15q1qrbafs_feature, $Vr15q1qrbafs_value) = $Vr15q1qrbafs;
                            
                            
                            if (in_array($Vr15q1qrbafs_feature, self::$Vwjaxztm30ih)) {
                                if ((strlen($Vr15q1qrbafs_feature) === 0 && !in_array($Vr15q1qrbafs, $V4dkbhpdu11qcceptedmedia)) || (in_array($Vr15q1qrbafs, $V4dkbhpdu11qcceptedmedia) && $Vr15q1qrbafs_value == "not")) {
                                    continue (3);
                                }
                            } else {
                                switch ($Vr15q1qrbafs_feature) {
                                    case "height":
                                        if ($V2d1s45w0hjoaper_height !== (float)$Vkvw5zjrwkdm->length_in_pt($Vr15q1qrbafs_value)) {
                                            continue (3);
                                        }
                                        break;
                                    case "min-height":
                                        if ($V2d1s45w0hjoaper_height < (float)$Vkvw5zjrwkdm->length_in_pt($Vr15q1qrbafs_value)) {
                                            continue (3);
                                        }
                                        break;
                                    case "max-height":
                                        if ($V2d1s45w0hjoaper_height > (float)$Vkvw5zjrwkdm->length_in_pt($Vr15q1qrbafs_value)) {
                                            continue (3);
                                        }
                                        break;
                                    case "width":
                                        if ($V2d1s45w0hjoaper_width !== (float)$Vkvw5zjrwkdm->length_in_pt($Vr15q1qrbafs_value)) {
                                            continue (3);
                                        }
                                        break;
                                    case "min-width":
                                        
                                        if ($V2d1s45w0hjoaper_width < (float)$Vkvw5zjrwkdm->length_in_pt($Vr15q1qrbafs_value)) {
                                            continue (3);
                                        }
                                        break;
                                    case "max-width":
                                        
                                        if ($V2d1s45w0hjoaper_width > (float)$Vkvw5zjrwkdm->length_in_pt($Vr15q1qrbafs_value)) {
                                            continue (3);
                                        }
                                        break;
                                    case "orientation":
                                        if ($V2d1s45w0hjoaper_orientation !== $Vr15q1qrbafs_value) {
                                            continue (3);
                                        }
                                        break;
                                    default:
                                        Helpers::record_warnings(E_USER_WARNING, "Unknown media query: $Vr15q1qrbafs_feature", __FILE__, __LINE__);
                                        break;
                                }
                            }
                        }

                        $Vkvw5zjrwkdm->merge($V500t5q0ulgs);
                    }
                }
            }

            
            if ($V2d1s45w0hjo) {

                if ($Vogaw3hbey3g) {
                    print "inherit:\n";
                    print "[\n";
                    $V2d1s45w0hjo->get_style()->debug_print();
                    print "]\n";
                }

                $Vkvw5zjrwkdm->inherit($V2d1s45w0hjo->get_style());
            }

            if ($Vogaw3hbey3g) {
                print "DomElementStyle:\n";
                print "[\n";
                $Vkvw5zjrwkdm->debug_print();
                print "]\n";
                print "/$Vngrhfhlmiygebug_nodename]\n</pre>";
            }

            
            $Vexjfacrc1d4->set_style($Vkvw5zjrwkdm);

            if (!$V131zbcz0qfq && $this->_page_styles["base"]) {
                $V131zbcz0qfq = true;

                
                if ($Vkvw5zjrwkdm->size !== "auto") {
                    list($V2d1s45w0hjoaper_width, $V2d1s45w0hjoaper_height) = $Vkvw5zjrwkdm->size;
                }
                $V2d1s45w0hjoaper_width = $V2d1s45w0hjoaper_width - (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_left) - (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_right);
                $V2d1s45w0hjoaper_height = $V2d1s45w0hjoaper_height - (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_top) - (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_bottom);
                $V2d1s45w0hjoaper_orientation = ($V2d1s45w0hjoaper_width > $V2d1s45w0hjoaper_height ? "landscape" : "portrait");
            }
        }

        
        
        foreach (array_keys($this->_styles) as $Vbd2mxirzq2d) {
            $this->_styles[$Vbd2mxirzq2d] = null;
            unset($this->_styles[$Vbd2mxirzq2d]);
        }

    }

    
    private function _parse_css($V500t5q0ulgstr)
    {

        $V500t5q0ulgstr = trim($V500t5q0ulgstr);

        
        $Vezwmkkcp5ez = preg_replace(array(
            "'/\*.*?\*/'si",
            "/^<!--/",
            "/-->$/"
        ), "", $V500t5q0ulgstr);

        

        
        $Vvij5cqnugea =
            "/\s*                                   # Skip leading whitespace                             \n" .
            "( @([^\s{]+)\s*([^{;]*) (?:;|({)) )?   # Match @rules followed by ';' or '{'                 \n" .
            "(?(1)                                  # Only parse sub-sections if we're in an @rule...     \n" .
            "  (?(4)                                # ...and if there was a leading '{'                   \n" .
            "    \s*( (?:(?>[^{}]+) ({)?            # Parse rulesets and individual @page rules           \n" .
            "            (?(6) (?>[^}]*) }) \s*)+?                                                        \n" .
            "       )                                                                                     \n" .
            "   })                                  # Balancing '}'                                       \n" .
            "|                                      # Branch to match regular rules (not preceded by '@') \n" .
            "([^{]*{[^}]*}))                        # Parse normal rulesets                               \n" .
            "/xs";

        if (preg_match_all($Vvij5cqnugea, $Vezwmkkcp5ez, $Vgvt1cvsrlfv, PREG_SET_ORDER) === false) {
            
            throw new Exception("Error parsing css file: preg_match_all() failed.");
        }

        
        
        
        
        
        
        
        
        
        
        

        $Vr15q1qrbafs_regex = "/(?:((only|not)?\s*(" . implode("|", self::$Vwjaxztm30ih) . "))|(\s*\(\s*((?:(min|max)-)?([\w\-]+))\s*(?:\:\s*(.*?)\s*)?\)))/isx";

        
        foreach ($Vgvt1cvsrlfv as $Vmms5wlre01j) {
            $Vmms5wlre01j[2] = trim($Vmms5wlre01j[2]);

            if ($Vmms5wlre01j[2] !== "") {
                
                switch ($Vmms5wlre01j[2]) {

                    case "import":
                        $this->_parse_import($Vmms5wlre01j[3]);
                        break;

                    case "media":
                        $V4dkbhpdu11qcceptedmedia = self::$V0puti5o3dds;
                        $V4dkbhpdu11qcceptedmedia[] = $this->_dompdf->getOptions()->getDefaultMediaType();

                        $Vtzoteyx4chw = preg_split("/\s*,\s*/", mb_strtolower(trim($Vmms5wlre01j[3])));
                        foreach ($Vtzoteyx4chw as $Vr15q1qrbafs) {
                            if (in_array($Vr15q1qrbafs, $V4dkbhpdu11qcceptedmedia)) {
                                
                                $this->_parse_sections($Vmms5wlre01j[5]);
                                break;
                            } elseif (!in_array($Vr15q1qrbafs, self::$Vwjaxztm30ih)) {
                                
                                if (preg_match_all($Vr15q1qrbafs_regex, $Vr15q1qrbafs, $Vr15q1qrbafs_matches, PREG_SET_ORDER) !== false) {
                                    $Vlqtdbsvuvii = array();
                                    foreach ($Vr15q1qrbafs_matches as $Vr15q1qrbafs_match) {
                                        if (empty($Vr15q1qrbafs_match[1]) === false) {
                                            $Vr15q1qrbafs_feature = strtolower($Vr15q1qrbafs_match[3]);
                                            $Vr15q1qrbafs_value = strtolower($Vr15q1qrbafs_match[2]);
                                            $Vlqtdbsvuvii[] = array($Vr15q1qrbafs_feature, $Vr15q1qrbafs_value);
                                        } else if (empty($Vr15q1qrbafs_match[4]) === false) {
                                            $Vr15q1qrbafs_feature = strtolower($Vr15q1qrbafs_match[5]);
                                            $Vr15q1qrbafs_value = (array_key_exists(8, $Vr15q1qrbafs_match) ? strtolower($Vr15q1qrbafs_match[8]) : null);
                                            $Vlqtdbsvuvii[] = array($Vr15q1qrbafs_feature, $Vr15q1qrbafs_value);
                                        }
                                    }
                                    $this->_parse_sections($Vmms5wlre01j[5], $Vlqtdbsvuvii);
                                    break;
                                }
                            }
                        }
                        break;

                    case "page":
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                        $V2d1s45w0hjoage_selector = trim($Vmms5wlre01j[3]);

                        $Vbd2mxirzq2d = null;
                        switch ($V2d1s45w0hjoage_selector) {
                            case "":
                                $Vbd2mxirzq2d = "base";
                                break;

                            case ":left":
                            case ":right":
                            case ":odd":
                            case ":even":
                            
                            case ":first":
                                $Vbd2mxirzq2d = $V2d1s45w0hjoage_selector;

                            default:
                                continue;
                        }

                        
                        if (empty($this->_page_styles[$Vbd2mxirzq2d])) {
                            $this->_page_styles[$Vbd2mxirzq2d] = $this->_parse_properties($Vmms5wlre01j[5]);
                        } else {
                            $this->_page_styles[$Vbd2mxirzq2d]->merge($this->_parse_properties($Vmms5wlre01j[5]));
                        }
                        break;

                    case "font-face":
                        $this->_parse_font_face($Vmms5wlre01j[5]);
                        break;

                    default:
                        
                        break;
                }

                continue;
            }

            if ($Vmms5wlre01j[7] !== "") {
                $this->_parse_sections($Vmms5wlre01j[7]);
            }

        }
    }

    
    protected function _image($Vso3o0kfkstx)
    {
        $Vogaw3hbey3g = $this->_dompdf->getOptions()->getDebugCss();
        $V45k3lamsnfi_url = "none";

        if (mb_strpos($Vso3o0kfkstx, "url") === false) {
            $Vt321vu1jwdw = "none"; 
        } else {
            $Vso3o0kfkstx = preg_replace("/url\(\s*['\"]?([^'\")]+)['\"]?\s*\)/", "\\1", trim($Vso3o0kfkstx));

            
            $V45k3lamsnfi_url = Helpers::explode_url($Vso3o0kfkstx);
            if ($V45k3lamsnfi_url["protocol"] == "" && $this->get_protocol() == "") {
                if ($V45k3lamsnfi_url["path"][0] === '/' || $V45k3lamsnfi_url["path"][0] === '\\') {
                    $Vt321vu1jwdw = $_SERVER["DOCUMENT_ROOT"] . '/';
                } else {
                    $Vt321vu1jwdw = $this->get_base_path();
                }

                $Vt321vu1jwdw .= $V45k3lamsnfi_url["path"] . $V45k3lamsnfi_url["file"];
                $Vt321vu1jwdw = realpath($Vt321vu1jwdw);
                
                
                if (!$Vt321vu1jwdw) {
                    $Vt321vu1jwdw = 'none';
                }
            } else {
                $Vt321vu1jwdw = Helpers::build_url($this->get_protocol(),
                    $this->get_host(),
                    $this->get_base_path(),
                    $Vso3o0kfkstx);
            }
        }

        if ($Vogaw3hbey3g) {
            print "<pre>[_image\n";
            print_r($V45k3lamsnfi_url);
            print $this->get_protocol() . "\n" . $this->get_base_path() . "\n" . $Vt321vu1jwdw . "\n";
            print "_image]</pre>";;
        }

        return $Vt321vu1jwdw;
    }

    
    private function _parse_import($Vop22rgf5euu)
    {
        $V4dkbhpdu11qrr = preg_split("/[\s\n,]/", $Vop22rgf5euu, -1, PREG_SPLIT_NO_EMPTY);
        $Vop22rgf5euu = array_shift($V4dkbhpdu11qrr);
        $V4dkbhpdu11qccept = false;

        if (count($V4dkbhpdu11qrr) > 0) {
            $V4dkbhpdu11qcceptedmedia = self::$V0puti5o3dds;
            $V4dkbhpdu11qcceptedmedia[] = $this->_dompdf->getOptions()->getDefaultMediaType();

            
            foreach ($V4dkbhpdu11qrr as $Vky1xzjrvbn4) {
                if (in_array(mb_strtolower(trim($Vky1xzjrvbn4)), $V4dkbhpdu11qcceptedmedia)) {
                    $V4dkbhpdu11qccept = true;
                    break;
                }
            }

        } else {
            
            $V4dkbhpdu11qccept = true;
        }

        if ($V4dkbhpdu11qccept) {
            
            $Vz2fphjg3555 = $this->_protocol;
            $Vskypresjwem = $this->_base_host;
            $Vt321vu1jwdw = $this->_base_path;

            
            
            
            
            

            $Vop22rgf5euu = $this->_image($Vop22rgf5euu);

            $this->load_css_file($Vop22rgf5euu);

            
            $this->_protocol = $Vz2fphjg3555;
            $this->_base_host = $Vskypresjwem;
            $this->_base_path = $Vt321vu1jwdw;
        }

    }

    
    private function _parse_font_face($V500t5q0ulgstr)
    {
        $Vngrhfhlmiygescriptors = $this->_parse_properties($V500t5q0ulgstr);

        preg_match_all("/(url|local)\s*\([\"\']?([^\"\'\)]+)[\"\']?\)\s*(format\s*\([\"\']?([^\"\'\)]+)[\"\']?\))?/i", $Vngrhfhlmiygescriptors->src, $V500t5q0ulgsrc);

        $V500t5q0ulgsources = array();
        $Vso3o0kfkstxid_sources = array();

        foreach ($V500t5q0ulgsrc[0] as $V0ixz2v5mxzy => $Veugw2h43vxz) {
            $V500t5q0ulgsource = array(
                "local" => strtolower($V500t5q0ulgsrc[1][$V0ixz2v5mxzy]) === "local",
                "uri" => $V500t5q0ulgsrc[2][$V0ixz2v5mxzy],
                "format" => strtolower($V500t5q0ulgsrc[4][$V0ixz2v5mxzy]),
                "path" => Helpers::build_url($this->_protocol, $this->_base_host, $this->_base_path, $V500t5q0ulgsrc[2][$V0ixz2v5mxzy]),
            );

            if (!$V500t5q0ulgsource["local"] && in_array($V500t5q0ulgsource["format"], array("", "truetype"))) {
                $Vso3o0kfkstxid_sources[] = $V500t5q0ulgsource;
            }

            $V500t5q0ulgsources[] = $V500t5q0ulgsource;
        }

        
        if (empty($Vso3o0kfkstxid_sources)) {
            return;
        }

        $Vkvw5zjrwkdm = array(
            "family" => $Vngrhfhlmiygescriptors->get_font_family_raw(),
            "weight" => $Vngrhfhlmiygescriptors->font_weight,
            "style" => $Vngrhfhlmiygescriptors->font_style,
        );

        $this->getFontMetrics()->registerFont($Vkvw5zjrwkdm, $Vso3o0kfkstxid_sources[0]["path"], $this->_dompdf->getHttpContext());
    }

    
    private function _parse_properties($V500t5q0ulgstr)
    {
        $V2d1s45w0hjoroperties = preg_split("/;(?=(?:[^\(]*\([^\)]*\))*(?![^\)]*\)))/", $V500t5q0ulgstr);
        $Vogaw3hbey3g = $this->_dompdf->getOptions()->getDebugCss();

        if ($Vogaw3hbey3g) {
            print '[_parse_properties';
        }

        
        $Vkvw5zjrwkdm = new Style($this, Stylesheet::ORIG_AUTHOR);

        foreach ($V2d1s45w0hjoroperties as $V2d1s45w0hjorop) {
            
            
            
            
            
            
            
            
            
            
            

            
            if ($Vogaw3hbey3g) print '(';

            $V0ixz2v5mxzymportant = false;
            $V2d1s45w0hjorop = trim($V2d1s45w0hjorop);

            if (substr($V2d1s45w0hjorop, -9) === 'important') {
                $V2d1s45w0hjorop_tmp = rtrim(substr($V2d1s45w0hjorop, 0, -9));

                if (substr($V2d1s45w0hjorop_tmp, -1) === '!') {
                    $V2d1s45w0hjorop = rtrim(substr($V2d1s45w0hjorop_tmp, 0, -1));
                    $V0ixz2v5mxzymportant = true;
                }
            }

            if ($V2d1s45w0hjorop === "") {
                if ($Vogaw3hbey3g) print 'empty)';
                continue;
            }

            $V0ixz2v5mxzy = mb_strpos($V2d1s45w0hjorop, ":");
            if ($V0ixz2v5mxzy === false) {
                if ($Vogaw3hbey3g) print 'novalue' . $V2d1s45w0hjorop . ')';
                continue;
            }

            $V2d1s45w0hjorop_name = rtrim(mb_strtolower(mb_substr($V2d1s45w0hjorop, 0, $V0ixz2v5mxzy)));
            $Veugw2h43vxz = ltrim(mb_substr($V2d1s45w0hjorop, $V0ixz2v5mxzy + 1));
            if ($Vogaw3hbey3g) print $V2d1s45w0hjorop_name . ':=' . $Veugw2h43vxz . ($V0ixz2v5mxzymportant ? '!IMPORTANT' : '') . ')';
            
            
            
            
            
            
            if ($V0ixz2v5mxzymportant) {
                $Vkvw5zjrwkdm->important_set($V2d1s45w0hjorop_name);
            }
            
            $Vkvw5zjrwkdm->$V2d1s45w0hjorop_name = $Veugw2h43vxz;
            
        }
        if ($Vogaw3hbey3g) print '_parse_properties]';

        return $Vkvw5zjrwkdm;
    }

    
    private function _parse_sections($V500t5q0ulgstr, $Vtzoteyx4chw = array())
    {
        
        

        $V2d1s45w0hjoatterns = array("/[\\s\n]+/", "/\\s+([>.:+#])\\s+/");
        $Vvij5cqnugeaplacements = array(" ", "\\1");
        $V500t5q0ulgstr = preg_replace($V2d1s45w0hjoatterns, $Vvij5cqnugeaplacements, $V500t5q0ulgstr);
        $Vogaw3hbey3g = $this->_dompdf->getOptions()->getDebugCss();

        $V500t5q0ulgsections = explode("}", $V500t5q0ulgstr);
        if ($Vogaw3hbey3g) print '[_parse_sections';
        foreach ($V500t5q0ulgsections as $V500t5q0ulgsect) {
            $V0ixz2v5mxzy = mb_strpos($V500t5q0ulgsect, "{");
            if ($V0ixz2v5mxzy === false) { continue; }

            
            $Vvevoq3s1gg5s = preg_split("/,(?![^\(]*\))/", mb_substr($V500t5q0ulgsect, 0, $V0ixz2v5mxzy),0, PREG_SPLIT_NO_EMPTY);
            if ($Vogaw3hbey3g) print '[section';

            $Vkvw5zjrwkdm = $this->_parse_properties(trim(mb_substr($V500t5q0ulgsect, $V0ixz2v5mxzy + 1)));

            
            foreach ($Vvevoq3s1gg5s as $Vvevoq3s1gg5) {
                $Vvevoq3s1gg5 = trim($Vvevoq3s1gg5);

                if ($Vvevoq3s1gg5 == "") {
                    if ($Vogaw3hbey3g) print '#empty#';
                    continue;
                }
                if ($Vogaw3hbey3g) print '#' . $Vvevoq3s1gg5 . '#';
                

                
                if (count($Vtzoteyx4chw) > 0) {
                    $Vkvw5zjrwkdm->set_media_queries($Vtzoteyx4chw);
                }
                $this->add_style($Vvevoq3s1gg5, $Vkvw5zjrwkdm);
            }

            if ($Vogaw3hbey3g) {
                print 'section]';
            }
        }

        if ($Vogaw3hbey3g) {
            print '_parse_sections]';
        }
    }

    
    public static function getDefaultStylesheet()
    {
        $Vngrhfhlmiygir = realpath(__DIR__ . "/../..");
        return $Vngrhfhlmiygir . self::DEFAULT_STYLESHEET;
    }

    
    public function setFontMetrics(FontMetrics $Vnl1binwcwye)
    {
        $this->fontMetrics = $Vnl1binwcwye;
        return $this;
    }

    
    public function getFontMetrics()
    {
        return $this->fontMetrics;
    }

    
    function __toString()
    {
        $V500t5q0ulgstr = "";
        foreach ($this->_styles as $Vvevoq3s1gg5 => $Vvevoq3s1gg5_styles) {
            
            foreach ($Vvevoq3s1gg5_styles as $Vkvw5zjrwkdm) {
                $V500t5q0ulgstr .= "$Vvevoq3s1gg5 => " . $Vkvw5zjrwkdm->__toString() . "\n";
            }
        }

        return $V500t5q0ulgstr;
    }
}
