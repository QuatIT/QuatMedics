<?php

namespace Dompdf\Css;

use Dompdf\Adapter\CPDF;
use Dompdf\Exception;
use Dompdf\Helpers;
use Dompdf\FontMetrics;
use Dompdf\Frame;


class Style
{

    const CSS_IDENTIFIER = "-?[_a-zA-Z]+[_a-zA-Z0-9-]*";
    const CSS_INTEGER = "-?\d+";

    
    static $Vwo33jxbw1qg = 12;

    
    static $Vk0tpaalobci = 1.2;

    
    static $Vkp1huvzgnqj = array(
        "xx-small" => 0.6, 
        "x-small" => 0.75, 
        "small" => 0.889, 
        "medium" => 1, 
        "large" => 1.2, 
        "x-large" => 1.5, 
        "xx-large" => 2.0, 
    );

    
    static $Ve4opixlv0wf = array("baseline", "bottom", "middle", "sub",
        "super", "text-bottom", "text-top", "top");

    
    static $Vumjaagcajbo = array("inline");

    
    static $V4ljaw3znygd = array("block", "inline-block", "table-cell", "list-item");

    
    static $Vlcojnozlwvg = array("relative", "absolute", "fixed");

    
    static $V1kgzsc154dh = array("table", "inline-table");

    
    static $Vsu0cqse33cm = array("none", "hidden", "dotted", "dashed", "solid",
        "double", "groove", "ridge", "inset", "outset");

    
    static protected $V04v34ed5kmm = null;

    
    static protected $Vbpe3lxpswdh = null;

    
    static protected $Vqduqtdqon2w = array();

    
    protected $Vey0vsemvkm4; 

    
    protected $Vmwlssmz05yy;

    
    protected $V4xvyllv4pg0;

    
    protected $Viocoezx3yfu;

    
    protected $Vxpeh2ii0beu;

    
    protected $Vhnndsvgxsq1; 

    protected $Vzph4ol2mxee;

    
    protected $Vzyb2djzba42;

    
    protected $Vpfwkfzmdfb4 = Stylesheet::ORIG_AUTHOR;

    
    
    private $Vv02ni040ea1; 

    
    private $Vfscpqblidch = null;

    
    private $Vkcudu5fbpvq = null;

    
    public $Vkl3i2nuhkcl = false;

    
    private $Vnl1binwcwye;

    
    public function __construct(Stylesheet $Vh0djujchlkk, $Vys1hksmqmvt = Stylesheet::ORIG_AUTHOR)
    {
        $Vvkqsaecgfirhis->setFontMetrics($Vh0djujchlkk->getFontMetrics());

        $Vvkqsaecgfirhis->_props = array();
        $Vvkqsaecgfirhis->_important_props = array();
        $Vvkqsaecgfirhis->_stylesheet = $Vh0djujchlkk;
        $Vvkqsaecgfirhis->_media_queries = array();
        $Vvkqsaecgfirhis->_origin = $Vys1hksmqmvt;
        $Vvkqsaecgfirhis->_parent_font_size = null;
        $Vvkqsaecgfirhis->__font_size_calculated = false;

        if (!isset(self::$V04v34ed5kmm)) {

            
            $Vngrhfhlmiyg =& self::$V04v34ed5kmm;

            
            $Vngrhfhlmiyg["azimuth"] = "center";
            $Vngrhfhlmiyg["background_attachment"] = "scroll";
            $Vngrhfhlmiyg["background_color"] = "transparent";
            $Vngrhfhlmiyg["background_image"] = "none";
            $Vngrhfhlmiyg["background_image_resolution"] = "normal";
            $Vngrhfhlmiyg["_dompdf_background_image_resolution"] = $Vngrhfhlmiyg["background_image_resolution"];
            $Vngrhfhlmiyg["background_position"] = "0% 0%";
            $Vngrhfhlmiyg["background_repeat"] = "repeat";
            $Vngrhfhlmiyg["background"] = "";
            $Vngrhfhlmiyg["border_collapse"] = "separate";
            $Vngrhfhlmiyg["border_color"] = "";
            $Vngrhfhlmiyg["border_spacing"] = "0";
            $Vngrhfhlmiyg["border_style"] = "";
            $Vngrhfhlmiyg["border_top"] = "";
            $Vngrhfhlmiyg["border_right"] = "";
            $Vngrhfhlmiyg["border_bottom"] = "";
            $Vngrhfhlmiyg["border_left"] = "";
            $Vngrhfhlmiyg["border_top_color"] = "";
            $Vngrhfhlmiyg["border_right_color"] = "";
            $Vngrhfhlmiyg["border_bottom_color"] = "";
            $Vngrhfhlmiyg["border_left_color"] = "";
            $Vngrhfhlmiyg["border_top_style"] = "none";
            $Vngrhfhlmiyg["border_right_style"] = "none";
            $Vngrhfhlmiyg["border_bottom_style"] = "none";
            $Vngrhfhlmiyg["border_left_style"] = "none";
            $Vngrhfhlmiyg["border_top_width"] = "medium";
            $Vngrhfhlmiyg["border_right_width"] = "medium";
            $Vngrhfhlmiyg["border_bottom_width"] = "medium";
            $Vngrhfhlmiyg["border_left_width"] = "medium";
            $Vngrhfhlmiyg["border_width"] = "medium";
            $Vngrhfhlmiyg["border_bottom_left_radius"] = "";
            $Vngrhfhlmiyg["border_bottom_right_radius"] = "";
            $Vngrhfhlmiyg["border_top_left_radius"] = "";
            $Vngrhfhlmiyg["border_top_right_radius"] = "";
            $Vngrhfhlmiyg["border_radius"] = "";
            $Vngrhfhlmiyg["border"] = "";
            $Vngrhfhlmiyg["bottom"] = "auto";
            $Vngrhfhlmiyg["caption_side"] = "top";
            $Vngrhfhlmiyg["clear"] = "none";
            $Vngrhfhlmiyg["clip"] = "auto";
            $Vngrhfhlmiyg["color"] = "#000000";
            $Vngrhfhlmiyg["content"] = "normal";
            $Vngrhfhlmiyg["counter_increment"] = "none";
            $Vngrhfhlmiyg["counter_reset"] = "none";
            $Vngrhfhlmiyg["cue_after"] = "none";
            $Vngrhfhlmiyg["cue_before"] = "none";
            $Vngrhfhlmiyg["cue"] = "";
            $Vngrhfhlmiyg["cursor"] = "auto";
            $Vngrhfhlmiyg["direction"] = "ltr";
            $Vngrhfhlmiyg["display"] = "inline";
            $Vngrhfhlmiyg["elevation"] = "level";
            $Vngrhfhlmiyg["empty_cells"] = "show";
            $Vngrhfhlmiyg["float"] = "none";
            $Vngrhfhlmiyg["font_family"] = $Vh0djujchlkk->get_dompdf()->getOptions()->getDefaultFont();
            $Vngrhfhlmiyg["font_size"] = "medium";
            $Vngrhfhlmiyg["font_style"] = "normal";
            $Vngrhfhlmiyg["font_variant"] = "normal";
            $Vngrhfhlmiyg["font_weight"] = "normal";
            $Vngrhfhlmiyg["font"] = "";
            $Vngrhfhlmiyg["height"] = "auto";
            $Vngrhfhlmiyg["image_resolution"] = "normal";
            $Vngrhfhlmiyg["_dompdf_image_resolution"] = $Vngrhfhlmiyg["image_resolution"];
            $Vngrhfhlmiyg["_dompdf_keep"] = "";
            $Vngrhfhlmiyg["left"] = "auto";
            $Vngrhfhlmiyg["letter_spacing"] = "normal";
            $Vngrhfhlmiyg["line_height"] = "normal";
            $Vngrhfhlmiyg["list_style_image"] = "none";
            $Vngrhfhlmiyg["list_style_position"] = "outside";
            $Vngrhfhlmiyg["list_style_type"] = "disc";
            $Vngrhfhlmiyg["list_style"] = "";
            $Vngrhfhlmiyg["margin_right"] = "0";
            $Vngrhfhlmiyg["margin_left"] = "0";
            $Vngrhfhlmiyg["margin_top"] = "0";
            $Vngrhfhlmiyg["margin_bottom"] = "0";
            $Vngrhfhlmiyg["margin"] = "";
            $Vngrhfhlmiyg["max_height"] = "none";
            $Vngrhfhlmiyg["max_width"] = "none";
            $Vngrhfhlmiyg["min_height"] = "0";
            $Vngrhfhlmiyg["min_width"] = "0";
            $Vngrhfhlmiyg["opacity"] = "1.0"; 
            $Vngrhfhlmiyg["orphans"] = "2";
            $Vngrhfhlmiyg["outline_color"] = ""; 
            $Vngrhfhlmiyg["outline_style"] = "none";
            $Vngrhfhlmiyg["outline_width"] = "medium";
            $Vngrhfhlmiyg["outline"] = "";
            $Vngrhfhlmiyg["overflow"] = "visible";
            $Vngrhfhlmiyg["padding_top"] = "0";
            $Vngrhfhlmiyg["padding_right"] = "0";
            $Vngrhfhlmiyg["padding_bottom"] = "0";
            $Vngrhfhlmiyg["padding_left"] = "0";
            $Vngrhfhlmiyg["padding"] = "";
            $Vngrhfhlmiyg["page_break_after"] = "auto";
            $Vngrhfhlmiyg["page_break_before"] = "auto";
            $Vngrhfhlmiyg["page_break_inside"] = "auto";
            $Vngrhfhlmiyg["pause_after"] = "0";
            $Vngrhfhlmiyg["pause_before"] = "0";
            $Vngrhfhlmiyg["pause"] = "";
            $Vngrhfhlmiyg["pitch_range"] = "50";
            $Vngrhfhlmiyg["pitch"] = "medium";
            $Vngrhfhlmiyg["play_during"] = "auto";
            $Vngrhfhlmiyg["position"] = "static";
            $Vngrhfhlmiyg["quotes"] = "";
            $Vngrhfhlmiyg["richness"] = "50";
            $Vngrhfhlmiyg["right"] = "auto";
            $Vngrhfhlmiyg["size"] = "auto"; 
            $Vngrhfhlmiyg["speak_header"] = "once";
            $Vngrhfhlmiyg["speak_numeral"] = "continuous";
            $Vngrhfhlmiyg["speak_punctuation"] = "none";
            $Vngrhfhlmiyg["speak"] = "normal";
            $Vngrhfhlmiyg["speech_rate"] = "medium";
            $Vngrhfhlmiyg["stress"] = "50";
            $Vngrhfhlmiyg["table_layout"] = "auto";
            $Vngrhfhlmiyg["text_align"] = "left";
            $Vngrhfhlmiyg["text_decoration"] = "none";
            $Vngrhfhlmiyg["text_indent"] = "0";
            $Vngrhfhlmiyg["text_transform"] = "none";
            $Vngrhfhlmiyg["top"] = "auto";
            $Vngrhfhlmiyg["transform"] = "none"; 
            $Vngrhfhlmiyg["transform_origin"] = "50% 50%"; 
            $Vngrhfhlmiyg["_webkit_transform"] = $Vngrhfhlmiyg["transform"]; 
            $Vngrhfhlmiyg["_webkit_transform_origin"] = $Vngrhfhlmiyg["transform_origin"]; 
            $Vngrhfhlmiyg["unicode_bidi"] = "normal";
            $Vngrhfhlmiyg["vertical_align"] = "baseline";
            $Vngrhfhlmiyg["visibility"] = "visible";
            $Vngrhfhlmiyg["voice_family"] = "";
            $Vngrhfhlmiyg["volume"] = "medium";
            $Vngrhfhlmiyg["white_space"] = "normal";
            $Vngrhfhlmiyg["word_wrap"] = "normal";
            $Vngrhfhlmiyg["widows"] = "2";
            $Vngrhfhlmiyg["width"] = "auto";
            $Vngrhfhlmiyg["word_spacing"] = "normal";
            $Vngrhfhlmiyg["z_index"] = "auto";

            
            $Vngrhfhlmiyg["src"] = "";
            $Vngrhfhlmiyg["unicode_range"] = "";

            
            self::$Vbpe3lxpswdh = array(
                "azimuth",
                "background_image_resolution",
                "border_collapse",
                "border_spacing",
                "caption_side",
                "color",
                "cursor",
                "direction",
                "elevation",
                "empty_cells",
                "font_family",
                "font_size",
                "font_style",
                "font_variant",
                "font_weight",
                "font",
                "image_resolution",
                "letter_spacing",
                "line_height",
                "list_style_image",
                "list_style_position",
                "list_style_type",
                "list_style",
                "orphans",
                "page_break_inside",
                "pitch_range",
                "pitch",
                "quotes",
                "richness",
                "speak_header",
                "speak_numeral",
                "speak_punctuation",
                "speak",
                "speech_rate",
                "stress",
                "text_align",
                "text_indent",
                "text_transform",
                "visibility",
                "voice_family",
                "volume",
                "white_space",
                "word_wrap",
                "widows",
                "word_spacing",
            );
        }
    }

    
    function dispose()
    {
    }

    
    function set_media_queries($Vtzoteyx4chw)
    {
        $Vvkqsaecgfirhis->_media_queries = $Vtzoteyx4chw;
    }

    
    function get_media_queries()
    {
        return $Vvkqsaecgfirhis->_media_queries;
    }

    
    function set_frame(Frame $Vexjfacrc1d4)
    {
        $Vvkqsaecgfirhis->_frame = $Vexjfacrc1d4;
    }

    
    function get_frame()
    {
        return $Vvkqsaecgfirhis->_frame;
    }

    
    function set_origin($Vys1hksmqmvt)
    {
        $Vvkqsaecgfirhis->_origin = $Vys1hksmqmvt;
    }

    
    function get_origin()
    {
        return $Vvkqsaecgfirhis->_origin;
    }

    
    function get_stylesheet()
    {
        return $Vvkqsaecgfirhis->_stylesheet;
    }

    
    function length_in_pt($Vyfoeno5vtuw, $V3kvvps2vvbk = null)
    {
        static $Vpqxygdkkwnh = array();

        if (!isset($V3kvvps2vvbk)) {
            $V3kvvps2vvbk = self::$Vwo33jxbw1qg;
        }

        if (!is_array($Vyfoeno5vtuw)) {
            $Vbd2mxirzq2d = $Vyfoeno5vtuw . "/$V3kvvps2vvbk";
            
            if (isset($Vpqxygdkkwnh[$Vbd2mxirzq2d])) {
                return $Vpqxygdkkwnh[$Vbd2mxirzq2d];
            }
            $Vyfoeno5vtuw = array($Vyfoeno5vtuw);
        } else {
            $Vbd2mxirzq2d = implode("@", $Vyfoeno5vtuw) . "/$V3kvvps2vvbk";
            if (isset($Vpqxygdkkwnh[$Vbd2mxirzq2d])) {
                return $Vpqxygdkkwnh[$Vbd2mxirzq2d];
            }
        }

        $Vaamzcof1atz = 0;
        foreach ($Vyfoeno5vtuw as $V3fvqcsh5wgl) {

            if ($V3fvqcsh5wgl === "auto") {
                return "auto";
            }

            if ($V3fvqcsh5wgl === "none") {
                return "none";
            }

            
            if (is_numeric($V3fvqcsh5wgl)) {
                $Vaamzcof1atz += $V3fvqcsh5wgl;
                continue;
            }

            if ($V3fvqcsh5wgl === "normal") {
                $Vaamzcof1atz += (float)$V3kvvps2vvbk;
                continue;
            }

            
            if ($V3fvqcsh5wgl === "thin") {
                $Vaamzcof1atz += 0.5;
                continue;
            }

            if ($V3fvqcsh5wgl === "medium") {
                $Vaamzcof1atz += 1.5;
                continue;
            }

            if ($V3fvqcsh5wgl === "thick") {
                $Vaamzcof1atz += 2.5;
                continue;
            }

            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "px")) !== false) {
                $Vngrhfhlmiygpi = $Vvkqsaecgfirhis->_stylesheet->get_dompdf()->getOptions()->getDpi();
                $Vaamzcof1atz += ((float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) * 72) / $Vngrhfhlmiygpi;
                continue;
            }

            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "pt")) !== false) {
                $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy);
                continue;
            }

            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "%")) !== false) {
                $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) / 100 * (float)$V3kvvps2vvbk;
                continue;
            }

            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "rem")) !== false) {
                if ($Vvkqsaecgfirhis->_stylesheet->get_dompdf()->getTree()->get_root()->get_style() === null) {
                    
                    $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) * $Vvkqsaecgfirhis->__get("font_size");
                } else {
                    $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) * $Vvkqsaecgfirhis->_stylesheet->get_dompdf()->getTree()->get_root()->get_style()->font_size;
                }
                continue;
            }

            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "em")) !== false) {
                $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) * $Vvkqsaecgfirhis->__get("font_size");
                continue;
            }

            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "cm")) !== false) {
                $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) * 72 / 2.54;
                continue;
            }

            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "mm")) !== false) {
                $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) * 72 / 25.4;
                continue;
            }

            
            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "ex")) !== false) {
                $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) * $Vvkqsaecgfirhis->__get("font_size") / 2;
                continue;
            }

            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "in")) !== false) {
                $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) * 72;
                continue;
            }

            if (($V0ixz2v5mxzy = mb_strpos($V3fvqcsh5wgl, "pc")) !== false) {
                $Vaamzcof1atz += (float)mb_substr($V3fvqcsh5wgl, 0, $V0ixz2v5mxzy) * 12;
                continue;
            }

            
            $Vaamzcof1atz += (float)$V3kvvps2vvbk;
        }

        return $Vpqxygdkkwnh[$Vbd2mxirzq2d] = $Vaamzcof1atz;
    }


    
    function inherit(Style $Vhbd3bset2hu)
    {

        
        $Vvkqsaecgfirhis->_parent_font_size = $Vhbd3bset2hu->get_font_size();

        foreach (self::$Vbpe3lxpswdh as $Vbmjcu43y45m) {
            
            
            if (isset($Vhbd3bset2hu->_props[$Vbmjcu43y45m]) &&
                (!isset($Vvkqsaecgfirhis->_props[$Vbmjcu43y45m]) ||
                    (isset($Vhbd3bset2hu->_important_props[$Vbmjcu43y45m]) && !isset($Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m]))
                )
            ) {
                if (isset($Vhbd3bset2hu->_important_props[$Vbmjcu43y45m])) {
                    $Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m] = true;
                }
                
                $Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m] = null;
                $Vvkqsaecgfirhis->_props[$Vbmjcu43y45m] = $Vhbd3bset2hu->_props[$Vbmjcu43y45m];
            }
        }

        foreach ($Vvkqsaecgfirhis->_props as $Vbmjcu43y45m => $Veugw2h43vxz) {
            if ($Veugw2h43vxz === "inherit") {
                if (isset($Vhbd3bset2hu->_important_props[$Vbmjcu43y45m])) {
                    $Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m] = true;
                }
                
                
                
                
                
                
                
                
                
                
                
                $Vvkqsaecgfirhis->__set($Vbmjcu43y45m, $Vhbd3bset2hu->__get($Vbmjcu43y45m));
            }
        }

        return $Vvkqsaecgfirhis;
    }

    
    function merge(Style $Vkvw5zjrwkdm)
    {
        $Viqatpxndpw5 = array("background", "border", "border_bottom", "border_color", "border_left", "border_radius", "border_right", "border_style", "border_top", "border_width", "flex", "font", "list_style", "margin", "padding", "transform");
        
        
        
        foreach ($Vkvw5zjrwkdm->_props as $Vbmjcu43y45m => $Vso3o0kfkstx) {
            $Via0c2f3rra3 = false;
            if (isset($Vkvw5zjrwkdm->_important_props[$Vbmjcu43y45m])) {
                $Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m] = true;
                $Via0c2f3rra3 = true;
            } else if (!isset($Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m])) {
                $Via0c2f3rra3 = true;
            }

            if ($Via0c2f3rra3) {
                
                $Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m] = null;
                $Vvkqsaecgfirhis->_props[$Vbmjcu43y45m] = $Vso3o0kfkstx;

                
                $V2hserrzoxgx = array_filter($Viqatpxndpw5, function($Vxutiqdcpozi) use ($Vbmjcu43y45m) {
                    return ( strpos($Vbmjcu43y45m, $Vxutiqdcpozi."_") !== false );
                });
                foreach ($V2hserrzoxgx as $V1llxlroymkt) {
                    if (array_key_exists($V1llxlroymkt, $Vvkqsaecgfirhis->_props) && $Vvkqsaecgfirhis->_props[$V1llxlroymkt] === "inherit") {
                        unset($Vvkqsaecgfirhis->_props[$V1llxlroymkt]);
                    }
                }
            }
        }

        if (isset($Vkvw5zjrwkdm->_props["font_size"])) {
            $Vvkqsaecgfirhis->__font_size_calculated = false;
        }
    }

    
    function munge_color($V3poxlnogtlh)
    {
        return Color::parse($V3poxlnogtlh);
    }

    
    function important_set($Vbmjcu43y45m)
    {
        $Vbmjcu43y45m = str_replace("-", "_", $Vbmjcu43y45m);
        $Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m] = true;
    }

    
    function important_get($Vbmjcu43y45m)
    {
        return isset($Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m]);
    }

    
    function __set($Vbmjcu43y45m, $Vso3o0kfkstx)
    {
        $Vbmjcu43y45m = str_replace("-", "_", $Vbmjcu43y45m);
        $Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m] = null;

        if (!isset(self::$V04v34ed5kmm[$Vbmjcu43y45m])) {
            global $V1vwj3kz31tm;
            $V1vwj3kz31tm[] = "'$Vbmjcu43y45m' is not a valid CSS2 property.";
            return;
        }

        if ($Vbmjcu43y45m !== "content" && is_string($Vso3o0kfkstx) && strlen($Vso3o0kfkstx) > 5 && mb_strpos($Vso3o0kfkstx, "url") === false) {
            $Vso3o0kfkstx = mb_strtolower(trim(str_replace(array("\n", "\t"), array(" "), $Vso3o0kfkstx)));
            $Vso3o0kfkstx = preg_replace("/([0-9]+) (pt|px|pc|em|ex|in|cm|mm|%)/S", "\\1\\2", $Vso3o0kfkstx);
        }

        $Vbj2tc0fvhny = "set_$Vbmjcu43y45m";

        if (!isset(self::$Vqduqtdqon2w[$Vbj2tc0fvhny])) {
            self::$Vqduqtdqon2w[$Vbj2tc0fvhny] = method_exists($Vvkqsaecgfirhis, $Vbj2tc0fvhny);
        }

        if (self::$Vqduqtdqon2w[$Vbj2tc0fvhny]) {
            $Vvkqsaecgfirhis->$Vbj2tc0fvhny($Vso3o0kfkstx);
        } else {
            $Vvkqsaecgfirhis->_props[$Vbmjcu43y45m] = $Vso3o0kfkstx;
        }
    }

    
    function __get($Vbmjcu43y45m)
    {
        if (!isset(self::$V04v34ed5kmm[$Vbmjcu43y45m])) {
            throw new Exception("'$Vbmjcu43y45m' is not a valid CSS2 property.");
        }

        if (isset($Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m]) && $Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m] != null) {
            return $Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m];
        }

        $Vbj2tc0fvhny = "get_$Vbmjcu43y45m";

        
        if (!isset($Vvkqsaecgfirhis->_props[$Vbmjcu43y45m])) {
            $Vvkqsaecgfirhis->_props[$Vbmjcu43y45m] = self::$V04v34ed5kmm[$Vbmjcu43y45m];
        }

        if (!isset(self::$Vqduqtdqon2w[$Vbj2tc0fvhny])) {
            self::$Vqduqtdqon2w[$Vbj2tc0fvhny] = method_exists($Vvkqsaecgfirhis, $Vbj2tc0fvhny);
        }

        if (self::$Vqduqtdqon2w[$Vbj2tc0fvhny]) {
            return $Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m] = $Vvkqsaecgfirhis->$Vbj2tc0fvhny();
        }

        return $Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m] = $Vvkqsaecgfirhis->_props[$Vbmjcu43y45m];
    }

    
    function get_prop($Vbmjcu43y45m)
    {
        if (!isset(self::$V04v34ed5kmm[$Vbmjcu43y45m])) {
            throw new Exception("'$Vbmjcu43y45m' is not a valid CSS2 property.");
        }

        $Vbj2tc0fvhny = "get_$Vbmjcu43y45m";

        
        if (!isset($Vvkqsaecgfirhis->_props[$Vbmjcu43y45m])) {
            return self::$V04v34ed5kmm[$Vbmjcu43y45m];
        }

        if (method_exists($Vvkqsaecgfirhis, $Vbj2tc0fvhny)) {
            return $Vvkqsaecgfirhis->$Vbj2tc0fvhny();
        }

        return $Vvkqsaecgfirhis->_props[$Vbmjcu43y45m];
    }

    
    function computed_bottom_spacing() {
        if ($Vvkqsaecgfirhis->_computed_bottom_spacing !== null) {
            return $Vvkqsaecgfirhis->_computed_bottom_spacing;
        }
        return $Vvkqsaecgfirhis->_computed_bottom_spacing = $Vvkqsaecgfirhis->length_in_pt(
            array(
                $Vvkqsaecgfirhis->margin_bottom,
                $Vvkqsaecgfirhis->padding_bottom,
                $Vvkqsaecgfirhis->border_bottom_width
            )
        );
    }

    
    function get_font_family_raw()
    {
        return trim($Vvkqsaecgfirhis->_props["font_family"], " \t\n\r\x0B\"'");
    }

    
    function get_font_family()
    {
        if (isset($Vvkqsaecgfirhis->_font_family)) {
            return $Vvkqsaecgfirhis->_font_family;
        }

        $Vogaw3hbey3g = $Vvkqsaecgfirhis->_stylesheet->get_dompdf()->getOptions()->getDebugCss();

        
        

        
        $Vhi4cuj0bfya = $Vvkqsaecgfirhis->__get("font_weight");

        if (is_numeric($Vhi4cuj0bfya)) {
            if ($Vhi4cuj0bfya < 600) {
                $Vhi4cuj0bfya = "normal";
            } else {
                $Vhi4cuj0bfya = "bold";
            }
        } else if ($Vhi4cuj0bfya === "bold" || $Vhi4cuj0bfya === "bolder") {
            $Vhi4cuj0bfya = "bold";
        } else {
            $Vhi4cuj0bfya = "normal";
        }

        
        $Vgijduey5nfu = $Vvkqsaecgfirhis->__get("font_style");

        if ($Vhi4cuj0bfya === "bold" && ($Vgijduey5nfu === "italic" || $Vgijduey5nfu === "oblique")) {
            $V4445zgqkfdm = "bold_italic";
        } else if ($Vhi4cuj0bfya === "bold" && $Vgijduey5nfu !== "italic" && $Vgijduey5nfu !== "oblique") {
            $V4445zgqkfdm = "bold";
        } else if ($Vhi4cuj0bfya !== "bold" && ($Vgijduey5nfu === "italic" || $Vgijduey5nfu === "oblique")) {
            $V4445zgqkfdm = "italic";
        } else {
            $V4445zgqkfdm = "normal";
        }

        
        if ($Vogaw3hbey3g) {
            print "<pre>[get_font_family:";
            print '(' . $Vvkqsaecgfirhis->_props["font_family"] . '.' . $Vgijduey5nfu . '.' . $Vvkqsaecgfirhis->__get("font_weight") . '.' . $Vhi4cuj0bfya . '.' . $V4445zgqkfdm . ')';
        }

        $Vijnp4pplof2 = preg_split("/\s*,\s*/", $Vvkqsaecgfirhis->_props["font_family"]);

        $Vfsinbbqzbga = null;
        foreach ($Vijnp4pplof2 as $V2jlfa3zutex) {
            
            
            $V2jlfa3zutex = trim($V2jlfa3zutex, " \t\n\r\x0B\"'");
            if ($Vogaw3hbey3g) {
                print '(' . $V2jlfa3zutex . ')';
            }
            $Vfsinbbqzbga = $Vvkqsaecgfirhis->getFontMetrics()->getFont($V2jlfa3zutex, $V4445zgqkfdm);

            if ($Vfsinbbqzbga) {
                if ($Vogaw3hbey3g) {
                    print '(' . $Vfsinbbqzbga . ")get_font_family]\n</pre>";
                }
                return $Vvkqsaecgfirhis->_font_family = $Vfsinbbqzbga;
            }
        }

        $V2jlfa3zutex = null;
        if ($Vogaw3hbey3g) {
            print '(default)';
        }
        $Vfsinbbqzbga = $Vvkqsaecgfirhis->getFontMetrics()->getFont($V2jlfa3zutex, $V4445zgqkfdm);

        if ($Vfsinbbqzbga) {
            if ($Vogaw3hbey3g) {
                print '(' . $Vfsinbbqzbga . ")get_font_family]\n</pre>";
            }
            return $Vvkqsaecgfirhis->_font_family = $Vfsinbbqzbga;
        }

        throw new Exception("Unable to find a suitable font replacement for: '" . $Vvkqsaecgfirhis->_props["font_family"] . "'");

    }

    
    function get_font_size()
    {

        if ($Vvkqsaecgfirhis->__font_size_calculated) {
            return $Vvkqsaecgfirhis->_props["font_size"];
        }

        if (!isset($Vvkqsaecgfirhis->_props["font_size"])) {
            $Vepzylbkouaw = self::$V04v34ed5kmm["font_size"];
        } else {
            $Vepzylbkouaw = $Vvkqsaecgfirhis->_props["font_size"];
        }

        if (!isset($Vvkqsaecgfirhis->_parent_font_size)) {
            $Vvkqsaecgfirhis->_parent_font_size = self::$Vwo33jxbw1qg;
        }

        switch ((string)$Vepzylbkouaw) {
            case "xx-small":
            case "x-small":
            case "small":
            case "medium":
            case "large":
            case "x-large":
            case "xx-large":
                $Vepzylbkouaw = self::$Vwo33jxbw1qg * self::$Vkp1huvzgnqj[$Vepzylbkouaw];
                break;

            case "smaller":
                $Vepzylbkouaw = 8 / 9 * $Vvkqsaecgfirhis->_parent_font_size;
                break;

            case "larger":
                $Vepzylbkouaw = 6 / 5 * $Vvkqsaecgfirhis->_parent_font_size;
                break;

            default:
                break;
        }

        
        if (($V0ixz2v5mxzy = mb_strpos($Vepzylbkouaw, "em")) !== false) {
            $Vepzylbkouaw = (float)mb_substr($Vepzylbkouaw, 0, $V0ixz2v5mxzy) * $Vvkqsaecgfirhis->_parent_font_size;
        } else if (($V0ixz2v5mxzy = mb_strpos($Vepzylbkouaw, "ex")) !== false) {
            $Vepzylbkouaw = (float)mb_substr($Vepzylbkouaw, 0, $V0ixz2v5mxzy) * $Vvkqsaecgfirhis->_parent_font_size;
        } else {
            $Vepzylbkouaw = (float)$Vvkqsaecgfirhis->length_in_pt($Vepzylbkouaw);
        }

        
        $Vvkqsaecgfirhis->_prop_cache["font_size"] = null;
        $Vvkqsaecgfirhis->_props["font_size"] = $Vepzylbkouaw;
        $Vvkqsaecgfirhis->__font_size_calculated = true;
        return $Vvkqsaecgfirhis->_props["font_size"];

    }

    
    function get_word_spacing()
    {
        if ($Vvkqsaecgfirhis->_props["word_spacing"] === "normal") {
            return 0;
        }

        return $Vvkqsaecgfirhis->_props["word_spacing"];
    }

    
    function get_letter_spacing()
    {
        if ($Vvkqsaecgfirhis->_props["letter_spacing"] === "normal") {
            return 0;
        }

        return $Vvkqsaecgfirhis->_props["letter_spacing"];
    }

    
    function get_line_height()
    {
        if (array_key_exists("line_height", $Vvkqsaecgfirhis->_props) === false) {
            $Vvkqsaecgfirhis->_props["line_height"] = self::$V04v34ed5kmm["line_height"];
        }
        $V3fvqcsh5wgline_height = $Vvkqsaecgfirhis->_props["line_height"];

        if ($V3fvqcsh5wgline_height === "normal") {
            return self::$Vk0tpaalobci * $Vvkqsaecgfirhis->get_font_size();
        }

        if (is_numeric($V3fvqcsh5wgline_height)) {
            return $Vvkqsaecgfirhis->length_in_pt($V3fvqcsh5wgline_height . "em", $Vvkqsaecgfirhis->get_font_size());
        }

        return $Vvkqsaecgfirhis->length_in_pt($V3fvqcsh5wgline_height, $Vvkqsaecgfirhis->_parent_font_size);
    }

    
    function get_color()
    {
        return $Vvkqsaecgfirhis->munge_color($Vvkqsaecgfirhis->_props["color"]);
    }

    
    function get_background_color()
    {
        return $Vvkqsaecgfirhis->munge_color($Vvkqsaecgfirhis->_props["background_color"]);
    }

    
    function get_background_position()
    {
        $Vj0eqma35tbv = explode(" ", $Vvkqsaecgfirhis->_props["background_position"]);

        switch ($Vj0eqma35tbv[0]) {
            case "left":
                $Vmm2pe5l4str = "0%";
                break;

            case "right":
                $Vmm2pe5l4str = "100%";
                break;

            case "top":
                $Vuua0v2znlr5 = "0%";
                break;

            case "bottom":
                $Vuua0v2znlr5 = "100%";
                break;

            case "center":
                $Vmm2pe5l4str = "50%";
                $Vuua0v2znlr5 = "50%";
                break;

            default:
                $Vmm2pe5l4str = $Vj0eqma35tbv[0];
                break;
        }

        if (isset($Vj0eqma35tbv[1])) {
            switch ($Vj0eqma35tbv[1]) {
                case "left":
                    $Vmm2pe5l4str = "0%";
                    break;

                case "right":
                    $Vmm2pe5l4str = "100%";
                    break;

                case "top":
                    $Vuua0v2znlr5 = "0%";
                    break;

                case "bottom":
                    $Vuua0v2znlr5 = "100%";
                    break;

                case "center":
                    if ($Vj0eqma35tbv[0] === "left" || $Vj0eqma35tbv[0] === "right" || $Vj0eqma35tbv[0] === "center") {
                        $Vuua0v2znlr5 = "50%";
                    } else {
                        $Vmm2pe5l4str = "50%";
                    }
                    break;

                default:
                    $Vuua0v2znlr5 = $Vj0eqma35tbv[1];
                    break;
            }
        } else {
            $Vuua0v2znlr5 = "50%";
        }

        if (!isset($Vmm2pe5l4str)) {
            $Vmm2pe5l4str = "0%";
        }

        if (!isset($Vuua0v2znlr5)) {
            $Vuua0v2znlr5 = "0%";
        }

        return array(
            0 => $Vmm2pe5l4str, "x" => $Vmm2pe5l4str,
            1 => $Vuua0v2znlr5, "y" => $Vuua0v2znlr5,
        );
    }


    
    function get_background_attachment()
    {
        return $Vvkqsaecgfirhis->_props["background_attachment"];
    }


    
    function get_background_repeat()
    {
        return $Vvkqsaecgfirhis->_props["background_repeat"];
    }


    
    function get_background()
    {
        return $Vvkqsaecgfirhis->_props["background"];
    }


    
    function get_border_top_color()
    {
        if ($Vvkqsaecgfirhis->_props["border_top_color"] === "") {
            
            $Vvkqsaecgfirhis->_prop_cache["border_top_color"] = null;
            $Vvkqsaecgfirhis->_props["border_top_color"] = $Vvkqsaecgfirhis->__get("color");
        }

        return $Vvkqsaecgfirhis->munge_color($Vvkqsaecgfirhis->_props["border_top_color"]);
    }

    
    function get_border_right_color()
    {
        if ($Vvkqsaecgfirhis->_props["border_right_color"] === "") {
            
            $Vvkqsaecgfirhis->_prop_cache["border_right_color"] = null;
            $Vvkqsaecgfirhis->_props["border_right_color"] = $Vvkqsaecgfirhis->__get("color");
        }

        return $Vvkqsaecgfirhis->munge_color($Vvkqsaecgfirhis->_props["border_right_color"]);
    }

    
    function get_border_bottom_color()
    {
        if ($Vvkqsaecgfirhis->_props["border_bottom_color"] === "") {
            
            $Vvkqsaecgfirhis->_prop_cache["border_bottom_color"] = null;
            $Vvkqsaecgfirhis->_props["border_bottom_color"] = $Vvkqsaecgfirhis->__get("color");
        }

        return $Vvkqsaecgfirhis->munge_color($Vvkqsaecgfirhis->_props["border_bottom_color"]);
    }

    
    function get_border_left_color()
    {
        if ($Vvkqsaecgfirhis->_props["border_left_color"] === "") {
            
            $Vvkqsaecgfirhis->_prop_cache["border_left_color"] = null;
            $Vvkqsaecgfirhis->_props["border_left_color"] = $Vvkqsaecgfirhis->__get("color");
        }

        return $Vvkqsaecgfirhis->munge_color($Vvkqsaecgfirhis->_props["border_left_color"]);
    }

    

    
    function get_border_top_width()
    {
        $Vkvw5zjrwkdm = $Vvkqsaecgfirhis->__get("border_top_style");
        return $Vkvw5zjrwkdm !== "none" && $Vkvw5zjrwkdm !== "hidden" ? $Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->_props["border_top_width"]) : 0;
    }

    
    function get_border_right_width()
    {
        $Vkvw5zjrwkdm = $Vvkqsaecgfirhis->__get("border_right_style");
        return $Vkvw5zjrwkdm !== "none" && $Vkvw5zjrwkdm !== "hidden" ? $Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->_props["border_right_width"]) : 0;
    }

    
    function get_border_bottom_width()
    {
        $Vkvw5zjrwkdm = $Vvkqsaecgfirhis->__get("border_bottom_style");
        return $Vkvw5zjrwkdm !== "none" && $Vkvw5zjrwkdm !== "hidden" ? $Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->_props["border_bottom_width"]) : 0;
    }

    
    function get_border_left_width()
    {
        $Vkvw5zjrwkdm = $Vvkqsaecgfirhis->__get("border_left_style");
        return $Vkvw5zjrwkdm !== "none" && $Vkvw5zjrwkdm !== "hidden" ? $Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->_props["border_left_width"]) : 0;
    }
    

    
    function get_border_properties()
    {
        return array(
            "top" => array(
                "width" => $Vvkqsaecgfirhis->__get("border_top_width"),
                "style" => $Vvkqsaecgfirhis->__get("border_top_style"),
                "color" => $Vvkqsaecgfirhis->__get("border_top_color"),
            ),
            "bottom" => array(
                "width" => $Vvkqsaecgfirhis->__get("border_bottom_width"),
                "style" => $Vvkqsaecgfirhis->__get("border_bottom_style"),
                "color" => $Vvkqsaecgfirhis->__get("border_bottom_color"),
            ),
            "right" => array(
                "width" => $Vvkqsaecgfirhis->__get("border_right_width"),
                "style" => $Vvkqsaecgfirhis->__get("border_right_style"),
                "color" => $Vvkqsaecgfirhis->__get("border_right_color"),
            ),
            "left" => array(
                "width" => $Vvkqsaecgfirhis->__get("border_left_width"),
                "style" => $Vvkqsaecgfirhis->__get("border_left_style"),
                "color" => $Vvkqsaecgfirhis->__get("border_left_color"),
            ),
        );
    }

    
    protected function _get_border($Vcxi3be0s51c)
    {
        $V3poxlnogtlh = $Vvkqsaecgfirhis->__get("border_" . $Vcxi3be0s51c . "_color");

        return $Vvkqsaecgfirhis->__get("border_" . $Vcxi3be0s51c . "_width") . " " .
        $Vvkqsaecgfirhis->__get("border_" . $Vcxi3be0s51c . "_style") . " " . $V3poxlnogtlh["hex"];
    }

    
    function get_border_top()
    {
        return $Vvkqsaecgfirhis->_get_border("top");
    }

    
    function get_border_right()
    {
        return $Vvkqsaecgfirhis->_get_border("right");
    }

    
    function get_border_bottom()
    {
        return $Vvkqsaecgfirhis->_get_border("bottom");
    }

    
    function get_border_left()
    {
        return $Vvkqsaecgfirhis->_get_border("left");
    }

    
    function get_computed_border_radius($V5ymvwogwh5y, $V2pgp3ppbjsi)
    {
        if (!empty($Vvkqsaecgfirhis->_computed_border_radius)) {
            return $Vvkqsaecgfirhis->_computed_border_radius;
        }

        $V5ymvwogwh5y = (float)$V5ymvwogwh5y;
        $V2pgp3ppbjsi = (float)$V2pgp3ppbjsi;
        $Vwt5bv33jejh = (float)$Vvkqsaecgfirhis->__get("border_top_left_radius");
        $Vqwxulammck0 = (float)$Vvkqsaecgfirhis->__get("border_top_right_radius");
        $Vumwapn4ocuu = (float)$Vvkqsaecgfirhis->__get("border_bottom_left_radius");
        $V5ugmqeqrvmq = (float)$Vvkqsaecgfirhis->__get("border_bottom_right_radius");

        if ($Vwt5bv33jejh + $Vqwxulammck0 + $Vumwapn4ocuu + $V5ugmqeqrvmq == 0) {
            return $Vvkqsaecgfirhis->_computed_border_radius = array(
                0, 0, 0, 0,
                "top-left" => 0,
                "top-right" => 0,
                "bottom-right" => 0,
                "bottom-left" => 0,
            );
        }

        $Vvkqsaecgfir = (float)$Vvkqsaecgfirhis->__get("border_top_width");
        $Vapkwgsb3w3r = (float)$Vvkqsaecgfirhis->__get("border_right_width");
        $Vkbvefdrfvxh = (float)$Vvkqsaecgfirhis->__get("border_bottom_width");
        $V3fvqcsh5wgl = (float)$Vvkqsaecgfirhis->__get("border_left_width");

        $Vwt5bv33jejh = min($Vwt5bv33jejh, $V2pgp3ppbjsi - $Vumwapn4ocuu - $Vvkqsaecgfir / 2 - $Vkbvefdrfvxh / 2, $V5ymvwogwh5y - $Vqwxulammck0 - $V3fvqcsh5wgl / 2 - $Vapkwgsb3w3r / 2);
        $Vqwxulammck0 = min($Vqwxulammck0, $V2pgp3ppbjsi - $V5ugmqeqrvmq - $Vvkqsaecgfir / 2 - $Vkbvefdrfvxh / 2, $V5ymvwogwh5y - $Vwt5bv33jejh - $V3fvqcsh5wgl / 2 - $Vapkwgsb3w3r / 2);
        $Vumwapn4ocuu = min($Vumwapn4ocuu, $V2pgp3ppbjsi - $Vwt5bv33jejh - $Vvkqsaecgfir / 2 - $Vkbvefdrfvxh / 2, $V5ymvwogwh5y - $V5ugmqeqrvmq - $V3fvqcsh5wgl / 2 - $Vapkwgsb3w3r / 2);
        $V5ugmqeqrvmq = min($V5ugmqeqrvmq, $V2pgp3ppbjsi - $Vqwxulammck0 - $Vvkqsaecgfir / 2 - $Vkbvefdrfvxh / 2, $V5ymvwogwh5y - $Vumwapn4ocuu - $V3fvqcsh5wgl / 2 - $Vapkwgsb3w3r / 2);

        return $Vvkqsaecgfirhis->_computed_border_radius = array(
            $Vwt5bv33jejh, $Vqwxulammck0, $V5ugmqeqrvmq, $Vumwapn4ocuu,
            "top-left" => $Vwt5bv33jejh,
            "top-right" => $Vqwxulammck0,
            "bottom-right" => $V5ugmqeqrvmq,
            "bottom-left" => $Vumwapn4ocuu,
        );
    }

    
    function get_outline_color()
    {
        if ($Vvkqsaecgfirhis->_props["outline_color"] === "") {
            
            $Vvkqsaecgfirhis->_prop_cache["outline_color"] = null;
            $Vvkqsaecgfirhis->_props["outline_color"] = $Vvkqsaecgfirhis->__get("color");
        }

        return $Vvkqsaecgfirhis->munge_color($Vvkqsaecgfirhis->_props["outline_color"]);
    }

    
    function get_outline_width()
    {
        $Vkvw5zjrwkdm = $Vvkqsaecgfirhis->__get("outline_style");
        return $Vkvw5zjrwkdm !== "none" && $Vkvw5zjrwkdm !== "hidden" ? $Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->_props["outline_width"]) : 0;
    }

    
    function get_outline()
    {
        $V3poxlnogtlh = $Vvkqsaecgfirhis->__get("outline_color");
        return
            $Vvkqsaecgfirhis->__get("outline_width") . " " .
            $Vvkqsaecgfirhis->__get("outline_style") . " " .
            $V3poxlnogtlh["hex"];
    }
    

    
    function get_border_spacing()
    {
        $Vkmcaia35nsn = explode(" ", $Vvkqsaecgfirhis->_props["border_spacing"]);
        if (count($Vkmcaia35nsn) == 1) {
            $Vkmcaia35nsn[1] = $Vkmcaia35nsn[0];
        }
        return $Vkmcaia35nsn;
    }

    

    

    
    protected function _set_style_side_type($Vkvw5zjrwkdm, $Vcxi3be0s51c, $Vvkqsaecgfirype, $Vso3o0kfkstx, $V0ixz2v5mxzymportant)
    {
        $Vbmjcu43y45m = $Vkvw5zjrwkdm . '_' . $Vcxi3be0s51c . $Vvkqsaecgfirype;

        if (!isset($Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m]) || $V0ixz2v5mxzymportant) {
            if ($Vcxi3be0s51c === "bottom") {
                $Vvkqsaecgfirhis->_computed_bottom_spacing = null; 
            }
            
            $Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m] = null;
            if ($V0ixz2v5mxzymportant) {
                $Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m] = true;
            }
            $Vvkqsaecgfirhis->_props[$Vbmjcu43y45m] = $Vso3o0kfkstx;
        }
    }

    
    protected function _set_style_sides_type($Vkvw5zjrwkdm, $Vvkqsaecgfirop, $Vapkwgsb3w3right, $Vkbvefdrfvxhottom, $V3fvqcsh5wgleft, $Vvkqsaecgfirype, $V0ixz2v5mxzymportant)
    {
        $Vvkqsaecgfirhis->_set_style_side_type($Vkvw5zjrwkdm, 'top', $Vvkqsaecgfirype, $Vvkqsaecgfirop, $V0ixz2v5mxzymportant);
        $Vvkqsaecgfirhis->_set_style_side_type($Vkvw5zjrwkdm, 'right', $Vvkqsaecgfirype, $Vapkwgsb3w3right, $V0ixz2v5mxzymportant);
        $Vvkqsaecgfirhis->_set_style_side_type($Vkvw5zjrwkdm, 'bottom', $Vvkqsaecgfirype, $Vkbvefdrfvxhottom, $V0ixz2v5mxzymportant);
        $Vvkqsaecgfirhis->_set_style_side_type($Vkvw5zjrwkdm, 'left', $Vvkqsaecgfirype, $V3fvqcsh5wgleft, $V0ixz2v5mxzymportant);
    }

    
    protected function _set_style_type($Vkvw5zjrwkdm, $Vvkqsaecgfirype, $Vso3o0kfkstx, $V0ixz2v5mxzymportant)
    {
        $Vso3o0kfkstx = preg_replace("/\s*\,\s*/", ",", $Vso3o0kfkstx); 
        $Vkmcaia35nsn = explode(" ", $Vso3o0kfkstx);

        switch (count($Vkmcaia35nsn)) {
            case 1:
                $Vvkqsaecgfirhis->_set_style_sides_type($Vkvw5zjrwkdm, $Vkmcaia35nsn[0], $Vkmcaia35nsn[0], $Vkmcaia35nsn[0], $Vkmcaia35nsn[0], $Vvkqsaecgfirype, $V0ixz2v5mxzymportant);
                break;
            case 2:
                $Vvkqsaecgfirhis->_set_style_sides_type($Vkvw5zjrwkdm, $Vkmcaia35nsn[0], $Vkmcaia35nsn[1], $Vkmcaia35nsn[0], $Vkmcaia35nsn[1], $Vvkqsaecgfirype, $V0ixz2v5mxzymportant);
                break;
            case 3:
                $Vvkqsaecgfirhis->_set_style_sides_type($Vkvw5zjrwkdm, $Vkmcaia35nsn[0], $Vkmcaia35nsn[1], $Vkmcaia35nsn[2], $Vkmcaia35nsn[1], $Vvkqsaecgfirype, $V0ixz2v5mxzymportant);
                break;
            case 4:
                $Vvkqsaecgfirhis->_set_style_sides_type($Vkvw5zjrwkdm, $Vkmcaia35nsn[0], $Vkmcaia35nsn[1], $Vkmcaia35nsn[2], $Vkmcaia35nsn[3], $Vvkqsaecgfirype, $V0ixz2v5mxzymportant);
                break;
        }

        
        $Vvkqsaecgfirhis->_prop_cache[$Vkvw5zjrwkdm . $Vvkqsaecgfirype] = null;
        $Vvkqsaecgfirhis->_props[$Vkvw5zjrwkdm . $Vvkqsaecgfirype] = $Vso3o0kfkstx;
    }

    
    protected function _set_style_type_important($Vkvw5zjrwkdm, $Vvkqsaecgfirype, $Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_type($Vkvw5zjrwkdm, $Vvkqsaecgfirype, $Vso3o0kfkstx, isset($Vvkqsaecgfirhis->_important_props[$Vkvw5zjrwkdm . $Vvkqsaecgfirype]));
    }

    
    protected function _set_style_side_width_important($Vkvw5zjrwkdm, $Vcxi3be0s51c, $Vso3o0kfkstx)
    {
        if ($Vcxi3be0s51c === "bottom") {
            $Vvkqsaecgfirhis->_computed_bottom_spacing = null; 
        }
        
        $Vvkqsaecgfirhis->_prop_cache[$Vkvw5zjrwkdm . '_' . $Vcxi3be0s51c] = null;
        $Vvkqsaecgfirhis->_props[$Vkvw5zjrwkdm . '_' . $Vcxi3be0s51c] = str_replace("none", "0px", $Vso3o0kfkstx);
    }

    
    protected function _set_style($Vkvw5zjrwkdm, $Vso3o0kfkstx, $V0ixz2v5mxzymportant)
    {
        if (!isset($Vvkqsaecgfirhis->_important_props[$Vkvw5zjrwkdm]) || $V0ixz2v5mxzymportant) {
            if ($V0ixz2v5mxzymportant) {
                $Vvkqsaecgfirhis->_important_props[$Vkvw5zjrwkdm] = true;
            }
            
            $Vvkqsaecgfirhis->_prop_cache[$Vkvw5zjrwkdm] = null;
            $Vvkqsaecgfirhis->_props[$Vkvw5zjrwkdm] = $Vso3o0kfkstx;
        }
    }

    
    protected function _image($Vso3o0kfkstx)
    {
        $Vogaw3hbey3g = $Vvkqsaecgfirhis->_stylesheet->get_dompdf()->getOptions()->getDebugCss();
        $Vv3mazk3ltvx = "none";

        if (mb_strpos($Vso3o0kfkstx, "url") === false) {
            $Vt321vu1jwdw = "none"; 
        } else {
            $Vso3o0kfkstx = preg_replace("/url\(\s*['\"]?([^'\")]+)['\"]?\s*\)/", "\\1", trim($Vso3o0kfkstx));

            
            $Vv3mazk3ltvx = Helpers::explode_url($Vso3o0kfkstx);
            if ($Vv3mazk3ltvx["protocol"] == "" && $Vvkqsaecgfirhis->_stylesheet->get_protocol() == "") {
                if ($Vv3mazk3ltvx["path"][0] === '/' || $Vv3mazk3ltvx["path"][0] === '\\') {
                    $Vt321vu1jwdw = $_SERVER["DOCUMENT_ROOT"] . '/';
                } else {
                    $Vt321vu1jwdw = $Vvkqsaecgfirhis->_stylesheet->get_base_path();
                }

                $Vt321vu1jwdw .= $Vv3mazk3ltvx["path"] . $Vv3mazk3ltvx["file"];
                $Vt321vu1jwdw = realpath($Vt321vu1jwdw);
                
                if (!$Vt321vu1jwdw) {
                    $Vt321vu1jwdw = 'none';
                }
            } else {
                $Vt321vu1jwdw = Helpers::build_url($Vvkqsaecgfirhis->_stylesheet->get_protocol(),
                    $Vvkqsaecgfirhis->_stylesheet->get_host(),
                    $Vvkqsaecgfirhis->_stylesheet->get_base_path(),
                    $Vso3o0kfkstx);
            }
        }
        if ($Vogaw3hbey3g) {
            print "<pre>[_image\n";
            print_r($Vv3mazk3ltvx);
            print $Vvkqsaecgfirhis->_stylesheet->get_protocol() . "\n" . $Vvkqsaecgfirhis->_stylesheet->get_base_path() . "\n" . $Vt321vu1jwdw . "\n";
            print "_image]</pre>";;
        }
        return $Vt321vu1jwdw;
    }

    

    
    function set_color($V3poxlnogtlh)
    {
        $Vqpgfq33o1wo = $Vvkqsaecgfirhis->munge_color($V3poxlnogtlh);

        if (is_null($Vqpgfq33o1wo) || !isset($Vqpgfq33o1wo["hex"])) {
            $V3poxlnogtlh = "inherit";
        } else {
            $V3poxlnogtlh = $Vqpgfq33o1wo["hex"];
        }

        
        $Vvkqsaecgfirhis->_prop_cache["color"] = null;
        $Vvkqsaecgfirhis->_props["color"] = $V3poxlnogtlh;
    }

    
    function set_background_color($V3poxlnogtlh)
    {
        $Vqpgfq33o1wo = $Vvkqsaecgfirhis->munge_color($V3poxlnogtlh);

        if (is_null($Vqpgfq33o1wo)) {
            return;
            
        }

        
        $Vvkqsaecgfirhis->_prop_cache["background_color"] = null;
        $Vvkqsaecgfirhis->_props["background_color"] = is_array($Vqpgfq33o1wo) ? $Vqpgfq33o1wo["hex"] : $Vqpgfq33o1wo;
    }

    
    function set_background_image($Vso3o0kfkstx)
    {
        
        $Vvkqsaecgfirhis->_prop_cache["background_image"] = null;
        $Vvkqsaecgfirhis->_props["background_image"] = $Vvkqsaecgfirhis->_image($Vso3o0kfkstx);
    }

    
    function set_background_repeat($Vso3o0kfkstx)
    {
        if (is_null($Vso3o0kfkstx)) {
            $Vso3o0kfkstx = self::$V04v34ed5kmm["background_repeat"];
        }

        
        $Vvkqsaecgfirhis->_prop_cache["background_repeat"] = null;
        $Vvkqsaecgfirhis->_props["background_repeat"] = $Vso3o0kfkstx;
    }

    
    function set_background_attachment($Vso3o0kfkstx)
    {
        if (is_null($Vso3o0kfkstx)) {
            $Vso3o0kfkstx = self::$V04v34ed5kmm["background_attachment"];
        }

        
        $Vvkqsaecgfirhis->_prop_cache["background_attachment"] = null;
        $Vvkqsaecgfirhis->_props["background_attachment"] = $Vso3o0kfkstx;
    }

    
    function set_background_position($Vso3o0kfkstx)
    {
        if (is_null($Vso3o0kfkstx)) {
            $Vso3o0kfkstx = self::$V04v34ed5kmm["background_position"];
        }

        
        $Vvkqsaecgfirhis->_prop_cache["background_position"] = null;
        $Vvkqsaecgfirhis->_props["background_position"] = $Vso3o0kfkstx;
    }

    
    function set_background($Vso3o0kfkstx)
    {
        $Vso3o0kfkstx = trim($Vso3o0kfkstx);
        $V0ixz2v5mxzymportant = isset($Vvkqsaecgfirhis->_important_props["background"]);

        if ($Vso3o0kfkstx === "none") {
            $Vvkqsaecgfirhis->_set_style("background_image", "none", $V0ixz2v5mxzymportant);
            $Vvkqsaecgfirhis->_set_style("background_color", "transparent", $V0ixz2v5mxzymportant);
        } else {
            $Vfrahdutb35k = array();
            $Vj0eqma35tbv = preg_replace("/\s*\,\s*/", ",", $Vso3o0kfkstx); 
            $Vj0eqma35tbv = preg_split("/\s+/", $Vj0eqma35tbv);

            foreach ($Vj0eqma35tbv as $Vparayyrg1lg) {
                if (mb_substr($Vparayyrg1lg, 0, 3) === "url" || $Vparayyrg1lg === "none") {
                    $Vvkqsaecgfirhis->_set_style("background_image", $Vvkqsaecgfirhis->_image($Vparayyrg1lg), $V0ixz2v5mxzymportant);
                } elseif ($Vparayyrg1lg === "fixed" || $Vparayyrg1lg === "scroll") {
                    $Vvkqsaecgfirhis->_set_style("background_attachment", $Vparayyrg1lg, $V0ixz2v5mxzymportant);
                } elseif ($Vparayyrg1lg === "repeat" || $Vparayyrg1lg === "repeat-x" || $Vparayyrg1lg === "repeat-y" || $Vparayyrg1lg === "no-repeat") {
                    $Vvkqsaecgfirhis->_set_style("background_repeat", $Vparayyrg1lg, $V0ixz2v5mxzymportant);
                } elseif (($Vqpgfq33o1wo = $Vvkqsaecgfirhis->munge_color($Vparayyrg1lg)) != null) {
                    $Vvkqsaecgfirhis->_set_style("background_color", is_array($Vqpgfq33o1wo) ? $Vqpgfq33o1wo["hex"] : $Vqpgfq33o1wo, $V0ixz2v5mxzymportant);
                } else {
                    $Vfrahdutb35k[] = $Vparayyrg1lg;
                }
            }

            if (count($Vfrahdutb35k)) {
                $Vvkqsaecgfirhis->_set_style("background_position", implode(" ", $Vfrahdutb35k), $V0ixz2v5mxzymportant);
            }
        }

        
        $Vvkqsaecgfirhis->_prop_cache["background"] = null;
        $Vvkqsaecgfirhis->_props["background"] = $Vso3o0kfkstx;
    }

    
    function set_font_size($Vkgj34o34uaw)
    {
        $Vvkqsaecgfirhis->__font_size_calculated = false;
        
        $Vvkqsaecgfirhis->_prop_cache["font_size"] = null;
        $Vvkqsaecgfirhis->_props["font_size"] = $Vkgj34o34uaw;
    }

    
    function set_font($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->__font_size_calculated = false;
        
        $Vvkqsaecgfirhis->_prop_cache["font"] = null;
        $Vvkqsaecgfirhis->_props["font"] = $Vso3o0kfkstx;

        $V0ixz2v5mxzymportant = isset($Vvkqsaecgfirhis->_important_props["font"]);

        if (preg_match("/^(italic|oblique|normal)\s*(.*)$/i", $Vso3o0kfkstx, $Vmms5wlre01j)) {
            $Vvkqsaecgfirhis->_set_style("font_style", $Vmms5wlre01j[1], $V0ixz2v5mxzymportant);
            $Vso3o0kfkstx = $Vmms5wlre01j[2];
        } else {
            $Vvkqsaecgfirhis->_set_style("font_style", self::$V04v34ed5kmm["font_style"], $V0ixz2v5mxzymportant);
        }

        if (preg_match("/^(small-caps|normal)\s*(.*)$/i", $Vso3o0kfkstx, $Vmms5wlre01j)) {
            $Vvkqsaecgfirhis->_set_style("font_variant", $Vmms5wlre01j[1], $V0ixz2v5mxzymportant);
            $Vso3o0kfkstx = $Vmms5wlre01j[2];
        } else {
            $Vvkqsaecgfirhis->_set_style("font_variant", self::$V04v34ed5kmm["font_variant"], $V0ixz2v5mxzymportant);
        }

        
        if (preg_match("/^(bold|bolder|lighter|100|200|300|400|500|600|700|800|900|normal)\s*(.*)$/i", $Vso3o0kfkstx, $Vmms5wlre01j) &&
            !preg_match("/^(?:pt|px|pc|em|ex|in|cm|mm|%)/", $Vmms5wlre01j[2])
        ) {
            $Vvkqsaecgfirhis->_set_style("font_weight", $Vmms5wlre01j[1], $V0ixz2v5mxzymportant);
            $Vso3o0kfkstx = $Vmms5wlre01j[2];
        } else {
            $Vvkqsaecgfirhis->_set_style("font_weight", self::$V04v34ed5kmm["font_weight"], $V0ixz2v5mxzymportant);
        }

        if (preg_match("/^(xx-small|x-small|small|medium|large|x-large|xx-large|smaller|larger|\d+\s*(?:pt|px|pc|em|ex|in|cm|mm|%))(?:\/|\s*)(.*)$/i", $Vso3o0kfkstx, $Vmms5wlre01j)) {
            $Vvkqsaecgfirhis->_set_style("font_size", $Vmms5wlre01j[1], $V0ixz2v5mxzymportant);
            $Vso3o0kfkstx = $Vmms5wlre01j[2];
            if (preg_match("/^(?:\/|\s*)(\d+\s*(?:pt|px|pc|em|ex|in|cm|mm|%)?)\s*(.*)$/i", $Vso3o0kfkstx, $Vmms5wlre01j)) {
                $Vvkqsaecgfirhis->_set_style("line_height", $Vmms5wlre01j[1], $V0ixz2v5mxzymportant);
                $Vso3o0kfkstx = $Vmms5wlre01j[2];
            } else {
                $Vvkqsaecgfirhis->_set_style("line_height", self::$V04v34ed5kmm["line_height"], $V0ixz2v5mxzymportant);
            }
        } else {
            $Vvkqsaecgfirhis->_set_style("font_size", self::$V04v34ed5kmm["font_size"], $V0ixz2v5mxzymportant);
            $Vvkqsaecgfirhis->_set_style("line_height", self::$V04v34ed5kmm["line_height"], $V0ixz2v5mxzymportant);
        }

        if (strlen($Vso3o0kfkstx) != 0) {
            $Vvkqsaecgfirhis->_set_style("font_family", $Vso3o0kfkstx, $V0ixz2v5mxzymportant);
        } else {
            $Vvkqsaecgfirhis->_set_style("font_family", self::$V04v34ed5kmm["font_family"], $V0ixz2v5mxzymportant);
        }
    }

    
    function set_page_break_before($Vkbvefdrfvxhreak)
    {
        if ($Vkbvefdrfvxhreak === "left" || $Vkbvefdrfvxhreak === "right") {
            $Vkbvefdrfvxhreak = "always";
        }

        
        $Vvkqsaecgfirhis->_prop_cache["page_break_before"] = null;
        $Vvkqsaecgfirhis->_props["page_break_before"] = $Vkbvefdrfvxhreak;
    }

    
    function set_page_break_after($Vkbvefdrfvxhreak)
    {
        if ($Vkbvefdrfvxhreak === "left" || $Vkbvefdrfvxhreak === "right") {
            $Vkbvefdrfvxhreak = "always";
        }

        
        $Vvkqsaecgfirhis->_prop_cache["page_break_after"] = null;
        $Vvkqsaecgfirhis->_props["page_break_after"] = $Vkbvefdrfvxhreak;
    }

    
    function set_margin_top($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_side_width_important('margin', 'top', $Vso3o0kfkstx);
    }

    
    function set_margin_right($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_side_width_important('margin', 'right', $Vso3o0kfkstx);
    }

    
    function set_margin_bottom($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_side_width_important('margin', 'bottom', $Vso3o0kfkstx);
    }

    
    function set_margin_left($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_side_width_important('margin', 'left', $Vso3o0kfkstx);
    }

    
    function set_margin($Vso3o0kfkstx)
    {
        $Vso3o0kfkstx = str_replace("none", "0px", $Vso3o0kfkstx);
        $Vvkqsaecgfirhis->_set_style_type_important('margin', '', $Vso3o0kfkstx);
    }

    
    function set_padding_top($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_side_width_important('padding', 'top', $Vso3o0kfkstx);
    }

    
    function set_padding_right($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_side_width_important('padding', 'right', $Vso3o0kfkstx);
    }

    
    function set_padding_bottom($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_side_width_important('padding', 'bottom', $Vso3o0kfkstx);
    }

    
    function set_padding_left($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_side_width_important('padding', 'left', $Vso3o0kfkstx);
    }

    
    function set_padding($Vso3o0kfkstx)
    {
        $Vso3o0kfkstx = str_replace("none", "0px", $Vso3o0kfkstx);
        $Vvkqsaecgfirhis->_set_style_type_important('padding', '', $Vso3o0kfkstx);
    }
    

    
    protected function _set_border($Vcxi3be0s51c, $Vkbvefdrfvxhorder_spec, $V0ixz2v5mxzymportant)
    {
        $Vkbvefdrfvxhorder_spec = preg_replace("/\s*\,\s*/", ",", $Vkbvefdrfvxhorder_spec);
        
        $Vkmcaia35nsn = explode(" ", $Vkbvefdrfvxhorder_spec);

        

        
        
        $Vvkqsaecgfirhis->_set_style_side_type('border', $Vcxi3be0s51c, '_style', self::$V04v34ed5kmm['border_' . $Vcxi3be0s51c . '_style'], $V0ixz2v5mxzymportant);
        $Vvkqsaecgfirhis->_set_style_side_type('border', $Vcxi3be0s51c, '_width', self::$V04v34ed5kmm['border_' . $Vcxi3be0s51c . '_width'], $V0ixz2v5mxzymportant);
        $Vvkqsaecgfirhis->_set_style_side_type('border', $Vcxi3be0s51c, '_color', self::$V04v34ed5kmm['border_' . $Vcxi3be0s51c . '_color'], $V0ixz2v5mxzymportant);

        foreach ($Vkmcaia35nsn as $Veugw2h43vxz) {
            $Veugw2h43vxz = trim($Veugw2h43vxz);
            if (in_array($Veugw2h43vxz, self::$Vsu0cqse33cm)) {
                $Vvkqsaecgfirhis->_set_style_side_type('border', $Vcxi3be0s51c, '_style', $Veugw2h43vxz, $V0ixz2v5mxzymportant);
            } else if (preg_match("/[.0-9]+(?:px|pt|pc|em|ex|%|in|mm|cm)|(?:thin|medium|thick)/", $Veugw2h43vxz)) {
                $Vvkqsaecgfirhis->_set_style_side_type('border', $Vcxi3be0s51c, '_width', $Veugw2h43vxz, $V0ixz2v5mxzymportant);
            } else {
                
                $Vvkqsaecgfirhis->_set_style_side_type('border', $Vcxi3be0s51c, '_color', $Veugw2h43vxz, $V0ixz2v5mxzymportant);
            }
        }

        
        $Vvkqsaecgfirhis->_prop_cache['border_' . $Vcxi3be0s51c] = null;
        $Vvkqsaecgfirhis->_props['border_' . $Vcxi3be0s51c] = $Vkbvefdrfvxhorder_spec;
    }

    
    function set_border_top($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_border("top", $Vso3o0kfkstx, isset($Vvkqsaecgfirhis->_important_props['border_top']));
    }

    
    function set_border_right($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_border("right", $Vso3o0kfkstx, isset($Vvkqsaecgfirhis->_important_props['border_right']));
    }

    
    function set_border_bottom($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_border("bottom", $Vso3o0kfkstx, isset($Vvkqsaecgfirhis->_important_props['border_bottom']));
    }

    
    function set_border_left($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_border("left", $Vso3o0kfkstx, isset($Vvkqsaecgfirhis->_important_props['border_left']));
    }

    
    function set_border($Vso3o0kfkstx)
    {
        $V0ixz2v5mxzymportant = isset($Vvkqsaecgfirhis->_important_props["border"]);
        $Vvkqsaecgfirhis->_set_border("top", $Vso3o0kfkstx, $V0ixz2v5mxzymportant);
        $Vvkqsaecgfirhis->_set_border("right", $Vso3o0kfkstx, $V0ixz2v5mxzymportant);
        $Vvkqsaecgfirhis->_set_border("bottom", $Vso3o0kfkstx, $V0ixz2v5mxzymportant);
        $Vvkqsaecgfirhis->_set_border("left", $Vso3o0kfkstx, $V0ixz2v5mxzymportant);
        
        $Vvkqsaecgfirhis->_prop_cache["border"] = null;
        $Vvkqsaecgfirhis->_props["border"] = $Vso3o0kfkstx;
    }

    
    function set_border_width($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_type_important('border', '_width', $Vso3o0kfkstx);
    }

    
    function set_border_color($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_type_important('border', '_color', $Vso3o0kfkstx);
    }

    
    function set_border_style($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_type_important('border', '_style', $Vso3o0kfkstx);
    }

    
    function set_border_top_left_radius($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_border_radius_corner($Vso3o0kfkstx, "top_left");
    }

    
    function set_border_top_right_radius($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_border_radius_corner($Vso3o0kfkstx, "top_right");
    }

    
    function set_border_bottom_left_radius($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_border_radius_corner($Vso3o0kfkstx, "bottom_left");
    }

    
    function set_border_bottom_right_radius($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_border_radius_corner($Vso3o0kfkstx, "bottom_right");
    }

    
    function set_border_radius($Vso3o0kfkstx)
    {
        $Vso3o0kfkstx = preg_replace("/\s*\,\s*/", ",", $Vso3o0kfkstx); 
        $Vkmcaia35nsn = explode(" ", $Vso3o0kfkstx);

        switch (count($Vkmcaia35nsn)) {
            case 1:
                $Vvkqsaecgfirhis->_set_border_radii($Vkmcaia35nsn[0], $Vkmcaia35nsn[0], $Vkmcaia35nsn[0], $Vkmcaia35nsn[0]);
                break;
            case 2:
                $Vvkqsaecgfirhis->_set_border_radii($Vkmcaia35nsn[0], $Vkmcaia35nsn[1], $Vkmcaia35nsn[0], $Vkmcaia35nsn[1]);
                break;
            case 3:
                $Vvkqsaecgfirhis->_set_border_radii($Vkmcaia35nsn[0], $Vkmcaia35nsn[1], $Vkmcaia35nsn[2], $Vkmcaia35nsn[1]);
                break;
            case 4:
                $Vvkqsaecgfirhis->_set_border_radii($Vkmcaia35nsn[0], $Vkmcaia35nsn[1], $Vkmcaia35nsn[2], $Vkmcaia35nsn[3]);
                break;
        }
    }

    
    protected function _set_border_radii($Vso3o0kfkstx1, $Vso3o0kfkstx2, $Vso3o0kfkstx3, $Vso3o0kfkstx4)
    {
        $Vvkqsaecgfirhis->_set_border_radius_corner($Vso3o0kfkstx1, "top_left");
        $Vvkqsaecgfirhis->_set_border_radius_corner($Vso3o0kfkstx2, "top_right");
        $Vvkqsaecgfirhis->_set_border_radius_corner($Vso3o0kfkstx3, "bottom_right");
        $Vvkqsaecgfirhis->_set_border_radius_corner($Vso3o0kfkstx4, "bottom_left");
    }

    
    protected function _set_border_radius_corner($Vso3o0kfkstx, $Vc142vyv4as1)
    {
        $Vvkqsaecgfirhis->_has_border_radius = true;

        
        $Vvkqsaecgfirhis->_prop_cache["border_" . $Vc142vyv4as1 . "_radius"] = null;

        $Vvkqsaecgfirhis->_props["border_" . $Vc142vyv4as1 . "_radius"] = $Vso3o0kfkstx;
    }

    
    function get_border_top_left_radius()
    {
        return $Vvkqsaecgfirhis->_get_border_radius_corner("top_left");
    }

    
    function get_border_top_right_radius()
    {
        return $Vvkqsaecgfirhis->_get_border_radius_corner("top_right");
    }

    
    function get_border_bottom_left_radius()
    {
        return $Vvkqsaecgfirhis->_get_border_radius_corner("bottom_left");
    }

    
    function get_border_bottom_right_radius()
    {
        return $Vvkqsaecgfirhis->_get_border_radius_corner("bottom_right");
    }

    
    protected function _get_border_radius_corner($Vc142vyv4as1)
    {
        if (!isset($Vvkqsaecgfirhis->_props["border_" . $Vc142vyv4as1 . "_radius"]) || empty($Vvkqsaecgfirhis->_props["border_" . $Vc142vyv4as1 . "_radius"])) {
            return 0;
        }

        return $Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->_props["border_" . $Vc142vyv4as1 . "_radius"]);
    }

    
    function set_outline($Vso3o0kfkstx)
    {
        $V0ixz2v5mxzymportant = isset($Vvkqsaecgfirhis->_important_props["outline"]);

        $Vbmjcu43y45ms = array(
            "outline_style",
            "outline_width",
            "outline_color",
        );

        foreach ($Vbmjcu43y45ms as $Vbmjcu43y45m) {
            $Vfwsmswwca1p = self::$V04v34ed5kmm[$Vbmjcu43y45m];

            if (!isset($Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m]) || $V0ixz2v5mxzymportant) {
                
                $Vvkqsaecgfirhis->_prop_cache[$Vbmjcu43y45m] = null;
                if ($V0ixz2v5mxzymportant) {
                    $Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m] = true;
                }
                $Vvkqsaecgfirhis->_props[$Vbmjcu43y45m] = $Vfwsmswwca1p;
            }
        }

        $Vso3o0kfkstx = preg_replace("/\s*\,\s*/", ",", $Vso3o0kfkstx); 
        $Vkmcaia35nsn = explode(" ", $Vso3o0kfkstx);
        foreach ($Vkmcaia35nsn as $Veugw2h43vxz) {
            $Veugw2h43vxz = trim($Veugw2h43vxz);

            if (in_array($Veugw2h43vxz, self::$Vsu0cqse33cm)) {
                $Vvkqsaecgfirhis->set_outline_style($Veugw2h43vxz);
            } else if (preg_match("/[.0-9]+(?:px|pt|pc|em|ex|%|in|mm|cm)|(?:thin|medium|thick)/", $Veugw2h43vxz)) {
                $Vvkqsaecgfirhis->set_outline_width($Veugw2h43vxz);
            } else {
                
                $Vvkqsaecgfirhis->set_outline_color($Veugw2h43vxz);
            }
        }

        
        $Vvkqsaecgfirhis->_prop_cache["outline"] = null;
        $Vvkqsaecgfirhis->_props["outline"] = $Vso3o0kfkstx;
    }

    
    function set_outline_width($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_type_important('outline', '_width', $Vso3o0kfkstx);
    }

    
    function set_outline_color($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_type_important('outline', '_color', $Vso3o0kfkstx);
    }

    
    function set_outline_style($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->_set_style_type_important('outline', '_style', $Vso3o0kfkstx);
    }

    
    function set_border_spacing($Vso3o0kfkstx)
    {
        $Vkmcaia35nsn = explode(" ", $Vso3o0kfkstx);

        if (count($Vkmcaia35nsn) == 1) {
            $Vkmcaia35nsn[1] = $Vkmcaia35nsn[0];
        }

        
        $Vvkqsaecgfirhis->_prop_cache["border_spacing"] = null;
        $Vvkqsaecgfirhis->_props["border_spacing"] = "$Vkmcaia35nsn[0] $Vkmcaia35nsn[1]";
    }

    
    function set_list_style_image($Vso3o0kfkstx)
    {
        
        $Vvkqsaecgfirhis->_prop_cache["list_style_image"] = null;
        $Vvkqsaecgfirhis->_props["list_style_image"] = $Vvkqsaecgfirhis->_image($Vso3o0kfkstx);
    }

    
    function set_list_style($Vso3o0kfkstx)
    {
        $V0ixz2v5mxzymportant = isset($Vvkqsaecgfirhis->_important_props["list_style"]);
        $Vkmcaia35nsn = explode(" ", str_replace(",", " ", $Vso3o0kfkstx));

        static $Vvkqsaecgfirypes = array(
            "disc", "circle", "square",
            "decimal-leading-zero", "decimal", "1",
            "lower-roman", "upper-roman", "a", "A",
            "lower-greek",
            "lower-latin", "upper-latin",
            "lower-alpha", "upper-alpha",
            "armenian", "georgian", "hebrew",
            "cjk-ideographic", "hiragana", "katakana",
            "hiragana-iroha", "katakana-iroha", "none"
        );

        static $Vfrahdutb35kitions = array("inside", "outside");

        foreach ($Vkmcaia35nsn as $Veugw2h43vxz) {
            
            if ($Veugw2h43vxz === "none") {
                $Vvkqsaecgfirhis->_set_style("list_style_type", $Veugw2h43vxz, $V0ixz2v5mxzymportant);
                $Vvkqsaecgfirhis->_set_style("list_style_image", $Veugw2h43vxz, $V0ixz2v5mxzymportant);
                continue;
            }

            
            
            
            

            if (mb_substr($Veugw2h43vxz, 0, 3) === "url") {
                $Vvkqsaecgfirhis->_set_style("list_style_image", $Vvkqsaecgfirhis->_image($Veugw2h43vxz), $V0ixz2v5mxzymportant);
                continue;
            }

            if (in_array($Veugw2h43vxz, $Vvkqsaecgfirypes)) {
                $Vvkqsaecgfirhis->_set_style("list_style_type", $Veugw2h43vxz, $V0ixz2v5mxzymportant);
            } else if (in_array($Veugw2h43vxz, $Vfrahdutb35kitions)) {
                $Vvkqsaecgfirhis->_set_style("list_style_position", $Veugw2h43vxz, $V0ixz2v5mxzymportant);
            }
        }

        
        $Vvkqsaecgfirhis->_prop_cache["list_style"] = null;
        $Vvkqsaecgfirhis->_props["list_style"] = $Vso3o0kfkstx;
    }

    
    function set_size($Vso3o0kfkstx)
    {
        $Vyfoeno5vtuw_re = "/(\d+\s*(?:pt|px|pc|em|ex|in|cm|mm|%))/";

        $Vso3o0kfkstx = mb_strtolower($Vso3o0kfkstx);

        if ($Vso3o0kfkstx === "auto") {
            return;
        }

        $Vrra0vtlxofn = preg_split("/\s+/", $Vso3o0kfkstx);

        $V1unjtsu4njh = array();
        if (preg_match($Vyfoeno5vtuw_re, $Vrra0vtlxofn[0])) {
            $V1unjtsu4njh[] = $Vvkqsaecgfirhis->length_in_pt($Vrra0vtlxofn[0]);

            if (isset($Vrra0vtlxofn[1]) && preg_match($Vyfoeno5vtuw_re, $Vrra0vtlxofn[1])) {
                $V1unjtsu4njh[] = $Vvkqsaecgfirhis->length_in_pt($Vrra0vtlxofn[1]);
            } else {
                $V1unjtsu4njh[] = $V1unjtsu4njh[0];
            }

            if (isset($Vrra0vtlxofn[2]) && $Vrra0vtlxofn[2] === "landscape") {
                $V1unjtsu4njh = array_reverse($V1unjtsu4njh);
            }
        } elseif (isset(CPDF::$Vfh5zaiuo2gy[$Vrra0vtlxofn[0]])) {
            $V1unjtsu4njh = array_slice(CPDF::$Vfh5zaiuo2gy[$Vrra0vtlxofn[0]], 2, 2);

            if (isset($Vrra0vtlxofn[1]) && $Vrra0vtlxofn[1] === "landscape") {
                $V1unjtsu4njh = array_reverse($V1unjtsu4njh);
            }
        } else {
            return;
        }

        $Vvkqsaecgfirhis->_props["size"] = $V1unjtsu4njh;
    }

    
    function get_transform()
    {
        $Vo4ugwgfc3na = "\s*([^,\s]+)\s*";
        $Vvkqsaecgfirr_value = "\s*([^,\s]+)\s*";
        $Vvb4ibm25tpf = "\s*([^,\s]+(?:deg|rad)?)\s*";

        if (!preg_match_all("/[a-z]+\([^\)]+\)/i", $Vvkqsaecgfirhis->_props["transform"], $Vrra0vtlxofn, PREG_SET_ORDER)) {
            return null;
        }

        $Vmidfzszbi5l = array(
            

            "translate" => "\($Vvkqsaecgfirr_value(?:,$Vvkqsaecgfirr_value)?\)",
            "translateX" => "\($Vvkqsaecgfirr_value\)",
            "translateY" => "\($Vvkqsaecgfirr_value\)",

            "scale" => "\($Vo4ugwgfc3na(?:,$Vo4ugwgfc3na)?\)",
            "scaleX" => "\($Vo4ugwgfc3na\)",
            "scaleY" => "\($Vo4ugwgfc3na\)",

            "rotate" => "\($Vvb4ibm25tpf\)",

            "skew" => "\($Vvb4ibm25tpf(?:,$Vvb4ibm25tpf)?\)",
            "skewX" => "\($Vvb4ibm25tpf\)",
            "skewY" => "\($Vvb4ibm25tpf\)",
        );

        $Vvkqsaecgfirransforms = array();

        foreach ($Vrra0vtlxofn as $V2v5fxvh4bil) {
            $Vvkqsaecgfir = $V2v5fxvh4bil[0];

            foreach ($Vmidfzszbi5l as $Vreuchxnm2nm => $V2apyt5442as) {
                if (preg_match("/$Vreuchxnm2nm\s*$V2apyt5442as/i", $Vvkqsaecgfir, $Vmms5wlre01jes)) {
                    $Veugw2h43vxzs = array_slice($Vmms5wlre01jes, 1);

                    switch ($Vreuchxnm2nm) {
                        
                        case "rotate":
                        case "skew":
                        case "skewX":
                        case "skewY":

                            foreach ($Veugw2h43vxzs as $V0ixz2v5mxzy => $Veugw2h43vxz) {
                                if (strpos($Veugw2h43vxz, "rad")) {
                                    $Veugw2h43vxzs[$V0ixz2v5mxzy] = rad2deg(floatval($Veugw2h43vxz));
                                } else {
                                    $Veugw2h43vxzs[$V0ixz2v5mxzy] = floatval($Veugw2h43vxz);
                                }
                            }

                            switch ($Vreuchxnm2nm) {
                                case "skew":
                                    if (!isset($Veugw2h43vxzs[1])) {
                                        $Veugw2h43vxzs[1] = 0;
                                    }
                                    break;
                                case "skewX":
                                    $Vreuchxnm2nm = "skew";
                                    $Veugw2h43vxzs = array($Veugw2h43vxzs[0], 0);
                                    break;
                                case "skewY":
                                    $Vreuchxnm2nm = "skew";
                                    $Veugw2h43vxzs = array(0, $Veugw2h43vxzs[0]);
                                    break;
                            }
                            break;

                        
                        case "translate":
                            $Veugw2h43vxzs[0] = $Vvkqsaecgfirhis->length_in_pt($Veugw2h43vxzs[0], (float)$Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->width));

                            if (isset($Veugw2h43vxzs[1])) {
                                $Veugw2h43vxzs[1] = $Vvkqsaecgfirhis->length_in_pt($Veugw2h43vxzs[1], (float)$Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->height));
                            } else {
                                $Veugw2h43vxzs[1] = 0;
                            }
                            break;

                        case "translateX":
                            $Vreuchxnm2nm = "translate";
                            $Veugw2h43vxzs = array($Vvkqsaecgfirhis->length_in_pt($Veugw2h43vxzs[0], (float)$Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->width)), 0);
                            break;

                        case "translateY":
                            $Vreuchxnm2nm = "translate";
                            $Veugw2h43vxzs = array(0, $Vvkqsaecgfirhis->length_in_pt($Veugw2h43vxzs[0], (float)$Vvkqsaecgfirhis->length_in_pt($Vvkqsaecgfirhis->height)));
                            break;

                        
                        case "scale":
                            if (!isset($Veugw2h43vxzs[1])) {
                                $Veugw2h43vxzs[1] = $Veugw2h43vxzs[0];
                            }
                            break;

                        case "scaleX":
                            $Vreuchxnm2nm = "scale";
                            $Veugw2h43vxzs = array($Veugw2h43vxzs[0], 1.0);
                            break;

                        case "scaleY":
                            $Vreuchxnm2nm = "scale";
                            $Veugw2h43vxzs = array(1.0, $Veugw2h43vxzs[0]);
                            break;
                    }

                    $Vvkqsaecgfirransforms[] = array(
                        $Vreuchxnm2nm,
                        $Veugw2h43vxzs,
                    );
                }
            }
        }

        return $Vvkqsaecgfirransforms;
    }

    
    function set_transform($Vso3o0kfkstx)
    {
        
        $Vvkqsaecgfirhis->_prop_cache["transform"] = null;
        $Vvkqsaecgfirhis->_props["transform"] = $Vso3o0kfkstx;
    }

    
    function set__webkit_transform($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->set_transform($Vso3o0kfkstx);
    }

    
    function set__webkit_transform_origin($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->set_transform_origin($Vso3o0kfkstx);
    }

    
    function set_transform_origin($Vso3o0kfkstx)
    {
        
        $Vvkqsaecgfirhis->_prop_cache["transform_origin"] = null;
        $Vvkqsaecgfirhis->_props["transform_origin"] = $Vso3o0kfkstx;
    }

    
    function get_transform_origin() {
        $Veugw2h43vxzs = preg_split("/\s+/", $Vvkqsaecgfirhis->_props['transform_origin']);

        if (count($Veugw2h43vxzs) === 0) {
            $Veugw2h43vxzs = preg_split("/\s+/", self::$V04v34ed5kmm["transform_origin"]);
        }

        $Veugw2h43vxzs = array_map(function($Veugw2h43vxz) {
            if (in_array($Veugw2h43vxz, array("top", "left"))) {
                return 0;
            } else if (in_array($Veugw2h43vxz, array("bottom", "right"))) {
                return "100%";
            } else {
                return $Veugw2h43vxz;
            }
        }, $Veugw2h43vxzs);

        if (!isset($Veugw2h43vxzs[1])) {
            $Veugw2h43vxzs[1] = $Veugw2h43vxzs[0];
        }

        return $Veugw2h43vxzs;
    }

    
    protected function parse_image_resolution($Vso3o0kfkstx)
    {
        
        

        $Vapkwgsb3w3re = '/^\s*(\d+|normal|auto)\s*$/';

        if (!preg_match($Vapkwgsb3w3re, $Vso3o0kfkstx, $Vmms5wlre01jes)) {
            return null;
        }

        return $Vmms5wlre01jes[1];
    }

    
    function set_background_image_resolution($Vso3o0kfkstx)
    {
        $V45k3lamsnfi = $Vvkqsaecgfirhis->parse_image_resolution($Vso3o0kfkstx);

        $Vvkqsaecgfirhis->_prop_cache["background_image_resolution"] = null;
        $Vvkqsaecgfirhis->_props["background_image_resolution"] = $V45k3lamsnfi;
    }

    
    function set_image_resolution($Vso3o0kfkstx)
    {
        $V45k3lamsnfi = $Vvkqsaecgfirhis->parse_image_resolution($Vso3o0kfkstx);

        $Vvkqsaecgfirhis->_prop_cache["image_resolution"] = null;
        $Vvkqsaecgfirhis->_props["image_resolution"] = $V45k3lamsnfi;
    }

    
    function set__dompdf_background_image_resolution($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->set_background_image_resolution($Vso3o0kfkstx);
    }

    
    function set__dompdf_image_resolution($Vso3o0kfkstx)
    {
        $Vvkqsaecgfirhis->set_image_resolution($Vso3o0kfkstx);
    }

    
    function set_z_index($Vso3o0kfkstx)
    {
        if (round($Vso3o0kfkstx) != $Vso3o0kfkstx && $Vso3o0kfkstx !== "auto") {
            return;
        }

        $Vvkqsaecgfirhis->_prop_cache["z_index"] = null;
        $Vvkqsaecgfirhis->_props["z_index"] = $Vso3o0kfkstx;
    }

    
    function set_counter_increment($Vso3o0kfkstx)
    {
        $Vso3o0kfkstx = trim($Vso3o0kfkstx);
        $Veugw2h43vxz = null;

        if (in_array($Vso3o0kfkstx, array("none", "inherit"))) {
            $Veugw2h43vxz = $Vso3o0kfkstx;
        } else {
            if (preg_match_all("/(" . self::CSS_IDENTIFIER . ")(?:\s+(" . self::CSS_INTEGER . "))?/", $Vso3o0kfkstx, $Vmms5wlre01jes, PREG_SET_ORDER)) {
                $Veugw2h43vxz = array();
                foreach ($Vmms5wlre01jes as $Vmms5wlre01j) {
                    $Veugw2h43vxz[$Vmms5wlre01j[1]] = isset($Vmms5wlre01j[2]) ? $Vmms5wlre01j[2] : 1;
                }
            }
        }

        $Vvkqsaecgfirhis->_prop_cache["counter_increment"] = null;
        $Vvkqsaecgfirhis->_props["counter_increment"] = $Veugw2h43vxz;
    }

    
    public function setFontMetrics(FontMetrics $Vnl1binwcwye)
    {
        $Vvkqsaecgfirhis->fontMetrics = $Vnl1binwcwye;
        return $Vvkqsaecgfirhis;
    }

    
    public function getFontMetrics()
    {
        return $Vvkqsaecgfirhis->fontMetrics;
    }

    
    
    function __toString()
    {
        return print_r(array_merge(array("parent_font_size" => $Vvkqsaecgfirhis->_parent_font_size),
            $Vvkqsaecgfirhis->_props), true);
    }

    
    function debug_print()
    {
        
        print "parent_font_size:" . $Vvkqsaecgfirhis->_parent_font_size . ";\n";
        
        foreach ($Vvkqsaecgfirhis->_props as $Vbmjcu43y45m => $Vso3o0kfkstx) {
            
            print $Vbmjcu43y45m . ':' . $Vso3o0kfkstx;
            
            if (isset($Vvkqsaecgfirhis->_important_props[$Vbmjcu43y45m])) {
                
                print '!important';
                
            }
            
            print ";\n";
            
        }
        
    }
}
