<?php

namespace Dompdf\Css;

use Dompdf\Frame;


class AttributeTranslator
{
    static $Vbmhvvjvqbtt = "_html_style_attribute";

    
    
    
    static private $Vmfgif2zhodu = array(
        
        'img' => array(
            'align' => array(
                'bottom' => 'vertical-align: baseline;',
                'middle' => 'vertical-align: middle;',
                'top' => 'vertical-align: top;',
                'left' => 'float: left;',
                'right' => 'float: right;'
            ),
            'border' => 'border: %0.2Fpx solid;',
            'height' => 'height: %spx;',
            'hspace' => 'padding-left: %1$0.2Fpx; padding-right: %1$0.2Fpx;',
            'vspace' => 'padding-top: %1$0.2Fpx; padding-bottom: %1$0.2Fpx;',
            'width' => 'width: %spx;',
        ),
        'table' => array(
            'align' => array(
                'left' => 'margin-left: 0; margin-right: auto;',
                'center' => 'margin-left: auto; margin-right: auto;',
                'right' => 'margin-left: auto; margin-right: 0;'
            ),
            'bgcolor' => 'background-color: %s;',
            'border' => '!set_table_border',
            'cellpadding' => '!set_table_cellpadding', 
            'cellspacing' => '!set_table_cellspacing',
            'frame' => array(
                'void' => 'border-style: none;',
                'above' => 'border-top-style: solid;',
                'below' => 'border-bottom-style: solid;',
                'hsides' => 'border-left-style: solid; border-right-style: solid;',
                'vsides' => 'border-top-style: solid; border-bottom-style: solid;',
                'lhs' => 'border-left-style: solid;',
                'rhs' => 'border-right-style: solid;',
                'box' => 'border-style: solid;',
                'border' => 'border-style: solid;'
            ),
            'rules' => '!set_table_rules',
            'width' => 'width: %s;',
        ),
        'hr' => array(
            'align' => '!set_hr_align', 
            'noshade' => 'border-style: solid;',
            'size' => '!set_hr_size', 
            'width' => 'width: %s;',
        ),
        'div' => array(
            'align' => 'text-align: %s;',
        ),
        'h1' => array(
            'align' => 'text-align: %s;',
        ),
        'h2' => array(
            'align' => 'text-align: %s;',
        ),
        'h3' => array(
            'align' => 'text-align: %s;',
        ),
        'h4' => array(
            'align' => 'text-align: %s;',
        ),
        'h5' => array(
            'align' => 'text-align: %s;',
        ),
        'h6' => array(
            'align' => 'text-align: %s;',
        ),
        
        'input' => array(
            'size' => '!set_input_width'
        ),
        'p' => array(
            'align' => 'text-align: %s;',
        ),








        'tbody' => array(
            'align' => '!set_table_row_align',
            'valign' => '!set_table_row_valign',
        ),
        'td' => array(
            'align' => 'text-align: %s;',
            'bgcolor' => '!set_background_color',
            'height' => 'height: %s;',
            'nowrap' => 'white-space: nowrap;',
            'valign' => 'vertical-align: %s;',
            'width' => 'width: %s;',
        ),
        'tfoot' => array(
            'align' => '!set_table_row_align',
            'valign' => '!set_table_row_valign',
        ),
        'th' => array(
            'align' => 'text-align: %s;',
            'bgcolor' => '!set_background_color',
            'height' => 'height: %s;',
            'nowrap' => 'white-space: nowrap;',
            'valign' => 'vertical-align: %s;',
            'width' => 'width: %s;',
        ),
        'thead' => array(
            'align' => '!set_table_row_align',
            'valign' => '!set_table_row_valign',
        ),
        'tr' => array(
            'align' => '!set_table_row_align',
            'bgcolor' => '!set_table_row_bgcolor',
            'valign' => '!set_table_row_valign',
        ),
        'body' => array(
            'background' => 'background-image: url(%s);',
            'bgcolor' => '!set_background_color',
            'link' => '!set_body_link',
            'text' => '!set_color',
        ),
        'br' => array(
            'clear' => 'clear: %s;',
        ),
        'basefont' => array(
            'color' => '!set_color',
            'face' => 'font-family: %s;',
            'size' => '!set_basefont_size',
        ),
        'font' => array(
            'color' => '!set_color',
            'face' => 'font-family: %s;',
            'size' => '!set_font_size',
        ),
        'dir' => array(
            'compact' => 'margin: 0.5em 0;',
        ),
        'dl' => array(
            'compact' => 'margin: 0.5em 0;',
        ),
        'menu' => array(
            'compact' => 'margin: 0.5em 0;',
        ),
        'ol' => array(
            'compact' => 'margin: 0.5em 0;',
            'start' => 'counter-reset: -dompdf-default-counter %d;',
            'type' => 'list-style-type: %s;',
        ),
        'ul' => array(
            'compact' => 'margin: 0.5em 0;',
            'type' => 'list-style-type: %s;',
        ),
        'li' => array(
            'type' => 'list-style-type: %s;',
            'value' => 'counter-reset: -dompdf-default-counter %d;',
        ),
        'pre' => array(
            'width' => 'width: %s;',
        ),
    );

    static protected $V4djnkcmjdcz = 3;
    static protected $Vboqoznj2kml = array(
        
        -3 => "4pt",
        -2 => "5pt",
        -1 => "6pt",
        0 => "7pt",

        1 => "8pt",
        2 => "10pt",
        3 => "12pt",
        4 => "14pt",
        5 => "18pt",
        6 => "24pt",
        7 => "34pt",

        
        8 => "48pt",
        9 => "44pt",
        10 => "52pt",
        11 => "60pt",
    );

    
    static function translate_attributes(Frame $Vexjfacrc1d4)
    {
        $Vivp5mmrkfpz = $Vexjfacrc1d4->get_node();
        $Vgvunyxfpvcq = $Vivp5mmrkfpz->nodeName;

        if (!isset(self::$Vmfgif2zhodu[$Vgvunyxfpvcq])) {
            return;
        }

        $V4gtvtivbwmj = self::$Vmfgif2zhodu[$Vgvunyxfpvcq];
        $Vk1141jubl0g = $Vivp5mmrkfpz->attributes;
        $Vkvw5zjrwkdm = rtrim($Vivp5mmrkfpz->getAttribute(self::$Vbmhvvjvqbtt), "; ");
        if ($Vkvw5zjrwkdm != "") {
            $Vkvw5zjrwkdm .= ";";
        }

        foreach ($Vk1141jubl0g as $Vparayyrg1lg => $Vparayyrg1lg_node) {
            if (!isset($V4gtvtivbwmj[$Vparayyrg1lg])) {
                continue;
            }

            $Veugw2h43vxz = $Vparayyrg1lg_node->value;

            $V4jfxynob0vk = $V4gtvtivbwmj[$Vparayyrg1lg];

            
            if (is_array($V4jfxynob0vk)) {
                if (isset($V4jfxynob0vk[$Veugw2h43vxz])) {
                    $Vkvw5zjrwkdm .= " " . self::_resolve_target($Vivp5mmrkfpz, $V4jfxynob0vk[$Veugw2h43vxz], $Veugw2h43vxz);
                }
            } else {
                
                $Vkvw5zjrwkdm .= " " . self::_resolve_target($Vivp5mmrkfpz, $V4jfxynob0vk, $Veugw2h43vxz);
            }
        }

        if (!is_null($Vkvw5zjrwkdm)) {
            $Vkvw5zjrwkdm = ltrim($Vkvw5zjrwkdm);
            $Vivp5mmrkfpz->setAttribute(self::$Vbmhvvjvqbtt, $Vkvw5zjrwkdm);
        }

    }

    
    static protected function _resolve_target(\DOMNode $Vivp5mmrkfpz, $V4jfxynob0vk, $Veugw2h43vxz)
    {
        if ($V4jfxynob0vk[0] === "!") {
            
            $Vla2pizivviu = "_" . mb_substr($V4jfxynob0vk, 1);

            return self::$Vla2pizivviu($Vivp5mmrkfpz, $Veugw2h43vxz);
        }

        return $Veugw2h43vxz ? sprintf($V4jfxynob0vk, $Veugw2h43vxz) : "";
    }

    
    static function append_style(\DOMElement $Vivp5mmrkfpz, $Vrgaijtp2xnn)
    {
        $Vkvw5zjrwkdm = rtrim($Vivp5mmrkfpz->getAttribute(self::$Vbmhvvjvqbtt), ";");
        $Vkvw5zjrwkdm .= $Vrgaijtp2xnn;
        $Vkvw5zjrwkdm = ltrim($Vkvw5zjrwkdm, ";");
        $Vivp5mmrkfpz->setAttribute(self::$Vbmhvvjvqbtt, $Vkvw5zjrwkdm);
    }

    
    static protected function get_cell_list(\DOMNode $Vivp5mmrkfpz)
    {
        $Vd34fc2deeyg = new \DOMXpath($Vivp5mmrkfpz->ownerDocument);

        switch ($Vivp5mmrkfpz->nodeName) {
            default:
            case "table":
                $V1tg34oowdmb = "tr/td | thead/tr/td | tbody/tr/td | tfoot/tr/td | tr/th | thead/tr/th | tbody/tr/th | tfoot/tr/th";
                break;

            case "tbody":
            case "tfoot":
            case "thead":
                $V1tg34oowdmb = "tr/td | tr/th";
                break;

            case "tr":
                $V1tg34oowdmb = "td | th";
                break;
        }

        return $Vd34fc2deeyg->query($V1tg34oowdmb, $Vivp5mmrkfpz);
    }

    
    static protected function _get_valid_color($Veugw2h43vxz)
    {
        if (preg_match('/^#?([0-9A-F]{6})$/i', $Veugw2h43vxz, $Vgvt1cvsrlfv)) {
            $Veugw2h43vxz = "#$Vgvt1cvsrlfv[1]";
        }

        return $Veugw2h43vxz;
    }

    
    static protected function _set_color(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Veugw2h43vxz = self::_get_valid_color($Veugw2h43vxz);

        return "color: $Veugw2h43vxz;";
    }

    
    static protected function _set_background_color(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Veugw2h43vxz = self::_get_valid_color($Veugw2h43vxz);

        return "background-color: $Veugw2h43vxz;";
    }

    
    static protected function _set_table_cellpadding(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vs552v1gceml = self::get_cell_list($Vivp5mmrkfpz);

        foreach ($Vs552v1gceml as $Vtbsq1x0wzpo) {
            self::append_style($Vtbsq1x0wzpo, "; padding: {$Veugw2h43vxz}px;");
        }

        return null;
    }

    
    static protected function _set_table_border(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vs552v1gceml = self::get_cell_list($Vivp5mmrkfpz);

        foreach ($Vs552v1gceml as $Vtbsq1x0wzpo) {
            $Vkvw5zjrwkdm = rtrim($Vtbsq1x0wzpo->getAttribute(self::$Vbmhvvjvqbtt));
            $Vkvw5zjrwkdm .= "; border-width: " . ($Veugw2h43vxz > 0 ? 1 : 0) . "pt; border-style: inset;";
            $Vkvw5zjrwkdm = ltrim($Vkvw5zjrwkdm, ";");
            $Vtbsq1x0wzpo->setAttribute(self::$Vbmhvvjvqbtt, $Vkvw5zjrwkdm);
        }

        $Vkvw5zjrwkdm = rtrim($Vivp5mmrkfpz->getAttribute(self::$Vbmhvvjvqbtt), ";");
        $Vkvw5zjrwkdm .= "; border-width: $Veugw2h43vxz" . "px; ";

        return ltrim($Vkvw5zjrwkdm, "; ");
    }

    
    static protected function _set_table_cellspacing(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vkvw5zjrwkdm = rtrim($Vivp5mmrkfpz->getAttribute(self::$Vbmhvvjvqbtt), ";");

        if ($Veugw2h43vxz == 0) {
            $Vkvw5zjrwkdm .= "; border-collapse: collapse;";
        } else {
            $Vkvw5zjrwkdm .= "; border-spacing: {$Veugw2h43vxz}px; border-collapse: separate;";
        }

        return ltrim($Vkvw5zjrwkdm, ";");
    }

    
    static protected function _set_table_rules(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vrgaijtp2xnn = "; border-collapse: collapse;";

        switch ($Veugw2h43vxz) {
            case "none":
                $Vrgaijtp2xnn .= "border-style: none;";
                break;

            case "groups":
                
                return null;

            case "rows":
                $Vrgaijtp2xnn .= "border-style: solid none solid none; border-width: 1px; ";
                break;

            case "cols":
                $Vrgaijtp2xnn .= "border-style: none solid none solid; border-width: 1px; ";
                break;

            case "all":
                $Vrgaijtp2xnn .= "border-style: solid; border-width: 1px; ";
                break;

            default:
                
                return null;
        }

        $Vs552v1gceml = self::get_cell_list($Vivp5mmrkfpz);

        foreach ($Vs552v1gceml as $Vtbsq1x0wzpo) {
            $Vkvw5zjrwkdm = $Vtbsq1x0wzpo->getAttribute(self::$Vbmhvvjvqbtt);
            $Vkvw5zjrwkdm .= $Vrgaijtp2xnn;
            $Vtbsq1x0wzpo->setAttribute(self::$Vbmhvvjvqbtt, $Vkvw5zjrwkdm);
        }

        $Vkvw5zjrwkdm = rtrim($Vivp5mmrkfpz->getAttribute(self::$Vbmhvvjvqbtt), ";");
        $Vkvw5zjrwkdm .= "; border-collapse: collapse; ";

        return ltrim($Vkvw5zjrwkdm, "; ");
    }

    
    static protected function _set_hr_size(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vkvw5zjrwkdm = rtrim($Vivp5mmrkfpz->getAttribute(self::$Vbmhvvjvqbtt), ";");
        $Vkvw5zjrwkdm .= "; border-width: " . max(0, $Veugw2h43vxz - 2) . "; ";

        return ltrim($Vkvw5zjrwkdm, "; ");
    }

    
    static protected function _set_hr_align(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vkvw5zjrwkdm = rtrim($Vivp5mmrkfpz->getAttribute(self::$Vbmhvvjvqbtt), ";");
        $Vtt4kvdwuqqh = $Vivp5mmrkfpz->getAttribute("width");

        if ($Vtt4kvdwuqqh == "") {
            $Vtt4kvdwuqqh = "100%";
        }

        $Vfkmki2ovb1g = 100 - (double)rtrim($Vtt4kvdwuqqh, "% ");

        switch ($Veugw2h43vxz) {
            case "left":
                $Vkvw5zjrwkdm .= "; margin-right: $Vfkmki2ovb1g %;";
                break;

            case "right":
                $Vkvw5zjrwkdm .= "; margin-left: $Vfkmki2ovb1g %;";
                break;

            case "center":
                $Vkvw5zjrwkdm .= "; margin-left: auto; margin-right: auto;";
                break;

            default:
                return null;
        }

        return ltrim($Vkvw5zjrwkdm, "; ");
    }

    
    static protected function _set_input_width(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        if (empty($Veugw2h43vxz)) { return null; }

        if ($Vivp5mmrkfpz->hasAttribute("type") && in_array(strtolower($Vivp5mmrkfpz->getAttribute("type")), array("text","password"))) {
            return sprintf("width: %Fem", (((int)$Veugw2h43vxz * .65)+2));
        } else {
            return sprintf("width: %upx;", (int)$Veugw2h43vxz);
        }
    }

    
    static protected function _set_table_row_align(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vs552v1gceml = self::get_cell_list($Vivp5mmrkfpz);

        foreach ($Vs552v1gceml as $Vtbsq1x0wzpo) {
            self::append_style($Vtbsq1x0wzpo, "; text-align: $Veugw2h43vxz;");
        }

        return null;
    }

    
    static protected function _set_table_row_valign(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vs552v1gceml = self::get_cell_list($Vivp5mmrkfpz);

        foreach ($Vs552v1gceml as $Vtbsq1x0wzpo) {
            self::append_style($Vtbsq1x0wzpo, "; vertical-align: $Veugw2h43vxz;");
        }

        return null;
    }

    
    static protected function _set_table_row_bgcolor(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vs552v1gceml = self::get_cell_list($Vivp5mmrkfpz);
        $Veugw2h43vxz = self::_get_valid_color($Veugw2h43vxz);

        foreach ($Vs552v1gceml as $Vtbsq1x0wzpo) {
            self::append_style($Vtbsq1x0wzpo, "; background-color: $Veugw2h43vxz;");
        }

        return null;
    }

    
    static protected function _set_body_link(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vgbar2hws452 = $Vivp5mmrkfpz->getElementsByTagName("a");
        $Veugw2h43vxz = self::_get_valid_color($Veugw2h43vxz);

        foreach ($Vgbar2hws452 as $V4dkbhpdu11q) {
            self::append_style($V4dkbhpdu11q, "; color: $Veugw2h43vxz;");
        }

        return null;
    }

    
    static protected function _set_basefont_size(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        
        
        self::$V4djnkcmjdcz = $Veugw2h43vxz;

        return null;
    }

    
    static protected function _set_font_size(\DOMElement $Vivp5mmrkfpz, $Veugw2h43vxz)
    {
        $Vkvw5zjrwkdm = $Vivp5mmrkfpz->getAttribute(self::$Vbmhvvjvqbtt);

        if ($Veugw2h43vxz[0] === "-" || $Veugw2h43vxz[0] === "+") {
            $Veugw2h43vxz = self::$V4djnkcmjdcz + (int)$Veugw2h43vxz;
        }

        if (isset(self::$Vboqoznj2kml[$Veugw2h43vxz])) {
            $Vkvw5zjrwkdm .= "; font-size: " . self::$Vboqoznj2kml[$Veugw2h43vxz] . ";";
        } else {
            $Vkvw5zjrwkdm .= "; font-size: $Veugw2h43vxz;";
        }

        return ltrim($Vkvw5zjrwkdm, "; ");
    }
}
