<?php
namespace Dompdf\Frame;

use Iterator;
use Dompdf\Frame;


class FrameTreeIterator implements Iterator
{
    
    protected $Vebl3bww3mws;

    
    protected $Vxiiut24i2s3 = array();

    
    protected $Vurkkjvfy4rq;

    
    public function __construct(Frame $Vfqvundqbe4u)
    {
        $this->_stack[] = $this->_root = $Vfqvundqbe4u;
        $this->_num = 0;
    }

    
    public function rewind()
    {
        $this->_stack = array($this->_root);
        $this->_num = 0;
    }

    
    public function valid()
    {
        return count($this->_stack) > 0;
    }

    
    public function key()
    {
        return $this->_num;
    }

    
    public function current()
    {
        return end($this->_stack);
    }

    
    public function next()
    {
        $Vkbvefdrfvxh = end($this->_stack);

        
        unset($this->_stack[key($this->_stack)]);
        $this->_num++;

        
        if ($Vdiqkcy1hsm4 = $Vkbvefdrfvxh->get_last_child()) {
            $this->_stack[] = $Vdiqkcy1hsm4;
            while ($Vdiqkcy1hsm4 = $Vdiqkcy1hsm4->get_prev_sibling()) {
                $this->_stack[] = $Vdiqkcy1hsm4;
            }
        }

        return $Vkbvefdrfvxh;
    }
}

