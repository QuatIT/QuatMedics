<?php
namespace Dompdf\Frame;

use Dompdf\Frame;
use IteratorAggregate;


class FrameList implements IteratorAggregate
{
    
    protected $Vzyb2djzba42;

    
    function __construct($Vexjfacrc1d4)
    {
        $this->_frame = $Vexjfacrc1d4;
    }

    
    function getIterator()
    {
        return new FrameListIterator($this->_frame);
    }
}
