<?php
namespace Dompdf\Frame;

use IteratorAggregate;
use Dompdf\Frame;


class FrameTreeList implements IteratorAggregate
{
    
    protected $Vebl3bww3mws;

    
    public function __construct(Frame $Vfqvundqbe4u)
    {
        $this->_root = $Vfqvundqbe4u;
    }

    
    public function getIterator()
    {
        return new FrameTreeIterator($this->_root);
    }
}
