<?php

namespace Dompdf\Frame;

use DOMDocument;
use DOMNode;
use DOMElement;
use DOMXPath;

use Dompdf\Exception;
use Dompdf\Frame;




class FrameTree
{
    
    protected static $Vg11451vwxri = array(
        "area",
        "base",
        "basefont",
        "head",
        "style",
        "meta",
        "title",
        "colgroup",
        "noembed",
        "param",
        "#comment"
    );

    
    protected $V13ysnuv2hk1;

    
    protected $Vebl3bww3mws;

    
    protected $Vllicx5d41ka;

    
    protected $Vdv521mxbu5d;

    
    public function __construct(DomDocument $Vpxru0eqkvw5)
    {
        $this->_dom = $Vpxru0eqkvw5;
        $this->_root = null;
        $this->_registry = array();
    }

    
    public function get_dom()
    {
        return $this->_dom;
    }

    
    public function get_root()
    {
        return $this->_root;
    }

    
    public function get_frame($Vawfntrfsy4f)
    {
        return isset($this->_registry[$Vawfntrfsy4f]) ? $this->_registry[$Vawfntrfsy4f] : null;
    }

    
    public function get_frames()
    {
        return new FrameTreeList($this->_root);
    }

    
    public function build_tree()
    {
        $Vr14vlgkz51r = $this->_dom->getElementsByTagName("html")->item(0);
        if (is_null($Vr14vlgkz51r)) {
            $Vr14vlgkz51r = $this->_dom->firstChild;
        }

        if (is_null($Vr14vlgkz51r)) {
            throw new Exception("Requested HTML document contains no data.");
        }

        $this->fix_tables();

        $this->_root = $this->_build_tree_r($Vr14vlgkz51r);
    }

    
    protected function fix_tables()
    {
        $V1szhjz3ctsp = new DOMXPath($this->_dom);

        
        
        $Vmqrflgbfxik = $V1szhjz3ctsp->query('//table/caption');
        foreach ($Vmqrflgbfxik as $Vbm0shc5wm12) {
            $Vp5rpvpxnb43 = $Vbm0shc5wm12->parentNode;
            $Vp5rpvpxnb43->parentNode->insertBefore($Vbm0shc5wm12, $Vp5rpvpxnb43);
        }

        $Vrcmm31dk4d3 = $V1szhjz3ctsp->query('//table/tr[1]');
        
        foreach ($Vrcmm31dk4d3 as $Vp5rpvpxnb43Child) {
            $Vj2ywqr0lj2f = $this->_dom->createElement('tbody');
            $Vp5rpvpxnb43Node = $Vp5rpvpxnb43Child->parentNode;
            do {
                if ($Vp5rpvpxnb43Child->nodeName === 'tr') {
                    $Vpjavq4um0qf = $Vp5rpvpxnb43Child;
                    $Vp5rpvpxnb43Child = $Vp5rpvpxnb43Child->nextSibling;
                    $Vp5rpvpxnb43Node->removeChild($Vpjavq4um0qf);
                    $Vj2ywqr0lj2f->appendChild($Vpjavq4um0qf);
                } else {
                    if ($Vj2ywqr0lj2f->hasChildNodes() === true) {
                        $Vp5rpvpxnb43Node->insertBefore($Vj2ywqr0lj2f, $Vp5rpvpxnb43Child);
                        $Vj2ywqr0lj2f = $this->_dom->createElement('tbody');
                    }
                    $Vp5rpvpxnb43Child = $Vp5rpvpxnb43Child->nextSibling;
                }
            } while ($Vp5rpvpxnb43Child);
            if ($Vj2ywqr0lj2f->hasChildNodes() === true) {
                $Vp5rpvpxnb43Node->appendChild($Vj2ywqr0lj2f);
            }
        }
    }

    
    
    protected function _remove_node(DOMNode $Vivp5mmrkfpz, array &$Vzi1s4z0nu10, $Vlx0mspyqviq)
    {
        $V0mqc4rbglqu = $Vzi1s4z0nu10[$Vlx0mspyqviq];
        $Ve1zkveryuxu = $V0mqc4rbglqu->previousSibling;
        $V54i3bvenifk = $V0mqc4rbglqu->nextSibling;
        $Vivp5mmrkfpz->removeChild($V0mqc4rbglqu);
        if (isset($Ve1zkveryuxu, $V54i3bvenifk)) {
            if ($Ve1zkveryuxu->nodeName === "#text" && $V54i3bvenifk->nodeName === "#text") {
                $Ve1zkveryuxu->nodeValue .= $V54i3bvenifk->nodeValue;
                $this->_remove_node($Vivp5mmrkfpz, $Vzi1s4z0nu10, $Vlx0mspyqviq+1);
            }
        }
        array_splice($Vzi1s4z0nu10, $Vlx0mspyqviq, 1);
    }

    
    protected function _build_tree_r(DOMNode $Vivp5mmrkfpz)
    {
        $Vexjfacrc1d4 = new Frame($Vivp5mmrkfpz);
        $Vawfntrfsy4f = $Vexjfacrc1d4->get_id();
        $this->_registry[$Vawfntrfsy4f] = $Vexjfacrc1d4;

        if (!$Vivp5mmrkfpz->hasChildNodes()) {
            return $Vexjfacrc1d4;
        }

        
        $Vzi1s4z0nu10 = array();
        $Vyfoeno5vtuw = $Vivp5mmrkfpz->childNodes->length;
        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vyfoeno5vtuw; $V0ixz2v5mxzy++) {
            $Vzi1s4z0nu10[] = $Vivp5mmrkfpz->childNodes->item($V0ixz2v5mxzy);
        }
        $Vlx0mspyqviq = 0;
        
        while ($Vlx0mspyqviq < count($Vzi1s4z0nu10)) {
            $V0mqc4rbglqu = $Vzi1s4z0nu10[$Vlx0mspyqviq];
            $Vivp5mmrkfpzName = strtolower($V0mqc4rbglqu->nodeName);

            
            if (in_array($Vivp5mmrkfpzName, self::$Vg11451vwxri)) {
                if ($Vivp5mmrkfpzName !== "head" && $Vivp5mmrkfpzName !== "style") {
                    $this->_remove_node($Vivp5mmrkfpz, $Vzi1s4z0nu10, $Vlx0mspyqviq);
                } else {
                    $Vlx0mspyqviq++;
                }
                continue;
            }
            
            if ($Vivp5mmrkfpzName === "#text" && $V0mqc4rbglqu->nodeValue === "") {
                $this->_remove_node($Vivp5mmrkfpz, $Vzi1s4z0nu10, $Vlx0mspyqviq);
                continue;
            }
            
            if ($Vivp5mmrkfpzName === "img" && $V0mqc4rbglqu->getAttribute("src") === "") {
                $this->_remove_node($Vivp5mmrkfpz, $Vzi1s4z0nu10, $Vlx0mspyqviq);
                continue;
            }

            if (is_object($V0mqc4rbglqu)) {
                $Vexjfacrc1d4->append_child($this->_build_tree_r($V0mqc4rbglqu), false);
            }
            $Vlx0mspyqviq++;
        }

        return $Vexjfacrc1d4;
    }

    
    public function insert_node(DOMElement $Vivp5mmrkfpz, DOMElement $Vl3r53fzd05f, $Vfrahdutb35k)
    {
        if ($Vfrahdutb35k === "after" || !$Vivp5mmrkfpz->firstChild) {
            $Vivp5mmrkfpz->appendChild($Vl3r53fzd05f);
        } else {
            $Vivp5mmrkfpz->insertBefore($Vl3r53fzd05f, $Vivp5mmrkfpz->firstChild);
        }

        $this->_build_tree_r($Vl3r53fzd05f);

        $Vexjfacrc1d4_id = $Vl3r53fzd05f->getAttribute("frame_id");
        $Vexjfacrc1d4 = $this->get_frame($Vexjfacrc1d4_id);

        $Veo2jkhu0l0x = $Vivp5mmrkfpz->getAttribute("frame_id");
        $Vhbd3bset2hu = $this->get_frame($Veo2jkhu0l0x);

        if ($Vhbd3bset2hu) {
            if ($Vfrahdutb35k === "before") {
                $Vhbd3bset2hu->prepend_child($Vexjfacrc1d4, false);
            } else {
                $Vhbd3bset2hu->append_child($Vexjfacrc1d4, false);
            }
        }

        return $Vexjfacrc1d4_id;
    }
}
