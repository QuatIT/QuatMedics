<?php

namespace Dompdf\Frame;

use Dompdf\Css\Style;
use Dompdf\Dompdf;
use Dompdf\Exception;
use Dompdf\Frame;
use Dompdf\FrameDecorator\AbstractFrameDecorator;
use DOMXPath;
use Dompdf\FrameDecorator\Page as PageFrameDecorator;
use Dompdf\FrameReflower\Page as PageFrameReflower;
use Dompdf\Positioner\AbstractPositioner;


class Factory
{

     
    protected static $Vjfslektq2ik;

    
    static function decorate_root(Frame $Vfqvundqbe4u, Dompdf $Vodc45cwlwwh)
    {
        $Vexjfacrc1d4 = new PageFrameDecorator($Vfqvundqbe4u, $Vodc45cwlwwh);
        $Vexjfacrc1d4->set_reflower(new PageFrameReflower($Vexjfacrc1d4));
        $Vfqvundqbe4u->set_decorator($Vexjfacrc1d4);

        return $Vexjfacrc1d4;
    }

    
    static function decorate_frame(Frame $Vexjfacrc1d4, Dompdf $Vodc45cwlwwh, Frame $Vfqvundqbe4u = null)
    {
        if (is_null($Vodc45cwlwwh)) {
            throw new Exception("The DOMPDF argument is required");
        }

        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        
        
        if (!$Vexjfacrc1d4->is_in_flow() && in_array($Vkvw5zjrwkdm->display, Style::$Vumjaagcajbo)) {
            $Vkvw5zjrwkdm->display = "block";
        }

        $Vqzifj31psr1 = $Vkvw5zjrwkdm->display;

        switch ($Vqzifj31psr1) {

            case "flex": 
            case "table-caption": 
            case "block":
                $Vpsnexix1aqc = "Block";
                $Vmgxucbvd04y = "Block";
                $Vvep0hy04kvb = "Block";
                break;

            case "inline-flex": 
            case "inline-block":
                $Vpsnexix1aqc = "Inline";
                $Vmgxucbvd04y = "Block";
                $Vvep0hy04kvb = "Block";
                break;

            case "inline":
                $Vpsnexix1aqc = "Inline";
                if ($Vexjfacrc1d4->is_text_node()) {
                    $Vmgxucbvd04y = "Text";
                    $Vvep0hy04kvb = "Text";
                } else {
                    if ($Vkvw5zjrwkdm->float !== "none") {
                        $Vmgxucbvd04y = "Block";
                        $Vvep0hy04kvb = "Block";
                    } else {
                        $Vmgxucbvd04y = "Inline";
                        $Vvep0hy04kvb = "Inline";
                    }
                }
                break;

            case "table":
                $Vpsnexix1aqc = "Block";
                $Vmgxucbvd04y = "Table";
                $Vvep0hy04kvb = "Table";
                break;

            case "inline-table":
                $Vpsnexix1aqc = "Inline";
                $Vmgxucbvd04y = "Table";
                $Vvep0hy04kvb = "Table";
                break;

            case "table-row-group":
            case "table-header-group":
            case "table-footer-group":
                $Vpsnexix1aqc = "NullPositioner";
                $Vmgxucbvd04y = "TableRowGroup";
                $Vvep0hy04kvb = "TableRowGroup";
                break;

            case "table-row":
                $Vpsnexix1aqc = "NullPositioner";
                $Vmgxucbvd04y = "TableRow";
                $Vvep0hy04kvb = "TableRow";
                break;

            case "table-cell":
                $Vpsnexix1aqc = "TableCell";
                $Vmgxucbvd04y = "TableCell";
                $Vvep0hy04kvb = "TableCell";
                break;

            case "list-item":
                $Vpsnexix1aqc = "Block";
                $Vmgxucbvd04y = "Block";
                $Vvep0hy04kvb = "Block";
                break;

            case "-dompdf-list-bullet":
                if ($Vkvw5zjrwkdm->list_style_position === "inside") {
                    $Vpsnexix1aqc = "Inline";
                } else {
                    $Vpsnexix1aqc = "ListBullet";
                }

                if ($Vkvw5zjrwkdm->list_style_image !== "none") {
                    $Vmgxucbvd04y = "ListBulletImage";
                } else {
                    $Vmgxucbvd04y = "ListBullet";
                }

                $Vvep0hy04kvb = "ListBullet";
                break;

            case "-dompdf-image":
                $Vpsnexix1aqc = "Inline";
                $Vmgxucbvd04y = "Image";
                $Vvep0hy04kvb = "Image";
                break;

            case "-dompdf-br":
                $Vpsnexix1aqc = "Inline";
                $Vmgxucbvd04y = "Inline";
                $Vvep0hy04kvb = "Inline";
                break;

            default:
                
            case "none":
                if ($Vkvw5zjrwkdm->_dompdf_keep !== "yes") {
                    
                    $Vexjfacrc1d4->get_parent()->remove_child($Vexjfacrc1d4);
                    return;
                }

                $Vpsnexix1aqc = "NullPositioner";
                $Vmgxucbvd04y = "NullFrameDecorator";
                $Vvep0hy04kvb = "NullFrameReflower";
                break;
        }

        
        $Vhyprn5v4f3y = $Vkvw5zjrwkdm->position;

        if ($Vhyprn5v4f3y === "absolute") {
            $Vpsnexix1aqc = "Absolute";
        } else {
            if ($Vhyprn5v4f3y === "fixed") {
                $Vpsnexix1aqc = "Fixed";
            }
        }

        $Vivp5mmrkfpz = $Vexjfacrc1d4->get_node();

        
        if ($Vivp5mmrkfpz->nodeName === "img") {
            $Vkvw5zjrwkdm->display = "-dompdf-image";
            $Vmgxucbvd04y = "Image";
            $Vvep0hy04kvb = "Image";
        }

        $Vmgxucbvd04y  = "Dompdf\\FrameDecorator\\$Vmgxucbvd04y";
        $Vvep0hy04kvb   = "Dompdf\\FrameReflower\\$Vvep0hy04kvb";

        
        $Vwhoam4hhp4h = new $Vmgxucbvd04y($Vexjfacrc1d4, $Vodc45cwlwwh);

        $Vwhoam4hhp4h->set_positioner(self::getPositionerInstance($Vpsnexix1aqc));
        $Vwhoam4hhp4h->set_reflower(new $Vvep0hy04kvb($Vwhoam4hhp4h, $Vodc45cwlwwh->getFontMetrics()));

        if ($Vfqvundqbe4u) {
            $Vwhoam4hhp4h->set_root($Vfqvundqbe4u);
        }

        if ($Vqzifj31psr1 === "list-item") {
            
            $Vse5n1rdsyvh = $Vodc45cwlwwh->getDom();
            $Vefw2mjnavto = $Vse5n1rdsyvh->createElement("bullet"); 
            $Vwtxkzk2n5qx = new Frame($Vefw2mjnavto);

            $Vivp5mmrkfpz = $Vexjfacrc1d4->get_node();
            $Vnit0ramrspy = $Vivp5mmrkfpz->parentNode;

            if ($Vnit0ramrspy) {
                if (!$Vnit0ramrspy->hasAttribute("dompdf-children-count")) {
                    $Vd34fc2deeyg = new DOMXPath($Vse5n1rdsyvh);
                    $V4wukmcy3ij2 = $Vd34fc2deeyg->query("li", $Vnit0ramrspy)->length;
                    $Vnit0ramrspy->setAttribute("dompdf-children-count", $V4wukmcy3ij2);
                }

                if (is_numeric($Vivp5mmrkfpz->getAttribute("value"))) {
                    $Vlx0mspyqviq = intval($Vivp5mmrkfpz->getAttribute("value"));
                } else {
                    if (!$Vnit0ramrspy->hasAttribute("dompdf-counter")) {
                        $Vlx0mspyqviq = ($Vnit0ramrspy->hasAttribute("start") ? $Vnit0ramrspy->getAttribute("start") : 1);
                    } else {
                        $Vlx0mspyqviq = (int)$Vnit0ramrspy->getAttribute("dompdf-counter") + 1;
                    }
                }

                $Vnit0ramrspy->setAttribute("dompdf-counter", $Vlx0mspyqviq);
                $Vefw2mjnavto->setAttribute("dompdf-counter", $Vlx0mspyqviq);
            }

            $Vrgaijtp2xnn = $Vodc45cwlwwh->getCss()->create_style();
            $Vrgaijtp2xnn->display = "-dompdf-list-bullet";
            $Vrgaijtp2xnn->inherit($Vkvw5zjrwkdm);
            $Vwtxkzk2n5qx->set_style($Vrgaijtp2xnn);

            $Vwhoam4hhp4h->prepend_child(Factory::decorate_frame($Vwtxkzk2n5qx, $Vodc45cwlwwh, $Vfqvundqbe4u));
        }

        return $Vwhoam4hhp4h;
    }

    
    protected static function getPositionerInstance($Vky1xzjrvbn4)
    {
        if (!isset(self::$Vjfslektq2ik[$Vky1xzjrvbn4])) {
            $Vrptwe2245zq = '\\Dompdf\\Positioner\\'.$Vky1xzjrvbn4;
            self::$Vjfslektq2ik[$Vky1xzjrvbn4] = new $Vrptwe2245zq();
        }
        return self::$Vjfslektq2ik[$Vky1xzjrvbn4];
    }
}
