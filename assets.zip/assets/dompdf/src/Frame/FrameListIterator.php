<?php
namespace Dompdf\Frame;

use Iterator;
use Dompdf\Frame;


class FrameListIterator implements Iterator
{

    
    protected $Vt4rxuuezyra;

    
    protected $Vol1k0z2g15f;

    
    protected $Vurkkjvfy4rq;

    
    public function __construct(Frame $Vexjfacrc1d4)
    {
        $this->_parent = $Vexjfacrc1d4;
        $this->_cur = $Vexjfacrc1d4->get_first_child();
        $this->_num = 0;
    }

    
    public function rewind()
    {
        $this->_cur = $this->_parent->get_first_child();
        $this->_num = 0;
    }

    
    public function valid()
    {
        return isset($this->_cur); 
    }

    
    public function key()
    {
        return $this->_num;
    }

    
    public function current()
    {
        return $this->_cur;
    }

    
    public function next()
    {
        $Vaamzcof1atz = $this->_cur;
        if (!$Vaamzcof1atz) {
            return null;
        }

        $this->_cur = $this->_cur->get_next_sibling();
        $this->_num++;
        return $Vaamzcof1atz;
    }
}
