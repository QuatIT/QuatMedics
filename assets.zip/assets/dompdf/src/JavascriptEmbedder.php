<?php

namespace Dompdf;


class JavascriptEmbedder
{

    
    protected $V3zitx0n32g4;

    
    public function __construct(Dompdf $Vodc45cwlwwh)
    {
        $this->_dompdf = $Vodc45cwlwwh;
    }

    
    public function insert($Vrmsxtweeon4)
    {
        $this->_dompdf->getCanvas()->javascript($Vrmsxtweeon4);
    }

    
    public function render(Frame $Vexjfacrc1d4)
    {
        if (!$this->_dompdf->getOptions()->getIsJavascriptEnabled()) {
            return;
        }

        $this->insert($Vexjfacrc1d4->get_node()->nodeValue);
    }
}
