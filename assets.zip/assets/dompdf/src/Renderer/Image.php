<?php

namespace Dompdf\Renderer;

use Dompdf\Frame;
use Dompdf\Image\Cache;


class Image extends Block
{

    
    function render(Frame $Vexjfacrc1d4)
    {
        
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();
        list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vexjfacrc1d4->get_border_box();

        $this->_set_opacity($Vexjfacrc1d4->get_opacity($Vkvw5zjrwkdm->opacity));

        list($Veltemnghp05, $Vkfno1tgq5nc, $Vbwp1e1ru2dj, $V3lmsgoqk24r) = $Vkvw5zjrwkdm->get_computed_border_radius($V5ymvwogwh5y, $V2pgp3ppbjsi);

        $V2pgp3ppbjsias_border_radius = $Veltemnghp05 + $Vkfno1tgq5nc + $Vbwp1e1ru2dj + $V3lmsgoqk24r > 0;

        if ($V2pgp3ppbjsias_border_radius) {
            $this->_canvas->clipping_roundrectangle($Vmm2pe5l4str, $Vuua0v2znlr5, (float)$V5ymvwogwh5y, (float)$V2pgp3ppbjsi, $Veltemnghp05, $Vkfno1tgq5nc, $Vbwp1e1ru2dj, $V3lmsgoqk24r);
        }

        if (($Vjpvoh1mwpv2 = $Vkvw5zjrwkdm->background_color) !== "transparent") {
            $this->_canvas->filled_rectangle($Vmm2pe5l4str, $Vuua0v2znlr5, (float)$V5ymvwogwh5y, (float)$V2pgp3ppbjsi, $Vjpvoh1mwpv2);
        }

        if (($Vop22rgf5euu = $Vkvw5zjrwkdm->background_image) && $Vop22rgf5euu !== "none") {
            $this->_background_image($Vop22rgf5euu, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vkvw5zjrwkdm);
        }

        if ($V2pgp3ppbjsias_border_radius) {
            $this->_canvas->clipping_end();
        }

        $this->_render_border($Vexjfacrc1d4);
        $this->_render_outline($Vexjfacrc1d4);

        list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vexjfacrc1d4->get_padding_box();

        $Vmm2pe5l4str += (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_left, $Ve0njdrnxyyx["w"]);
        $Vuua0v2znlr5 += (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_top, $Ve0njdrnxyyx["h"]);

        $V5ymvwogwh5y = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->width, $Ve0njdrnxyyx["w"]);
        $V2pgp3ppbjsi = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->height, $Ve0njdrnxyyx["h"]);

        if ($V2pgp3ppbjsias_border_radius) {
            list($V5ymvwogwh5yt, $V5ymvwogwh5yr, $V5ymvwogwh5yb, $V5ymvwogwh5yl) = array(
                $Vkvw5zjrwkdm->border_top_width,
                $Vkvw5zjrwkdm->border_right_width,
                $Vkvw5zjrwkdm->border_bottom_width,
                $Vkvw5zjrwkdm->border_left_width,
            );

            
            if ($Veltemnghp05 > 0) {
                $Veltemnghp05 -= ($V5ymvwogwh5yt + $V5ymvwogwh5yl) / 2;
            }
            if ($Vkfno1tgq5nc > 0) {
                $Vkfno1tgq5nc -= ($V5ymvwogwh5yt + $V5ymvwogwh5yr) / 2;
            }
            if ($Vbwp1e1ru2dj > 0) {
                $Vbwp1e1ru2dj -= ($V5ymvwogwh5yb + $V5ymvwogwh5yr) / 2;
            }
            if ($V3lmsgoqk24r > 0) {
                $V3lmsgoqk24r -= ($V5ymvwogwh5yb + $V5ymvwogwh5yl) / 2;
            }

            $this->_canvas->clipping_roundrectangle($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Veltemnghp05, $Vkfno1tgq5nc, $Vbwp1e1ru2dj, $V3lmsgoqk24r);
        }

        $Vahsl5oryz00 = $Vexjfacrc1d4->get_image_url();
        $Vximyhzisgt3 = null;

        if (Cache::is_broken($Vahsl5oryz00) &&
            $Vximyhzisgt3 = $Vexjfacrc1d4->get_node()->getAttribute("alt")
        ) {
            $Vfsinbbqzbga = $Vkvw5zjrwkdm->font_family;
            $Vkgj34o34uaw = $Vkvw5zjrwkdm->font_size;
            $Vd1hiq0tzl4w = $Vkvw5zjrwkdm->word_spacing;
            $this->_canvas->text(
                $Vmm2pe5l4str,
                $Vuua0v2znlr5,
                $Vximyhzisgt3,
                $Vfsinbbqzbga,
                $Vkgj34o34uaw,
                $Vkvw5zjrwkdm->color,
                $Vd1hiq0tzl4w
            );
        } else {
            $this->_canvas->image($Vahsl5oryz00, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vkvw5zjrwkdm->image_resolution);
        }

        if ($V2pgp3ppbjsias_border_radius) {
            $this->_canvas->clipping_end();
        }

        if ($V4kq14u5yvh5 = $Vexjfacrc1d4->get_image_msg()) {
            $Vrra0vtlxofn = preg_split("/\s*\n\s*/", $V4kq14u5yvh5);
            $V2pgp3ppbjsieight = 10;
            $Vnm4hhw00u4w = $Vximyhzisgt3 ? $Vuua0v2znlr5 + $V2pgp3ppbjsi - count($Vrra0vtlxofn) * $V2pgp3ppbjsieight : $Vuua0v2znlr5;

            foreach ($Vrra0vtlxofn as $V0ixz2v5mxzy => $Vid0eg5by5oh) {
                $this->_canvas->text($Vmm2pe5l4str, $Vnm4hhw00u4w + $V0ixz2v5mxzy * $V2pgp3ppbjsieight, $Vid0eg5by5oh, "times", $V2pgp3ppbjsieight * 0.8, array(0.5, 0.5, 0.5));
            }
        }

        if ($this->_dompdf->getOptions()->getDebugLayout() && $this->_dompdf->getOptions()->getDebugLayoutBlocks()) {
            $this->_debug_layout($Vexjfacrc1d4->get_border_box(), "blue");
            if ($this->_dompdf->getOptions()->getDebugLayoutPaddingBox()) {
                $this->_debug_layout($Vexjfacrc1d4->get_padding_box(), "blue", array(0.5, 0.5));
            }
        }

        $V0ixz2v5mxzyd = $Vexjfacrc1d4->get_node()->getAttribute("id");
        if (strlen($V0ixz2v5mxzyd) > 0)  {
            $this->_canvas->add_named_dest($V0ixz2v5mxzyd);
        }
    }
}
