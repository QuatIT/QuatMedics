<?php

namespace Dompdf\Renderer;

use Dompdf\Adapter\CPDF;
use Dompdf\Css\Color;
use Dompdf\Css\Style;
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Frame;
use Dompdf\Image\Cache;


abstract class AbstractRenderer
{

    
    protected $V2ndtbforzqn;

    
    protected $V3zitx0n32g4;

    
    function __construct(Dompdf $Vodc45cwlwwh)
    {
        $this->_dompdf = $Vodc45cwlwwh;
        $this->_canvas = $Vodc45cwlwwh->getCanvas();
    }

    
    abstract function render(Frame $Vexjfacrc1d4);

    
    protected function _background_image($Vop22rgf5euu, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vtt4kvdwuqqh, $Vxtfrabd3i5r, $Vkvw5zjrwkdm)
    {
        if (!function_exists("imagecreatetruecolor")) {
            throw new \Exception("The PHP GD extension is required, but is not installed.");
        }

        $Vxurj050eld2 = $Vkvw5zjrwkdm->get_stylesheet();

        
        if ($Vtt4kvdwuqqh == 0 || $Vxtfrabd3i5r == 0) {
            return;
        }

        $V14oy2nqdsdy = $Vtt4kvdwuqqh;
        $Vpoxtmjp1c1e = $Vxtfrabd3i5r;

        
        if ($this->_dompdf->getOptions()->getDebugPng()) {
            print '[_background_image ' . $Vop22rgf5euu . ']';
        }

        list($Vz1jukgekuy3, $Vky1xzjrvbn4, ) = Cache::resolve_url(
            $Vop22rgf5euu,
            $Vxurj050eld2->get_protocol(),
            $Vxurj050eld2->get_host(),
            $Vxurj050eld2->get_base_path(),
            $this->_dompdf
        );

        
        if (Cache::is_broken($Vz1jukgekuy3)) {
            return;
        }

        
        
        
        
        

        list($Vz1jukgekuy3_w, $Vz1jukgekuy3_h) = Helpers::dompdf_getimagesize($Vz1jukgekuy3, $this->_dompdf->getHttpContext());
        if (!isset($Vz1jukgekuy3_w) || $Vz1jukgekuy3_w == 0 || !isset($Vz1jukgekuy3_h) || $Vz1jukgekuy3_h == 0) {
            return;
        }

        $Vf41t341wqpb = $Vkvw5zjrwkdm->background_repeat;
        $Vfwb1n1yh3ll = $this->_dompdf->getOptions()->getDpi();

        
        
        $Vcpf2qsuzqmh = round((float)($Vtt4kvdwuqqh * $Vfwb1n1yh3ll) / 72);
        $Vcoqd1a5ckqe = round((float)($Vxtfrabd3i5r * $Vfwb1n1yh3ll) / 72);

        

        list($Vl0hq30b2stm, $Vc2y3ofiyuhq) = $Vkvw5zjrwkdm->background_position;

        if (Helpers::is_percent($Vl0hq30b2stm)) {
            
            
            $V2d1s45w0hjo = ((float)$Vl0hq30b2stm) / 100.0;
            $Vmm2pe5l4str1 = $V2d1s45w0hjo * $Vz1jukgekuy3_w;
            $Vmm2pe5l4str2 = $V2d1s45w0hjo * $Vcpf2qsuzqmh;

            $Vl0hq30b2stm = $Vmm2pe5l4str2 - $Vmm2pe5l4str1;
        } else {
            $Vl0hq30b2stm = (float)($Vkvw5zjrwkdm->length_in_pt($Vl0hq30b2stm) * $Vfwb1n1yh3ll) / 72;
        }

        $Vl0hq30b2stm = round($Vl0hq30b2stm + (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->border_left_width) * $Vfwb1n1yh3ll / 72);

        if (Helpers::is_percent($Vc2y3ofiyuhq)) {
            
            
            $V2d1s45w0hjo = ((float)$Vc2y3ofiyuhq) / 100.0;
            $Vuua0v2znlr51 = $V2d1s45w0hjo * $Vz1jukgekuy3_h;
            $Vuua0v2znlr52 = $V2d1s45w0hjo * $Vcoqd1a5ckqe;

            $Vc2y3ofiyuhq = $Vuua0v2znlr52 - $Vuua0v2znlr51;
        } else {
            $Vc2y3ofiyuhq = (float)($Vkvw5zjrwkdm->length_in_pt($Vc2y3ofiyuhq) * $Vfwb1n1yh3ll) / 72;
        }

        $Vc2y3ofiyuhq = round($Vc2y3ofiyuhq + (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->border_top_width) * $Vfwb1n1yh3ll / 72);

        
        
        
        

        if ($Vf41t341wqpb !== "repeat" && $Vf41t341wqpb !== "repeat-x") {
            
            if ($Vl0hq30b2stm < 0) {
                $Vcpf2qsuzqmh = $Vz1jukgekuy3_w + $Vl0hq30b2stm;
            } else {
                $Vmm2pe5l4str += ($Vl0hq30b2stm * 72) / $Vfwb1n1yh3ll;
                $Vcpf2qsuzqmh = $Vcpf2qsuzqmh - $Vl0hq30b2stm;
                if ($Vcpf2qsuzqmh > $Vz1jukgekuy3_w) {
                    $Vcpf2qsuzqmh = $Vz1jukgekuy3_w;
                }
                $Vl0hq30b2stm = 0;
            }

            if ($Vcpf2qsuzqmh <= 0) {
                return;
            }

            $Vtt4kvdwuqqh = (float)($Vcpf2qsuzqmh * 72) / $Vfwb1n1yh3ll;
        } else {
            
            if ($Vl0hq30b2stm < 0) {
                $Vl0hq30b2stm = -((-$Vl0hq30b2stm) % $Vz1jukgekuy3_w);
            } else {
                $Vl0hq30b2stm = $Vl0hq30b2stm % $Vz1jukgekuy3_w;
                if ($Vl0hq30b2stm > 0) {
                    $Vl0hq30b2stm -= $Vz1jukgekuy3_w;
                }
            }
        }

        if ($Vf41t341wqpb !== "repeat" && $Vf41t341wqpb !== "repeat-y") {
            
            if ($Vc2y3ofiyuhq < 0) {
                $Vcoqd1a5ckqe = $Vz1jukgekuy3_h + $Vc2y3ofiyuhq;
            } else {
                $Vuua0v2znlr5 += ($Vc2y3ofiyuhq * 72) / $Vfwb1n1yh3ll;
                $Vcoqd1a5ckqe = $Vcoqd1a5ckqe - $Vc2y3ofiyuhq;
                if ($Vcoqd1a5ckqe > $Vz1jukgekuy3_h) {
                    $Vcoqd1a5ckqe = $Vz1jukgekuy3_h;
                }
                $Vc2y3ofiyuhq = 0;
            }
            if ($Vcoqd1a5ckqe <= 0) {
                return;
            }
            $Vxtfrabd3i5r = (float)($Vcoqd1a5ckqe * 72) / $Vfwb1n1yh3ll;
        } else {
            
            if ($Vc2y3ofiyuhq < 0) {
                $Vc2y3ofiyuhq = -((-$Vc2y3ofiyuhq) % $Vz1jukgekuy3_h);
            } else {
                $Vc2y3ofiyuhq = $Vc2y3ofiyuhq % $Vz1jukgekuy3_h;
                if ($Vc2y3ofiyuhq > 0) {
                    $Vc2y3ofiyuhq -= $Vz1jukgekuy3_h;
                }
            }
        }

        
        if ($Vf41t341wqpb === "repeat" && $Vc2y3ofiyuhq <= 0 && $Vz1jukgekuy3_h + $Vc2y3ofiyuhq >= $Vcoqd1a5ckqe) {
            $Vf41t341wqpb = "repeat-x";
        }

        if ($Vf41t341wqpb === "repeat" && $Vl0hq30b2stm <= 0 && $Vz1jukgekuy3_w + $Vl0hq30b2stm >= $Vcpf2qsuzqmh) {
            $Vf41t341wqpb = "repeat-y";
        }

        if (($Vf41t341wqpb === "repeat-x" && $Vl0hq30b2stm <= 0 && $Vz1jukgekuy3_w + $Vl0hq30b2stm >= $Vcpf2qsuzqmh) ||
            ($Vf41t341wqpb === "repeat-y" && $Vc2y3ofiyuhq <= 0 && $Vz1jukgekuy3_h + $Vc2y3ofiyuhq >= $Vcoqd1a5ckqe)
        ) {
            $Vf41t341wqpb = "no-repeat";
        }

        
        
        
        

        $Vu0aiofzwpha = $Vz1jukgekuy3;

        $Vofc2rwg2zkd = false;
        $Vu0aiofzwpha .= '_' . $Vcpf2qsuzqmh . '_' . $Vcoqd1a5ckqe . '_' . $Vl0hq30b2stm . '_' . $Vc2y3ofiyuhq . '_' . $Vf41t341wqpb;

        
        
        
        if ($this->_canvas instanceof CPDF && $this->_canvas->get_cpdf()->image_iscached($Vu0aiofzwpha)) {
            $Vjpvoh1mwpv2 = null;
        } else {
            
            $Vjpvoh1mwpv2 = imagecreatetruecolor($Vcpf2qsuzqmh, $Vcoqd1a5ckqe);

            switch (strtolower($Vky1xzjrvbn4)) {
                case "png":
                    $Vofc2rwg2zkd = true;
                    imagesavealpha($Vjpvoh1mwpv2, true);
                    imagealphablending($Vjpvoh1mwpv2, false);
                    $Vahsl5oryz00 = imagecreatefrompng($Vz1jukgekuy3);
                    break;

                case "jpeg":
                    $Vahsl5oryz00 = imagecreatefromjpeg($Vz1jukgekuy3);
                    break;

                case "gif":
                    $Vahsl5oryz00 = imagecreatefromgif($Vz1jukgekuy3);
                    break;

                case "bmp":
                    $Vahsl5oryz00 = Helpers::imagecreatefrombmp($Vz1jukgekuy3);
                    break;

                default:
                    return; 
            }

            if ($Vahsl5oryz00 == null) {
                return;
            }

            
            
            
            
            
            $Vgsosvnss2i4 = imagecolortransparent($Vahsl5oryz00);

            if ($Vgsosvnss2i4 >= 0) {
                $Vfblezhvf1dm = imagecolorsforindex($Vahsl5oryz00, $Vgsosvnss2i4);
                $Vgsosvnss2i4 = imagecolorallocate($Vjpvoh1mwpv2, $Vfblezhvf1dm['red'], $Vfblezhvf1dm['green'], $Vfblezhvf1dm['blue']);
                imagefill($Vjpvoh1mwpv2, 0, 0, $Vgsosvnss2i4);
                imagecolortransparent($Vjpvoh1mwpv2, $Vgsosvnss2i4);
            }

            
            
            if ($Vl0hq30b2stm < 0) {
                $Vny250ffuhzl = 0;
                $Vahsl5oryz00_x = -$Vl0hq30b2stm;
            } else {
                $Vahsl5oryz00_x = 0;
                $Vny250ffuhzl = $Vl0hq30b2stm;
            }

            if ($Vc2y3ofiyuhq < 0) {
                $Vxodfznpp3xy = 0;
                $Vahsl5oryz00_y = -$Vc2y3ofiyuhq;
            } else {
                $Vahsl5oryz00_y = 0;
                $Vxodfznpp3xy = $Vc2y3ofiyuhq;
            }

            
            
            $V45fvvmapqm4 = $Vl0hq30b2stm;
            $Vhcuhkgwxiyg = $Vc2y3ofiyuhq;

            
            if ($Vf41t341wqpb === "no-repeat") {
                
                imagecopy($Vjpvoh1mwpv2, $Vahsl5oryz00, $Vny250ffuhzl, $Vxodfznpp3xy, $Vahsl5oryz00_x, $Vahsl5oryz00_y, $Vz1jukgekuy3_w, $Vz1jukgekuy3_h);

            } else if ($Vf41t341wqpb === "repeat-x") {
                for ($Vl0hq30b2stm = $V45fvvmapqm4; $Vl0hq30b2stm < $Vcpf2qsuzqmh; $Vl0hq30b2stm += $Vz1jukgekuy3_w) {
                    if ($Vl0hq30b2stm < 0) {
                        $Vny250ffuhzl = 0;
                        $Vahsl5oryz00_x = -$Vl0hq30b2stm;
                        $V5ymvwogwh5y = $Vz1jukgekuy3_w + $Vl0hq30b2stm;
                    } else {
                        $Vny250ffuhzl = $Vl0hq30b2stm;
                        $Vahsl5oryz00_x = 0;
                        $V5ymvwogwh5y = $Vz1jukgekuy3_w;
                    }
                    imagecopy($Vjpvoh1mwpv2, $Vahsl5oryz00, $Vny250ffuhzl, $Vxodfznpp3xy, $Vahsl5oryz00_x, $Vahsl5oryz00_y, $V5ymvwogwh5y, $Vz1jukgekuy3_h);
                }
            } else if ($Vf41t341wqpb === "repeat-y") {

                for ($Vc2y3ofiyuhq = $Vhcuhkgwxiyg; $Vc2y3ofiyuhq < $Vcoqd1a5ckqe; $Vc2y3ofiyuhq += $Vz1jukgekuy3_h) {
                    if ($Vc2y3ofiyuhq < 0) {
                        $Vxodfznpp3xy = 0;
                        $Vahsl5oryz00_y = -$Vc2y3ofiyuhq;
                        $V2pgp3ppbjsi = $Vz1jukgekuy3_h + $Vc2y3ofiyuhq;
                    } else {
                        $Vxodfznpp3xy = $Vc2y3ofiyuhq;
                        $Vahsl5oryz00_y = 0;
                        $V2pgp3ppbjsi = $Vz1jukgekuy3_h;
                    }
                    imagecopy($Vjpvoh1mwpv2, $Vahsl5oryz00, $Vny250ffuhzl, $Vxodfznpp3xy, $Vahsl5oryz00_x, $Vahsl5oryz00_y, $Vz1jukgekuy3_w, $V2pgp3ppbjsi);
                }
            } else if ($Vf41t341wqpb === "repeat") {
                for ($Vc2y3ofiyuhq = $Vhcuhkgwxiyg; $Vc2y3ofiyuhq < $Vcoqd1a5ckqe; $Vc2y3ofiyuhq += $Vz1jukgekuy3_h) {
                    for ($Vl0hq30b2stm = $V45fvvmapqm4; $Vl0hq30b2stm < $Vcpf2qsuzqmh; $Vl0hq30b2stm += $Vz1jukgekuy3_w) {
                        if ($Vl0hq30b2stm < 0) {
                            $Vny250ffuhzl = 0;
                            $Vahsl5oryz00_x = -$Vl0hq30b2stm;
                            $V5ymvwogwh5y = $Vz1jukgekuy3_w + $Vl0hq30b2stm;
                        } else {
                            $Vny250ffuhzl = $Vl0hq30b2stm;
                            $Vahsl5oryz00_x = 0;
                            $V5ymvwogwh5y = $Vz1jukgekuy3_w;
                        }

                        if ($Vc2y3ofiyuhq < 0) {
                            $Vxodfznpp3xy = 0;
                            $Vahsl5oryz00_y = -$Vc2y3ofiyuhq;
                            $V2pgp3ppbjsi = $Vz1jukgekuy3_h + $Vc2y3ofiyuhq;
                        } else {
                            $Vxodfznpp3xy = $Vc2y3ofiyuhq;
                            $Vahsl5oryz00_y = 0;
                            $V2pgp3ppbjsi = $Vz1jukgekuy3_h;
                        }
                        imagecopy($Vjpvoh1mwpv2, $Vahsl5oryz00, $Vny250ffuhzl, $Vxodfznpp3xy, $Vahsl5oryz00_x, $Vahsl5oryz00_y, $V5ymvwogwh5y, $V2pgp3ppbjsi);
                    }
                }
            } else {
                print 'Unknown repeat!';
            }

            imagedestroy($Vahsl5oryz00);

        } 

        $this->_canvas->clipping_rectangle($Vmm2pe5l4str, $Vuua0v2znlr5, $V14oy2nqdsdy, $Vpoxtmjp1c1e);

        
        
        
        
        
        
        
        
        
        
        
        if (!$Vofc2rwg2zkd && $this->_canvas instanceof CPDF) {
            
            $this->_canvas->get_cpdf()->addImagePng($Vu0aiofzwpha, $Vmm2pe5l4str, $this->_canvas->get_height() - $Vuua0v2znlr5 - $Vxtfrabd3i5r, $Vtt4kvdwuqqh, $Vxtfrabd3i5r, $Vjpvoh1mwpv2);
        } else {
            $V3h3ilzzwl20 = $this->_dompdf->getOptions()->getTempDir();
            $Vzelhepcnuf3 = tempnam($V3h3ilzzwl20, "bg_dompdf_img_");
            @unlink($Vzelhepcnuf3);
            $Vmlwzt5vfidd = "$Vzelhepcnuf3.png";

            
            if ($this->_dompdf->getOptions()->getDebugPng()) {
                print '[_background_image ' . $Vmlwzt5vfidd . ']';
            }

            imagepng($Vjpvoh1mwpv2, $Vmlwzt5vfidd);
            $this->_canvas->image($Vmlwzt5vfidd, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vtt4kvdwuqqh, $Vxtfrabd3i5r);
            imagedestroy($Vjpvoh1mwpv2);

            
            if ($this->_dompdf->getOptions()->getDebugPng()) {
                print '[_background_image unlink ' . $Vmlwzt5vfidd . ']';
            }

            if (!$this->_dompdf->getOptions()->getDebugKeepTemp()) {
                unlink($Vmlwzt5vfidd);
            }
        }

        $this->_canvas->clipping_end();
    }

    
    protected function _get_dash_pattern($Vkvw5zjrwkdm, $Vtt4kvdwuqqh)
    {
        $V2d1s45w0hjoattern = array();

        switch ($Vkvw5zjrwkdm) {
            default:
                
            case "none":
                break;

            case "dotted":
                if ($Vtt4kvdwuqqh <= 1) {
                    $V2d1s45w0hjoattern = array($Vtt4kvdwuqqh, $Vtt4kvdwuqqh * 2);
                } else {
                    $V2d1s45w0hjoattern = array($Vtt4kvdwuqqh);
                }
                break;

            case "dashed":
                $V2d1s45w0hjoattern = array(3 * $Vtt4kvdwuqqh);
                break;
        }

        return $V2d1s45w0hjoattern;
    }

    
    protected function _border_none($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        return;
    }

    
    protected function _border_hidden($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        return;
    }

    

    
    protected function _border_dotted($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        $this->_border_line($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l, "dotted", $Vapguowxhnfz, $V1wjrukdrpg5);
    }


    
    protected function _border_dashed($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        $this->_border_line($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l, "dashed", $Vapguowxhnfz, $V1wjrukdrpg5);
    }


    
    protected function _border_solid($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        
        if ($Vvjvaevwt31l !== "bevel" || $Vapguowxhnfz > 0 || $V1wjrukdrpg5 > 0) {
            
            $this->_border_line($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l, "solid", $Vapguowxhnfz, $V1wjrukdrpg5);
            return;
        }

        list($Vzn5k4lefp5v, $Vqswkdbtte35, $V3xygetcwtmz, $Vb5dthqtenbv) = $Vtt4kvdwuqqhs;

        
        switch ($Vcxi3be0s51c) {
            case "top":
                $V2d1s45w0hjooints = array($Vmm2pe5l4str, $Vuua0v2znlr5,
                    $Vmm2pe5l4str + $Vyfoeno5vtuw, $Vuua0v2znlr5,
                    $Vmm2pe5l4str + $Vyfoeno5vtuw - $Vqswkdbtte35, $Vuua0v2znlr5 + $Vzn5k4lefp5v,
                    $Vmm2pe5l4str + $Vb5dthqtenbv, $Vuua0v2znlr5 + $Vzn5k4lefp5v);
                $this->_canvas->polygon($V2d1s45w0hjooints, $V3poxlnogtlh, null, null, true);
                break;

            case "bottom":
                $V2d1s45w0hjooints = array($Vmm2pe5l4str, $Vuua0v2znlr5,
                    $Vmm2pe5l4str + $Vyfoeno5vtuw, $Vuua0v2znlr5,
                    $Vmm2pe5l4str + $Vyfoeno5vtuw - $Vqswkdbtte35, $Vuua0v2znlr5 - $V3xygetcwtmz,
                    $Vmm2pe5l4str + $Vb5dthqtenbv, $Vuua0v2znlr5 - $V3xygetcwtmz);
                $this->_canvas->polygon($V2d1s45w0hjooints, $V3poxlnogtlh, null, null, true);
                break;

            case "left":
                $V2d1s45w0hjooints = array($Vmm2pe5l4str, $Vuua0v2znlr5,
                    $Vmm2pe5l4str, $Vuua0v2znlr5 + $Vyfoeno5vtuw,
                    $Vmm2pe5l4str + $Vb5dthqtenbv, $Vuua0v2znlr5 + $Vyfoeno5vtuw - $V3xygetcwtmz,
                    $Vmm2pe5l4str + $Vb5dthqtenbv, $Vuua0v2znlr5 + $Vzn5k4lefp5v);
                $this->_canvas->polygon($V2d1s45w0hjooints, $V3poxlnogtlh, null, null, true);
                break;

            case "right":
                $V2d1s45w0hjooints = array($Vmm2pe5l4str, $Vuua0v2znlr5,
                    $Vmm2pe5l4str, $Vuua0v2znlr5 + $Vyfoeno5vtuw,
                    $Vmm2pe5l4str - $Vqswkdbtte35, $Vuua0v2znlr5 + $Vyfoeno5vtuw - $V3xygetcwtmz,
                    $Vmm2pe5l4str - $Vqswkdbtte35, $Vuua0v2znlr5 + $Vzn5k4lefp5v);
                $this->_canvas->polygon($V2d1s45w0hjooints, $V3poxlnogtlh, null, null, true);
                break;

            default:
                return;
        }
    }

    
    protected function _apply_ratio($Vcxi3be0s51c, $V4j2ohhe2azc, $Vzn5k4lefp5v, $Vqswkdbtte35, $V3xygetcwtmz, $Vb5dthqtenbv, &$Vmm2pe5l4str, &$Vuua0v2znlr5, &$Vyfoeno5vtuw, &$Vapguowxhnfz, &$V1wjrukdrpg5)
    {
        switch ($Vcxi3be0s51c) {
            case "top":
                $Vapguowxhnfz -= $Vb5dthqtenbv * $V4j2ohhe2azc;
                $V1wjrukdrpg5 -= $Vqswkdbtte35 * $V4j2ohhe2azc;
                $Vmm2pe5l4str += $Vb5dthqtenbv * $V4j2ohhe2azc;
                $Vuua0v2znlr5 += $Vzn5k4lefp5v * $V4j2ohhe2azc;
                $Vyfoeno5vtuw -= $Vb5dthqtenbv * $V4j2ohhe2azc + $Vqswkdbtte35 * $V4j2ohhe2azc;
                break;

            case "bottom":
                $Vapguowxhnfz -= $Vqswkdbtte35 * $V4j2ohhe2azc;
                $V1wjrukdrpg5 -= $Vb5dthqtenbv * $V4j2ohhe2azc;
                $Vmm2pe5l4str += $Vb5dthqtenbv * $V4j2ohhe2azc;
                $Vuua0v2znlr5 -= $V3xygetcwtmz * $V4j2ohhe2azc;
                $Vyfoeno5vtuw -= $Vb5dthqtenbv * $V4j2ohhe2azc + $Vqswkdbtte35 * $V4j2ohhe2azc;
                break;

            case "left":
                $Vapguowxhnfz -= $Vzn5k4lefp5v * $V4j2ohhe2azc;
                $V1wjrukdrpg5 -= $V3xygetcwtmz * $V4j2ohhe2azc;
                $Vmm2pe5l4str += $Vb5dthqtenbv * $V4j2ohhe2azc;
                $Vuua0v2znlr5 += $Vzn5k4lefp5v * $V4j2ohhe2azc;
                $Vyfoeno5vtuw -= $Vzn5k4lefp5v * $V4j2ohhe2azc + $V3xygetcwtmz * $V4j2ohhe2azc;
                break;

            case "right":
                $Vapguowxhnfz -= $V3xygetcwtmz * $V4j2ohhe2azc;
                $V1wjrukdrpg5 -= $Vzn5k4lefp5v * $V4j2ohhe2azc;
                $Vmm2pe5l4str -= $Vqswkdbtte35 * $V4j2ohhe2azc;
                $Vuua0v2znlr5 += $Vzn5k4lefp5v * $V4j2ohhe2azc;
                $Vyfoeno5vtuw -= $Vzn5k4lefp5v * $V4j2ohhe2azc + $V3xygetcwtmz * $V4j2ohhe2azc;
                break;

            default:
                return;
        }
    }

    
    protected function _border_double($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        list($Vzn5k4lefp5v, $Vqswkdbtte35, $V3xygetcwtmz, $Vb5dthqtenbv) = $Vtt4kvdwuqqhs;

        $Vzbxuqc4r1er = array($Vzn5k4lefp5v / 3, $Vqswkdbtte35 / 3, $V3xygetcwtmz / 3, $Vb5dthqtenbv / 3);

        
        $this->_border_solid($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vzbxuqc4r1er, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);

        $this->_apply_ratio($Vcxi3be0s51c, 2 / 3, $Vzn5k4lefp5v, $Vqswkdbtte35, $V3xygetcwtmz, $Vb5dthqtenbv, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $Vapguowxhnfz, $V1wjrukdrpg5);

        $this->_border_solid($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vzbxuqc4r1er, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);
    }

    
    protected function _border_groove($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        list($Vzn5k4lefp5v, $Vqswkdbtte35, $V3xygetcwtmz, $Vb5dthqtenbv) = $Vtt4kvdwuqqhs;

        $V2pgp3ppbjsialf_widths = array($Vzn5k4lefp5v / 2, $Vqswkdbtte35 / 2, $V3xygetcwtmz / 2, $Vb5dthqtenbv / 2);

        $this->_border_inset($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $V2pgp3ppbjsialf_widths, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);

        $this->_apply_ratio($Vcxi3be0s51c, 0.5, $Vzn5k4lefp5v, $Vqswkdbtte35, $V3xygetcwtmz, $Vb5dthqtenbv, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $Vapguowxhnfz, $V1wjrukdrpg5);

        $this->_border_outset($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $V2pgp3ppbjsialf_widths, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);

    }

    
    protected function _border_ridge($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        list($Vzn5k4lefp5v, $Vqswkdbtte35, $V3xygetcwtmz, $Vb5dthqtenbv) = $Vtt4kvdwuqqhs;

        $V2pgp3ppbjsialf_widths = array($Vzn5k4lefp5v / 2, $Vqswkdbtte35 / 2, $V3xygetcwtmz / 2, $Vb5dthqtenbv / 2);

        $this->_border_outset($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $V2pgp3ppbjsialf_widths, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);

        $this->_apply_ratio($Vcxi3be0s51c, 0.5, $Vzn5k4lefp5v, $Vqswkdbtte35, $V3xygetcwtmz, $Vb5dthqtenbv, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $Vapguowxhnfz, $V1wjrukdrpg5);

        $this->_border_inset($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $V2pgp3ppbjsialf_widths, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);

    }

    
    protected function _tint($Vdiqkcy1hsm4)
    {
        if (!is_numeric($Vdiqkcy1hsm4)) {
            return $Vdiqkcy1hsm4;
        }

        return min(1, $Vdiqkcy1hsm4 + 0.16);
    }

    
    protected function _shade($Vdiqkcy1hsm4)
    {
        if (!is_numeric($Vdiqkcy1hsm4)) {
            return $Vdiqkcy1hsm4;
        }

        return max(0, $Vdiqkcy1hsm4 - 0.33);
    }

    
    protected function _border_inset($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        switch ($Vcxi3be0s51c) {
            case "top":
            case "left":
                $Va1ekny2pcgf = array_map(array($this, "_shade"), $V3poxlnogtlh);
                $this->_border_solid($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $Va1ekny2pcgf, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);
                break;

            case "bottom":
            case "right":
                $Vgsosvnss2i4nt = array_map(array($this, "_tint"), $V3poxlnogtlh);
                $this->_border_solid($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $Vgsosvnss2i4nt, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);
                break;

            default:
                return;
        }
    }

    
    protected function _border_outset($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        switch ($Vcxi3be0s51c) {
            case "top":
            case "left":
                $Vgsosvnss2i4nt = array_map(array($this, "_tint"), $V3poxlnogtlh);
                $this->_border_solid($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $Vgsosvnss2i4nt, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);
                break;

            case "bottom":
            case "right":
                $Va1ekny2pcgf = array_map(array($this, "_shade"), $V3poxlnogtlh);
                $this->_border_solid($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $Va1ekny2pcgf, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);
                break;

            default:
                return;
        }
    }

    
    protected function _border_line($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $V3poxlnogtlh, $Vtt4kvdwuqqhs, $Vcxi3be0s51c, $Vvjvaevwt31l = "bevel", $V2d1s45w0hjoattern_name, $Vapguowxhnfz = 0, $V1wjrukdrpg5 = 0)
    {
        
        list($Vzn5k4lefp5v, $Vqswkdbtte35, $V3xygetcwtmz, $Vb5dthqtenbv) = $Vtt4kvdwuqqhs;
        $Vtt4kvdwuqqh = $$Vcxi3be0s51c;

        $V2d1s45w0hjoattern = $this->_get_dash_pattern($V2d1s45w0hjoattern_name, $Vtt4kvdwuqqh);

        $V2pgp3ppbjsialf_width = $Vtt4kvdwuqqh / 2;
        $Vapguowxhnfz -= $V2pgp3ppbjsialf_width;
        $V1wjrukdrpg5 -= $V2pgp3ppbjsialf_width;
        $Vmp1ozssfxod = $Vapguowxhnfz / 80;
        $Vyfoeno5vtuw -= $Vtt4kvdwuqqh;

        switch ($Vcxi3be0s51c) {
            case "top":
                $Vmm2pe5l4str += $V2pgp3ppbjsialf_width;
                $Vuua0v2znlr5 += $V2pgp3ppbjsialf_width;

                if ($Vapguowxhnfz > 0) {
                    $this->_canvas->arc($Vmm2pe5l4str + $Vapguowxhnfz, $Vuua0v2znlr5 + $Vapguowxhnfz, $Vapguowxhnfz, $Vapguowxhnfz, 90 - $Vmp1ozssfxod, 135 + $Vmp1ozssfxod, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);
                }

                $this->_canvas->line($Vmm2pe5l4str + $Vapguowxhnfz, $Vuua0v2znlr5, $Vmm2pe5l4str + $Vyfoeno5vtuw - $V1wjrukdrpg5, $Vuua0v2znlr5, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);

                if ($V1wjrukdrpg5 > 0) {
                    $this->_canvas->arc($Vmm2pe5l4str + $Vyfoeno5vtuw - $V1wjrukdrpg5, $Vuua0v2znlr5 + $V1wjrukdrpg5, $V1wjrukdrpg5, $V1wjrukdrpg5, 45 - $Vmp1ozssfxod, 90 + $Vmp1ozssfxod, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);
                }
                break;

            case "bottom":
                $Vmm2pe5l4str += $V2pgp3ppbjsialf_width;
                $Vuua0v2znlr5 -= $V2pgp3ppbjsialf_width;

                if ($Vapguowxhnfz > 0) {
                    $this->_canvas->arc($Vmm2pe5l4str + $Vapguowxhnfz, $Vuua0v2znlr5 - $Vapguowxhnfz, $Vapguowxhnfz, $Vapguowxhnfz, 225 - $Vmp1ozssfxod, 270 + $Vmp1ozssfxod, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);
                }

                $this->_canvas->line($Vmm2pe5l4str + $Vapguowxhnfz, $Vuua0v2znlr5, $Vmm2pe5l4str + $Vyfoeno5vtuw - $V1wjrukdrpg5, $Vuua0v2znlr5, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);

                if ($V1wjrukdrpg5 > 0) {
                    $this->_canvas->arc($Vmm2pe5l4str + $Vyfoeno5vtuw - $V1wjrukdrpg5, $Vuua0v2znlr5 - $V1wjrukdrpg5, $V1wjrukdrpg5, $V1wjrukdrpg5, 270 - $Vmp1ozssfxod, 315 + $Vmp1ozssfxod, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);
                }
                break;

            case "left":
                $Vuua0v2znlr5 += $V2pgp3ppbjsialf_width;
                $Vmm2pe5l4str += $V2pgp3ppbjsialf_width;

                if ($Vapguowxhnfz > 0) {
                    $this->_canvas->arc($Vmm2pe5l4str + $Vapguowxhnfz, $Vuua0v2znlr5 + $Vapguowxhnfz, $Vapguowxhnfz, $Vapguowxhnfz, 135 - $Vmp1ozssfxod, 180 + $Vmp1ozssfxod, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);
                }

                $this->_canvas->line($Vmm2pe5l4str, $Vuua0v2znlr5 + $Vapguowxhnfz, $Vmm2pe5l4str, $Vuua0v2znlr5 + $Vyfoeno5vtuw - $V1wjrukdrpg5, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);

                if ($V1wjrukdrpg5 > 0) {
                    $this->_canvas->arc($Vmm2pe5l4str + $V1wjrukdrpg5, $Vuua0v2znlr5 + $Vyfoeno5vtuw - $V1wjrukdrpg5, $V1wjrukdrpg5, $V1wjrukdrpg5, 180 - $Vmp1ozssfxod, 225 + $Vmp1ozssfxod, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);
                }
                break;

            case "right":
                $Vuua0v2znlr5 += $V2pgp3ppbjsialf_width;
                $Vmm2pe5l4str -= $V2pgp3ppbjsialf_width;

                if ($Vapguowxhnfz > 0) {
                    $this->_canvas->arc($Vmm2pe5l4str - $Vapguowxhnfz, $Vuua0v2znlr5 + $Vapguowxhnfz, $Vapguowxhnfz, $Vapguowxhnfz, 0 - $Vmp1ozssfxod, 45 + $Vmp1ozssfxod, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);
                }

                $this->_canvas->line($Vmm2pe5l4str, $Vuua0v2znlr5 + $Vapguowxhnfz, $Vmm2pe5l4str, $Vuua0v2znlr5 + $Vyfoeno5vtuw - $V1wjrukdrpg5, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);

                if ($V1wjrukdrpg5 > 0) {
                    $this->_canvas->arc($Vmm2pe5l4str - $V1wjrukdrpg5, $Vuua0v2znlr5 + $Vyfoeno5vtuw - $V1wjrukdrpg5, $V1wjrukdrpg5, $V1wjrukdrpg5, 315 - $Vmp1ozssfxod, 360 + $Vmp1ozssfxod, $V3poxlnogtlh, $Vtt4kvdwuqqh, $V2d1s45w0hjoattern);
                }
                break;
        }
    }

    
    protected function _set_opacity($Vhrfbgup2xix)
    {
        if (is_numeric($Vhrfbgup2xix) && $Vhrfbgup2xix <= 1.0 && $Vhrfbgup2xix >= 0.0) {
            $this->_canvas->set_opacity($Vhrfbgup2xix);
        }
    }

    
    protected function _debug_layout($Vf3vw5b20aaa, $V3poxlnogtlh = "red", $Vkvw5zjrwkdm = array())
    {
        $this->_canvas->rectangle($Vf3vw5b20aaa[0], $Vf3vw5b20aaa[1], $Vf3vw5b20aaa[2], $Vf3vw5b20aaa[3], Color::parse($V3poxlnogtlh), 0.1, $Vkvw5zjrwkdm);
    }
}
