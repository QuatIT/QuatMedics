<?php

namespace Dompdf\Renderer;

use Dompdf\Adapter\CPDF;
use Dompdf\Frame;


class Text extends AbstractRenderer
{
    
    const DECO_THICKNESS = 0.02;

    
    
    
    
    

    
    const UNDERLINE_OFFSET = 0.0;

    
    const OVERLINE_OFFSET = 0.0;

    
    const LINETHROUGH_OFFSET = 0.0;

    
    const DECO_EXTENSION = 0.0;

    
    function render(Frame $Vexjfacrc1d4)
    {
        $Vnjapcj4bkpc = $Vexjfacrc1d4->get_text();
        if (trim($Vnjapcj4bkpc) === "") {
            return;
        }

        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vexjfacrc1d4->get_position();
        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();

        if (($Vu3smia4dog2 = $Vkvw5zjrwkdm->margin_left) === "auto" || $Vu3smia4dog2 === "none") {
            $Vu3smia4dog2 = 0;
        }

        if (($Vwbyfevy1rop = $Vkvw5zjrwkdm->padding_left) === "auto" || $Vwbyfevy1rop === "none") {
            $Vwbyfevy1rop = 0;
        }

        if (($V3lmsgoqk24r = $Vkvw5zjrwkdm->border_left_width) === "auto" || $V3lmsgoqk24r === "none") {
            $V3lmsgoqk24r = 0;
        }

        $Vmm2pe5l4str += (float)$Vkvw5zjrwkdm->length_in_pt(array($Vu3smia4dog2, $Vwbyfevy1rop, $V3lmsgoqk24r), $Ve0njdrnxyyx["w"]);

        $Vfsinbbqzbga = $Vkvw5zjrwkdm->font_family;
        $Vkgj34o34uaw = $Vexjfacrc1d4_font_size = $Vkvw5zjrwkdm->font_size;
        $Vwvfvnewm3zv = $Vexjfacrc1d4->get_text_spacing() + (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->word_spacing);
        $Vymiqxxasoom = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->letter_spacing);
        $Vtt4kvdwuqqh = $Vkvw5zjrwkdm->width;

        

        $this->_canvas->text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc,
            $Vfsinbbqzbga, $Vkgj34o34uaw,
            $Vkvw5zjrwkdm->color, $Vwvfvnewm3zv, $Vymiqxxasoom);

        $V4dr003jf14h = $Vexjfacrc1d4->get_containing_line();

        
        
        if (false && $V4dr003jf14h->tallest_frame) {
            $Vwaq4l5l5nbd = $V4dr003jf14h->tallest_frame;
            $Vkvw5zjrwkdm = $Vwaq4l5l5nbd->get_style();
            $Vkgj34o34uaw = $Vkvw5zjrwkdm->font_size;
        }

        $V4dr003jf14h_thickness = $Vkgj34o34uaw * self::DECO_THICKNESS;
        $Vfrp3wthm1wi = $Vkgj34o34uaw * self::UNDERLINE_OFFSET;
        $Vc4i1ou51ngm = $Vkgj34o34uaw * self::OVERLINE_OFFSET;
        $V4dr003jf14hthrough_offset = $Vkgj34o34uaw * self::LINETHROUGH_OFFSET;
        $V4ebeyyuqnkx = -0.08;

        if ($this->_canvas instanceof CPDF) {
            $Vbmor20ms2vn = $this->_canvas->get_cpdf()->fonts[$Vkvw5zjrwkdm->font_family];

            if (isset($Vbmor20ms2vn["UnderlinePosition"])) {
                $V4ebeyyuqnkx = $Vbmor20ms2vn["UnderlinePosition"] / 1000;
            }

            if (isset($Vbmor20ms2vn["UnderlineThickness"])) {
                $V4dr003jf14h_thickness = $Vkgj34o34uaw * ($Vbmor20ms2vn["UnderlineThickness"] / 1000);
            }
        }

        $Vzwmajb1widu = $Vkgj34o34uaw * $V4ebeyyuqnkx;
        $Vavgn2zl5gq1 = $Vkgj34o34uaw;

        
        

        
        $V2d1s45w0hjo = $Vexjfacrc1d4;
        $Vo1vhygcjja1 = array();
        while ($V2d1s45w0hjo = $V2d1s45w0hjo->get_parent()) {
            $Vo1vhygcjja1[] = $V2d1s45w0hjo;
        }

        while (isset($Vo1vhygcjja1[0])) {
            $Vtmlsxxw3ne1 = array_pop($Vo1vhygcjja1);

            if (($Vnjapcj4bkpc_deco = $Vtmlsxxw3ne1->get_style()->text_decoration) === "none") {
                continue;
            }

            $Vdoxqslhh514 = $Vuua0v2znlr5; 
            $V3poxlnogtlh = $Vtmlsxxw3ne1->get_style()->color;

            switch ($Vnjapcj4bkpc_deco) {
                default:
                    continue;

                case "underline":
                    $Vdoxqslhh514 += $Vavgn2zl5gq1 - $Vzwmajb1widu + $Vfrp3wthm1wi + $V4dr003jf14h_thickness / 2;
                    break;

                case "overline":
                    $Vdoxqslhh514 += $Vc4i1ou51ngm + $V4dr003jf14h_thickness / 2;
                    break;

                case "line-through":
                    $Vdoxqslhh514 += $Vavgn2zl5gq1 * 0.7 + $V4dr003jf14hthrough_offset;
                    break;
            }

            $Vdpjnuewahqw = 0;
            $Vmm2pe5l4str1 = $Vmm2pe5l4str - self::DECO_EXTENSION;
            $Vmm2pe5l4str2 = $Vmm2pe5l4str + $Vtt4kvdwuqqh + $Vdpjnuewahqw + self::DECO_EXTENSION;
            $this->_canvas->line($Vmm2pe5l4str1, $Vdoxqslhh514, $Vmm2pe5l4str2, $Vdoxqslhh514, $V3poxlnogtlh, $V4dr003jf14h_thickness);
        }

        if ($this->_dompdf->getOptions()->getDebugLayout() && $this->_dompdf->getOptions()->getDebugLayoutLines()) {
            $Vnjapcj4bkpc_width = $this->_dompdf->getFontMetrics()->getTextWidth($Vnjapcj4bkpc, $Vfsinbbqzbga, $Vexjfacrc1d4_font_size);
            $this->_debug_layout(array($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc_width + ($V4dr003jf14h->wc - 1) * $Vwvfvnewm3zv, $Vexjfacrc1d4_font_size), "orange", array(0.5, 0.5));
        }
    }
}
