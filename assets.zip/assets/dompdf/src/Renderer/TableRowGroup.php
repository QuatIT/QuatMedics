<?php

namespace Dompdf\Renderer;

use Dompdf\Frame;


class TableRowGroup extends Block
{

    
    function render(Frame $Vexjfacrc1d4)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        $this->_set_opacity($Vexjfacrc1d4->get_opacity($Vkvw5zjrwkdm->opacity));

        $this->_render_border($Vexjfacrc1d4);
        $this->_render_outline($Vexjfacrc1d4);

        if ($this->_dompdf->getOptions()->getDebugLayout() && $this->_dompdf->getOptions()->getDebugLayoutBlocks()) {
            $this->_debug_layout($Vexjfacrc1d4->get_border_box(), "red");
            if ($this->_dompdf->getOptions()->getDebugLayoutPaddingBox()) {
                $this->_debug_layout($Vexjfacrc1d4->get_padding_box(), "red", array(0.5, 0.5));
            }
        }

        if ($this->_dompdf->getOptions()->getDebugLayout() && $this->_dompdf->getOptions()->getDebugLayoutLines() && $Vexjfacrc1d4->get_decorator()) {
            foreach ($Vexjfacrc1d4->get_decorator()->get_line_boxes() as $V4dr003jf14h) {
                $Vexjfacrc1d4->_debug_layout(array($V4dr003jf14h->x, $V4dr003jf14h->y, $V4dr003jf14h->w, $V4dr003jf14h->h), "orange");
            }
        }

        $Vawfntrfsy4f = $Vexjfacrc1d4->get_node()->getAttribute("id");
        if (strlen($Vawfntrfsy4f) > 0)  {
            $this->_canvas->add_named_dest($Vawfntrfsy4f);
        }
    }
}
