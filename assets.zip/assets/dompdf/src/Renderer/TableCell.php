<?php

namespace Dompdf\Renderer;

use Dompdf\Frame;
use Dompdf\FrameDecorator\Table;


class TableCell extends Block
{

    
    function render(Frame $Vexjfacrc1d4)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        if (trim($Vexjfacrc1d4->get_node()->nodeValue) === "" && $Vkvw5zjrwkdm->empty_cells === "hide") {
            return;
        }

        $this->_set_opacity($Vexjfacrc1d4->get_opacity($Vkvw5zjrwkdm->opacity));
        list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vexjfacrc1d4->get_border_box();

        
        if (($Vjpvoh1mwpv2 = $Vkvw5zjrwkdm->background_color) !== "transparent") {
            $this->_canvas->filled_rectangle($Vmm2pe5l4str, $Vuua0v2znlr5, (float)$V5ymvwogwh5y, (float)$V2pgp3ppbjsi, $Vjpvoh1mwpv2);
        }

        if (($Vop22rgf5euu = $Vkvw5zjrwkdm->background_image) && $Vop22rgf5euu !== "none") {
            $this->_background_image($Vop22rgf5euu, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vkvw5zjrwkdm);
        }

        $Vp5rpvpxnb43 = Table::find_parent_table($Vexjfacrc1d4);

        if ($Vp5rpvpxnb43->get_style()->border_collapse !== "collapse") {
            $this->_render_border($Vexjfacrc1d4);
            $this->_render_outline($Vexjfacrc1d4);
            return;
        }

        
        

        $V5hlwkutan5t = $Vp5rpvpxnb43->get_cellmap();
        $Vpnyh0054enj = $V5hlwkutan5t->get_spanned_cells($Vexjfacrc1d4);

        if (is_null($Vpnyh0054enj)) {
            return;
        }

        $Vgo25rmzptcl = $V5hlwkutan5t->get_num_rows();
        $Vejser2qukeu = $V5hlwkutan5t->get_num_cols();

        
        $V0ixz2v5mxzy = $Vpnyh0054enj["rows"][0];
        $Vt5cnnjqpsvf = $V5hlwkutan5t->get_row($V0ixz2v5mxzy);

        
        
        
        if (in_array($Vgo25rmzptcl - 1, $Vpnyh0054enj["rows"])) {
            $V0gnkykws0zd = true;
            $Vgot5o4dznv4 = $V5hlwkutan5t->get_row($Vgo25rmzptcl - 1);
        } else {
            $V0gnkykws0zd = false;
        }

        
        foreach ($Vpnyh0054enj["columns"] as $Vy4wtqjehnh5) {
            $Vjbw5irva2if = $V5hlwkutan5t->get_border_properties($V0ixz2v5mxzy, $Vy4wtqjehnh5);

            $Vuua0v2znlr5 = $Vt5cnnjqpsvf["y"] - $Vjbw5irva2if["top"]["width"] / 2;

            $Vqpgfq33o1wo = $V5hlwkutan5t->get_column($Vy4wtqjehnh5);
            $Vmm2pe5l4str = $Vqpgfq33o1wo["x"] - $Vjbw5irva2if["left"]["width"] / 2;
            $V5ymvwogwh5y = $Vqpgfq33o1wo["used-width"] + ($Vjbw5irva2if["left"]["width"] + $Vjbw5irva2if["right"]["width"]) / 2;

            if ($Vjbw5irva2if["top"]["style"] !== "none" && $Vjbw5irva2if["top"]["width"] > 0) {
                $V5ymvwogwh5yidths = array(
                    (float)$Vjbw5irva2if["top"]["width"],
                    (float)$Vjbw5irva2if["right"]["width"],
                    (float)$Vjbw5irva2if["bottom"]["width"],
                    (float)$Vjbw5irva2if["left"]["width"]
                );
                $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["top"]["style"];
                $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $Vjbw5irva2if["top"]["color"], $V5ymvwogwh5yidths, "top", "square");
            }

            if ($V0gnkykws0zd) {
                $Vjbw5irva2if = $V5hlwkutan5t->get_border_properties($Vgo25rmzptcl - 1, $Vy4wtqjehnh5);
                if ($Vjbw5irva2if["bottom"]["style"] === "none" || $Vjbw5irva2if["bottom"]["width"] <= 0) {
                    continue;
                }

                $Vuua0v2znlr5 = $Vgot5o4dznv4["y"] + $Vgot5o4dznv4["height"] + $Vjbw5irva2if["bottom"]["width"] / 2;

                $V5ymvwogwh5yidths = array(
                    (float)$Vjbw5irva2if["top"]["width"],
                    (float)$Vjbw5irva2if["right"]["width"],
                    (float)$Vjbw5irva2if["bottom"]["width"],
                    (float)$Vjbw5irva2if["left"]["width"]
                );
                $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["bottom"]["style"];
                $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $Vjbw5irva2if["bottom"]["color"], $V5ymvwogwh5yidths, "bottom", "square");

            }
        }

        $Vy4wtqjehnh5 = $Vpnyh0054enj["columns"][0];

        $Vinot3uneoxu = $V5hlwkutan5t->get_column($Vy4wtqjehnh5);

        if (in_array($Vejser2qukeu - 1, $Vpnyh0054enj["columns"])) {
            $Vn0vba04rebw = true;
            $Vub1nvvlk0ow = $V5hlwkutan5t->get_column($Vejser2qukeu - 1);
        } else {
            $Vn0vba04rebw = false;
        }

        
        foreach ($Vpnyh0054enj["rows"] as $V0ixz2v5mxzy) {
            $Vjbw5irva2if = $V5hlwkutan5t->get_border_properties($V0ixz2v5mxzy, $Vy4wtqjehnh5);

            $Vmm2pe5l4str = $Vinot3uneoxu["x"] - $Vjbw5irva2if["left"]["width"] / 2;

            $Vcqwpvcjcqxw = $V5hlwkutan5t->get_row($V0ixz2v5mxzy);

            $Vuua0v2znlr5 = $Vcqwpvcjcqxw["y"] - $Vjbw5irva2if["top"]["width"] / 2;
            $V2pgp3ppbjsi = $Vcqwpvcjcqxw["height"] + ($Vjbw5irva2if["top"]["width"] + $Vjbw5irva2if["bottom"]["width"]) / 2;

            if ($Vjbw5irva2if["left"]["style"] !== "none" && $Vjbw5irva2if["left"]["width"] > 0) {
                $V5ymvwogwh5yidths = array(
                    (float)$Vjbw5irva2if["top"]["width"],
                    (float)$Vjbw5irva2if["right"]["width"],
                    (float)$Vjbw5irva2if["bottom"]["width"],
                    (float)$Vjbw5irva2if["left"]["width"]
                );

                $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["left"]["style"];
                $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $V2pgp3ppbjsi, $Vjbw5irva2if["left"]["color"], $V5ymvwogwh5yidths, "left", "square");
            }

            if ($Vn0vba04rebw) {
                $Vjbw5irva2if = $V5hlwkutan5t->get_border_properties($V0ixz2v5mxzy, $Vejser2qukeu - 1);
                if ($Vjbw5irva2if["right"]["style"] === "none" || $Vjbw5irva2if["right"]["width"] <= 0) {
                    continue;
                }

                $Vmm2pe5l4str = $Vub1nvvlk0ow["x"] + $Vub1nvvlk0ow["used-width"] + $Vjbw5irva2if["right"]["width"] / 2;

                $V5ymvwogwh5yidths = array(
                    (float)$Vjbw5irva2if["top"]["width"],
                    (float)$Vjbw5irva2if["right"]["width"],
                    (float)$Vjbw5irva2if["bottom"]["width"],
                    (float)$Vjbw5irva2if["left"]["width"]
                );

                $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["right"]["style"];
                $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $V2pgp3ppbjsi, $Vjbw5irva2if["right"]["color"], $V5ymvwogwh5yidths, "right", "square");
            }
        }

        $V0ixz2v5mxzyd = $Vexjfacrc1d4->get_node()->getAttribute("id");
        if (strlen($V0ixz2v5mxzyd) > 0)  {
            $this->_canvas->add_named_dest($V0ixz2v5mxzyd);
        }
    }
}
