<?php

namespace Dompdf\Renderer;

use Dompdf\Frame;
use Dompdf\Helpers;


class Inline extends AbstractRenderer
{

    
    function render(Frame $Vexjfacrc1d4)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        if (!$Vexjfacrc1d4->get_first_child()) {
            return; 
        }

        
        $Vjbw5irva2if = $Vkvw5zjrwkdm->get_border_properties();
        $Vo42arrulsgp = array(
            (float)$Vkvw5zjrwkdm->length_in_pt($Vjbw5irva2if["top"]["width"]),
            (float)$Vkvw5zjrwkdm->length_in_pt($Vjbw5irva2if["right"]["width"]),
            (float)$Vkvw5zjrwkdm->length_in_pt($Vjbw5irva2if["bottom"]["width"]),
            (float)$Vkvw5zjrwkdm->length_in_pt($Vjbw5irva2if["left"]["width"])
        );

        
        
        list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vexjfacrc1d4->get_first_child()->get_position();
        $V5ymvwogwh5y = null;
        $V2pgp3ppbjsi = 0;
        
        

        $this->_set_opacity($Vexjfacrc1d4->get_opacity($Vkvw5zjrwkdm->opacity));

        $Vhmgwkusoojt = true;

        $Vm4k3jvsdcna = $this->_dompdf->getOptions()->getDebugLayout() && $this->_dompdf->getOptions()->getDebugLayoutInline();

        foreach ($Vexjfacrc1d4->get_children() as $V0mqc4rbglqu) {
            list($V0mqc4rbglqu_x, $V0mqc4rbglqu_y, $V0mqc4rbglqu_w, $V0mqc4rbglqu_h) = $V0mqc4rbglqu->get_padding_box();

            if (!is_null($V5ymvwogwh5y) && $V0mqc4rbglqu_x < $Vmm2pe5l4str + $V5ymvwogwh5y) {
                
                
                
                
                

                
                

                
                if (($Vjpvoh1mwpv2 = $Vkvw5zjrwkdm->background_color) !== "transparent") {
                    $this->_canvas->filled_rectangle($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vjpvoh1mwpv2);
                }

                if (($Vop22rgf5euu = $Vkvw5zjrwkdm->background_image) && $Vop22rgf5euu !== "none") {
                    $this->_background_image($Vop22rgf5euu, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vkvw5zjrwkdm);
                }

                
                if ($Vhmgwkusoojt) {
                    if ($Vjbw5irva2if["left"]["style"] !== "none" && $Vjbw5irva2if["left"]["color"] !== "transparent" && $Vjbw5irva2if["left"]["width"] > 0) {
                        $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["left"]["style"];
                        $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $V2pgp3ppbjsi + $Vo42arrulsgp[0] + $Vo42arrulsgp[2], $Vjbw5irva2if["left"]["color"], $Vo42arrulsgp, "left");
                    }
                    $Vhmgwkusoojt = false;
                }

                
                if ($Vjbw5irva2if["top"]["style"] !== "none" && $Vjbw5irva2if["top"]["color"] !== "transparent" && $Vjbw5irva2if["top"]["width"] > 0) {
                    $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["top"]["style"];
                    $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y + $Vo42arrulsgp[1] + $Vo42arrulsgp[3], $Vjbw5irva2if["top"]["color"], $Vo42arrulsgp, "top");
                }

                if ($Vjbw5irva2if["bottom"]["style"] !== "none" && $Vjbw5irva2if["bottom"]["color"] !== "transparent" && $Vjbw5irva2if["bottom"]["width"] > 0) {
                    $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["bottom"]["style"];
                    $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5 + $V2pgp3ppbjsi + $Vo42arrulsgp[0] + $Vo42arrulsgp[2], $V5ymvwogwh5y + $Vo42arrulsgp[1] + $Vo42arrulsgp[3], $Vjbw5irva2if["bottom"]["color"], $Vo42arrulsgp, "bottom");
                }

                
                $Vxi1zcttpbsx = null;
                if ($Vexjfacrc1d4->get_node()->nodeName === "a") {
                    $Vxi1zcttpbsx = $Vexjfacrc1d4->get_node();
                } else if ($Vexjfacrc1d4->get_parent()->get_node()->nodeName === "a") {
                    $Vxi1zcttpbsx = $Vexjfacrc1d4->get_parent()->get_node();
                }

                if ($Vxi1zcttpbsx && $V2pgp3ppbjsiref = $Vxi1zcttpbsx->getAttribute("href")) {
                    $V2pgp3ppbjsiref = Helpers::build_url($this->_dompdf->getProtocol(), $this->_dompdf->getBaseHost(), $this->_dompdf->getBasePath(), $V2pgp3ppbjsiref);
                    $this->_canvas->add_link($V2pgp3ppbjsiref, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
                }

                $Vmm2pe5l4str = $V0mqc4rbglqu_x;
                $Vuua0v2znlr5 = $V0mqc4rbglqu_y;
                $V5ymvwogwh5y = (float)$V0mqc4rbglqu_w;
                $V2pgp3ppbjsi = (float)$V0mqc4rbglqu_h;
                continue;
            }

            if (is_null($V5ymvwogwh5y)) {
                $V5ymvwogwh5y = (float)$V0mqc4rbglqu_w;
            }else {
                $V5ymvwogwh5y += (float)$V0mqc4rbglqu_w;
            }

            $V2pgp3ppbjsi = max($V2pgp3ppbjsi, $V0mqc4rbglqu_h);

            if ($Vm4k3jvsdcna) {
                $this->_debug_layout($V0mqc4rbglqu->get_border_box(), "blue");
                if ($this->_dompdf->getOptions()->getDebugLayoutPaddingBox()) {
                    $this->_debug_layout($V0mqc4rbglqu->get_padding_box(), "blue", array(0.5, 0.5));
                }
            }
        }

        
        if (($Vjpvoh1mwpv2 = $Vkvw5zjrwkdm->background_color) !== "transparent") {
            $this->_canvas->filled_rectangle($Vmm2pe5l4str + $Vo42arrulsgp[3], $Vuua0v2znlr5 + $Vo42arrulsgp[0], $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vjpvoh1mwpv2);
        }

        
        
        
        
        
        
        
        
        if (($Vop22rgf5euu = $Vkvw5zjrwkdm->background_image) && $Vop22rgf5euu !== "none") {
            $this->_background_image($Vop22rgf5euu, $Vmm2pe5l4str + $Vo42arrulsgp[3], $Vuua0v2znlr5 + $Vo42arrulsgp[0], $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vkvw5zjrwkdm);
        }

        
        $V5ymvwogwh5y += (float)$Vo42arrulsgp[1] + (float)$Vo42arrulsgp[3];
        $V2pgp3ppbjsi += (float)$Vo42arrulsgp[0] + (float)$Vo42arrulsgp[2];

        
        $Vxs3xmar5nyt = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_left);
        $Vmm2pe5l4str += $Vxs3xmar5nyt;

        
        if ($Vhmgwkusoojt && $Vjbw5irva2if["left"]["style"] !== "none" && $Vjbw5irva2if["left"]["color"] !== "transparent" && $Vo42arrulsgp[3] > 0) {
            $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["left"]["style"];
            $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $V2pgp3ppbjsi, $Vjbw5irva2if["left"]["color"], $Vo42arrulsgp, "left");
        }

        
        if ($Vjbw5irva2if["top"]["style"] !== "none" && $Vjbw5irva2if["top"]["color"] !== "transparent" && $Vo42arrulsgp[0] > 0) {
            $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["top"]["style"];
            $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $Vjbw5irva2if["top"]["color"], $Vo42arrulsgp, "top");
        }

        if ($Vjbw5irva2if["bottom"]["style"] !== "none" && $Vjbw5irva2if["bottom"]["color"] !== "transparent" && $Vo42arrulsgp[2] > 0) {
            $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["bottom"]["style"];
            $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5 + $V2pgp3ppbjsi, $V5ymvwogwh5y, $Vjbw5irva2if["bottom"]["color"], $Vo42arrulsgp, "bottom");
        }

        
        
        
        if ($Vjbw5irva2if["right"]["style"] !== "none" && $Vjbw5irva2if["right"]["color"] !== "transparent" && $Vo42arrulsgp[1] > 0) {
            $Vbj2tc0fvhny = "_border_" . $Vjbw5irva2if["right"]["style"];
            $this->$Vbj2tc0fvhny($Vmm2pe5l4str + $V5ymvwogwh5y, $Vuua0v2znlr5, $V2pgp3ppbjsi, $Vjbw5irva2if["right"]["color"], $Vo42arrulsgp, "right");
        }

        $Vawfntrfsy4f = $Vexjfacrc1d4->get_node()->getAttribute("id");
        if (strlen($Vawfntrfsy4f) > 0)  {
            $this->_canvas->add_named_dest($Vawfntrfsy4f);
        }

        
        $Vxi1zcttpbsx = null;
        if ($Vexjfacrc1d4->get_node()->nodeName === "a") {
            $Vxi1zcttpbsx = $Vexjfacrc1d4->get_node();

            if (($Vreuchxnm2nm = $Vxi1zcttpbsx->getAttribute("name"))) {
                $this->_canvas->add_named_dest($Vreuchxnm2nm);
            }
        }

        if ($Vexjfacrc1d4->get_parent() && $Vexjfacrc1d4->get_parent()->get_node()->nodeName === "a") {
            $Vxi1zcttpbsx = $Vexjfacrc1d4->get_parent()->get_node();
        }

        
        if ($Vxi1zcttpbsx) {
            if ($V2pgp3ppbjsiref = $Vxi1zcttpbsx->getAttribute("href")) {
                $V2pgp3ppbjsiref = Helpers::build_url($this->_dompdf->getProtocol(), $this->_dompdf->getBaseHost(), $this->_dompdf->getBasePath(), $V2pgp3ppbjsiref);
                $this->_canvas->add_link($V2pgp3ppbjsiref, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
            }
        }
    }
}
