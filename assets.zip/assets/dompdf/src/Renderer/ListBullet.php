<?php

namespace Dompdf\Renderer;

use Dompdf\Helpers;
use Dompdf\Frame;
use Dompdf\Image\Cache;
use Dompdf\FrameDecorator\ListBullet as ListBulletFrameDecorator;


class ListBullet extends AbstractRenderer
{
    
    static function get_counter_chars($Vky1xzjrvbn4)
    {
        static $Vpqxygdkkwnh = array();

        if (isset($Vpqxygdkkwnh[$Vky1xzjrvbn4])) {
            return $Vpqxygdkkwnh[$Vky1xzjrvbn4];
        }

        $Vnazuscy2smz = false;
        $Vnjapcj4bkpc = "";

        switch ($Vky1xzjrvbn4) {
            case "decimal-leading-zero":
            case "decimal":
            case "1":
                return "0123456789";

            case "upper-alpha":
            case "upper-latin":
            case "A":
                $Vnazuscy2smz = true;
            case "lower-alpha":
            case "lower-latin":
            case "a":
                $Vnjapcj4bkpc = "abcdefghijklmnopqrstuvwxyz";
                break;

            case "upper-roman":
            case "I":
                $Vnazuscy2smz = true;
            case "lower-roman":
            case "i":
                $Vnjapcj4bkpc = "ivxlcdm";
                break;

            case "lower-greek":
                for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < 24; $V0ixz2v5mxzy++) {
                    $Vnjapcj4bkpc .= Helpers::unichr($V0ixz2v5mxzy + 944);
                }
                break;
        }

        if ($Vnazuscy2smz) {
            $Vnjapcj4bkpc = strtoupper($Vnjapcj4bkpc);
        }

        return $Vpqxygdkkwnh[$Vky1xzjrvbn4] = "$Vnjapcj4bkpc.";
    }

    
    private function make_counter($Vu440l53e414, $Vky1xzjrvbn4, $Viwtkcmztr2m = null)
    {
        $Vu440l53e414 = intval($Vu440l53e414);
        $Vnjapcj4bkpc = "";
        $Vnazuscy2smz = false;

        switch ($Vky1xzjrvbn4) {
            case "decimal-leading-zero":
            case "decimal":
            case "1":
                if ($Viwtkcmztr2m) {
                    $Vnjapcj4bkpc = str_pad($Vu440l53e414, $Viwtkcmztr2m, "0", STR_PAD_LEFT);
                } else {
                    $Vnjapcj4bkpc = $Vu440l53e414;
                }
                break;

            case "upper-alpha":
            case "upper-latin":
            case "A":
                $Vnazuscy2smz = true;
            case "lower-alpha":
            case "lower-latin":
            case "a":
                $Vnjapcj4bkpc = chr(($Vu440l53e414 % 26) + ord('a') - 1);
                break;

            case "upper-roman":
            case "I":
                $Vnazuscy2smz = true;
            case "lower-roman":
            case "i":
                $Vnjapcj4bkpc = Helpers::dec2roman($Vu440l53e414);
                break;

            case "lower-greek":
                $Vnjapcj4bkpc = Helpers::unichr($Vu440l53e414 + 944);
                break;
        }

        if ($Vnazuscy2smz) {
            $Vnjapcj4bkpc = strtoupper($Vnjapcj4bkpc);
        }

        return "$Vnjapcj4bkpc.";
    }

    
    function render(Frame $Vexjfacrc1d4)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Va2yzrxh4s3e = $Vkvw5zjrwkdm->get_font_size();
        $Vpoaseiviesy = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->line_height, $Vexjfacrc1d4->get_containing_block("h"));

        $this->_set_opacity($Vexjfacrc1d4->get_opacity($Vkvw5zjrwkdm->opacity));

        $V3dm2ztdjmvw = $Vexjfacrc1d4->get_parent();

        
        if ($V3dm2ztdjmvw->_splitted) {
            return;
        }

        
        
        if ($Vkvw5zjrwkdm->list_style_image !== "none" && !Cache::is_broken($V0ixz2v5mxzymg = $Vexjfacrc1d4->get_image_url())) {
            list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vexjfacrc1d4->get_position();

            
            
            
            
            
            
            list($Vtt4kvdwuqqh, $Vxtfrabd3i5r) = Helpers::dompdf_getimagesize($V0ixz2v5mxzymg, $this->_dompdf->getHttpContext());
            $Vfwb1n1yh3ll = $this->_dompdf->getOptions()->getDpi();
            $V5ymvwogwh5y = ((float)rtrim($Vtt4kvdwuqqh, "px") * 72) / $Vfwb1n1yh3ll;
            $V2pgp3ppbjsi = ((float)rtrim($Vxtfrabd3i5r, "px") * 72) / $Vfwb1n1yh3ll;

            $Vmm2pe5l4str -= $V5ymvwogwh5y;
            $Vuua0v2znlr5 -= ($Vpoaseiviesy - $Va2yzrxh4s3e) / 2; 

            $this->_canvas->image($V0ixz2v5mxzymg, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        } else {
            $V4dqdouks44l = $Vkvw5zjrwkdm->list_style_type;

            $Vbopclc0ksnj = false;

            switch ($V4dqdouks44l) {
                default:
                
                case "disc":
                    $Vbopclc0ksnj = true;

                case "circle":
                    list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vexjfacrc1d4->get_position();
                    $Vapkwgsb3w3r = ($Va2yzrxh4s3e * (ListBulletFrameDecorator::BULLET_SIZE )) / 2;
                    $Vmm2pe5l4str -= $Va2yzrxh4s3e * (ListBulletFrameDecorator::BULLET_SIZE / 2);
                    $Vuua0v2znlr5 += ($Va2yzrxh4s3e * (1 - ListBulletFrameDecorator::BULLET_DESCENT)) / 2;
                    $Vyea2e2tvrvz = $Va2yzrxh4s3e * ListBulletFrameDecorator::BULLET_THICKNESS;
                    $this->_canvas->circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vapkwgsb3w3r, $Vkvw5zjrwkdm->color, $Vyea2e2tvrvz, null, $Vbopclc0ksnj);
                    break;

                case "square":
                    list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vexjfacrc1d4->get_position();
                    $V5ymvwogwh5y = $Va2yzrxh4s3e * ListBulletFrameDecorator::BULLET_SIZE;
                    $Vmm2pe5l4str -= $V5ymvwogwh5y;
                    $Vuua0v2znlr5 += ($Va2yzrxh4s3e * (1 - ListBulletFrameDecorator::BULLET_DESCENT - ListBulletFrameDecorator::BULLET_SIZE)) / 2;
                    $this->_canvas->filled_rectangle($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V5ymvwogwh5y, $Vkvw5zjrwkdm->color);
                    break;

                case "decimal-leading-zero":
                case "decimal":
                case "lower-alpha":
                case "lower-latin":
                case "lower-roman":
                case "lower-greek":
                case "upper-alpha":
                case "upper-latin":
                case "upper-roman":
                case "1": 
                case "a":
                case "i":
                case "A":
                case "I":
                    $Viwtkcmztr2m = null;
                    if ($V4dqdouks44l === "decimal-leading-zero") {
                        $Viwtkcmztr2m = strlen($V3dm2ztdjmvw->get_parent()->get_node()->getAttribute("dompdf-children-count"));
                    }

                    $Vu440l53e414ode = $Vexjfacrc1d4->get_node();

                    if (!$Vu440l53e414ode->hasAttribute("dompdf-counter")) {
                        return;
                    }

                    $V0ixz2v5mxzyndex = $Vu440l53e414ode->getAttribute("dompdf-counter");
                    $Vnjapcj4bkpc = $this->make_counter($V0ixz2v5mxzyndex, $V4dqdouks44l, $Viwtkcmztr2m);

                    if (trim($Vnjapcj4bkpc) == "") {
                        return;
                    }

                    $Vd1hiq0tzl4w = 0;
                    $Vsljiaepvcft = $Vkvw5zjrwkdm->font_family;

                    $V3dm2ztdjmvwne = $V3dm2ztdjmvw->get_containing_line();
                    list($Vmm2pe5l4str, $Vuua0v2znlr5) = array($Vexjfacrc1d4->get_position("x"), $V3dm2ztdjmvwne->y);

                    $Vmm2pe5l4str -= $this->_dompdf->getFontMetrics()->getTextWidth($Vnjapcj4bkpc, $Vsljiaepvcft, $Va2yzrxh4s3e, $Vd1hiq0tzl4w);

                    
                    $Vpoaseiviesy = $Vkvw5zjrwkdm->line_height;
                    $Vuua0v2znlr5 += ($Vpoaseiviesy - $Va2yzrxh4s3e) / 4; 

                    $this->_canvas->text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc,
                        $Vsljiaepvcft, $Va2yzrxh4s3e,
                        $Vkvw5zjrwkdm->color, $Vd1hiq0tzl4w);

                case "none":
                    break;
            }
        }

        $V0ixz2v5mxzyd = $Vexjfacrc1d4->get_node()->getAttribute("id");
        if (strlen($V0ixz2v5mxzyd) > 0)  {
            $this->_canvas->add_named_dest($V0ixz2v5mxzyd);
        }
    }
}
