<?php

namespace Dompdf\Renderer;

use Dompdf\Frame;
use Dompdf\FrameDecorator\AbstractFrameDecorator;
use Dompdf\Helpers;


class Block extends AbstractRenderer
{

    
    function render(Frame $Vexjfacrc1d4)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Vivp5mmrkfpz = $Vexjfacrc1d4->get_node();

        list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vexjfacrc1d4->get_border_box();

        $this->_set_opacity($Vexjfacrc1d4->get_opacity($Vkvw5zjrwkdm->opacity));

        if ($Vivp5mmrkfpz->nodeName === "body") {
            $V2pgp3ppbjsi = $Vexjfacrc1d4->get_containing_block("h") - (float)$Vkvw5zjrwkdm->length_in_pt(array(
                        $Vkvw5zjrwkdm->margin_top,
                        $Vkvw5zjrwkdm->border_top_width,
                        $Vkvw5zjrwkdm->border_bottom_width,
                        $Vkvw5zjrwkdm->margin_bottom),
                    (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->width));
        }

        
        if ($Vivp5mmrkfpz->nodeName === "a" && $V2pgp3ppbjsiref = $Vivp5mmrkfpz->getAttribute("href")) {
            $V2pgp3ppbjsiref = Helpers::build_url($this->_dompdf->getProtocol(), $this->_dompdf->getBaseHost(), $this->_dompdf->getBasePath(), $V2pgp3ppbjsiref);
            $this->_canvas->add_link($V2pgp3ppbjsiref, $Vmm2pe5l4str, $Vuua0v2znlr5, (float)$V5ymvwogwh5y, (float)$V2pgp3ppbjsi);
        }

        
        list($Veltemnghp05, $Vkfno1tgq5nc, $Vbwp1e1ru2dj, $V3lmsgoqk24r) = $Vkvw5zjrwkdm->get_computed_border_radius($V5ymvwogwh5y, $V2pgp3ppbjsi);

        if ($Veltemnghp05 + $Vkfno1tgq5nc + $Vbwp1e1ru2dj + $V3lmsgoqk24r > 0) {
            $this->_canvas->clipping_roundrectangle($Vmm2pe5l4str, $Vuua0v2znlr5, (float)$V5ymvwogwh5y, (float)$V2pgp3ppbjsi, $Veltemnghp05, $Vkfno1tgq5nc, $Vbwp1e1ru2dj, $V3lmsgoqk24r);
        }

        if (($Vjpvoh1mwpv2 = $Vkvw5zjrwkdm->background_color) !== "transparent") {
            $this->_canvas->filled_rectangle($Vmm2pe5l4str, $Vuua0v2znlr5, (float)$V5ymvwogwh5y, (float)$V2pgp3ppbjsi, $Vjpvoh1mwpv2);
        }

        if (($Vop22rgf5euu = $Vkvw5zjrwkdm->background_image) && $Vop22rgf5euu !== "none") {
            $this->_background_image($Vop22rgf5euu, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vkvw5zjrwkdm);
        }

        if ($Veltemnghp05 + $Vkfno1tgq5nc + $Vbwp1e1ru2dj + $V3lmsgoqk24r > 0) {
            $this->_canvas->clipping_end();
        }

        $Vameiikrqx2v = array($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        $this->_render_border($Vexjfacrc1d4, $Vameiikrqx2v);
        $this->_render_outline($Vexjfacrc1d4, $Vameiikrqx2v);

        if ($this->_dompdf->getOptions()->getDebugLayout() && $this->_dompdf->getOptions()->getDebugLayoutBlocks()) {
            $this->_debug_layout($Vexjfacrc1d4->get_border_box(), "red");
            if ($this->_dompdf->getOptions()->getDebugLayoutPaddingBox()) {
                $this->_debug_layout($Vexjfacrc1d4->get_padding_box(), "red", array(0.5, 0.5));
            }
        }

        if ($this->_dompdf->getOptions()->getDebugLayout() && $this->_dompdf->getOptions()->getDebugLayoutLines() && $Vexjfacrc1d4->get_decorator()) {
            foreach ($Vexjfacrc1d4->get_decorator()->get_line_boxes() as $V4dr003jf14h) {
                $Vexjfacrc1d4->_debug_layout(array($V4dr003jf14h->x, $V4dr003jf14h->y, $V4dr003jf14h->w, $V4dr003jf14h->h), "orange");
            }
        }

        $Vawfntrfsy4f = $Vexjfacrc1d4->get_node()->getAttribute("id");
        if (strlen($Vawfntrfsy4f) > 0)  {
            $this->_canvas->add_named_dest($Vawfntrfsy4f);
        }
    }

    
    protected function _render_border(AbstractFrameDecorator $Vexjfacrc1d4, $Vameiikrqx2v = null, $Vvjvaevwt31l = "bevel")
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Vjbw5irva2if = $Vkvw5zjrwkdm->get_border_properties();

        if (empty($Vameiikrqx2v)) {
            $Vameiikrqx2v = $Vexjfacrc1d4->get_border_box();
        }

        
        $Vc4ozih12zue = $Vkvw5zjrwkdm->get_computed_border_radius($Vameiikrqx2v[2], $Vameiikrqx2v[3]); 

        
        if (
            in_array($Vjbw5irva2if["top"]["style"], array("solid", "dashed", "dotted")) &&
            $Vjbw5irva2if["top"] == $Vjbw5irva2if["right"] &&
            $Vjbw5irva2if["right"] == $Vjbw5irva2if["bottom"] &&
            $Vjbw5irva2if["bottom"] == $Vjbw5irva2if["left"] &&
            array_sum($Vc4ozih12zue) == 0
        ) {
            $Vbgj2xsenowe = $Vjbw5irva2if["top"];
            if ($Vbgj2xsenowe["color"] === "transparent" || $Vbgj2xsenowe["width"] <= 0) {
                return;
            }

            list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vameiikrqx2v;
            $V5ymvwogwh5yidth = (float)$Vkvw5zjrwkdm->length_in_pt($Vbgj2xsenowe["width"]);
            $V2apyt5442as = $this->_get_dash_pattern($Vbgj2xsenowe["style"], $V5ymvwogwh5yidth);
            $this->_canvas->rectangle($Vmm2pe5l4str + $V5ymvwogwh5yidth / 2, $Vuua0v2znlr5 + $V5ymvwogwh5yidth / 2, (float)$V5ymvwogwh5y - $V5ymvwogwh5yidth, (float)$V2pgp3ppbjsi - $V5ymvwogwh5yidth, $Vbgj2xsenowe["color"], $V5ymvwogwh5yidth, $V2apyt5442as);
            return;
        }

        
        $V5ymvwogwh5yidths = array(
            (float)$Vkvw5zjrwkdm->length_in_pt($Vjbw5irva2if["top"]["width"]),
            (float)$Vkvw5zjrwkdm->length_in_pt($Vjbw5irva2if["right"]["width"]),
            (float)$Vkvw5zjrwkdm->length_in_pt($Vjbw5irva2if["bottom"]["width"]),
            (float)$Vkvw5zjrwkdm->length_in_pt($Vjbw5irva2if["left"]["width"])
        );

        foreach ($Vjbw5irva2if as $Vcxi3be0s51c => $Vbgj2xsenowe) {
            list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vameiikrqx2v;
            $Vyfoeno5vtuw = 0;
            $Vapguowxhnfz = 0;
            $V1wjrukdrpg5 = 0;

            if (!$Vbgj2xsenowe["style"] ||
                $Vbgj2xsenowe["style"] === "none" ||
                $Vbgj2xsenowe["width"] <= 0 ||
                $Vbgj2xsenowe["color"] == "transparent"
            ) {
                continue;
            }

            switch ($Vcxi3be0s51c) {
                case "top":
                    $Vyfoeno5vtuw = (float)$V5ymvwogwh5y;
                    $Vapguowxhnfz = $Vc4ozih12zue["top-left"];
                    $V1wjrukdrpg5 = $Vc4ozih12zue["top-right"];
                    break;

                case "bottom":
                    $Vyfoeno5vtuw = (float)$V5ymvwogwh5y;
                    $Vuua0v2znlr5 += (float)$V2pgp3ppbjsi;
                    $Vapguowxhnfz = $Vc4ozih12zue["bottom-left"];
                    $V1wjrukdrpg5 = $Vc4ozih12zue["bottom-right"];
                    break;

                case "left":
                    $Vyfoeno5vtuw = (float)$V2pgp3ppbjsi;
                    $Vapguowxhnfz = $Vc4ozih12zue["top-left"];
                    $V1wjrukdrpg5 = $Vc4ozih12zue["bottom-left"];
                    break;

                case "right":
                    $Vyfoeno5vtuw = (float)$V2pgp3ppbjsi;
                    $Vmm2pe5l4str += (float)$V5ymvwogwh5y;
                    $Vapguowxhnfz = $Vc4ozih12zue["top-right"];
                    $V1wjrukdrpg5 = $Vc4ozih12zue["bottom-right"];
                    break;
                default:
                    break;
            }
            $Vbj2tc0fvhny = "_border_" . $Vbgj2xsenowe["style"];

            
            $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $Vbgj2xsenowe["color"], $V5ymvwogwh5yidths, $Vcxi3be0s51c, $Vvjvaevwt31l, $Vapguowxhnfz, $V1wjrukdrpg5);
        }
    }

    
    protected function _render_outline(AbstractFrameDecorator $Vexjfacrc1d4, $Vameiikrqx2v = null, $Vvjvaevwt31l = "bevel")
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        $Vbgj2xsenowe = array(
            "width" => $Vkvw5zjrwkdm->outline_width,
            "style" => $Vkvw5zjrwkdm->outline_style,
            "color" => $Vkvw5zjrwkdm->outline_color,
        );

        if (!$Vbgj2xsenowe["style"] || $Vbgj2xsenowe["style"] === "none" || $Vbgj2xsenowe["width"] <= 0) {
            return;
        }

        if (empty($Vameiikrqx2v)) {
            $Vameiikrqx2v = $Vexjfacrc1d4->get_border_box();
        }

        $Veatxxxrhqpk = (float)$Vkvw5zjrwkdm->length_in_pt($Vbgj2xsenowe["width"]);
        $V2apyt5442as = $this->_get_dash_pattern($Vbgj2xsenowe["style"], $Veatxxxrhqpk);

        
        if (in_array($Vbgj2xsenowe["style"], array("solid", "dashed", "dotted"))) {
            $Vameiikrqx2v[0] -= $Veatxxxrhqpk / 2;
            $Vameiikrqx2v[1] -= $Veatxxxrhqpk / 2;
            $Vameiikrqx2v[2] += $Veatxxxrhqpk;
            $Vameiikrqx2v[3] += $Veatxxxrhqpk;

            list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vameiikrqx2v;
            $this->_canvas->rectangle($Vmm2pe5l4str, $Vuua0v2znlr5, (float)$V5ymvwogwh5y, (float)$V2pgp3ppbjsi, $Vbgj2xsenowe["color"], $Veatxxxrhqpk, $V2apyt5442as);
            return;
        }

        $Vameiikrqx2v[0] -= $Veatxxxrhqpk;
        $Vameiikrqx2v[1] -= $Veatxxxrhqpk;
        $Vameiikrqx2v[2] += $Veatxxxrhqpk * 2;
        $Vameiikrqx2v[3] += $Veatxxxrhqpk * 2;

        $Vbj2tc0fvhny = "_border_" . $Vbgj2xsenowe["style"];
        $V5ymvwogwh5yidths = array_fill(0, 4, (float)$Vkvw5zjrwkdm->length_in_pt($Vbgj2xsenowe["width"]));
        $Vcxi3be0s51cs = array("top", "right", "left", "bottom");
        $Vyfoeno5vtuw = 0;

        foreach ($Vcxi3be0s51cs as $Vcxi3be0s51c) {
            list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vameiikrqx2v;

            switch ($Vcxi3be0s51c) {
                case "top":
                    $Vyfoeno5vtuw = (float)$V5ymvwogwh5y;
                    break;

                case "bottom":
                    $Vyfoeno5vtuw = (float)$V5ymvwogwh5y;
                    $Vuua0v2znlr5 += (float)$V2pgp3ppbjsi;
                    break;

                case "left":
                    $Vyfoeno5vtuw = (float)$V2pgp3ppbjsi;
                    break;

                case "right":
                    $Vyfoeno5vtuw = (float)$V2pgp3ppbjsi;
                    $Vmm2pe5l4str += (float)$V5ymvwogwh5y;
                    break;
                default:
                    break;
            }

            $this->$Vbj2tc0fvhny($Vmm2pe5l4str, $Vuua0v2znlr5, $Vyfoeno5vtuw, $Vbgj2xsenowe["color"], $V5ymvwogwh5yidths, $Vcxi3be0s51c, $Vvjvaevwt31l);
        }
    }
}
