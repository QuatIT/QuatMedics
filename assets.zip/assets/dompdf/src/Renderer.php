<?php

namespace Dompdf;

use Dompdf\Renderer\AbstractRenderer;
use Dompdf\Renderer\Block;
use Dompdf\Renderer\Image;
use Dompdf\Renderer\ListBullet;
use Dompdf\Renderer\TableCell;
use Dompdf\Renderer\TableRowGroup;
use Dompdf\Renderer\Text;


class Renderer extends AbstractRenderer
{

    
    protected $Vrqod0b4i5z2;

    
    private $V50lbpgsppq2;

    
    function new_page()
    {
        $this->_canvas->new_page();
    }

    
    public function render(Frame $Vexjfacrc1d4)
    {
        global $Vqg3ys0emmj5;

        $this->_check_callbacks("begin_frame", $Vexjfacrc1d4);

        if ($Vqg3ys0emmj5) {
            echo $Vexjfacrc1d4;
            flush();
        }

        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        if (in_array($Vkvw5zjrwkdm->visibility, array("hidden", "collapse"))) {
            return;
        }

        $Vqzifj31psr1 = $Vkvw5zjrwkdm->display;

        
        if ($Vkvw5zjrwkdm->transform && is_array($Vkvw5zjrwkdm->transform)) {
            $this->_canvas->save();
            list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vexjfacrc1d4->get_padding_box();
            $Vys1hksmqmvt = $Vkvw5zjrwkdm->transform_origin;

            foreach ($Vkvw5zjrwkdm->transform as $Vrwc0twf3nir) {
                list($Vgzy4tqtxz0x, $Vtb2d1vzec35) = $Vrwc0twf3nir;
                if ($Vgzy4tqtxz0x === "matrix") {
                    $Vgzy4tqtxz0x = "transform";
                }

                $Vtb2d1vzec35 = array_map("floatval", $Vtb2d1vzec35);
                $Vtb2d1vzec35[] = $Vmm2pe5l4str + (float)$Vkvw5zjrwkdm->length_in_pt($Vys1hksmqmvt[0], (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->width));
                $Vtb2d1vzec35[] = $Vuua0v2znlr5 + (float)$Vkvw5zjrwkdm->length_in_pt($Vys1hksmqmvt[1], (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->height));

                call_user_func_array(array($this->_canvas, $Vgzy4tqtxz0x), $Vtb2d1vzec35);
            }
        }

        switch ($Vqzifj31psr1) {

            case "block":
            case "list-item":
            case "inline-block":
            case "table":
            case "inline-table":
                $this->_render_frame("block", $Vexjfacrc1d4);
                break;

            case "inline":
                if ($Vexjfacrc1d4->is_text_node()) {
                    $this->_render_frame("text", $Vexjfacrc1d4);
                } else {
                    $this->_render_frame("inline", $Vexjfacrc1d4);
                }
                break;

            case "table-cell":
                $this->_render_frame("table-cell", $Vexjfacrc1d4);
                break;

            case "table-row-group":
            case "table-header-group":
            case "table-footer-group":
                $this->_render_frame("table-row-group", $Vexjfacrc1d4);
                break;

            case "-dompdf-list-bullet":
                $this->_render_frame("list-bullet", $Vexjfacrc1d4);
                break;

            case "-dompdf-image":
                $this->_render_frame("image", $Vexjfacrc1d4);
                break;

            case "none":
                $Vivp5mmrkfpz = $Vexjfacrc1d4->get_node();

                if ($Vivp5mmrkfpz->nodeName === "script") {
                    if ($Vivp5mmrkfpz->getAttribute("type") === "text/php" ||
                        $Vivp5mmrkfpz->getAttribute("language") === "php"
                    ) {
                        
                        $this->_render_frame("php", $Vexjfacrc1d4);
                    } elseif ($Vivp5mmrkfpz->getAttribute("type") === "text/javascript" ||
                        $Vivp5mmrkfpz->getAttribute("language") === "javascript"
                    ) {
                        
                        $this->_render_frame("javascript", $Vexjfacrc1d4);
                    }
                }

                
                return;

            default:
                break;

        }

        
        if ($Vkvw5zjrwkdm->overflow === "hidden") {
            list($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vexjfacrc1d4->get_padding_box();

            
            $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
            list($Veltemnghp05, $Vkfno1tgq5nc, $Vbwp1e1ru2dj, $V3lmsgoqk24r) = $Vkvw5zjrwkdm->get_computed_border_radius($V5ymvwogwh5y, $V2pgp3ppbjsi);

            if ($Veltemnghp05 + $Vkfno1tgq5nc + $Vbwp1e1ru2dj + $V3lmsgoqk24r > 0) {
                $this->_canvas->clipping_roundrectangle($Vmm2pe5l4str, $Vuua0v2znlr5, (float)$V5ymvwogwh5y, (float)$V2pgp3ppbjsi, $Veltemnghp05, $Vkfno1tgq5nc, $Vbwp1e1ru2dj, $V3lmsgoqk24r);
            } else {
                $this->_canvas->clipping_rectangle($Vmm2pe5l4str, $Vuua0v2znlr5, (float)$V5ymvwogwh5y, (float)$V2pgp3ppbjsi);
            }
        }

        $Vo1vhygcjja1 = array();

        foreach ($Vexjfacrc1d4->get_children() as $V0mqc4rbglqu) {
            
            
            
            
            $V0mqc4rbglqu_style = $V0mqc4rbglqu->get_style();
            $V0mqc4rbglqu_z_index = $V0mqc4rbglqu_style->z_index;
            $Vng2r3tvw202 = 0;

            if ($V0mqc4rbglqu_z_index !== "auto") {
                $Vng2r3tvw202 = intval($V0mqc4rbglqu_z_index) + 1;
            } elseif ($V0mqc4rbglqu_style->float !== "none" || $V0mqc4rbglqu->is_positionned()) {
                $Vng2r3tvw202 = 1;
            }

            $Vo1vhygcjja1[$Vng2r3tvw202][] = $V0mqc4rbglqu;
        }

        ksort($Vo1vhygcjja1);

        foreach ($Vo1vhygcjja1 as $Vs5u2h1w2fjf) {
            foreach ($Vs5u2h1w2fjf as $V0mqc4rbglqu) {
                $this->render($V0mqc4rbglqu);
            }
        }

        
        if ($Vkvw5zjrwkdm->overflow === "hidden") {
            $this->_canvas->clipping_end();
        }

        if ($Vkvw5zjrwkdm->transform && is_array($Vkvw5zjrwkdm->transform)) {
            $this->_canvas->restore();
        }

        
        $this->_check_callbacks("end_frame", $Vexjfacrc1d4);
    }

    
    protected function _check_callbacks($Vnd23tleybdf, $Vexjfacrc1d4)
    {
        if (!isset($this->_callbacks)) {
            $this->_callbacks = $this->_dompdf->getCallbacks();
        }

        if (is_array($this->_callbacks) && isset($this->_callbacks[$Vnd23tleybdf])) {
            $Vjm5y31o3qu2 = array(0 => $this->_canvas, "canvas" => $this->_canvas,
                1 => $Vexjfacrc1d4, "frame" => $Vexjfacrc1d4);
            $Vepzylbkouaw = $this->_callbacks[$Vnd23tleybdf];
            foreach ($Vepzylbkouaw as $Vtmlsxxw3ne1) {
                if (is_callable($Vtmlsxxw3ne1)) {
                    if (is_array($Vtmlsxxw3ne1)) {
                        $Vtmlsxxw3ne1[0]->{$Vtmlsxxw3ne1[1]}($Vjm5y31o3qu2);
                    } else {
                        $Vtmlsxxw3ne1($Vjm5y31o3qu2);
                    }
                }
            }
        }
    }

    
    protected function _render_frame($Vky1xzjrvbn4, $Vexjfacrc1d4)
    {

        if (!isset($this->_renderers[$Vky1xzjrvbn4])) {

            switch ($Vky1xzjrvbn4) {
                case "block":
                    $this->_renderers[$Vky1xzjrvbn4] = new Block($this->_dompdf);
                    break;

                case "inline":
                    $this->_renderers[$Vky1xzjrvbn4] = new Renderer\Inline($this->_dompdf);
                    break;

                case "text":
                    $this->_renderers[$Vky1xzjrvbn4] = new Text($this->_dompdf);
                    break;

                case "image":
                    $this->_renderers[$Vky1xzjrvbn4] = new Image($this->_dompdf);
                    break;

                case "table-cell":
                    $this->_renderers[$Vky1xzjrvbn4] = new TableCell($this->_dompdf);
                    break;

                case "table-row-group":
                    $this->_renderers[$Vky1xzjrvbn4] = new TableRowGroup($this->_dompdf);
                    break;

                case "list-bullet":
                    $this->_renderers[$Vky1xzjrvbn4] = new ListBullet($this->_dompdf);
                    break;

                case "php":
                    $this->_renderers[$Vky1xzjrvbn4] = new PhpEvaluator($this->_canvas);
                    break;

                case "javascript":
                    $this->_renderers[$Vky1xzjrvbn4] = new JavascriptEmbedder($this->_dompdf);
                    break;

            }
        }

        $this->_renderers[$Vky1xzjrvbn4]->render($Vexjfacrc1d4);
    }
}
