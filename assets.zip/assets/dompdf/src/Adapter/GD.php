<?php

namespace Dompdf\Adapter;

use Dompdf\Canvas;
use Dompdf\Dompdf;
use Dompdf\Image\Cache;
use Dompdf\Helpers;


class GD implements Canvas
{
    
    private $V3zitx0n32g4;

    
    private $Vdsq4tkubjau;

    
    private $Vdsq4tkubjaus;

    
    private $Vxc0qtxc1w0o;

    
    private $Vhuqn53j4zao;

    
    private $Vfuwokv2stjk;

    
    private $Vj2qcdqqojyj;

    
    private $Vhefvyusmcj3;

    
    private $Vm2e5vffkgjz;

    
    private $Vifztu2fnoff;

    
    private $Vgfr1fk032tx;

    
    private $V35j1olp4ngx;

    
    private $V35j1olp4ngx_array;

    
    private $Vfwb1n1yh3ll;

    
    const FONT_SCALE = 0.75;

    
    public function __construct($Vkgj34o34uaw = 'letter', $V00gcroe4i4s = "portrait", Dompdf $Vodc45cwlwwh, $Vviddltwtpip = 1.0, $Vzto452lyyfe = array(1, 1, 1, 0))
    {

        if (!is_array($Vkgj34o34uaw)) {
            $Vkgj34o34uaw = strtolower($Vkgj34o34uaw);

            if (isset(CPDF::$Vfh5zaiuo2gy[$Vkgj34o34uaw])) {
                $Vkgj34o34uaw = CPDF::$Vfh5zaiuo2gy[$Vkgj34o34uaw];
            } else {
                $Vkgj34o34uaw = CPDF::$Vfh5zaiuo2gy["letter"];
            }
        }

        if (strtolower($V00gcroe4i4s) === "landscape") {
            list($Vkgj34o34uaw[2], $Vkgj34o34uaw[3]) = array($Vkgj34o34uaw[3], $Vkgj34o34uaw[2]);
        }

        $this->_dompdf = $Vodc45cwlwwh;

        $this->dpi = $this->get_dompdf()->getOptions()->getDpi();

        if ($Vviddltwtpip < 1) {
            $Vviddltwtpip = 1;
        }

        $this->_aa_factor = $Vviddltwtpip;

        $Vkgj34o34uaw[2] *= $Vviddltwtpip;
        $Vkgj34o34uaw[3] *= $Vviddltwtpip;

        $this->_width = $Vkgj34o34uaw[2] - $Vkgj34o34uaw[0];
        $this->_height = $Vkgj34o34uaw[3] - $Vkgj34o34uaw[1];

        $this->_actual_width = $this->_upscale($this->_width);
        $this->_actual_height = $this->_upscale($this->_height);

        if (is_null($Vzto452lyyfe) || !is_array($Vzto452lyyfe)) {
            
            $Vzto452lyyfe = array(1, 1, 1, 0);
        }

        $this->_bg_color_array = $Vzto452lyyfe;

        $this->new_page();
    }

    
    public function get_dompdf()
    {
        return $this->_dompdf;
    }

    
    public function get_image()
    {
        return $this->_img;
    }

    
    public function get_width()
    {
        return $this->_width / $this->_aa_factor;
    }

    
    public function get_height()
    {
        return $this->_height / $this->_aa_factor;
    }

    
    public function get_page_number()
    {
        return $this->_page_number;
    }

    
    public function get_page_count()
    {
        return $this->_page_count;
    }

    
    public function set_page_number($Vaucqj0hftp5)
    {
        $this->_page_number = $Vaucqj0hftp5;
    }

    
    public function set_page_count($V4wukmcy3ij2)
    {
        $this->_page_count = $V4wukmcy3ij2;
    }

    
    public function set_opacity($Vhrfbgup2xix, $V4rgua51nlxl = "Normal")
    {
        
    }

    
    private function _allocate_color($V3poxlnogtlh)
    {
        $V4dkbhpdu11q = isset($V3poxlnogtlh["alpha"]) ? $V3poxlnogtlh["alpha"] : 1;

        if (isset($V3poxlnogtlh["c"])) {
            $V3poxlnogtlh = Helpers::cmyk_to_rgb($V3poxlnogtlh);
        }

        list($Vapkwgsb3w3r, $Vlqbrj3xtbjj, $Vkbvefdrfvxh) = $V3poxlnogtlh;

        $Vapkwgsb3w3r *= 255;
        $Vlqbrj3xtbjj *= 255;
        $Vkbvefdrfvxh *= 255;
        $V4dkbhpdu11q = 127 - ($V4dkbhpdu11q * 127);

        
        $Vapkwgsb3w3r = $Vapkwgsb3w3r > 255 ? 255 : $Vapkwgsb3w3r;
        $Vlqbrj3xtbjj = $Vlqbrj3xtbjj > 255 ? 255 : $Vlqbrj3xtbjj;
        $Vkbvefdrfvxh = $Vkbvefdrfvxh > 255 ? 255 : $Vkbvefdrfvxh;
        $V4dkbhpdu11q = $V4dkbhpdu11q > 127 ? 127 : $V4dkbhpdu11q;

        $Vapkwgsb3w3r = $Vapkwgsb3w3r < 0 ? 0 : $Vapkwgsb3w3r;
        $Vlqbrj3xtbjj = $Vlqbrj3xtbjj < 0 ? 0 : $Vlqbrj3xtbjj;
        $Vkbvefdrfvxh = $Vkbvefdrfvxh < 0 ? 0 : $Vkbvefdrfvxh;
        $V4dkbhpdu11q = $V4dkbhpdu11q < 0 ? 0 : $V4dkbhpdu11q;

        $Vbd2mxirzq2d = sprintf("#%02X%02X%02X%02X", $Vapkwgsb3w3r, $Vlqbrj3xtbjj, $Vkbvefdrfvxh, $V4dkbhpdu11q);

        if (isset($this->_colors[$Vbd2mxirzq2d])) {
            return $this->_colors[$Vbd2mxirzq2d];
        }

        if ($V4dkbhpdu11q != 0) {
            $this->_colors[$Vbd2mxirzq2d] = imagecolorallocatealpha($this->get_image(), $Vapkwgsb3w3r, $Vlqbrj3xtbjj, $Vkbvefdrfvxh, $V4dkbhpdu11q);
        } else {
            $this->_colors[$Vbd2mxirzq2d] = imagecolorallocate($this->get_image(), $Vapkwgsb3w3r, $Vlqbrj3xtbjj, $Vkbvefdrfvxh);
        }

        return $this->_colors[$Vbd2mxirzq2d];
    }

    
    private function _upscale($Vyfoeno5vtuw)
    {
        return ($Vyfoeno5vtuw * $this->dpi) / 72 * $this->_aa_factor;
    }

    
    private function _downscale($Vyfoeno5vtuw)
    {
        return ($Vyfoeno5vtuw / $this->dpi * 72) / $this->_aa_factor;
    }

    
    public function line($V4wnp2r2nst5, $V2e3azycubv1, $V2kam3hj2q41, $Vg1v0wo0w4jj, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = null)
    {

        
        $V4wnp2r2nst5 = $this->_upscale($V4wnp2r2nst5);
        $V2e3azycubv1 = $this->_upscale($V2e3azycubv1);
        $V2kam3hj2q41 = $this->_upscale($V2kam3hj2q41);
        $Vg1v0wo0w4jj = $this->_upscale($Vg1v0wo0w4jj);
        $Vtt4kvdwuqqh = $this->_upscale($Vtt4kvdwuqqh);

        $Vdiqkcy1hsm4 = $this->_allocate_color($V3poxlnogtlh);

        
        if (is_array($Vkvw5zjrwkdm) && count($Vkvw5zjrwkdm) > 0) {
            $Vlqbrj3xtbjjd_style = array();

            if (count($Vkvw5zjrwkdm) == 1) {
                for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vkvw5zjrwkdm[0] * $this->_aa_factor; $V0ixz2v5mxzy++) {
                    $Vlqbrj3xtbjjd_style[] = $Vdiqkcy1hsm4;
                }

                for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vkvw5zjrwkdm[0] * $this->_aa_factor; $V0ixz2v5mxzy++) {
                    $Vlqbrj3xtbjjd_style[] = $this->_bg_color;
                }
            } else {
                $V0ixz2v5mxzy = 0;
                foreach ($Vkvw5zjrwkdm as $Vyfoeno5vtuw) {
                    if ($V0ixz2v5mxzy % 2 == 0) {
                        
                        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vkvw5zjrwkdm[0] * $this->_aa_factor; $V0ixz2v5mxzy++) {
                            $Vlqbrj3xtbjjd_style[] = $Vdiqkcy1hsm4;
                        }

                    } else {
                        
                        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vkvw5zjrwkdm[0] * $this->_aa_factor; $V0ixz2v5mxzy++) {
                            $Vlqbrj3xtbjjd_style[] = $this->_bg_color;
                        }
                    }
                    $V0ixz2v5mxzy++;
                }
            }

            if (!empty($Vlqbrj3xtbjjd_style)) {
                imagesetstyle($this->get_image(), $Vlqbrj3xtbjjd_style);
                $Vdiqkcy1hsm4 = IMG_COLOR_STYLED;
            }
        }

        imagesetthickness($this->get_image(), $Vtt4kvdwuqqh);

        imageline($this->get_image(), $V4wnp2r2nst5, $V2e3azycubv1, $V2kam3hj2q41, $Vg1v0wo0w4jj, $Vdiqkcy1hsm4);
    }

    
    public function arc($V4wnp2r2nst5, $V2e3azycubv1, $Vapkwgsb3w3r1, $Vapkwgsb3w3r2, $V4dkbhpdu11qstart, $V4dkbhpdu11qend, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = array())
    {
        
    }

    
    public function rectangle($V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = null)
    {

        
        $V4wnp2r2nst5 = $this->_upscale($V4wnp2r2nst5);
        $V2e3azycubv1 = $this->_upscale($V2e3azycubv1);
        $V5ymvwogwh5y = $this->_upscale($V5ymvwogwh5y);
        $V2pgp3ppbjsi = $this->_upscale($V2pgp3ppbjsi);
        $Vtt4kvdwuqqh = $this->_upscale($Vtt4kvdwuqqh);

        $Vdiqkcy1hsm4 = $this->_allocate_color($V3poxlnogtlh);

        
        if (is_array($Vkvw5zjrwkdm) && count($Vkvw5zjrwkdm) > 0) {
            $Vlqbrj3xtbjjd_style = array();

            foreach ($Vkvw5zjrwkdm as $Vyfoeno5vtuw) {
                for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vyfoeno5vtuw; $V0ixz2v5mxzy++) {
                    $Vlqbrj3xtbjjd_style[] = $Vdiqkcy1hsm4;
                }
            }

            if (!empty($Vlqbrj3xtbjjd_style)) {
                imagesetstyle($this->get_image(), $Vlqbrj3xtbjjd_style);
                $Vdiqkcy1hsm4 = IMG_COLOR_STYLED;
            }
        }

        imagesetthickness($this->get_image(), $Vtt4kvdwuqqh);

        imagerectangle($this->get_image(), $V4wnp2r2nst5, $V2e3azycubv1, $V4wnp2r2nst5 + $V5ymvwogwh5y, $V2e3azycubv1 + $V2pgp3ppbjsi, $Vdiqkcy1hsm4);
    }

    
    public function filled_rectangle($V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V3poxlnogtlh)
    {
        
        $V4wnp2r2nst5 = $this->_upscale($V4wnp2r2nst5);
        $V2e3azycubv1 = $this->_upscale($V2e3azycubv1);
        $V5ymvwogwh5y = $this->_upscale($V5ymvwogwh5y);
        $V2pgp3ppbjsi = $this->_upscale($V2pgp3ppbjsi);

        $Vdiqkcy1hsm4 = $this->_allocate_color($V3poxlnogtlh);

        imagefilledrectangle($this->get_image(), $V4wnp2r2nst5, $V2e3azycubv1, $V4wnp2r2nst5 + $V5ymvwogwh5y, $V2e3azycubv1 + $V2pgp3ppbjsi, $Vdiqkcy1hsm4);
    }

    
    public function clipping_rectangle($V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5y, $V2pgp3ppbjsi)
    {
        
    }

    public function clipping_roundrectangle($V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vapkwgsb3w3rTL, $Vapkwgsb3w3rTR, $Vapkwgsb3w3rBR, $Vapkwgsb3w3rBL)
    {
        
    }

    
    public function clipping_end()
    {
        
    }

    
    public function save()
    {
        $this->get_dompdf()->getOptions()->setDpi(72);
    }

    
    public function restore()
    {
        $this->get_dompdf()->getOptions()->setDpi($this->dpi);
    }

    
    public function rotate($V4dkbhpdu11qngle, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        
    }

    
    public function skew($V4dkbhpdu11qngle_x, $V4dkbhpdu11qngle_y, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        
    }

    
    public function scale($Vb01jpbrlun1, $Vt5g1id0c1cp, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        
    }

    
    public function translate($Vbs1pcpjo5lt, $Vml2vjgadh2o)
    {
        
    }

    
    public function transform($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1)
    {
        
    }

    
    public function polygon($Vz0kp11gbnu4, $V3poxlnogtlh, $Vtt4kvdwuqqh = null, $Vkvw5zjrwkdm = null, $Vtmlsxxw3ne1ill = false)
    {

        
        foreach (array_keys($Vz0kp11gbnu4) as $V0ixz2v5mxzy) {
            $Vz0kp11gbnu4[$V0ixz2v5mxzy] = $this->_upscale($Vz0kp11gbnu4[$V0ixz2v5mxzy]);
        }

        $Vdiqkcy1hsm4 = $this->_allocate_color($V3poxlnogtlh);

        
        if (is_array($Vkvw5zjrwkdm) && count($Vkvw5zjrwkdm) > 0 && !$Vtmlsxxw3ne1ill) {
            $Vlqbrj3xtbjjd_style = array();

            foreach ($Vkvw5zjrwkdm as $Vyfoeno5vtuw) {
                for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vyfoeno5vtuw; $V0ixz2v5mxzy++) {
                    $Vlqbrj3xtbjjd_style[] = $Vdiqkcy1hsm4;
                }
            }

            if (!empty($Vlqbrj3xtbjjd_style)) {
                imagesetstyle($this->get_image(), $Vlqbrj3xtbjjd_style);
                $Vdiqkcy1hsm4 = IMG_COLOR_STYLED;
            }
        }

        imagesetthickness($this->get_image(), $Vtt4kvdwuqqh);

        if ($Vtmlsxxw3ne1ill) {
            imagefilledpolygon($this->get_image(), $Vz0kp11gbnu4, count($Vz0kp11gbnu4) / 2, $Vdiqkcy1hsm4);
        } else {
            imagepolygon($this->get_image(), $Vz0kp11gbnu4, count($Vz0kp11gbnu4) / 2, $Vdiqkcy1hsm4);
        }
    }

    
    public function circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vapkwgsb3w3r, $V3poxlnogtlh, $Vtt4kvdwuqqh = null, $Vkvw5zjrwkdm = null, $Vtmlsxxw3ne1ill = false)
    {
        
        $Vmm2pe5l4str = $this->_upscale($Vmm2pe5l4str);
        $Vuua0v2znlr5 = $this->_upscale($Vuua0v2znlr5);
        $Vapkwgsb3w3r = $this->_upscale($Vapkwgsb3w3r);

        $Vdiqkcy1hsm4 = $this->_allocate_color($V3poxlnogtlh);

        
        if (is_array($Vkvw5zjrwkdm) && count($Vkvw5zjrwkdm) > 0 && !$Vtmlsxxw3ne1ill) {
            $Vlqbrj3xtbjjd_style = array();

            foreach ($Vkvw5zjrwkdm as $Vyfoeno5vtuw) {
                for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vyfoeno5vtuw; $V0ixz2v5mxzy++) {
                    $Vlqbrj3xtbjjd_style[] = $Vdiqkcy1hsm4;
                }
            }

            if (!empty($Vlqbrj3xtbjjd_style)) {
                imagesetstyle($this->get_image(), $Vlqbrj3xtbjjd_style);
                $Vdiqkcy1hsm4 = IMG_COLOR_STYLED;
            }
        }

        imagesetthickness($this->get_image(), $Vtt4kvdwuqqh);

        if ($Vtmlsxxw3ne1ill) {
            imagefilledellipse($this->get_image(), $Vmm2pe5l4str, $Vuua0v2znlr5, $Vapkwgsb3w3r, $Vapkwgsb3w3r, $Vdiqkcy1hsm4);
        } else {
            imageellipse($this->get_image(), $Vmm2pe5l4str, $Vuua0v2znlr5, $Vapkwgsb3w3r, $Vapkwgsb3w3r, $Vdiqkcy1hsm4);
        }
    }

    
    public function image($V0ixz2v5mxzymg_url, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vapkwgsb3w3resolution = "normal")
    {
        $V0ixz2v5mxzymg_type = Cache::detect_type($V0ixz2v5mxzymg_url, $this->get_dompdf()->getHttpContext());

        if (!$V0ixz2v5mxzymg_type) {
            return;
        }

        $Vtmlsxxw3ne1unc_name = "imagecreatefrom$V0ixz2v5mxzymg_type";
        if (!function_exists($Vtmlsxxw3ne1unc_name)) {
            if (!method_exists("Dompdf\Helpers", $Vtmlsxxw3ne1unc_name)) {
                throw new \Exception("Function $Vtmlsxxw3ne1unc_name() not found.  Cannot convert $Vky1xzjrvbn4 image: $V0ixz2v5mxzymg_url.  Please install the image PHP extension.");
            }
            $Vtmlsxxw3ne1unc_name = "\\Dompdf\\Helpers::" . $Vtmlsxxw3ne1unc_name;
        }
        $Vahsl5oryz00 = @call_user_func($Vtmlsxxw3ne1unc_name, $V0ixz2v5mxzymg_url);

        if (!$Vahsl5oryz00) {
            return; 
        }

        
        $Vmm2pe5l4str = $this->_upscale($Vmm2pe5l4str);
        $Vuua0v2znlr5 = $this->_upscale($Vuua0v2znlr5);

        $V5ymvwogwh5y = $this->_upscale($V5ymvwogwh5y);
        $V2pgp3ppbjsi = $this->_upscale($V2pgp3ppbjsi);

        $V0ixz2v5mxzymg_w = imagesx($Vahsl5oryz00);
        $V0ixz2v5mxzymg_h = imagesy($Vahsl5oryz00);

        imagecopyresampled($this->get_image(), $Vahsl5oryz00, $Vmm2pe5l4str, $Vuua0v2znlr5, 0, 0, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V0ixz2v5mxzymg_w, $V0ixz2v5mxzymg_h);
    }

    
    public function text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc, $Vtmlsxxw3ne1ont, $Vkgj34o34uaw, $V3poxlnogtlh = array(0, 0, 0), $V5ymvwogwh5yord_spacing = 0.0, $Vdiqkcy1hsm4har_spacing = 0.0, $V4dkbhpdu11qngle = 0.0)
    {
        
        $Vmm2pe5l4str = $this->_upscale($Vmm2pe5l4str);
        $Vuua0v2znlr5 = $this->_upscale($Vuua0v2znlr5);
        $Vkgj34o34uaw = $this->_upscale($Vkgj34o34uaw) * self::FONT_SCALE;

        $V2pgp3ppbjsi = $this->get_font_height_actual($Vtmlsxxw3ne1ont, $Vkgj34o34uaw);
        $Vdiqkcy1hsm4 = $this->_allocate_color($V3poxlnogtlh);

        
        
        
        
        $Vnjapcj4bkpc = preg_replace('/&(#(?:x[a-fA-F0-9]+|[0-9]+);)/', '&#38;\1', $Vnjapcj4bkpc);

        $Vnjapcj4bkpc = mb_encode_numericentity($Vnjapcj4bkpc, array(0x0080, 0xff, 0, 0xff), 'UTF-8');

        $Vtmlsxxw3ne1ont = $this->get_ttf_file($Vtmlsxxw3ne1ont);

        
        imagettftext($this->get_image(), $Vkgj34o34uaw, $V4dkbhpdu11qngle, $Vmm2pe5l4str, $Vuua0v2znlr5 + $V2pgp3ppbjsi, $Vdiqkcy1hsm4, $Vtmlsxxw3ne1ont, $Vnjapcj4bkpc);
    }

    public function javascript($Vdiqkcy1hsm4ode)
    {
        
    }

    
    public function add_named_dest($V4dkbhpdu11qnchorname)
    {
        
    }

    
    public function add_link($Vop22rgf5euu, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vtt4kvdwuqqh, $V2pgp3ppbjsieight)
    {
        
    }

    
    public function add_info($Vovi5zubtdii, $Veugw2h43vxz)
    {
        
    }

    
    public function set_default_view($V5op4eazb4xu, $V3vmzyblbtdy = array())
    {
        
    }

    
    public function get_text_width($Vnjapcj4bkpc, $Vtmlsxxw3ne1ont, $Vkgj34o34uaw, $V5ymvwogwh5yord_spacing = 0.0, $Vdiqkcy1hsm4har_spacing = 0.0)
    {
        $Vtmlsxxw3ne1ont = $this->get_ttf_file($Vtmlsxxw3ne1ont);
        $Vkgj34o34uaw = $this->_upscale($Vkgj34o34uaw) * self::FONT_SCALE;

        
        
        
        
        $Vnjapcj4bkpc = preg_replace('/&(#(?:x[a-fA-F0-9]+|[0-9]+);)/', '&#38;\1', $Vnjapcj4bkpc);

        $Vnjapcj4bkpc = mb_encode_numericentity($Vnjapcj4bkpc, array(0x0080, 0xffff, 0, 0xffff), 'UTF-8');

        
        list($V4wnp2r2nst5, , $V2kam3hj2q41) = imagettfbbox($Vkgj34o34uaw, 0, $Vtmlsxxw3ne1ont, $Vnjapcj4bkpc);

        
        return $this->_downscale($V2kam3hj2q41 - $V4wnp2r2nst5) + 1;
    }

    
    public function get_ttf_file($Vtmlsxxw3ne1ont)
    {
        if ( stripos($Vtmlsxxw3ne1ont, ".ttf") === false ) {
            $Vtmlsxxw3ne1ont .= ".ttf";
        }

        if (!file_exists($Vtmlsxxw3ne1ont)) {
            $Vtmlsxxw3ne1ont_metrics = $this->_dompdf->getFontMetrics();
            $Vtmlsxxw3ne1ont = $Vtmlsxxw3ne1ont_metrics->getFont($this->_dompdf->getOptions()->getDefaultFont()) . ".ttf";
            if (!file_exists($Vtmlsxxw3ne1ont)) {
                if (strpos($Vtmlsxxw3ne1ont, "mono")) {
                    $Vtmlsxxw3ne1ont = $Vtmlsxxw3ne1ont_metrics->getFont("DejaVu Mono") . ".ttf";
                } elseif (strpos($Vtmlsxxw3ne1ont, "sans") !== false) {
                    $Vtmlsxxw3ne1ont = $Vtmlsxxw3ne1ont_metrics->getFont("DejaVu Sans") . ".ttf";
                } elseif (strpos($Vtmlsxxw3ne1ont, "serif")) {
                    $Vtmlsxxw3ne1ont = $Vtmlsxxw3ne1ont_metrics->getFont("DejaVu Serif") . ".ttf";
                } else {
                    $Vtmlsxxw3ne1ont = $Vtmlsxxw3ne1ont_metrics->getFont("DejaVu Sans") . ".ttf";
                }
            }
        }

        return $Vtmlsxxw3ne1ont;
    }

    
    public function get_font_height($Vtmlsxxw3ne1ont, $Vkgj34o34uaw)
    {
        $Vkgj34o34uaw = $this->_upscale($Vkgj34o34uaw) * self::FONT_SCALE;

        $V2pgp3ppbjsieight = $this->get_font_height_actual($Vtmlsxxw3ne1ont, $Vkgj34o34uaw);

        return $this->_downscale($V2pgp3ppbjsieight);
    }

    private function get_font_height_actual($Vtmlsxxw3ne1ont, $Vkgj34o34uaw)
    {
        $Vtmlsxxw3ne1ont = $this->get_ttf_file($Vtmlsxxw3ne1ont);
        $Vapkwgsb3w3ratio = $this->_dompdf->getOptions()->getFontHeightRatio();

        
        list(, $Vg1v0wo0w4jj, , , , $V2e3azycubv1) = imagettfbbox($Vkgj34o34uaw, 0, $Vtmlsxxw3ne1ont, "MXjpqytfhl"); 
        return ($Vg1v0wo0w4jj - $V2e3azycubv1) * $Vapkwgsb3w3ratio;
    }

    
    public function get_font_baseline($Vtmlsxxw3ne1ont, $Vkgj34o34uaw)
    {
        $Vapkwgsb3w3ratio = $this->_dompdf->getOptions()->getFontHeightRatio();
        return $this->get_font_height($Vtmlsxxw3ne1ont, $Vkgj34o34uaw) / $Vapkwgsb3w3ratio;
    }

    
    public function new_page()
    {
        $this->_page_number++;
        $this->_page_count++;

        $this->_img = imagecreatetruecolor($this->_actual_width, $this->_actual_height);

        $this->_bg_color = $this->_allocate_color($this->_bg_color_array);
        imagealphablending($this->_img, true);
        imagesavealpha($this->_img, true);
        imagefill($this->_img, 0, 0, $this->_bg_color);

        $this->_imgs[] = $this->_img;
    }

    public function open_object()
    {
        
    }

    public function close_object()
    {
        
    }

    public function add_object()
    {
        
    }

    public function page_text()
    {
        
    }

    
    public function stream($Vtmlsxxw3ne1ilename, $V3vmzyblbtdy = array())
    {
        if (headers_sent()) {
            die("Unable to stream image: headers already sent");
        }

        if (!isset($V3vmzyblbtdy["type"])) $V3vmzyblbtdy["type"] = "png";
        if (!isset($V3vmzyblbtdy["Attachment"])) $V3vmzyblbtdy["Attachment"] = true;
        $Vky1xzjrvbn4 = strtolower($V3vmzyblbtdy["type"]);

        switch ($Vky1xzjrvbn4) {
            case "jpg":
            case "jpeg":
                $Vdiqkcy1hsm4ontentType = "image/jpeg";
                $Vqfltxpxjekkxtension = ".jpg";
                break;
            case "png":
            default:
                $Vdiqkcy1hsm4ontentType = "image/png";
                $Vqfltxpxjekkxtension = ".png";
                break;
        }

        header("Cache-Control: private");
        header("Content-Type: $Vdiqkcy1hsm4ontentType");

        $Vtmlsxxw3ne1ilename = str_replace(array("\n", "'"), "", basename($Vtmlsxxw3ne1ilename, ".$Vky1xzjrvbn4")) . $Vqfltxpxjekkxtension;
        $V4dkbhpdu11qttachment = $V3vmzyblbtdy["Attachment"] ? "attachment" : "inline";
        header(Helpers::buildContentDispositionHeader($V4dkbhpdu11qttachment, $Vtmlsxxw3ne1ilename));

        $this->_output($V3vmzyblbtdy);
        flush();
    }

    
    public function output($V3vmzyblbtdy = array())
    {
        ob_start();

        $this->_output($V3vmzyblbtdy);

        return ob_get_clean();
    }

    
    private function _output($V3vmzyblbtdy = array())
    {
        if (!isset($V3vmzyblbtdy["type"])) $V3vmzyblbtdy["type"] = "png";
        if (!isset($V3vmzyblbtdy["page"])) $V3vmzyblbtdy["page"] = 1;
        $Vky1xzjrvbn4 = strtolower($V3vmzyblbtdy["type"]);

        if (isset($this->_imgs[$V3vmzyblbtdy["page"] - 1])) {
            $V0ixz2v5mxzymg = $this->_imgs[$V3vmzyblbtdy["page"] - 1];
        } else {
            $V0ixz2v5mxzymg = $this->_imgs[0];
        }

        
        if ($this->_aa_factor != 1) {
            $Vngrhfhlmiygst_w = $this->_actual_width / $this->_aa_factor;
            $Vngrhfhlmiygst_h = $this->_actual_height / $this->_aa_factor;
            $Vngrhfhlmiygst = imagecreatetruecolor($Vngrhfhlmiygst_w, $Vngrhfhlmiygst_h);
            imagecopyresampled($Vngrhfhlmiygst, $V0ixz2v5mxzymg, 0, 0, 0, 0,
                $Vngrhfhlmiygst_w, $Vngrhfhlmiygst_h,
                $this->_actual_width, $this->_actual_height);
        } else {
            $Vngrhfhlmiygst = $V0ixz2v5mxzymg;
        }

        switch ($Vky1xzjrvbn4) {
            case "jpg":
            case "jpeg":
                if (!isset($V3vmzyblbtdy["quality"])) {
                    $V3vmzyblbtdy["quality"] = 75;
                }

                imagejpeg($Vngrhfhlmiygst, null, $V3vmzyblbtdy["quality"]);
                break;
            case "png":
            default:
                imagepng($Vngrhfhlmiygst);
                break;
        }

        if ($this->_aa_factor != 1) {
            imagedestroy($Vngrhfhlmiygst);
        }
    }
}
