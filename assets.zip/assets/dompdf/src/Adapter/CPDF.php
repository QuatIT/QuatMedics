<?php



namespace Dompdf\Adapter;

use Dompdf\Canvas;
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception;
use Dompdf\Image\Cache;
use Dompdf\PhpEvaluator;


class CPDF implements Canvas
{

    
    static $Vfh5zaiuo2gy = array(
        "4a0" => array(0, 0, 4767.87, 6740.79),
        "2a0" => array(0, 0, 3370.39, 4767.87),
        "a0" => array(0, 0, 2383.94, 3370.39),
        "a1" => array(0, 0, 1683.78, 2383.94),
        "a2" => array(0, 0, 1190.55, 1683.78),
        "a3" => array(0, 0, 841.89, 1190.55),
        "a4" => array(0, 0, 595.28, 841.89),
        "a5" => array(0, 0, 419.53, 595.28),
        "a6" => array(0, 0, 297.64, 419.53),
        "a7" => array(0, 0, 209.76, 297.64),
        "a8" => array(0, 0, 147.40, 209.76),
        "a9" => array(0, 0, 104.88, 147.40),
        "a10" => array(0, 0, 73.70, 104.88),
        "b0" => array(0, 0, 2834.65, 4008.19),
        "b1" => array(0, 0, 2004.09, 2834.65),
        "b2" => array(0, 0, 1417.32, 2004.09),
        "b3" => array(0, 0, 1000.63, 1417.32),
        "b4" => array(0, 0, 708.66, 1000.63),
        "b5" => array(0, 0, 498.90, 708.66),
        "b6" => array(0, 0, 354.33, 498.90),
        "b7" => array(0, 0, 249.45, 354.33),
        "b8" => array(0, 0, 175.75, 249.45),
        "b9" => array(0, 0, 124.72, 175.75),
        "b10" => array(0, 0, 87.87, 124.72),
        "c0" => array(0, 0, 2599.37, 3676.54),
        "c1" => array(0, 0, 1836.85, 2599.37),
        "c2" => array(0, 0, 1298.27, 1836.85),
        "c3" => array(0, 0, 918.43, 1298.27),
        "c4" => array(0, 0, 649.13, 918.43),
        "c5" => array(0, 0, 459.21, 649.13),
        "c6" => array(0, 0, 323.15, 459.21),
        "c7" => array(0, 0, 229.61, 323.15),
        "c8" => array(0, 0, 161.57, 229.61),
        "c9" => array(0, 0, 113.39, 161.57),
        "c10" => array(0, 0, 79.37, 113.39),
        "ra0" => array(0, 0, 2437.80, 3458.27),
        "ra1" => array(0, 0, 1729.13, 2437.80),
        "ra2" => array(0, 0, 1218.90, 1729.13),
        "ra3" => array(0, 0, 864.57, 1218.90),
        "ra4" => array(0, 0, 609.45, 864.57),
        "sra0" => array(0, 0, 2551.18, 3628.35),
        "sra1" => array(0, 0, 1814.17, 2551.18),
        "sra2" => array(0, 0, 1275.59, 1814.17),
        "sra3" => array(0, 0, 907.09, 1275.59),
        "sra4" => array(0, 0, 637.80, 907.09),
        "letter" => array(0, 0, 612.00, 792.00),
        "half-letter" => array(0, 0, 396.00, 612.00),
        "legal" => array(0, 0, 612.00, 1008.00),
        "ledger" => array(0, 0, 1224.00, 792.00),
        "tabloid" => array(0, 0, 792.00, 1224.00),
        "executive" => array(0, 0, 521.86, 756.00),
        "folio" => array(0, 0, 612.00, 936.00),
        "commercial #10 envelope" => array(0, 0, 684, 297),
        "catalog #10 1/2 envelope" => array(0, 0, 648, 864),
        "8.5x11" => array(0, 0, 612.00, 792.00),
        "8.5x14" => array(0, 0, 612.00, 1008.0),
        "11x17" => array(0, 0, 792.00, 1224.00),
    );

    
    private $V3zitx0n32g4;

    
    private $Vsk1sogv33gw;

    
    private $Vxc0qtxc1w0o;

    
    private $Vhuqn53j4zao;

    
    private $Vhefvyusmcj3;

    
    private $Vm2e5vffkgjz;

    
    private $Vzv00pgujk3p;

    
    private $Vm3npf2jtnwh;

    
    private $V4fn4p3y1qym;

    
    private $Vimsucsz0113 = 1;

    
    public function __construct($V54vxutwmj54 = "letter", $V00gcroe4i4s = "portrait", Dompdf $Vodc45cwlwwh)
    {
        if (is_array($V54vxutwmj54)) {
            $Vkgj34o34uaw = $V54vxutwmj54;
        } else if (isset(self::$Vfh5zaiuo2gy[mb_strtolower($V54vxutwmj54)])) {
            $Vkgj34o34uaw = self::$Vfh5zaiuo2gy[mb_strtolower($V54vxutwmj54)];
        } else {
            $Vkgj34o34uaw = self::$Vfh5zaiuo2gy["letter"];
        }

        if (mb_strtolower($V00gcroe4i4s) === "landscape") {
            list($Vkgj34o34uaw[2], $Vkgj34o34uaw[3]) = array($Vkgj34o34uaw[3], $Vkgj34o34uaw[2]);
        }

        $this->_dompdf = $Vodc45cwlwwh;

        $this->_pdf = new \Cpdf(
            $Vkgj34o34uaw,
            true,
            $Vodc45cwlwwh->getOptions()->getFontCache(),
            $Vodc45cwlwwh->getOptions()->getTempDir()
        );

        $this->_pdf->addInfo("Producer", sprintf("%s + CPDF", $Vodc45cwlwwh->version));
        $Vgy250y3jfdg = substr_replace(date('YmdHisO'), '\'', -2, 0) . '\'';
        $this->_pdf->addInfo("CreationDate", "D:$Vgy250y3jfdg");
        $this->_pdf->addInfo("ModDate", "D:$Vgy250y3jfdg");

        $this->_width = $Vkgj34o34uaw[2] - $Vkgj34o34uaw[0];
        $this->_height = $Vkgj34o34uaw[3] - $Vkgj34o34uaw[1];

        $this->_page_number = $this->_page_count = 1;
        $this->_page_text = array();

        $this->_pages = array($this->_pdf->getFirstPageId());

        $this->_image_cache = array();
    }

    
    public function get_dompdf()
    {
        return $this->_dompdf;
    }

    
    public function __destruct()
    {
        foreach ($this->_image_cache as $Vz1jukgekuy3) {
            
            
            
            
            if (!file_exists($Vz1jukgekuy3)) {
                continue;
            }

            if ($this->_dompdf->getOptions()->getDebugPng()) {
                print '[__destruct unlink ' . $Vz1jukgekuy3 . ']';
            }
            if (!$this->_dompdf->getOptions()->getDebugKeepTemp()) {
                unlink($Vz1jukgekuy3);
            }
        }
    }

    
    public function get_cpdf()
    {
        return $this->_pdf;
    }

    
    public function add_info($Vovi5zubtdii, $Veugw2h43vxz)
    {
        $this->_pdf->addInfo($Vovi5zubtdii, $Veugw2h43vxz);
    }

    
    public function open_object()
    {
        $Vaamzcof1atz = $this->_pdf->openObject();
        $this->_pdf->saveState();
        return $Vaamzcof1atz;
    }

    
    public function reopen_object($V0e5yoazsdyk)
    {
        $this->_pdf->reopenObject($V0e5yoazsdyk);
        $this->_pdf->saveState();
    }

    
    public function close_object()
    {
        $this->_pdf->restoreState();
        $this->_pdf->closeObject();
    }

    
    public function add_object($V0e5yoazsdyk, $Vhjnp30tipbb = 'all')
    {
        $this->_pdf->addObject($V0e5yoazsdyk, $Vhjnp30tipbb);
    }

    
    public function stop_object($V0e5yoazsdyk)
    {
        $this->_pdf->stopObject($V0e5yoazsdyk);
    }

    
    public function serialize_object($Vawfntrfsy4f)
    {
        
        return $this->_pdf->serializeObject($Vawfntrfsy4f);
    }

    
    public function reopen_serialized_object($Vqiatkt0jg5p)
    {
        return $this->_pdf->restoreSerializedObject($Vqiatkt0jg5p);
    }

    

    
    public function get_width()
    {
        return $this->_width;
    }

    
    public function get_height()
    {
        return $this->_height;
    }

    
    public function get_page_number()
    {
        return $this->_page_number;
    }

    
    public function get_page_count()
    {
        return $this->_page_count;
    }

    
    public function set_page_number($Vaucqj0hftp5)
    {
        $this->_page_number = $Vaucqj0hftp5;
    }

    
    public function set_page_count($V4wukmcy3ij2)
    {
        $this->_page_count = $V4wukmcy3ij2;
    }

    
    protected function _set_stroke_color($V3poxlnogtlh)
    {
        $this->_pdf->setStrokeColor($V3poxlnogtlh);
        $Visj32pb1rwu = isset($V3poxlnogtlh["alpha"]) ? $V3poxlnogtlh["alpha"] : 1;
        if ($this->_current_opacity != 1) {
            $Visj32pb1rwu *= $this->_current_opacity;
        }
        $this->_set_line_transparency("Normal", $Visj32pb1rwu);
    }

    
    protected function _set_fill_color($V3poxlnogtlh)
    {
        $this->_pdf->setColor($V3poxlnogtlh);
        $Visj32pb1rwu = isset($V3poxlnogtlh["alpha"]) ? $V3poxlnogtlh["alpha"] : 1;
        if ($this->_current_opacity) {
            $Visj32pb1rwu *= $this->_current_opacity;
        }
        $this->_set_fill_transparency("Normal", $Visj32pb1rwu);
    }

    
    protected function _set_line_transparency($V4rgua51nlxl, $Vhrfbgup2xix)
    {
        $this->_pdf->setLineTransparency($V4rgua51nlxl, $Vhrfbgup2xix);
    }

    
    protected function _set_fill_transparency($V4rgua51nlxl, $Vhrfbgup2xix)
    {
        $this->_pdf->setFillTransparency($V4rgua51nlxl, $Vhrfbgup2xix);
    }

    
    protected function _set_line_style($Vtt4kvdwuqqh, $Vryn5vp4knpl, $Vo3ls5ffiiu2, $V3gef50hyo1a)
    {
        $this->_pdf->setLineStyle($Vtt4kvdwuqqh, $Vryn5vp4knpl, $Vo3ls5ffiiu2, $V3gef50hyo1a);
    }

    
    public function set_opacity($Vhrfbgup2xix, $V4rgua51nlxl = "Normal")
    {
        $this->_set_line_transparency($V4rgua51nlxl, $Vhrfbgup2xix);
        $this->_set_fill_transparency($V4rgua51nlxl, $Vhrfbgup2xix);
        $this->_current_opacity = $Vhrfbgup2xix;
    }

    public function set_default_view($V5op4eazb4xu, $V3vmzyblbtdy = array())
    {
        array_unshift($V3vmzyblbtdy, $V5op4eazb4xu);
        call_user_func_array(array($this->_pdf, "openHere"), $V3vmzyblbtdy);
    }

    
    protected function y($Vuua0v2znlr5)
    {
        return $this->_height - $Vuua0v2znlr5;
    }

    
    public function line($V4wnp2r2nst5, $Vuua0v2znlr51, $V2kam3hj2q41, $Vuua0v2znlr52, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = array())
    {
        $this->_set_stroke_color($V3poxlnogtlh);
        $this->_set_line_style($Vtt4kvdwuqqh, "butt", "", $Vkvw5zjrwkdm);

        $this->_pdf->line($V4wnp2r2nst5, $this->y($Vuua0v2znlr51),
            $V2kam3hj2q41, $this->y($Vuua0v2znlr52));
        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    public function arc($Vmm2pe5l4str, $Vuua0v2znlr5, $Vapguowxhnfz, $V1wjrukdrpg5, $Vkz1dooibwko, $Ve4azsyeqjqc, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = array())
    {
        $this->_set_stroke_color($V3poxlnogtlh);
        $this->_set_line_style($Vtt4kvdwuqqh, "butt", "", $Vkvw5zjrwkdm);

        $this->_pdf->ellipse($Vmm2pe5l4str, $this->y($Vuua0v2znlr5), $Vapguowxhnfz, $V1wjrukdrpg5, 0, 8, $Vkz1dooibwko, $Ve4azsyeqjqc, false, false, true, false);
        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    protected function _convert_gif_bmp_to_png($Vumy2xhehmwp, $Vky1xzjrvbn4)
    {
        $Vqzscwux20an = "imagecreatefrom$Vky1xzjrvbn4";

        if (!function_exists($Vqzscwux20an)) {
            if (!method_exists("Dompdf\Helpers", $Vqzscwux20an)) {
                throw new Exception("Function $Vqzscwux20an() not found.  Cannot convert $Vky1xzjrvbn4 image: $Vumy2xhehmwp.  Please install the image PHP extension.");
            }
            $Vqzscwux20an = "\\Dompdf\\Helpers::" . $Vqzscwux20an;
        }

        set_error_handler(array("\\Dompdf\\Helpers", "record_warnings"));
        $Vaqqrlqabmyo = call_user_func($Vqzscwux20an, $Vumy2xhehmwp);

        if ($Vaqqrlqabmyo) {
            imageinterlace($Vaqqrlqabmyo, false);

            $V3h3ilzzwl20 = $this->_dompdf->getOptions()->getTempDir();
            $Vzelhepcnuf3 = tempnam($V3h3ilzzwl20, "{$Vky1xzjrvbn4}dompdf_img_");
            @unlink($Vzelhepcnuf3);
            $Vnbqjwe42int = "$Vzelhepcnuf3.png";
            $this->_image_cache[] = $Vnbqjwe42int;

            imagepng($Vaqqrlqabmyo, $Vnbqjwe42int);
            imagedestroy($Vaqqrlqabmyo);
        } else {
            $Vnbqjwe42int = Cache::$Vnnsqq0ncoc0;
        }

        restore_error_handler();

        return $Vnbqjwe42int;
    }

    
    public function rectangle($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = array())
    {
        $this->_set_stroke_color($V3poxlnogtlh);
        $this->_set_line_style($Vtt4kvdwuqqh, "butt", "", $Vkvw5zjrwkdm);
        $this->_pdf->rectangle($V4wnp2r2nst5, $this->y($Vuua0v2znlr51) - $V2pgp3ppbjsi, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    public function filled_rectangle($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V3poxlnogtlh)
    {
        $this->_set_fill_color($V3poxlnogtlh);
        $this->_pdf->filledRectangle($V4wnp2r2nst5, $this->y($Vuua0v2znlr51) - $V2pgp3ppbjsi, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        $this->_set_fill_transparency("Normal", $this->_current_opacity);
    }

    
    public function clipping_rectangle($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi)
    {
        $this->_pdf->clippingRectangle($V4wnp2r2nst5, $this->y($Vuua0v2znlr51) - $V2pgp3ppbjsi, $V5ymvwogwh5y, $V2pgp3ppbjsi);
    }

    
    public function clipping_roundrectangle($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vwt5bv33jejh, $Vqwxulammck0, $V5ugmqeqrvmq, $Vumwapn4ocuu)
    {
        $this->_pdf->clippingRectangleRounded($V4wnp2r2nst5, $this->y($Vuua0v2znlr51) - $V2pgp3ppbjsi, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vwt5bv33jejh, $Vqwxulammck0, $V5ugmqeqrvmq, $Vumwapn4ocuu);
    }

    
    public function clipping_end()
    {
        $this->_pdf->clippingEnd();
    }

    
    public function save()
    {
        $this->_pdf->saveState();
    }

    
    public function restore()
    {
        $this->_pdf->restoreState();
    }

    
    public function rotate($Vvb4ibm25tpf, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $this->_pdf->rotate($Vvb4ibm25tpf, $Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    
    public function skew($Vvb4ibm25tpf_x, $Vvb4ibm25tpf_y, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $this->_pdf->skew($Vvb4ibm25tpf_x, $Vvb4ibm25tpf_y, $Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    
    public function scale($Vb01jpbrlun1, $Vt5g1id0c1cp, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $this->_pdf->scale($Vb01jpbrlun1, $Vt5g1id0c1cp, $Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    
    public function translate($Vbs1pcpjo5lt, $Vml2vjgadh2o)
    {
        $this->_pdf->translate($Vbs1pcpjo5lt, $Vml2vjgadh2o);
    }

    
    public function transform($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1)
    {
        $this->_pdf->transform(array($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1));
    }

    
    public function polygon($Vz0kp11gbnu4, $V3poxlnogtlh, $Vtt4kvdwuqqh = null, $Vkvw5zjrwkdm = array(), $Vtmlsxxw3ne1ill = false)
    {
        $this->_set_fill_color($V3poxlnogtlh);
        $this->_set_stroke_color($V3poxlnogtlh);

        
        for ($V0ixz2v5mxzy = 1; $V0ixz2v5mxzy < count($Vz0kp11gbnu4); $V0ixz2v5mxzy += 2) {
            $Vz0kp11gbnu4[$V0ixz2v5mxzy] = $this->y($Vz0kp11gbnu4[$V0ixz2v5mxzy]);
        }

        $this->_pdf->polygon($Vz0kp11gbnu4, count($Vz0kp11gbnu4) / 2, $Vtmlsxxw3ne1ill);

        $this->_set_fill_transparency("Normal", $this->_current_opacity);
        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    public function circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vapguowxhnfz, $V3poxlnogtlh, $Vtt4kvdwuqqh = null, $Vkvw5zjrwkdm = null, $Vtmlsxxw3ne1ill = false)
    {
        $this->_set_fill_color($V3poxlnogtlh);
        $this->_set_stroke_color($V3poxlnogtlh);

        if (!$Vtmlsxxw3ne1ill && isset($Vtt4kvdwuqqh)) {
            $this->_set_line_style($Vtt4kvdwuqqh, "round", "round", $Vkvw5zjrwkdm);
        }

        $this->_pdf->ellipse($Vmm2pe5l4str, $this->y($Vuua0v2znlr5), $Vapguowxhnfz, 0, 0, 8, 0, 360, 1, $Vtmlsxxw3ne1ill);

        $this->_set_fill_transparency("Normal", $this->_current_opacity);
        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    public function image($Vz1jukgekuy3, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vbjhyqj5trxb = "normal")
    {
        list($Vtt4kvdwuqqh, $V2pgp3ppbjsieight, $Vky1xzjrvbn4) = Helpers::dompdf_getimagesize($Vz1jukgekuy3, $this->get_dompdf()->getHttpContext());

        $Vngrhfhlmiygebug_png = $this->_dompdf->getOptions()->getDebugPng();

        if ($Vngrhfhlmiygebug_png) {
            print "[image:$Vz1jukgekuy3|$Vtt4kvdwuqqh|$V2pgp3ppbjsieight|$Vky1xzjrvbn4]";
        }

        switch ($Vky1xzjrvbn4) {
            case "jpeg":
                if ($Vngrhfhlmiygebug_png) {
                    print '!!!jpg!!!';
                }
                $this->_pdf->addJpegFromFile($Vz1jukgekuy3, $Vmm2pe5l4str, $this->y($Vuua0v2znlr5) - $V2pgp3ppbjsi, $V5ymvwogwh5y, $V2pgp3ppbjsi);
                break;

            case "gif":
            
            case "bmp":
                if ($Vngrhfhlmiygebug_png) print '!!!bmp or gif!!!';
                
                $Vz1jukgekuy3 = $this->_convert_gif_bmp_to_png($Vz1jukgekuy3, $Vky1xzjrvbn4);

            case "png":
                if ($Vngrhfhlmiygebug_png) print '!!!png!!!';

                $this->_pdf->addPngFromFile($Vz1jukgekuy3, $Vmm2pe5l4str, $this->y($Vuua0v2znlr5) - $V2pgp3ppbjsi, $V5ymvwogwh5y, $V2pgp3ppbjsi);
                break;

            case "svg":
                if ($Vngrhfhlmiygebug_png) print '!!!SVG!!!';

                $this->_pdf->addSvgFromFile($Vz1jukgekuy3, $Vmm2pe5l4str, $this->y($Vuua0v2znlr5) - $V2pgp3ppbjsi, $V5ymvwogwh5y, $V2pgp3ppbjsi);
                break;

            default:
                if ($Vngrhfhlmiygebug_png) print '!!!unknown!!!';
        }
    }

    
    public function text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc, $Vtmlsxxw3ne1ont, $Vkgj34o34uaw, $V3poxlnogtlh = array(0, 0, 0), $V5ymvwogwh5yord_space = 0.0, $Vdiqkcy1hsm4har_space = 0.0, $Vvb4ibm25tpf = 0.0)
    {
        $V0xtvw1d0eq2 = $this->_pdf;

        $this->_set_fill_color($V3poxlnogtlh);

        $Vtmlsxxw3ne1ont .= ".afm";
        $V0xtvw1d0eq2->selectFont($Vtmlsxxw3ne1ont);

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        $V0xtvw1d0eq2->addText($Vmm2pe5l4str, $this->y($Vuua0v2znlr5) - $V0xtvw1d0eq2->getFontHeight($Vkgj34o34uaw), $Vkgj34o34uaw, $Vnjapcj4bkpc, $Vvb4ibm25tpf, $V5ymvwogwh5yord_space, $Vdiqkcy1hsm4har_space);

        $this->_set_fill_transparency("Normal", $this->_current_opacity);
    }

    
    public function javascript($Vdiqkcy1hsm4ode)
    {
        $this->_pdf->addJavascript($Vdiqkcy1hsm4ode);
    }

    

    
    public function add_named_dest($V4dkbhpdu11qnchorname)
    {
        $this->_pdf->addDestination($V4dkbhpdu11qnchorname, "Fit");
    }

    
    public function add_link($Vop22rgf5euu, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vtt4kvdwuqqh, $V2pgp3ppbjsieight)
    {
        $Vuua0v2znlr5 = $this->y($Vuua0v2znlr5) - $V2pgp3ppbjsieight;

        if (strpos($Vop22rgf5euu, '#') === 0) {
            
            $Vreuchxnm2nm = substr($Vop22rgf5euu, 1);
            if ($Vreuchxnm2nm) {
                $this->_pdf->addInternalLink($Vreuchxnm2nm, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vmm2pe5l4str + $Vtt4kvdwuqqh, $Vuua0v2znlr5 + $V2pgp3ppbjsieight);
            }
        } else {
            $this->_pdf->addLink(rawurldecode($Vop22rgf5euu), $Vmm2pe5l4str, $Vuua0v2znlr5, $Vmm2pe5l4str + $Vtt4kvdwuqqh, $Vuua0v2znlr5 + $V2pgp3ppbjsieight);
        }
    }

    
    public function get_text_width($Vnjapcj4bkpc, $Vtmlsxxw3ne1ont, $Vkgj34o34uaw, $V5ymvwogwh5yord_spacing = 0, $Vdiqkcy1hsm4har_spacing = 0)
    {
        $this->_pdf->selectFont($Vtmlsxxw3ne1ont);
        return $this->_pdf->getTextWidth($Vkgj34o34uaw, $Vnjapcj4bkpc, $V5ymvwogwh5yord_spacing, $Vdiqkcy1hsm4har_spacing);
    }

    
    public function register_string_subset($Vtmlsxxw3ne1ont, $Vo3pamb05rqg)
    {
        $this->_pdf->registerText($Vtmlsxxw3ne1ont, $Vo3pamb05rqg);
    }

    
    public function get_font_height($Vtmlsxxw3ne1ont, $Vkgj34o34uaw)
    {
        $this->_pdf->selectFont($Vtmlsxxw3ne1ont);

        $V4j2ohhe2azc = $this->_dompdf->getOptions()->getFontHeightRatio();
        return $this->_pdf->getFontHeight($Vkgj34o34uaw) * $V4j2ohhe2azc;
    }

    

    
    public function get_font_baseline($Vtmlsxxw3ne1ont, $Vkgj34o34uaw)
    {
        $V4j2ohhe2azc = $this->_dompdf->getOptions()->getFontHeightRatio();
        return $this->get_font_height($Vtmlsxxw3ne1ont, $Vkgj34o34uaw) / $V4j2ohhe2azc;
    }

    
    public function page_text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc, $Vtmlsxxw3ne1ont, $Vkgj34o34uaw, $V3poxlnogtlh = array(0, 0, 0), $V5ymvwogwh5yord_space = 0.0, $Vdiqkcy1hsm4har_space = 0.0, $Vvb4ibm25tpf = 0.0)
    {
        $V5l1v13bikva = "text";
        $this->_page_text[] = compact("_t", "x", "y", "text", "font", "size", "color", "word_space", "char_space", "angle");
    }

    
    public function page_script($Vdiqkcy1hsm4ode, $Vky1xzjrvbn4 = "text/php")
    {
        $V5l1v13bikva = "script";
        $this->_page_text[] = compact("_t", "code", "type");
    }

    
    public function new_page()
    {
        $this->_page_number++;
        $this->_page_count++;

        $Vaamzcof1atz = $this->_pdf->newPage();
        $this->_pages[] = $Vaamzcof1atz;
        return $Vaamzcof1atz;
    }

    
    protected function _add_page_text()
    {
        if (!count($this->_page_text)) {
            return;
        }

        $Vrgtvfxdkuag = 1;
        $Vqfltxpxjekkval = null;

        foreach ($this->_pages as $Vqw0mzuejanc) {
            $this->reopen_object($Vqw0mzuejanc);

            foreach ($this->_page_text as $Vgzddiwybwv4) {
                extract($Vgzddiwybwv4);

                switch ($V5l1v13bikva) {
                    case "text":
                        $Vnjapcj4bkpc = str_replace(array("{PAGE_NUM}", "{PAGE_COUNT}"),
                            array($Vrgtvfxdkuag, $this->_page_count), $Vnjapcj4bkpc);
                        $this->text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc, $Vtmlsxxw3ne1ont, $Vkgj34o34uaw, $V3poxlnogtlh, $V5ymvwogwh5yord_space, $Vdiqkcy1hsm4har_space, $Vvb4ibm25tpf);
                        break;

                    case "script":
                        if (!$Vqfltxpxjekkval) {
                            $Vqfltxpxjekkval = new PhpEvaluator($this);
                        }
                        $Vqfltxpxjekkval->evaluate($Vdiqkcy1hsm4ode, array('PAGE_NUM' => $Vrgtvfxdkuag, 'PAGE_COUNT' => $this->_page_count));
                        break;
                }
            }

            $this->close_object();
            $Vrgtvfxdkuag++;
        }
    }

    
    public function stream($Vnbqjwe42int = "document.pdf", $V3vmzyblbtdy = array())
    {
        if (headers_sent()) {
            die("Unable to stream pdf: headers already sent");
        }

        if (!isset($V3vmzyblbtdy["compress"])) $V3vmzyblbtdy["compress"] = true;
        if (!isset($V3vmzyblbtdy["Attachment"])) $V3vmzyblbtdy["Attachment"] = true;

        $this->_add_page_text();

        $Vngrhfhlmiygebug = !$V3vmzyblbtdy['compress'];
        $Vj0eqma35tbv = ltrim($this->_pdf->output($Vngrhfhlmiygebug));

        header("Cache-Control: private");
        header("Content-Type: application/pdf");
        header("Content-Length: " . mb_strlen($Vj0eqma35tbv, "8bit"));

        $Vnbqjwe42int = str_replace(array("\n", "'"), "", basename($Vnbqjwe42int, ".pdf")) . ".pdf";
        $V4dkbhpdu11qttachment = $V3vmzyblbtdy["Attachment"] ? "attachment" : "inline";
        header(Helpers::buildContentDispositionHeader($V4dkbhpdu11qttachment, $Vnbqjwe42int));

        echo $Vj0eqma35tbv;
        flush();
    }

    
    public function output($V3vmzyblbtdy = array())
    {
        if (!isset($V3vmzyblbtdy["compress"])) $V3vmzyblbtdy["compress"] = true;

        $this->_add_page_text();

        $Vngrhfhlmiygebug = !$V3vmzyblbtdy['compress'];

        return $this->_pdf->output($Vngrhfhlmiygebug);
    }

    
    public function get_messages()
    {
        return $this->_pdf->messages;
    }
}
