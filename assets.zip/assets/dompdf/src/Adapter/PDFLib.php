<?php


namespace Dompdf\Adapter;

use Dompdf\Canvas;
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception;
use Dompdf\Image\Cache;
use Dompdf\PhpEvaluator;


class PDFLib implements Canvas
{

    
    static public $Vfh5zaiuo2gy = array(); 

    
    static $Vu24barbsr0s = true;

    
    private $V3zitx0n32g4;

    
    private $Vsk1sogv33gw;

    
    private $Vsvpj2p1padt;

    
    private $Vxc0qtxc1w0o;

    
    private $Vhuqn53j4zao;

    
    private $V5sn1xatqzzv;

    
    private $Vhooge52dloc;

    
    private $Vimsucsz0113;

    
    private $Vw13ppq0kwxl;

    
    private $V4ofnlegtn40;

    
    private $V5d4ajchtydw;

    
    private $V0bbfvzvacvn = array();

    
    private $Vhefvyusmcj3;

    
    private $Vm2e5vffkgjz;

    
    private $Vzv00pgujk3p;

    
    private $Vm3npf2jtnwh;

    
    public function __construct($V54vxutwmj54 = "letter", $V00gcroe4i4s = "portrait", Dompdf $Vodc45cwlwwh)
    {
        if (is_array($V54vxutwmj54)) {
            $Vkgj34o34uaw = $V54vxutwmj54;
        } else if (isset(self::$Vfh5zaiuo2gy[mb_strtolower($V54vxutwmj54)])) {
            $Vkgj34o34uaw = self::$Vfh5zaiuo2gy[mb_strtolower($V54vxutwmj54)];
        } else {
            $Vkgj34o34uaw = self::$Vfh5zaiuo2gy["letter"];
        }

        if (mb_strtolower($V00gcroe4i4s) === "landscape") {
            list($Vkgj34o34uaw[2], $Vkgj34o34uaw[3]) = array($Vkgj34o34uaw[3], $Vkgj34o34uaw[2]);
        }

        $this->_width = $Vkgj34o34uaw[2] - $Vkgj34o34uaw[0];
        $this->_height = $Vkgj34o34uaw[3] - $Vkgj34o34uaw[1];

        $this->_dompdf = $Vodc45cwlwwh;

        $this->_pdf = new \PDFLib();

        $Vzgyllmc5hrq = $Vodc45cwlwwh->getOptions()->getPdflibLicense();
        if (strlen($Vzgyllmc5hrq) > 0) {
            $this->_pdf->set_parameter("license", $Vzgyllmc5hrq);
        }

        $this->_pdf->set_parameter("textformat", "utf8");
        $this->_pdf->set_parameter("fontwarning", "false");

        
        $this->_pdf->set_info("Producer Addendum", sprintf("%s + PDFLib", $Vodc45cwlwwh->version));

        
        $V1zgfueihm3c = @date_default_timezone_get();
        date_default_timezone_set("UTC");
        $this->_pdf->set_info("Date", date("Y-m-d"));
        date_default_timezone_set($V1zgfueihm3c);

        if (self::$Vu24barbsr0s) {
            $this->_pdf->begin_document("", "");
        } else {
            $V3h3ilzzwl20 = $this->_dompdf->getOptions()->getTempDir();
            $Vzelhepcnuf3 = tempnam($V3h3ilzzwl20, "libdompdf_pdf_");
            @unlink($Vzelhepcnuf3);
            $this->_file = "$Vzelhepcnuf3.pdf";
            $this->_pdf->begin_document($this->_file, "");
        }

        $this->_pdf->begin_page_ext($this->_width, $this->_height, "");

        $this->_page_number = $this->_page_count = 1;
        $this->_page_text = array();

        $this->_imgs = array();
        $this->_fonts = array();
        $this->_objs = array();
    }

    
    function get_dompdf()
    {
        return $this->_dompdf;
    }

    
    protected function _close()
    {
        $this->_place_objects();

        
        $this->_pdf->suspend_page("");
        for ($V2d1s45w0hjo = 1; $V2d1s45w0hjo <= $this->_page_count; $V2d1s45w0hjo++) {
            $this->_pdf->resume_page("pagenumber=$V2d1s45w0hjo");
            $this->_pdf->end_page_ext("");
        }

        $this->_pdf->end_document("");
    }


    
    public function get_pdflib()
    {
        return $this->_pdf;
    }

    
    public function add_info($Vovi5zubtdii, $Veugw2h43vxz)
    {
        $this->_pdf->set_info($Vovi5zubtdii, $Veugw2h43vxz);
    }

    
    public function open_object()
    {
        $this->_pdf->suspend_page("");
        $Vaamzcof1atz = $this->_pdf->begin_template($this->_width, $this->_height);
        $this->_pdf->save();
        $this->_objs[$Vaamzcof1atz] = array("start_page" => $this->_page_number);
        return $Vaamzcof1atz;
    }

    
    public function reopen_object($V0e5yoazsdyk)
    {
        throw new Exception("PDFLib does not support reopening objects.");
    }

    
    public function close_object()
    {
        $this->_pdf->restore();
        $this->_pdf->end_template();
        $this->_pdf->resume_page("pagenumber=" . $this->_page_number);
    }

    
    public function add_object($V0e5yoazsdyk, $Vhjnp30tipbb = 'all')
    {

        if (mb_strpos($Vhjnp30tipbb, "next") !== false) {
            $this->_objs[$V0e5yoazsdyk]["start_page"]++;
            $Vhjnp30tipbb = str_replace("next", "", $Vhjnp30tipbb);
            if ($Vhjnp30tipbb == "") {
                $Vhjnp30tipbb = "add";
            }
        }

        $this->_objs[$V0e5yoazsdyk]["where"] = $Vhjnp30tipbb;
    }

    
    public function stop_object($V0e5yoazsdyk)
    {

        if (!isset($this->_objs[$V0e5yoazsdyk])) {
            return;
        }

        $Vyaw1hu5o3zh = $this->_objs[$V0e5yoazsdyk]["start_page"];
        $Vhjnp30tipbb = $this->_objs[$V0e5yoazsdyk]["where"];

        
        if ($this->_page_number >= $Vyaw1hu5o3zh &&
            (($this->_page_number % 2 == 0 && $Vhjnp30tipbb === "even") ||
                ($this->_page_number % 2 == 1 && $Vhjnp30tipbb === "odd") ||
                ($Vhjnp30tipbb === "all"))
        ) {
            $this->_pdf->fit_image($V0e5yoazsdyk, 0, 0, "");
        }

        $this->_objs[$V0e5yoazsdyk] = null;
        unset($this->_objs[$V0e5yoazsdyk]);
    }

    
    protected function _place_objects()
    {

        foreach ($this->_objs as $Vqiatkt0jg5p => $V2d1s45w0hjorops) {
            $Vyaw1hu5o3zh = $V2d1s45w0hjorops["start_page"];
            $Vhjnp30tipbb = $V2d1s45w0hjorops["where"];

            
            if ($this->_page_number >= $Vyaw1hu5o3zh &&
                (($this->_page_number % 2 == 0 && $Vhjnp30tipbb === "even") ||
                    ($this->_page_number % 2 == 1 && $Vhjnp30tipbb === "odd") ||
                    ($Vhjnp30tipbb === "all"))
            ) {
                $this->_pdf->fit_image($Vqiatkt0jg5p, 0, 0, "");
            }
        }

    }

    
    public function get_width()
    {
        return $this->_width;
    }

    
    public function get_height()
    {
        return $this->_height;
    }

    
    public function get_page_number()
    {
        return $this->_page_number;
    }

    
    public function get_page_count()
    {
        return $this->_page_count;
    }

    
    public function set_page_number($Vaucqj0hftp5)
    {
        $this->_page_number = (int)$Vaucqj0hftp5;
    }

    
    public function set_page_count($V4wukmcy3ij2)
    {
        $this->_page_count = (int)$V4wukmcy3ij2;
    }

    
    protected function _set_line_style($Vtt4kvdwuqqh, $Vryn5vp4knpl, $Vo3ls5ffiiu2, $V3gef50hyo1a)
    {
        if (count($V3gef50hyo1a) == 1) {
            $V3gef50hyo1a[] = $V3gef50hyo1a[0];
        }

        if (count($V3gef50hyo1a) > 1) {
            $this->_pdf->setdashpattern("dasharray={" . implode(" ", $V3gef50hyo1a) . "}");
        } else {
            $this->_pdf->setdash(0, 0);
        }

        switch ($Vo3ls5ffiiu2) {
            case "miter":
                $this->_pdf->setlinejoin(0);
                break;

            case "round":
                $this->_pdf->setlinejoin(1);
                break;

            case "bevel":
                $this->_pdf->setlinejoin(2);
                break;

            default:
                break;
        }

        switch ($Vryn5vp4knpl) {
            case "butt":
                $this->_pdf->setlinecap(0);
                break;

            case "round":
                $this->_pdf->setlinecap(1);
                break;

            case "square":
                $this->_pdf->setlinecap(2);
                break;

            default:
                break;
        }

        $this->_pdf->setlinewidth($Vtt4kvdwuqqh);
    }

    
    protected function _set_stroke_color($V3poxlnogtlh)
    {
        if ($this->_last_stroke_color == $V3poxlnogtlh) {
            
        }

        $Visj32pb1rwu = isset($V3poxlnogtlh["alpha"]) ? $V3poxlnogtlh["alpha"] : 1;
        if (isset($this->_current_opacity)) {
            $Visj32pb1rwu *= $this->_current_opacity;
        }

        $this->_last_stroke_color = $V3poxlnogtlh;

        if (isset($V3poxlnogtlh[3])) {
            $Vky1xzjrvbn4 = "cmyk";
            list($Vh1ippl03amh, $Vpueagypxyip, $Vb3dp4cv2edo, $V3mpv0tobh22) = array($V3poxlnogtlh[0], $V3poxlnogtlh[1], $V3poxlnogtlh[2], $V3poxlnogtlh[3]);
        } elseif (isset($V3poxlnogtlh[2])) {
            $Vky1xzjrvbn4 = "rgb";
            list($Vh1ippl03amh, $Vpueagypxyip, $Vb3dp4cv2edo, $V3mpv0tobh22) = array($V3poxlnogtlh[0], $V3poxlnogtlh[1], $V3poxlnogtlh[2], null);
        } else {
            $Vky1xzjrvbn4 = "gray";
            list($Vh1ippl03amh, $Vpueagypxyip, $Vb3dp4cv2edo, $V3mpv0tobh22) = array($V3poxlnogtlh[0], $V3poxlnogtlh[1], null, null);
        }

        $this->_set_stroke_opacity($Visj32pb1rwu);
        $this->_pdf->setcolor("stroke", $Vky1xzjrvbn4, $Vh1ippl03amh, $Vpueagypxyip, $Vb3dp4cv2edo, $V3mpv0tobh22);
    }

    
    protected function _set_fill_color($V3poxlnogtlh)
    {
        if ($this->_last_fill_color == $V3poxlnogtlh) {
            return;
        }

        $Visj32pb1rwu = isset($V3poxlnogtlh["alpha"]) ? $V3poxlnogtlh["alpha"] : 1;
        if (isset($this->_current_opacity)) {
            $Visj32pb1rwu *= $this->_current_opacity;
        }

        $this->_last_fill_color = $V3poxlnogtlh;

        if (isset($V3poxlnogtlh[3])) {
            $Vky1xzjrvbn4 = "cmyk";
            list($Vh1ippl03amh, $Vpueagypxyip, $Vb3dp4cv2edo, $V3mpv0tobh22) = array($V3poxlnogtlh[0], $V3poxlnogtlh[1], $V3poxlnogtlh[2], $V3poxlnogtlh[3]);
        } elseif (isset($V3poxlnogtlh[2])) {
            $Vky1xzjrvbn4 = "rgb";
            list($Vh1ippl03amh, $Vpueagypxyip, $Vb3dp4cv2edo, $V3mpv0tobh22) = array($V3poxlnogtlh[0], $V3poxlnogtlh[1], $V3poxlnogtlh[2], null);
        } else {
            $Vky1xzjrvbn4 = "gray";
            list($Vh1ippl03amh, $Vpueagypxyip, $Vb3dp4cv2edo, $V3mpv0tobh22) = array($V3poxlnogtlh[0], $V3poxlnogtlh[1], null, null);
        }

        $this->_set_fill_opacity($Visj32pb1rwu);
        $this->_pdf->setcolor("fill", $Vky1xzjrvbn4, $Vh1ippl03amh, $Vpueagypxyip, $Vb3dp4cv2edo, $V3mpv0tobh22);
    }

    
    public function _set_fill_opacity($Vhrfbgup2xix, $V4rgua51nlxl = "Normal")
    {
        if ($V4rgua51nlxl === "Normal") {
            $this->_set_gstate("opacityfill=$Vhrfbgup2xix");
        }
    }

    
    public function _set_stroke_opacity($Vhrfbgup2xix, $V4rgua51nlxl = "Normal")
    {
        if ($V4rgua51nlxl === "Normal") {
            $this->_set_gstate("opacitystroke=$Vhrfbgup2xix");
        }
    }

    
    public function set_opacity($Vhrfbgup2xix, $V4rgua51nlxl = "Normal")
    {
        if ($V4rgua51nlxl === "Normal") {
            $this->_set_gstate("opacityfill=$Vhrfbgup2xix opacitystroke=$Vhrfbgup2xix");
            $this->_current_opacity = $Vhrfbgup2xix;
        }
    }

    
    public function _set_gstate($Vvsvqz0idpjf)
    {
        if (($Vs5kiplwjh4v = array_search($Vvsvqz0idpjf, $this->_gstates)) === false) {
            $Vs5kiplwjh4v = $this->_pdf->create_gstate($Vvsvqz0idpjf);
            $this->_gstates[$Vs5kiplwjh4v] = $Vvsvqz0idpjf;
        }
        return $this->_pdf->set_gstate($Vs5kiplwjh4v);
    }

    public function set_default_view($V5op4eazb4xu, $V3vmzyblbtdy = array())
    {
        
        
        
        
    }

    
    protected function _load_font($Vfsinbbqzbga, $Vpxiihrwof30 = null, $V3vmzyblbtdy = "")
    {
        
        if ($this->_pdf->get_parameter("FontOutline", 1) === "") {
            $Vijnp4pplof2 = $this->_dompdf->getFontMetrics()->getFontFamilies();
            foreach ($Vijnp4pplof2 as $V0bqd3huwfyd) {
                foreach ($V0bqd3huwfyd as $Voheucoc3jxv) {
                    $Vl4v10qkm02m = basename($Voheucoc3jxv);
                    $Vougvkmrdlgv = null;

                    
                    if (file_exists("$Voheucoc3jxv.ttf")) {
                        $Vvc4qjzksm20 = "$Voheucoc3jxv.ttf";

                    } else if (file_exists("$Voheucoc3jxv.TTF")) {
                        $Vvc4qjzksm20 = "$Voheucoc3jxv.TTF";

                    } else if (file_exists("$Voheucoc3jxv.pfb")) {
                        $Vvc4qjzksm20 = "$Voheucoc3jxv.pfb";
                        if (file_exists("$Voheucoc3jxv.afm")) {
                            $Vougvkmrdlgv = "$Voheucoc3jxv.afm";
                        }

                    } else if (file_exists("$Voheucoc3jxv.PFB")) {
                        $Vvc4qjzksm20 = "$Voheucoc3jxv.PFB";
                        if (file_exists("$Voheucoc3jxv.AFM")) {
                            $Vougvkmrdlgv = "$Voheucoc3jxv.AFM";
                        }
                    } else {
                        continue;
                    }

                    $this->_pdf->set_parameter("FontOutline", "\{$Vl4v10qkm02m\}=\{$Vvc4qjzksm20\}");

                    if (!is_null($Vougvkmrdlgv)) {
                        $this->_pdf->set_parameter("FontAFM", "\{$Vl4v10qkm02m\}=\{$Vougvkmrdlgv\}");
                    }
                }
            }
        }

        
        
        $Vrhznaa0orx3 = strtolower(basename($Vfsinbbqzbga));
        if (in_array($Vrhznaa0orx3, DOMPDF::$Vktosnxwbjcy)) {
            $Vfsinbbqzbga = basename($Vfsinbbqzbga);
        } else {
            
            $V3vmzyblbtdy .= " embedding=true";
        }

        if (is_null($Vpxiihrwof30)) {
            
            
            if (strlen($this->_dompdf->getOptions()->getPdflibLicense()) > 0) {
                $Vpxiihrwof30 = "unicode";
            } else {
                $Vpxiihrwof30 = "auto";
            }
        }

        $Vbd2mxirzq2d = "$Vfsinbbqzbga:$Vpxiihrwof30:$V3vmzyblbtdy";

        if (isset($this->_fonts[$Vbd2mxirzq2d])) {
            return $this->_fonts[$Vbd2mxirzq2d];
        } else {
            $this->_fonts[$Vbd2mxirzq2d] = $this->_pdf->load_font($Vfsinbbqzbga, $Vpxiihrwof30, $V3vmzyblbtdy);
            return $this->_fonts[$Vbd2mxirzq2d];
        }
    }

    
    protected function y($Vuua0v2znlr5)
    {
        return $this->_height - $Vuua0v2znlr5;
    }

    
    public function line($V4wnp2r2nst5, $Vuua0v2znlr51, $V2kam3hj2q41, $Vuua0v2znlr52, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = null)
    {
        $this->_set_line_style($Vtt4kvdwuqqh, "butt", "", $Vkvw5zjrwkdm);
        $this->_set_stroke_color($V3poxlnogtlh);

        $Vuua0v2znlr51 = $this->y($Vuua0v2znlr51);
        $Vuua0v2znlr52 = $this->y($Vuua0v2znlr52);

        $this->_pdf->moveto($V4wnp2r2nst5, $Vuua0v2znlr51);
        $this->_pdf->lineto($V2kam3hj2q41, $Vuua0v2znlr52);
        $this->_pdf->stroke();

        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    public function arc($V4wnp2r2nst5, $Vuua0v2znlr51, $Vapguowxhnfz, $V1wjrukdrpg5, $Vkz1dooibwko, $Ve4azsyeqjqc, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = array())
    {
        $this->_set_line_style($Vtt4kvdwuqqh, "butt", "", $Vkvw5zjrwkdm);
        $this->_set_stroke_color($V3poxlnogtlh);

        $Vuua0v2znlr51 = $this->y($Vuua0v2znlr51);

        $this->_pdf->arc($V4wnp2r2nst5, $Vuua0v2znlr51, $Vapguowxhnfz, $Vkz1dooibwko, $Ve4azsyeqjqc);
        $this->_pdf->stroke();

        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    public function rectangle($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = null)
    {
        $this->_set_stroke_color($V3poxlnogtlh);
        $this->_set_line_style($Vtt4kvdwuqqh, "butt", "", $Vkvw5zjrwkdm);

        $Vuua0v2znlr51 = $this->y($Vuua0v2znlr51) - $V2pgp3ppbjsi;

        $this->_pdf->rect($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        $this->_pdf->stroke();

        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    public function filled_rectangle($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V3poxlnogtlh)
    {
        $this->_set_fill_color($V3poxlnogtlh);

        $Vuua0v2znlr51 = $this->y($Vuua0v2znlr51) - $V2pgp3ppbjsi;

        $this->_pdf->rect(floatval($V4wnp2r2nst5), floatval($Vuua0v2znlr51), floatval($V5ymvwogwh5y), floatval($V2pgp3ppbjsi));
        $this->_pdf->fill();

        $this->_set_fill_transparency("Normal", $this->_current_opacity);
    }

    
    public function clipping_rectangle($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi)
    {
        $this->_pdf->save();

        $Vuua0v2znlr51 = $this->y($Vuua0v2znlr51) - $V2pgp3ppbjsi;

        $this->_pdf->rect(floatval($V4wnp2r2nst5), floatval($Vuua0v2znlr51), floatval($V5ymvwogwh5y), floatval($V2pgp3ppbjsi));
        $this->_pdf->clip();
    }

    
    public function clipping_roundrectangle($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vwt5bv33jejh, $Vqwxulammck0, $V5ugmqeqrvmq, $Vumwapn4ocuu)
    {
        
        $this->clipping_rectangle($V4wnp2r2nst5, $Vuua0v2znlr51, $V5ymvwogwh5y, $V2pgp3ppbjsi);
    }

    
    public function clipping_end()
    {
        $this->_pdf->restore();
    }

    
    public function save()
    {
        $this->_pdf->save();
    }

    function restore()
    {
        $this->_pdf->restore();
    }

    
    public function rotate($Vvb4ibm25tpf, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $V2d1s45w0hjodf = $this->_pdf;
        $V2d1s45w0hjodf->translate($Vmm2pe5l4str, $this->_height - $Vuua0v2znlr5);
        $V2d1s45w0hjodf->rotate(-$Vvb4ibm25tpf);
        $V2d1s45w0hjodf->translate(-$Vmm2pe5l4str, -$this->_height + $Vuua0v2znlr5);
    }

    
    public function skew($Vvb4ibm25tpf_x, $Vvb4ibm25tpf_y, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $V2d1s45w0hjodf = $this->_pdf;
        $V2d1s45w0hjodf->translate($Vmm2pe5l4str, $this->_height - $Vuua0v2znlr5);
        $V2d1s45w0hjodf->skew($Vvb4ibm25tpf_y, $Vvb4ibm25tpf_x); 
        $V2d1s45w0hjodf->translate(-$Vmm2pe5l4str, -$this->_height + $Vuua0v2znlr5);
    }

    
    public function scale($Vb01jpbrlun1, $Vt5g1id0c1cp, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $V2d1s45w0hjodf = $this->_pdf;
        $V2d1s45w0hjodf->translate($Vmm2pe5l4str, $this->_height - $Vuua0v2znlr5);
        $V2d1s45w0hjodf->scale($Vb01jpbrlun1, $Vt5g1id0c1cp);
        $V2d1s45w0hjodf->translate(-$Vmm2pe5l4str, -$this->_height + $Vuua0v2znlr5);
    }

    
    public function translate($Vbs1pcpjo5lt, $Vml2vjgadh2o)
    {
        $this->_pdf->translate($Vbs1pcpjo5lt, -$Vml2vjgadh2o);
    }

    
    public function transform($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1)
    {
        $this->_pdf->concat($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1);
    }

    
    public function polygon($V2d1s45w0hjooints, $V3poxlnogtlh, $Vtt4kvdwuqqh = null, $Vkvw5zjrwkdm = null, $Vtmlsxxw3ne1ill = false)
    {
        $this->_set_fill_color($V3poxlnogtlh);
        $this->_set_stroke_color($V3poxlnogtlh);

        if (!$Vtmlsxxw3ne1ill && isset($Vtt4kvdwuqqh)) {
            $this->_set_line_style($Vtt4kvdwuqqh, "square", "miter", $Vkvw5zjrwkdm);
        }

        $Vuua0v2znlr5 = $this->y(array_pop($V2d1s45w0hjooints));
        $Vmm2pe5l4str = array_pop($V2d1s45w0hjooints);
        $this->_pdf->moveto($Vmm2pe5l4str, $Vuua0v2znlr5);

        while (count($V2d1s45w0hjooints) > 1) {
            $Vuua0v2znlr5 = $this->y(array_pop($V2d1s45w0hjooints));
            $Vmm2pe5l4str = array_pop($V2d1s45w0hjooints);
            $this->_pdf->lineto($Vmm2pe5l4str, $Vuua0v2znlr5);
        }

        if ($Vtmlsxxw3ne1ill) {
            $this->_pdf->fill();
        } else {
            $this->_pdf->closepath_stroke();
        }

        $this->_set_fill_transparency("Normal", $this->_current_opacity);
        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    public function circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vapkwgsb3w3r, $V3poxlnogtlh, $Vtt4kvdwuqqh = null, $Vkvw5zjrwkdm = null, $Vtmlsxxw3ne1ill = false)
    {
        $this->_set_fill_color($V3poxlnogtlh);
        $this->_set_stroke_color($V3poxlnogtlh);

        if (!$Vtmlsxxw3ne1ill && isset($Vtt4kvdwuqqh)) {
            $this->_set_line_style($Vtt4kvdwuqqh, "round", "round", $Vkvw5zjrwkdm);
        }

        $Vuua0v2znlr5 = $this->y($Vuua0v2znlr5);

        $this->_pdf->circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vapkwgsb3w3r);

        if ($Vtmlsxxw3ne1ill) {
            $this->_pdf->fill();
        } else {
            $this->_pdf->stroke();
        }

        $this->_set_fill_transparency("Normal", $this->_current_opacity);
        $this->_set_line_transparency("Normal", $this->_current_opacity);
    }

    
    public function image($Vtafxiaximgz, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vapkwgsb3w3resolution = "normal")
    {
        $V5ymvwogwh5y = (int)$V5ymvwogwh5y;
        $V2pgp3ppbjsi = (int)$V2pgp3ppbjsi;

        $V0hpsd551wjc = Cache::detect_type($Vtafxiaximgz, $this->get_dompdf()->getHttpContext());

        if (!isset($this->_imgs[$Vtafxiaximgz])) {
            $this->_imgs[$Vtafxiaximgz] = $this->_pdf->load_image($V0hpsd551wjc, $Vtafxiaximgz, "");
        }

        $Vz1jukgekuy3 = $this->_imgs[$Vtafxiaximgz];

        $Vuua0v2znlr5 = $this->y($Vuua0v2znlr5) - $V2pgp3ppbjsi;
        $this->_pdf->fit_image($Vz1jukgekuy3, $Vmm2pe5l4str, $Vuua0v2znlr5, 'boxsize={' . "$V5ymvwogwh5y $V2pgp3ppbjsi" . '} fitmethod=entire');
    }

    
    public function text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $V3poxlnogtlh = array(0, 0, 0), $V5ymvwogwh5yord_spacing = 0, $Vdiqkcy1hsm4har_spacing = 0, $Vvb4ibm25tpf = 0)
    {
        $Vtmlsxxw3ne1h = $this->_load_font($Vfsinbbqzbga);

        $this->_pdf->setfont($Vtmlsxxw3ne1h, $Vkgj34o34uaw);
        $this->_set_fill_color($V3poxlnogtlh);

        $Vuua0v2znlr5 = $this->y($Vuua0v2znlr5) - $this->get_font_height($Vfsinbbqzbga, $Vkgj34o34uaw);

        $V5ymvwogwh5yord_spacing = (float)$V5ymvwogwh5yord_spacing;
        $Vdiqkcy1hsm4har_spacing = (float)$Vdiqkcy1hsm4har_spacing;
        $Vvb4ibm25tpf = -(float)$Vvb4ibm25tpf;

        $this->_pdf->fit_textline($Vnjapcj4bkpc, $Vmm2pe5l4str, $Vuua0v2znlr5, "rotate=$Vvb4ibm25tpf wordspacing=$V5ymvwogwh5yord_spacing charspacing=$Vdiqkcy1hsm4har_spacing ");

        $this->_set_fill_transparency("Normal", $this->_current_opacity);
    }

    
    public function javascript($Vdiqkcy1hsm4ode)
    {
        if (strlen($this->_dompdf->getOptions()->getPdflibLicense()) > 0) {
            $this->_pdf->create_action("JavaScript", $Vdiqkcy1hsm4ode);
        }
    }

    
    public function add_named_dest($V4dkbhpdu11qnchorname)
    {
        $this->_pdf->add_nameddest($V4dkbhpdu11qnchorname, "");
    }

    
    public function add_link($Vop22rgf5euu, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vtt4kvdwuqqh, $V2pgp3ppbjsieight)
    {
        $Vuua0v2znlr5 = $this->y($Vuua0v2znlr5) - $V2pgp3ppbjsieight;
        if (strpos($Vop22rgf5euu, '#') === 0) {
            
            $Vreuchxnm2nm = substr($Vop22rgf5euu, 1);
            if ($Vreuchxnm2nm) {
                $this->_pdf->create_annotation($Vmm2pe5l4str, $Vuua0v2znlr5, $Vmm2pe5l4str + $Vtt4kvdwuqqh, $Vuua0v2znlr5 + $V2pgp3ppbjsieight, 'Link',
                    "contents={$Vop22rgf5euu} destname=" . substr($Vop22rgf5euu, 1) . " linewidth=0");
            }
        } else {
            list($V2d1s45w0hjoroto, $V2pgp3ppbjsiost, $V2d1s45w0hjoath, $Voheucoc3jxv) = Helpers::explode_url($Vop22rgf5euu);

            if ($V2d1s45w0hjoroto == "" || $V2d1s45w0hjoroto === "file://") {
                return; 
            }
            $Vop22rgf5euu = Helpers::build_url($V2d1s45w0hjoroto, $V2pgp3ppbjsiost, $V2d1s45w0hjoath, $Voheucoc3jxv);
            $Vop22rgf5euu = '{' . rawurldecode($Vop22rgf5euu) . '}';

            $V4dkbhpdu11qction = $this->_pdf->create_action("URI", "url=" . $Vop22rgf5euu);
            $this->_pdf->create_annotation($Vmm2pe5l4str, $Vuua0v2znlr5, $Vmm2pe5l4str + $Vtt4kvdwuqqh, $Vuua0v2znlr5 + $V2pgp3ppbjsieight, 'Link', "contents={$Vop22rgf5euu} action={activate=$V4dkbhpdu11qction} linewidth=0");
        }
    }

    
    public function get_text_width($Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $V5ymvwogwh5yord_spacing = 0, $V445tnh1qd0p = 0)
    {
        $Vtmlsxxw3ne1h = $this->_load_font($Vfsinbbqzbga);

        
        $Vaucqj0hftp5_spaces = mb_substr_count($Vnjapcj4bkpc, " ");
        $Vngrhfhlmiygelta = $V5ymvwogwh5yord_spacing * $Vaucqj0hftp5_spaces;

        if ($V445tnh1qd0p) {
            $Vaucqj0hftp5_chars = mb_strlen($Vnjapcj4bkpc);
            $Vngrhfhlmiygelta += ($Vaucqj0hftp5_chars - $Vaucqj0hftp5_spaces) * $V445tnh1qd0p;
        }

        return $this->_pdf->stringwidth($Vnjapcj4bkpc, $Vtmlsxxw3ne1h, $Vkgj34o34uaw) + $Vngrhfhlmiygelta;
    }

    
    public function get_font_height($Vfsinbbqzbga, $Vkgj34o34uaw)
    {
        $Vtmlsxxw3ne1h = $this->_load_font($Vfsinbbqzbga);

        $this->_pdf->setfont($Vtmlsxxw3ne1h, $Vkgj34o34uaw);

        $V4dkbhpdu11qsc = $this->_pdf->get_value("ascender", $Vtmlsxxw3ne1h);
        $Vngrhfhlmiygesc = $this->_pdf->get_value("descender", $Vtmlsxxw3ne1h);

        
        $Vapkwgsb3w3ratio = $this->_dompdf->getOptions()->getFontHeightRatio();
        return $Vkgj34o34uaw * ($V4dkbhpdu11qsc - $Vngrhfhlmiygesc) * $Vapkwgsb3w3ratio;
    }

    
    public function get_font_baseline($Vfsinbbqzbga, $Vkgj34o34uaw)
    {
        $Vapkwgsb3w3ratio = $this->_dompdf->getOptions()->getFontHeightRatio();
        return $this->get_font_height($Vfsinbbqzbga, $Vkgj34o34uaw) / $Vapkwgsb3w3ratio * 1.1;
    }

    
    public function page_text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $V3poxlnogtlh = array(0, 0, 0), $V5ymvwogwh5yord_space = 0.0, $Vdiqkcy1hsm4har_space = 0.0, $Vvb4ibm25tpf = 0.0)
    {
        $V5l1v13bikva = "text";
        $this->_page_text[] = compact("_t", "x", "y", "text", "font", "size", "color", "word_space", "char_space", "angle");
    }

    

    
    public function page_script($Vdiqkcy1hsm4ode, $Vky1xzjrvbn4 = "text/php")
    {
        $V5l1v13bikva = "script";
        $this->_page_text[] = compact("_t", "code", "type");
    }

    
    public function new_page()
    {
        
        $this->_place_objects();

        $this->_pdf->suspend_page("");
        $this->_pdf->begin_page_ext($this->_width, $this->_height, "");
        $this->_page_number = ++$this->_page_count;
    }

    
    protected function _add_page_text()
    {
        if (!count($this->_page_text)) {
            return;
        }

        $Vqfltxpxjekkval = null;
        $this->_pdf->suspend_page("");

        for ($V2d1s45w0hjo = 1; $V2d1s45w0hjo <= $this->_page_count; $V2d1s45w0hjo++) {
            $this->_pdf->resume_page("pagenumber=$V2d1s45w0hjo");

            foreach ($this->_page_text as $V2d1s45w0hjot) {
                extract($V2d1s45w0hjot);

                switch ($V5l1v13bikva) {
                    case "text":
                        $Vnjapcj4bkpc = str_replace(array("{PAGE_NUM}", "{PAGE_COUNT}"),
                            array($V2d1s45w0hjo, $this->_page_count), $Vnjapcj4bkpc);
                        $this->text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $V3poxlnogtlh, $V5ymvwogwh5yord_space, $Vdiqkcy1hsm4har_space, $Vvb4ibm25tpf);
                        break;

                    case "script":
                        if (!$Vqfltxpxjekkval) {
                            $Vqfltxpxjekkval = new PHPEvaluator($this);
                        }
                        $Vqfltxpxjekkval->evaluate($Vdiqkcy1hsm4ode, array('PAGE_NUM' => $V2d1s45w0hjo, 'PAGE_COUNT' => $this->_page_count));
                        break;
                }
            }

            $this->_pdf->suspend_page("");
        }

        $this->_pdf->resume_page("pagenumber=" . $this->_page_number);
    }

    
    public function stream($Voheucoc3jxvname = "document.pdf", $V3vmzyblbtdy = array())
    {
        if (headers_sent()) {
            die("Unable to stream pdf: headers already sent");
        }

        if (!isset($V3vmzyblbtdy["compress"])) $V3vmzyblbtdy["compress"] = true;
        if (!isset($V3vmzyblbtdy["Attachment"])) $V3vmzyblbtdy["Attachment"] = true;

        $this->_add_page_text();

        if ($V3vmzyblbtdy["compress"]) {
            $this->_pdf->set_value("compress", 6);
        } else {
            $this->_pdf->set_value("compress", 0);
        }

        $this->_close();

        $Vngrhfhlmiygata = "";

        if (self::$Vu24barbsr0s) {
            $Vngrhfhlmiygata = $this->_pdf->get_buffer();
            $Vkgj34o34uaw = mb_strlen($Vngrhfhlmiygata, "8bit");
        } else {
            $Vkgj34o34uaw = filesize($this->_file);
        }

        header("Cache-Control: private");
        header("Content-Type: application/pdf");
        header("Content-Length: " . $Vkgj34o34uaw);

        $Voheucoc3jxvname = str_replace(array("\n", "'"), "", basename($Voheucoc3jxvname, ".pdf")) . ".pdf";
        $V4dkbhpdu11qttachment = $V3vmzyblbtdy["Attachment"] ? "attachment" : "inline";
        header(Helpers::buildContentDispositionHeader($V4dkbhpdu11qttachment, $Voheucoc3jxvname));

        if (self::$Vu24barbsr0s) {
            echo $Vngrhfhlmiygata;
        } else {
            
            $Vdiqkcy1hsm4hunk = (1 << 21); 
            $Vtmlsxxw3ne1h = fopen($this->_file, "rb");
            if (!$Vtmlsxxw3ne1h) {
                throw new Exception("Unable to load temporary PDF file: " . $this->_file);
            }

            while (!feof($Vtmlsxxw3ne1h)) {
                echo fread($Vtmlsxxw3ne1h, $Vdiqkcy1hsm4hunk);
            }
            fclose($Vtmlsxxw3ne1h);

            
            if ($this->_dompdf->getOptions()->getDebugPng()) {
                print '[pdflib stream unlink ' . $this->_file . ']';
            }
            if (!$this->_dompdf->getOptions()->getDebugKeepTemp()) {
                unlink($this->_file);
            }
            $this->_file = null;
            unset($this->_file);
        }

        flush();
    }

    
    public function output($V3vmzyblbtdy = array())
    {
        if (!isset($V3vmzyblbtdy["compress"])) $V3vmzyblbtdy["compress"] = true;

        $this->_add_page_text();

        if ($V3vmzyblbtdy["compress"]) {
            $this->_pdf->set_value("compress", 6);
        } else {
            $this->_pdf->set_value("compress", 0);
        }

        $this->_close();

        if (self::$Vu24barbsr0s) {
            $Vngrhfhlmiygata = $this->_pdf->get_buffer();
        } else {
            $Vngrhfhlmiygata = file_get_contents($this->_file);

            
            if ($this->_dompdf->getOptions()->getDebugPng()) {
                print '[pdflib output unlink ' . $this->_file . ']';
            }
            if (!$this->_dompdf->getOptions()->getDebugKeepTemp()) {
                unlink($this->_file);
            }
            $this->_file = null;
            unset($this->_file);
        }

        return $Vngrhfhlmiygata;
    }
}


PDFLib::$Vfh5zaiuo2gy = CPDF::$Vfh5zaiuo2gy;
