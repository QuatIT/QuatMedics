<?php

namespace Dompdf\FrameReflower;

use Dompdf\FrameDecorator\Block as BlockFrameDecorator;
use Dompdf\FrameDecorator\AbstractFrameDecorator;


class ListBullet extends AbstractFrameReflower
{

    
    function __construct(AbstractFrameDecorator $Vexjfacrc1d4)
    {
        parent::__construct($Vexjfacrc1d4);
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {
        $Vkvw5zjrwkdm = $this->_frame->get_style();

        $Vkvw5zjrwkdm->width = $this->_frame->get_width();
        $this->_frame->position();

        if ($Vkvw5zjrwkdm->list_style_position === "inside") {
            $V2d1s45w0hjo = $this->_frame->find_block_parent();
            $V2d1s45w0hjo->add_frame_to_line($this->_frame);
        }
    }
}
