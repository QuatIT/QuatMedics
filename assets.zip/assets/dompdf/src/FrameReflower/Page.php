<?php

namespace Dompdf\FrameReflower;

use Dompdf\Frame;
use Dompdf\FrameDecorator\Block as BlockFrameDecorator;
use Dompdf\FrameDecorator\Page as PageFrameDecorator;


class Page extends AbstractFrameReflower
{

    
    private $V50lbpgsppq2;

    
    private $V2ndtbforzqn;

    
    function __construct(PageFrameDecorator $Vexjfacrc1d4)
    {
        parent::__construct($Vexjfacrc1d4);
    }

    
    function apply_page_style(Frame $Vexjfacrc1d4, $Vrgtvfxdkuag)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Vlbqeivmc3gs = $Vkvw5zjrwkdm->get_stylesheet()->get_page_styles();

        
        if (count($Vlbqeivmc3gs) > 1) {
            $Voudos40imq1 = $Vrgtvfxdkuag % 2 == 1;
            $Vemq1ewypfma = $Vrgtvfxdkuag == 1;

            $Vkvw5zjrwkdm = clone $Vlbqeivmc3gs["base"];

            
            if ($Voudos40imq1 && isset($Vlbqeivmc3gs[":right"])) {
                $Vkvw5zjrwkdm->merge($Vlbqeivmc3gs[":right"]);
            }

            if ($Voudos40imq1 && isset($Vlbqeivmc3gs[":odd"])) {
                $Vkvw5zjrwkdm->merge($Vlbqeivmc3gs[":odd"]);
            }

            
            if (!$Voudos40imq1 && isset($Vlbqeivmc3gs[":left"])) {
                $Vkvw5zjrwkdm->merge($Vlbqeivmc3gs[":left"]);
            }

            if (!$Voudos40imq1 && isset($Vlbqeivmc3gs[":even"])) {
                $Vkvw5zjrwkdm->merge($Vlbqeivmc3gs[":even"]);
            }

            if ($Vemq1ewypfma && isset($Vlbqeivmc3gs[":first"])) {
                $Vkvw5zjrwkdm->merge($Vlbqeivmc3gs[":first"]);
            }

            $Vexjfacrc1d4->set_style($Vkvw5zjrwkdm);
        }
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {
        $Vvbuiqhyt5rr = array();
        $Vaizkjlc0lnn = null;
        $V0mqc4rbglqu = $this->_frame->get_first_child();
        $Vcobthjnnoyt = 0;

        while ($V0mqc4rbglqu) {
            $this->apply_page_style($this->_frame, $Vcobthjnnoyt + 1);

            $Vkvw5zjrwkdm = $this->_frame->get_style();

            
            $Ve0njdrnxyyx = $this->_frame->get_containing_block();
            $Vb5dthqtenbv = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_left, $Ve0njdrnxyyx["w"]);
            $Vqswkdbtte35 = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_right, $Ve0njdrnxyyx["w"]);
            $Vzn5k4lefp5v = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_top, $Ve0njdrnxyyx["h"]);
            $V3xygetcwtmz = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_bottom, $Ve0njdrnxyyx["h"]);

            $Ve2dmezkcmq5 = $Ve0njdrnxyyx["x"] + $Vb5dthqtenbv;
            $Vjkulspqzllw = $Ve0njdrnxyyx["y"] + $Vzn5k4lefp5v;
            $Vjlfebbimda5 = $Ve0njdrnxyyx["w"] - $Vb5dthqtenbv - $Vqswkdbtte35;
            $Vf0dppyi23hd = $Ve0njdrnxyyx["h"] - $Vzn5k4lefp5v - $V3xygetcwtmz;

            
            if ($Vcobthjnnoyt == 0) {
                $V0mqc4rbglquren = $V0mqc4rbglqu->get_children();
                foreach ($V0mqc4rbglquren as $Vu3hfvjxrvwo) {
                    if ($Vu3hfvjxrvwo->get_style()->position === "fixed") {
                        $Vvbuiqhyt5rr[] = $Vu3hfvjxrvwo->deep_copy();
                    }
                }
                $Vvbuiqhyt5rr = array_reverse($Vvbuiqhyt5rr);
            }

            $V0mqc4rbglqu->set_containing_block($Ve2dmezkcmq5, $Vjkulspqzllw, $Vjlfebbimda5, $Vf0dppyi23hd);

            
            $this->_check_callbacks("begin_page_reflow", $V0mqc4rbglqu);

            
            if ($Vcobthjnnoyt >= 1) {
                foreach ($Vvbuiqhyt5rr as $Vtmcv4nmmrne) {
                    $V0mqc4rbglqu->insert_child_before($Vtmcv4nmmrne->deep_copy(), $V0mqc4rbglqu->get_first_child());
                }
            }

            $V0mqc4rbglqu->reflow();
            $Vrjzvk2it3c5 = $V0mqc4rbglqu->get_next_sibling();

            
            $this->_check_callbacks("begin_page_render", $V0mqc4rbglqu);

            
            $this->_frame->get_renderer()->render($V0mqc4rbglqu);

            
            $this->_check_callbacks("end_page_render", $V0mqc4rbglqu);

            if ($Vrjzvk2it3c5) {
                $this->_frame->next_page();
            }

            
            
            if ($Vaizkjlc0lnn) {
                $Vaizkjlc0lnn->dispose(true);
            }
            $Vaizkjlc0lnn = $V0mqc4rbglqu;
            $V0mqc4rbglqu = $Vrjzvk2it3c5;
            $Vcobthjnnoyt++;
        }

        
        if ($Vaizkjlc0lnn) {
            $Vaizkjlc0lnn->dispose(true);
        }
    }

    
    protected function _check_callbacks($Vnd23tleybdf, $Vexjfacrc1d4)
    {
        if (!isset($this->_callbacks)) {
            $Vodc45cwlwwh = $this->_frame->get_dompdf();
            $this->_callbacks = $Vodc45cwlwwh->get_callbacks();
            $this->_canvas = $Vodc45cwlwwh->get_canvas();
        }

        if (is_array($this->_callbacks) && isset($this->_callbacks[$Vnd23tleybdf])) {
            $Vjm5y31o3qu2 = array(
                0 => $this->_canvas, "canvas" => $this->_canvas,
                1 => $Vexjfacrc1d4,         "frame"  => $Vexjfacrc1d4,
            );
            $Vepzylbkouaw = $this->_callbacks[$Vnd23tleybdf];
            foreach ($Vepzylbkouaw as $Vtmlsxxw3ne1) {
                if (is_callable($Vtmlsxxw3ne1)) {
                    if (is_array($Vtmlsxxw3ne1)) {
                        $Vtmlsxxw3ne1[0]->{$Vtmlsxxw3ne1[1]}($Vjm5y31o3qu2);
                    } else {
                        $Vtmlsxxw3ne1($Vjm5y31o3qu2);
                    }
                }
            }
        }
    }
}
