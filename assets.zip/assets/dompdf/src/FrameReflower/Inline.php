<?php

namespace Dompdf\FrameReflower;

use Dompdf\Frame;
use Dompdf\FrameDecorator\Block as BlockFrameDecorator;
use Dompdf\FrameDecorator\Text as TextFrameDecorator;


class Inline extends AbstractFrameReflower
{

    
    function __construct(Frame $Vexjfacrc1d4)
    {
        parent::__construct($Vexjfacrc1d4);
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {
        $Vexjfacrc1d4 = $this->_frame;

        
        $Vvhh3j3svzeq = $Vexjfacrc1d4->get_root();
        $Vvhh3j3svzeq->check_forced_page_break($Vexjfacrc1d4);

        if ($Vvhh3j3svzeq->is_full()) {
            return;
        }

        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        
        $this->_set_content();

        $Vexjfacrc1d4->position();

        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();

        
        if (($Vtmlsxxw3ne1 = $Vexjfacrc1d4->get_first_child()) && $Vtmlsxxw3ne1 instanceof TextFrameDecorator) {
            $Vtmlsxxw3ne1_style = $Vtmlsxxw3ne1->get_style();
            $Vtmlsxxw3ne1_style->margin_left = $Vkvw5zjrwkdm->margin_left;
            $Vtmlsxxw3ne1_style->padding_left = $Vkvw5zjrwkdm->padding_left;
            $Vtmlsxxw3ne1_style->border_left = $Vkvw5zjrwkdm->border_left;
        }

        if (($V3fvqcsh5wgl = $Vexjfacrc1d4->get_last_child()) && $V3fvqcsh5wgl instanceof TextFrameDecorator) {
            $V3fvqcsh5wgl_style = $V3fvqcsh5wgl->get_style();
            $V3fvqcsh5wgl_style->margin_right = $Vkvw5zjrwkdm->margin_right;
            $V3fvqcsh5wgl_style->padding_right = $Vkvw5zjrwkdm->padding_right;
            $V3fvqcsh5wgl_style->border_right = $Vkvw5zjrwkdm->border_right;
        }

        if ($Vynts1bqvpvb) {
            $Vynts1bqvpvb->add_frame_to_line($this->_frame);
        }

        
        
        foreach ($Vexjfacrc1d4->get_children() as $V0mqc4rbglqu) {
            $V0mqc4rbglqu->set_containing_block($Ve0njdrnxyyx);
            $V0mqc4rbglqu->reflow($Vynts1bqvpvb);
        }
    }

    
    public function calculate_auto_width()
    {
        $Vtt4kvdwuqqh = 0;

        foreach ($this->_frame->get_children() as $V0mqc4rbglqu) {
            if ($V0mqc4rbglqu->get_original_style()->width == 'auto') {
                $Vtt4kvdwuqqh += $V0mqc4rbglqu->calculate_auto_width();
            } else {
                $Vtt4kvdwuqqh += $V0mqc4rbglqu->get_margin_width();
            }
        }

        $this->_frame->get_style()->width = $Vtt4kvdwuqqh;

        return $this->_frame->get_margin_width();
    }
}
