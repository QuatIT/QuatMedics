<?php

namespace Dompdf\FrameReflower;

use Dompdf\FrameDecorator\Block as BlockFrameDecorator;
use Dompdf\FrameDecorator\Table as TableFrameDecorator;


class TableCell extends Block
{
    
    function __construct(BlockFrameDecorator $Vexjfacrc1d4)
    {
        parent::__construct($Vexjfacrc1d4);
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {
        $Vkvw5zjrwkdm = $this->_frame->get_style();

        $Vp5rpvpxnb43 = TableFrameDecorator::find_parent_table($this->_frame);
        $V5hlwkutan5t = $Vp5rpvpxnb43->get_cellmap();

        list($Vmm2pe5l4str, $Vuua0v2znlr5) = $V5hlwkutan5t->get_frame_position($this->_frame);
        $this->_frame->set_position($Vmm2pe5l4str, $Vuua0v2znlr5);

        $Vpnyh0054enj = $V5hlwkutan5t->get_spanned_cells($this->_frame);

        $V5ymvwogwh5y = 0;
        foreach ($Vpnyh0054enj["columns"] as $V0ixz2v5mxzy) {
            $Vqpgfq33o1wo = $V5hlwkutan5t->get_column($V0ixz2v5mxzy);
            $V5ymvwogwh5y += $Vqpgfq33o1wo["used-width"];
        }

        
        $V2pgp3ppbjsi = $this->_frame->get_containing_block("h");

        $Vrxbu0equ5ca = (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_left,
                $Vkvw5zjrwkdm->padding_left,
                $Vkvw5zjrwkdm->border_left_width),
            $V5ymvwogwh5y);

        $Vcp1akgphyol = (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->padding_right,
                $Vkvw5zjrwkdm->margin_right,
                $Vkvw5zjrwkdm->border_right_width),
            $V5ymvwogwh5y);

        $V5kr1wq4ogny = (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_top,
                $Vkvw5zjrwkdm->padding_top,
                $Vkvw5zjrwkdm->border_top_width),
            $V2pgp3ppbjsi);
        $Vaka2aa4rmak = (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_bottom,
                $Vkvw5zjrwkdm->padding_bottom,
                $Vkvw5zjrwkdm->border_bottom_width),
            $V2pgp3ppbjsi);

        $Vkvw5zjrwkdm->width = $Vcddyxnftff2 = $V5ymvwogwh5y - $Vrxbu0equ5ca - $Vcp1akgphyol;

        $Ve2dmezkcmq5 = $Vmm2pe5l4str + $Vrxbu0equ5ca;
        $Vjkulspqzllw = $Vwxrtunfgnow = $Vuua0v2znlr5 + $V5kr1wq4ogny;

        
        $V0ixz2v5mxzyndent = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->text_indent, $V5ymvwogwh5y);
        $this->_frame->increase_line_width($V0ixz2v5mxzyndent);

        $Vvhh3j3svzeq = $this->_frame->get_root();

        
        $V2sd5a4r2ikr = $this->_frame->get_current_line_box();
        $V2sd5a4r2ikr->y = $Vwxrtunfgnow;

        
        foreach ($this->_frame->get_children() as $V0mqc4rbglqu) {
            if ($Vvhh3j3svzeq->is_full()) {
                break;
            }

            $V0mqc4rbglqu->set_containing_block($Ve2dmezkcmq5, $Vjkulspqzllw, $Vcddyxnftff2, $V2pgp3ppbjsi);
            $this->process_clear($V0mqc4rbglqu);
            $V0mqc4rbglqu->reflow($this->_frame);
            $this->process_float($V0mqc4rbglqu, $Vmm2pe5l4str + $Vrxbu0equ5ca, $V5ymvwogwh5y - $Vcp1akgphyol - $Vrxbu0equ5ca);
        }

        
        $Vkvw5zjrwkdm_height = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->height, $V2pgp3ppbjsi);

        $this->_frame->set_content_height($this->_calculate_content_height());

        $V2pgp3ppbjsieight = max($Vkvw5zjrwkdm_height, (float)$this->_frame->get_content_height());

        
        $Vcbjeqivpc0c = $V2pgp3ppbjsieight / count($Vpnyh0054enj["rows"]);

        if ($Vkvw5zjrwkdm_height <= $V2pgp3ppbjsieight) {
            $Vcbjeqivpc0c += $V5kr1wq4ogny + $Vaka2aa4rmak;
        }

        foreach ($Vpnyh0054enj["rows"] as $V0ixz2v5mxzy) {
            $V5hlwkutan5t->set_row_height($V0ixz2v5mxzy, $Vcbjeqivpc0c);
        }

        $Vkvw5zjrwkdm->height = $V2pgp3ppbjsieight;
        $this->_text_align();
        $this->vertical_align();
    }
}
