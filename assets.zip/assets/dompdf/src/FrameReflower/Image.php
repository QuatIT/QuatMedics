<?php

namespace Dompdf\FrameReflower;

use Dompdf\Helpers;
use Dompdf\FrameDecorator\Block as BlockFrameDecorator;
use Dompdf\FrameDecorator\Image as ImageFrameDecorator;


class Image extends AbstractFrameReflower
{

    
    function __construct(ImageFrameDecorator $Vexjfacrc1d4)
    {
        parent::__construct($Vexjfacrc1d4);
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {
        $Vvkqsaecgfirhis->_frame->position();

        
        
        

        
        
        

        
        $Vvkqsaecgfirhis->get_min_max_width();

        if ($Vynts1bqvpvb) {
            $Vynts1bqvpvb->add_frame_to_line($Vvkqsaecgfirhis->_frame);
        }
    }

    
    function get_min_max_width()
    {
        if ($Vvkqsaecgfirhis->get_dompdf()->getOptions()->getDebugPng()) {
            
            list($Vtsthl4u20at, $Vhp54vu1aqfg) = Helpers::dompdf_getimagesize($Vvkqsaecgfirhis->_frame->get_image_url(), $Vvkqsaecgfirhis->get_dompdf()->getHttpContext());
            print "get_min_max_width() " .
                $Vvkqsaecgfirhis->_frame->get_style()->width . ' ' .
                $Vvkqsaecgfirhis->_frame->get_style()->height . ';' .
                $Vvkqsaecgfirhis->_frame->get_parent()->get_style()->width . " " .
                $Vvkqsaecgfirhis->_frame->get_parent()->get_style()->height . ";" .
                $Vvkqsaecgfirhis->_frame->get_parent()->get_parent()->get_style()->width . ' ' .
                $Vvkqsaecgfirhis->_frame->get_parent()->get_parent()->get_style()->height . ';' .
                $Vtsthl4u20at . ' ' .
                $Vhp54vu1aqfg . '|';
        }

        $Vkvw5zjrwkdm = $Vvkqsaecgfirhis->_frame->get_style();

        $Vuxypcvhxxl0 = true;
        $Vr2qoargjmtp = true;

        
        
        
        
        

        $Vtt4kvdwuqqh = ($Vkvw5zjrwkdm->width > 0 ? $Vkvw5zjrwkdm->width : 0);
        if (Helpers::is_percent($Vtt4kvdwuqqh)) {
            $Vvkqsaecgfir = 0.0;
            for ($Vtmlsxxw3ne1 = $Vvkqsaecgfirhis->_frame->get_parent(); $Vtmlsxxw3ne1; $Vtmlsxxw3ne1 = $Vtmlsxxw3ne1->get_parent()) {
                $Vtmlsxxw3ne1_style = $Vtmlsxxw3ne1->get_style();
                $Vvkqsaecgfir = $Vtmlsxxw3ne1_style->length_in_pt($Vtmlsxxw3ne1_style->width);
                if ($Vvkqsaecgfir != 0) {
                    break;
                }
            }
            $Vtt4kvdwuqqh = ((float)rtrim($Vtt4kvdwuqqh, "%") * $Vvkqsaecgfir) / 100; 
        } else {
            
            
            
            
            $Vtt4kvdwuqqh = $Vkvw5zjrwkdm->length_in_pt($Vtt4kvdwuqqh);
        }

        $Vxtfrabd3i5r = ($Vkvw5zjrwkdm->height > 0 ? $Vkvw5zjrwkdm->height : 0);
        if (Helpers::is_percent($Vxtfrabd3i5r)) {
            $Vvkqsaecgfir = 0.0;
            for ($Vtmlsxxw3ne1 = $Vvkqsaecgfirhis->_frame->get_parent(); $Vtmlsxxw3ne1; $Vtmlsxxw3ne1 = $Vtmlsxxw3ne1->get_parent()) {
                $Vtmlsxxw3ne1_style = $Vtmlsxxw3ne1->get_style();
                $Vvkqsaecgfir = (float)$Vtmlsxxw3ne1_style->length_in_pt($Vtmlsxxw3ne1_style->height);
                if ($Vvkqsaecgfir != 0) {
                    break;
                }
            }
            $Vxtfrabd3i5r = ((float)rtrim($Vxtfrabd3i5r, "%") * $Vvkqsaecgfir) / 100; 
        } else {
            
            
            
            
            $Vxtfrabd3i5r = $Vkvw5zjrwkdm->length_in_pt($Vxtfrabd3i5r);
        }

        if ($Vtt4kvdwuqqh == 0 || $Vxtfrabd3i5r == 0) {
            
            list($Vtsthl4u20at, $Vhp54vu1aqfg) = Helpers::dompdf_getimagesize($Vvkqsaecgfirhis->_frame->get_image_url(), $Vvkqsaecgfirhis->get_dompdf()->getHttpContext());

            
            
            
            if ($Vtt4kvdwuqqh == 0 && $Vxtfrabd3i5r == 0) {
                $Vfwb1n1yh3ll = $Vvkqsaecgfirhis->_frame->get_dompdf()->getOptions()->getDpi();
                $Vtt4kvdwuqqh = (float)($Vtsthl4u20at * 72) / $Vfwb1n1yh3ll;
                $Vxtfrabd3i5r = (float)($Vhp54vu1aqfg * 72) / $Vfwb1n1yh3ll;
                $Vuxypcvhxxl0 = false;
                $Vr2qoargjmtp = false;
            } elseif ($Vxtfrabd3i5r == 0 && $Vtt4kvdwuqqh != 0) {
                $Vr2qoargjmtp = false;
                $Vxtfrabd3i5r = ($Vtt4kvdwuqqh / $Vtsthl4u20at) * $Vhp54vu1aqfg; 
            } elseif ($Vtt4kvdwuqqh == 0 && $Vxtfrabd3i5r != 0) {
                $Vuxypcvhxxl0 = false;
                $Vtt4kvdwuqqh = ($Vxtfrabd3i5r / $Vhp54vu1aqfg) * $Vtsthl4u20at; 
            }
        }

        
        if ($Vkvw5zjrwkdm->min_width !== "none" ||
            $Vkvw5zjrwkdm->max_width !== "none" ||
            $Vkvw5zjrwkdm->min_height !== "none" ||
            $Vkvw5zjrwkdm->max_height !== "none"
        ) {

            list( , , $V5ymvwogwh5y, $V2pgp3ppbjsi) = $Vvkqsaecgfirhis->_frame->get_containing_block();

            $V0jbpqbcix1k = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->min_width, $V5ymvwogwh5y);
            $Vfxjf4xuzqhr = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->max_width, $V5ymvwogwh5y);
            $Vq4phveyfcky = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->min_height, $V2pgp3ppbjsi);
            $V1fpzf3yli20 = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->max_height, $V2pgp3ppbjsi);

            if ($Vfxjf4xuzqhr !== "none" && $Vtt4kvdwuqqh > $Vfxjf4xuzqhr) {
                if (!$Vr2qoargjmtp) {
                    $Vxtfrabd3i5r *= $Vfxjf4xuzqhr / $Vtt4kvdwuqqh;
                }

                $Vtt4kvdwuqqh = $Vfxjf4xuzqhr;
            }

            if ($V0jbpqbcix1k !== "none" && $Vtt4kvdwuqqh < $V0jbpqbcix1k) {
                if (!$Vr2qoargjmtp) {
                    $Vxtfrabd3i5r *= $V0jbpqbcix1k / $Vtt4kvdwuqqh;
                }

                $Vtt4kvdwuqqh = $V0jbpqbcix1k;
            }

            if ($V1fpzf3yli20 !== "none" && $Vxtfrabd3i5r > $V1fpzf3yli20) {
                if (!$Vuxypcvhxxl0) {
                    $Vtt4kvdwuqqh *= $V1fpzf3yli20 / $Vxtfrabd3i5r;
                }

                $Vxtfrabd3i5r = $V1fpzf3yli20;
            }

            if ($Vq4phveyfcky !== "none" && $Vxtfrabd3i5r < $Vq4phveyfcky) {
                if (!$Vuxypcvhxxl0) {
                    $Vtt4kvdwuqqh *= $Vq4phveyfcky / $Vxtfrabd3i5r;
                }

                $Vxtfrabd3i5r = $Vq4phveyfcky;
            }
        }

        if ($Vvkqsaecgfirhis->get_dompdf()->getOptions()->getDebugPng()) {
            print $Vtt4kvdwuqqh . ' ' . $Vxtfrabd3i5r . ';';
        }

        $Vkvw5zjrwkdm->width = $Vtt4kvdwuqqh . "pt";
        $Vkvw5zjrwkdm->height = $Vxtfrabd3i5r . "pt";

        $Vkvw5zjrwkdm->min_width = "none";
        $Vkvw5zjrwkdm->max_width = "none";
        $Vkvw5zjrwkdm->min_height = "none";
        $Vkvw5zjrwkdm->max_height = "none";

        return array($Vtt4kvdwuqqh, $Vtt4kvdwuqqh, "min" => $Vtt4kvdwuqqh, "max" => $Vtt4kvdwuqqh);
    }
}
