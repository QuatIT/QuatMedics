<?php

namespace Dompdf\FrameReflower;

use Dompdf\FrameDecorator\Block as BlockFrameDecorator;
use Dompdf\FrameDecorator\Table as TableFrameDecorator;


class Table extends AbstractFrameReflower
{
    
    protected $Vzyb2djzba42;

    
    protected $V5foimtp4zpy;

    
    function __construct(TableFrameDecorator $Vexjfacrc1d4)
    {
        $this->_state = null;
        parent::__construct($Vexjfacrc1d4);
    }

    
    function reset()
    {
        $this->_state = null;
        $this->_min_max_cache = null;
    }

    protected function _assign_widths()
    {
        $Vkvw5zjrwkdm = $this->_frame->get_style();

        
        
        $V0jbpqbcix1k = $this->_state["min_width"];
        $Vfxjf4xuzqhr = $this->_state["max_width"];
        $Voqwpjop24bd = $this->_state["percent_used"];
        $Vtaweirsqq0o = $this->_state["absolute_used"];
        $V0aycfaordpo = $this->_state["auto_min"];

        $Vwofzdwloxyc =& $this->_state["absolute"];
        $Vwg2mlcjmdye =& $this->_state["percent"];
        $Vzlllkt4ixym =& $this->_state["auto"];

        
        $Ve0njdrnxyyx = $this->_frame->get_containing_block();
        $Vwq0k2uyyc4q =& $this->_frame->get_cellmap()->get_columns();

        $Vtt4kvdwuqqh = $Vkvw5zjrwkdm->width;

        
        $Vb5dthqtenbv = $Vkvw5zjrwkdm->margin_left;
        $Vqswkdbtte35 = $Vkvw5zjrwkdm->margin_right;

        $V2xstpl4i5y0 = ($Vb5dthqtenbv === "auto" && $Vqswkdbtte35 === "auto");

        $Vb5dthqtenbv = (float)($Vb5dthqtenbv === "auto" ? 0 : $Vkvw5zjrwkdm->length_in_pt($Vb5dthqtenbv, $Ve0njdrnxyyx["w"]));
        $Vqswkdbtte35 = (float)($Vqswkdbtte35 === "auto" ? 0 : $Vkvw5zjrwkdm->length_in_pt($Vqswkdbtte35, $Ve0njdrnxyyx["w"]));

        $V0w5rvqizf1i = $Vb5dthqtenbv + $Vqswkdbtte35;

        if (!$V2xstpl4i5y0) {
            $V0w5rvqizf1i += (float)$Vkvw5zjrwkdm->length_in_pt(array(
                    $Vkvw5zjrwkdm->padding_left,
                    $Vkvw5zjrwkdm->border_left_width,
                    $Vkvw5zjrwkdm->border_right_width,
                    $Vkvw5zjrwkdm->padding_right),
                $Ve0njdrnxyyx["w"]);
        }

        $Vokmlgi2mzzq = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->min_width, $Ve0njdrnxyyx["w"] - $V0w5rvqizf1i);

        
        $V0jbpqbcix1k -= $V0w5rvqizf1i;
        $Vfxjf4xuzqhr -= $V0w5rvqizf1i;

        if ($Vtt4kvdwuqqh !== "auto") {
            $Vuhac3gd031h = (float)$Vkvw5zjrwkdm->length_in_pt($Vtt4kvdwuqqh, $Ve0njdrnxyyx["w"]) - $V0w5rvqizf1i;

            if ($Vuhac3gd031h < $Vokmlgi2mzzq) {
                $Vuhac3gd031h = $Vokmlgi2mzzq;
            }

            if ($Vuhac3gd031h > $V0jbpqbcix1k) {
                $Vtt4kvdwuqqh = $Vuhac3gd031h;
            } else {
                $Vtt4kvdwuqqh = $V0jbpqbcix1k;
            }

        } else {
            if ($Vfxjf4xuzqhr + $V0w5rvqizf1i < $Ve0njdrnxyyx["w"]) {
                $Vtt4kvdwuqqh = $Vfxjf4xuzqhr;
            } else if ($Ve0njdrnxyyx["w"] - $V0w5rvqizf1i > $V0jbpqbcix1k) {
                $Vtt4kvdwuqqh = $Ve0njdrnxyyx["w"] - $V0w5rvqizf1i;
            } else {
                $Vtt4kvdwuqqh = $V0jbpqbcix1k;
            }

            if ($Vtt4kvdwuqqh < $Vokmlgi2mzzq) {
                $Vtt4kvdwuqqh = $Vokmlgi2mzzq;
            }

        }

        
        $Vkvw5zjrwkdm->width = $Vtt4kvdwuqqh;

        $V5hlwkutan5t = $this->_frame->get_cellmap();

        if ($V5hlwkutan5t->is_columns_locked()) {
            return;
        }

        
        if ($Vtt4kvdwuqqh == $Vfxjf4xuzqhr) {
            foreach (array_keys($Vwq0k2uyyc4q) as $V0ixz2v5mxzy) {
                $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["max-width"]);
            }

            return;
        }

        
        if ($Vtt4kvdwuqqh > $V0jbpqbcix1k) {
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            $V0ixz2v5mxzyncrement = 0;

            
            if ($Vtaweirsqq0o == 0 && $Voqwpjop24bd == 0) {
                $V0ixz2v5mxzyncrement = $Vtt4kvdwuqqh - $V0jbpqbcix1k;

                foreach (array_keys($Vwq0k2uyyc4q) as $V0ixz2v5mxzy) {
                    $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"] + $V0ixz2v5mxzyncrement * ($Vwq0k2uyyc4q[$V0ixz2v5mxzy]["max-width"] / $Vfxjf4xuzqhr));
                }
                return;
            }

            
            if ($Vtaweirsqq0o > 0 && $Voqwpjop24bd == 0) {
                if (count($Vzlllkt4ixym) > 0) {
                    $V0ixz2v5mxzyncrement = ($Vtt4kvdwuqqh - $V0aycfaordpo - $Vtaweirsqq0o) / count($Vzlllkt4ixym);
                }

                
                foreach (array_keys($Vwq0k2uyyc4q) as $V0ixz2v5mxzy) {
                    if ($Vwq0k2uyyc4q[$V0ixz2v5mxzy]["absolute"] > 0 && count($Vzlllkt4ixym)) {
                        $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"]);
                    } else if (count($Vzlllkt4ixym)) {
                        $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"] + $V0ixz2v5mxzyncrement);
                    } else {
                        
                        $V0ixz2v5mxzyncrement = ($Vtt4kvdwuqqh - $Vtaweirsqq0o) * $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["absolute"] / $Vtaweirsqq0o;

                        $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"] + $V0ixz2v5mxzyncrement);
                    }

                }
                return;
            }

            
            if ($Vtaweirsqq0o == 0 && $Voqwpjop24bd > 0) {
                $Vzhl3npnukbb = null;
                $Vhl02vir5elt = null;

                
                
                if ($Voqwpjop24bd > 100 || count($Vzlllkt4ixym) == 0) {
                    $Vzhl3npnukbb = 100 / $Voqwpjop24bd;
                } else {
                    $Vzhl3npnukbb = 1;
                }

                
                $V1mq5tzzjntj = $V0aycfaordpo;

                foreach ($Vwg2mlcjmdye as $V0ixz2v5mxzy) {
                    $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["percent"] *= $Vzhl3npnukbb;

                    $Vq0uuo14wl2u = $Vtt4kvdwuqqh - $V1mq5tzzjntj;

                    $V5ymvwogwh5y = min($Vwq0k2uyyc4q[$V0ixz2v5mxzy]["percent"] * $Vtt4kvdwuqqh / 100, $Vq0uuo14wl2u);

                    if ($V5ymvwogwh5y < $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"]) {
                        $V5ymvwogwh5y = $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"];
                    }

                    $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $V5ymvwogwh5y);
                    $V1mq5tzzjntj += $V5ymvwogwh5y;

                }

                
                
                if (count($Vzlllkt4ixym) > 0) {
                    $V0ixz2v5mxzyncrement = ($Vtt4kvdwuqqh - $V1mq5tzzjntj) / count($Vzlllkt4ixym);

                    foreach ($Vzlllkt4ixym as $V0ixz2v5mxzy) {
                        $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"] + $V0ixz2v5mxzyncrement);
                    }

                }
                return;
            }

            

            
            if ($Vtaweirsqq0o > 0 && $Voqwpjop24bd > 0) {
                $V1mq5tzzjntj = $V0aycfaordpo;

                foreach ($Vwofzdwloxyc as $V0ixz2v5mxzy) {
                    $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"]);
                    $V1mq5tzzjntj += $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"];
                }

                
                
                if ($Voqwpjop24bd > 100 || count($Vzlllkt4ixym) == 0) {
                    $Vzhl3npnukbb = 100 / $Voqwpjop24bd;
                } else {
                    $Vzhl3npnukbb = 1;
                }

                $Vhl02vir5elt_width = $Vtt4kvdwuqqh - $V1mq5tzzjntj;

                foreach ($Vwg2mlcjmdye as $V0ixz2v5mxzy) {
                    $Vq0uuo14wl2u = $Vhl02vir5elt_width - $V1mq5tzzjntj;

                    $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["percent"] *= $Vzhl3npnukbb;
                    $V5ymvwogwh5y = min($Vwq0k2uyyc4q[$V0ixz2v5mxzy]["percent"] * $Vhl02vir5elt_width / 100, $Vq0uuo14wl2u);

                    if ($V5ymvwogwh5y < $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"]) {
                        $V5ymvwogwh5y = $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"];
                    }

                    $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["used-width"] = $V5ymvwogwh5y;
                    $V1mq5tzzjntj += $V5ymvwogwh5y;
                }

                if (count($Vzlllkt4ixym) > 0) {
                    $V0ixz2v5mxzyncrement = ($Vtt4kvdwuqqh - $V1mq5tzzjntj) / count($Vzlllkt4ixym);

                    foreach ($Vzlllkt4ixym as $V0ixz2v5mxzy) {
                        $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"] + $V0ixz2v5mxzyncrement);
                    }
                }

                return;
            }
        } else { 
            
            foreach (array_keys($Vwq0k2uyyc4q) as $V0ixz2v5mxzy) {
                $V5hlwkutan5t->set_column_width($V0ixz2v5mxzy, $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"]);
            }
        }
    }

    
    protected function _calculate_height()
    {
        $Vkvw5zjrwkdm = $this->_frame->get_style();
        $Vxtfrabd3i5r = $Vkvw5zjrwkdm->height;

        $V5hlwkutan5t = $this->_frame->get_cellmap();
        $V5hlwkutan5t->assign_frame_heights();
        $Vtct32p53glw = $V5hlwkutan5t->get_rows();

        
        $Vf0dppyi23hd = 0;
        foreach ($Vtct32p53glw as $Vapkwgsb3w3r) {
            $Vf0dppyi23hd += $Vapkwgsb3w3r["height"];
        }

        $Ve0njdrnxyyx = $this->_frame->get_containing_block();

        if (!($Vkvw5zjrwkdm->overflow === "visible" ||
            ($Vkvw5zjrwkdm->overflow === "hidden" && $Vxtfrabd3i5r === "auto"))
        ) {
            

            $Vq4phveyfcky = $Vkvw5zjrwkdm->min_height;
            $V1fpzf3yli20 = $Vkvw5zjrwkdm->max_height;

            if (isset($Ve0njdrnxyyx["h"])) {
                $Vq4phveyfcky = $Vkvw5zjrwkdm->length_in_pt($Vq4phveyfcky, $Ve0njdrnxyyx["h"]);
                $V1fpzf3yli20 = $Vkvw5zjrwkdm->length_in_pt($V1fpzf3yli20, $Ve0njdrnxyyx["h"]);

            } else if (isset($Ve0njdrnxyyx["w"])) {
                if (mb_strpos($Vq4phveyfcky, "%") !== false) {
                    $Vq4phveyfcky = 0;
                } else {
                    $Vq4phveyfcky = $Vkvw5zjrwkdm->length_in_pt($Vq4phveyfcky, $Ve0njdrnxyyx["w"]);
                }
                if (mb_strpos($V1fpzf3yli20, "%") !== false) {
                    $V1fpzf3yli20 = "none";
                } else {
                    $V1fpzf3yli20 = $Vkvw5zjrwkdm->length_in_pt($V1fpzf3yli20, $Ve0njdrnxyyx["w"]);
                }
            }

            if ($V1fpzf3yli20 !== "none" && $Vq4phveyfcky > $V1fpzf3yli20) {
                
                list($V1fpzf3yli20, $Vq4phveyfcky) = array($Vq4phveyfcky, $V1fpzf3yli20);
            }

            if ($V1fpzf3yli20 !== "none" && $Vxtfrabd3i5r > $V1fpzf3yli20) {
                $Vxtfrabd3i5r = $V1fpzf3yli20;
            }

            if ($Vxtfrabd3i5r < $Vq4phveyfcky) {
                $Vxtfrabd3i5r = $Vq4phveyfcky;
            }
        } else {
            
            if ($Vxtfrabd3i5r !== "auto") {
                $Vxtfrabd3i5r = $Vkvw5zjrwkdm->length_in_pt($Vxtfrabd3i5r, $Ve0njdrnxyyx["h"]);

                if ($Vxtfrabd3i5r <= $Vf0dppyi23hd) {
                    $Vxtfrabd3i5r = $Vf0dppyi23hd;
                } else {
                    $V5hlwkutan5t->set_frame_heights($Vxtfrabd3i5r, $Vf0dppyi23hd);
                }
            } else {
                $Vxtfrabd3i5r = $Vf0dppyi23hd;
            }
        }

        return $Vxtfrabd3i5r;
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {
        
        $Vexjfacrc1d4 = $this->_frame;

        
        $Vvhh3j3svzeq = $Vexjfacrc1d4->get_root();
        $Vvhh3j3svzeq->check_forced_page_break($Vexjfacrc1d4);

        
        if ($Vvhh3j3svzeq->is_full()) {
            return;
        }

        
        
        
        
        $Vvhh3j3svzeq->table_reflow_start();

        
        $this->_collapse_margins();

        $Vexjfacrc1d4->position();

        
        

        if (is_null($this->_state)) {
            $this->get_min_max_width();
        }

        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        
        
        
        if ($Vkvw5zjrwkdm->border_collapse === "separate") {
            list($V2pgp3ppbjsi, $Vfanetclug4s) = $Vkvw5zjrwkdm->border_spacing;

            $Vfanetclug4s = (float)$Vkvw5zjrwkdm->length_in_pt($Vfanetclug4s) / 2;
            $V2pgp3ppbjsi = (float)$Vkvw5zjrwkdm->length_in_pt($V2pgp3ppbjsi) / 2;

            $Vkvw5zjrwkdm->padding_left = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_left, $Ve0njdrnxyyx["w"]) + $V2pgp3ppbjsi;
            $Vkvw5zjrwkdm->padding_right = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_right, $Ve0njdrnxyyx["w"]) + $V2pgp3ppbjsi;
            $Vkvw5zjrwkdm->padding_top = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_top, $Ve0njdrnxyyx["h"]) + $Vfanetclug4s;
            $Vkvw5zjrwkdm->padding_bottom = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_bottom, $Ve0njdrnxyyx["h"]) + $Vfanetclug4s;
        }

        $this->_assign_widths();

        
        $Vtt4kvdwuqqh = $Vkvw5zjrwkdm->width;
        $Vb5dthqtenbv = $Vkvw5zjrwkdm->margin_left;
        $Vqswkdbtte35 = $Vkvw5zjrwkdm->margin_right;

        $Voq1154hnlga = $Ve0njdrnxyyx["w"] - $Vtt4kvdwuqqh;

        if ($Vb5dthqtenbv === "auto" && $Vqswkdbtte35 === "auto") {
            if ($Voq1154hnlga < 0) {
                $Vb5dthqtenbv = 0;
                $Vqswkdbtte35 = $Voq1154hnlga;
            } else {
                $Vb5dthqtenbv = $Vqswkdbtte35 = $Voq1154hnlga / 2;
            }

            $Vkvw5zjrwkdm->margin_left = sprintf("%Fpt", $Vb5dthqtenbv);
            $Vkvw5zjrwkdm->margin_right = sprintf("%Fpt", $Vqswkdbtte35);;
        } else {
            if ($Vb5dthqtenbv === "auto") {
                $Vb5dthqtenbv = (float)$Vkvw5zjrwkdm->length_in_pt($Ve0njdrnxyyx["w"] - $Vqswkdbtte35 - $Vtt4kvdwuqqh, $Ve0njdrnxyyx["w"]);
            }
            if ($Vqswkdbtte35 === "auto") {
                $Vb5dthqtenbv = (float)$Vkvw5zjrwkdm->length_in_pt($Vb5dthqtenbv, $Ve0njdrnxyyx["w"]);
            }
        }

        list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vexjfacrc1d4->get_position();

        
        $Ve2dmezkcmq5 = $Vmm2pe5l4str + (float)$Vb5dthqtenbv + (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->padding_left,
                $Vkvw5zjrwkdm->border_left_width), $Ve0njdrnxyyx["w"]);
        $Vjkulspqzllw = $Vuua0v2znlr5 + (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_top,
                $Vkvw5zjrwkdm->border_top_width,
                $Vkvw5zjrwkdm->padding_top), $Ve0njdrnxyyx["h"]);

        if (isset($Ve0njdrnxyyx["h"])) {
            $V2pgp3ppbjsi = $Ve0njdrnxyyx["h"];
        } else {
            $V2pgp3ppbjsi = null;
        }

        $V5hlwkutan5t = $Vexjfacrc1d4->get_cellmap();
        $Vqpgfq33o1wo =& $V5hlwkutan5t->get_column(0);
        $Vqpgfq33o1wo["x"] = $Ve2dmezkcmq5;

        $Vapkwgsb3w3row =& $V5hlwkutan5t->get_row(0);
        $Vapkwgsb3w3row["y"] = $Vjkulspqzllw;

        $V5hlwkutan5t->assign_x_positions();

        
        foreach ($Vexjfacrc1d4->get_children() as $V0mqc4rbglqu) {
            
            if (!$Vvhh3j3svzeq->in_nested_table() && $Vvhh3j3svzeq->is_full()) {
                break;
            }

            $V0mqc4rbglqu->set_containing_block($Ve2dmezkcmq5, $Vjkulspqzllw, $Vtt4kvdwuqqh, $V2pgp3ppbjsi);
            $V0mqc4rbglqu->reflow();

            if (!$Vvhh3j3svzeq->in_nested_table()) {
                
                $Vvhh3j3svzeq->check_page_break($V0mqc4rbglqu);
            }

        }

        
        $Vkvw5zjrwkdm->height = $this->_calculate_height();

        if ($Vkvw5zjrwkdm->border_collapse === "collapse") {
            
            $Vkvw5zjrwkdm->border_style = "none";
        }

        $Vvhh3j3svzeq->table_reflow_end();

        
        

        if ($Vynts1bqvpvb && $Vkvw5zjrwkdm->float === "none" && $Vexjfacrc1d4->is_in_flow()) {
            $Vynts1bqvpvb->add_frame_to_line($Vexjfacrc1d4);
            $Vynts1bqvpvb->add_line();
        }
    }

    
    function get_min_max_width()
    {
        if (!is_null($this->_min_max_cache)) {
            return $this->_min_max_cache;
        }

        $Vkvw5zjrwkdm = $this->_frame->get_style();

        $this->_frame->normalise();

        
        
        $this->_frame->get_cellmap()->add_frame($this->_frame);

        
        
        $this->_state = array();
        $this->_state["min_width"] = 0;
        $this->_state["max_width"] = 0;

        $this->_state["percent_used"] = 0;
        $this->_state["absolute_used"] = 0;
        $this->_state["auto_min"] = 0;

        $this->_state["absolute"] = array();
        $this->_state["percent"] = array();
        $this->_state["auto"] = array();

        $Vwq0k2uyyc4q =& $this->_frame->get_cellmap()->get_columns();
        foreach (array_keys($Vwq0k2uyyc4q) as $V0ixz2v5mxzy) {
            $this->_state["min_width"] += $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"];
            $this->_state["max_width"] += $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["max-width"];

            if ($Vwq0k2uyyc4q[$V0ixz2v5mxzy]["absolute"] > 0) {
                $this->_state["absolute"][] = $V0ixz2v5mxzy;
                $this->_state["absolute_used"] += $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["absolute"];
            } else if ($Vwq0k2uyyc4q[$V0ixz2v5mxzy]["percent"] > 0) {
                $this->_state["percent"][] = $V0ixz2v5mxzy;
                $this->_state["percent_used"] += $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["percent"];
            } else {
                $this->_state["auto"][] = $V0ixz2v5mxzy;
                $this->_state["auto_min"] += $Vwq0k2uyyc4q[$V0ixz2v5mxzy]["min-width"];
            }
        }

        
        $Vgt3r4xkc5nj = array($Vkvw5zjrwkdm->border_left_width,
            $Vkvw5zjrwkdm->border_right_width,
            $Vkvw5zjrwkdm->padding_left,
            $Vkvw5zjrwkdm->padding_right,
            $Vkvw5zjrwkdm->margin_left,
            $Vkvw5zjrwkdm->margin_right);

        if ($Vkvw5zjrwkdm->border_collapse !== "collapse") {
            list($Vgt3r4xkc5nj[]) = $Vkvw5zjrwkdm->border_spacing;
        }

        $V0w5rvqizf1i = (float)$Vkvw5zjrwkdm->length_in_pt($Vgt3r4xkc5nj, $this->_frame->get_containing_block("w"));

        $this->_state["min_width"] += $V0w5rvqizf1i;
        $this->_state["max_width"] += $V0w5rvqizf1i;

        return $this->_min_max_cache = array(
            $this->_state["min_width"],
            $this->_state["max_width"],
            "min" => $this->_state["min_width"],
            "max" => $this->_state["max_width"],
        );
    }
}
