<?php

namespace Dompdf\FrameReflower;

use Dompdf\Frame;
use Dompdf\FrameDecorator\Block as BlockFrameDecorator;
use Dompdf\FrameDecorator\TableCell as TableCellFrameDecorator;
use Dompdf\FrameDecorator\Text as TextFrameDecorator;
use Dompdf\Exception;
use Dompdf\Css\Style;


class Block extends AbstractFrameReflower
{
    
    const MIN_JUSTIFY_WIDTH = 0.80;

    
    protected $Vzyb2djzba42;

    function __construct(BlockFrameDecorator $Vexjfacrc1d4)
    {
        parent::__construct($Vexjfacrc1d4);
    }

    
    protected function _calculate_width($Vtt4kvdwuqqh)
    {
        $Vexjfacrc1d4 = $this->_frame;
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $V5ymvwogwh5y = $Vexjfacrc1d4->get_containing_block("w");

        if ($Vkvw5zjrwkdm->position === "fixed") {
            $V5ymvwogwh5y = $Vexjfacrc1d4->get_parent()->get_containing_block("w");
        }

        $Vinjlszjmu45 = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_right, $V5ymvwogwh5y);
        $Voxz0xor1j4m = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_left, $V5ymvwogwh5y);

        $Vb5dthqtenbv = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->left, $V5ymvwogwh5y);
        $Vqswkdbtte35 = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->right, $V5ymvwogwh5y);

        
        $Vgt3r4xkc5nj = array($Vkvw5zjrwkdm->border_left_width,
            $Vkvw5zjrwkdm->border_right_width,
            $Vkvw5zjrwkdm->padding_left,
            $Vkvw5zjrwkdm->padding_right,
            $Vtt4kvdwuqqh !== "auto" ? $Vtt4kvdwuqqh : 0,
            $Vinjlszjmu45 !== "auto" ? $Vinjlszjmu45 : 0,
            $Voxz0xor1j4m !== "auto" ? $Voxz0xor1j4m : 0);

        
        if ($Vexjfacrc1d4->is_absolute()) {
            $Vwofzdwloxyc = true;
            $Vgt3r4xkc5nj[] = $Vb5dthqtenbv !== "auto" ? $Vb5dthqtenbv : 0;
            $Vgt3r4xkc5nj[] = $Vqswkdbtte35 !== "auto" ? $Vqswkdbtte35 : 0;
        } else {
            $Vwofzdwloxyc = false;
        }

        $V3rvdjymh0pq = (float)$Vkvw5zjrwkdm->length_in_pt($Vgt3r4xkc5nj, $V5ymvwogwh5y);

        
        $Voq1154hnlga = $V5ymvwogwh5y - $V3rvdjymh0pq;

        if ($Voq1154hnlga > 0) {
            if ($Vwofzdwloxyc) {
                
                

                if ($Vtt4kvdwuqqh === "auto" && $Vb5dthqtenbv === "auto" && $Vqswkdbtte35 === "auto") {
                    if ($Voxz0xor1j4m === "auto") {
                        $Voxz0xor1j4m = 0;
                    }
                    if ($Vinjlszjmu45 === "auto") {
                        $Vinjlszjmu45 = 0;
                    }

                    
                    
                    
                    $Vb5dthqtenbv = 0;
                    $Vqswkdbtte35 = 0;
                    $Vtt4kvdwuqqh = $Voq1154hnlga;
                } else if ($Vtt4kvdwuqqh === "auto") {
                    if ($Voxz0xor1j4m === "auto") {
                        $Voxz0xor1j4m = 0;
                    }
                    if ($Vinjlszjmu45 === "auto") {
                        $Vinjlszjmu45 = 0;
                    }
                    if ($Vb5dthqtenbv === "auto") {
                        $Vb5dthqtenbv = 0;
                    }
                    if ($Vqswkdbtte35 === "auto") {
                        $Vqswkdbtte35 = 0;
                    }

                    $Vtt4kvdwuqqh = $Voq1154hnlga;
                } else if ($Vb5dthqtenbv === "auto") {
                    if ($Voxz0xor1j4m === "auto") {
                        $Voxz0xor1j4m = 0;
                    }
                    if ($Vinjlszjmu45 === "auto") {
                        $Vinjlszjmu45 = 0;
                    }
                    if ($Vqswkdbtte35 === "auto") {
                        $Vqswkdbtte35 = 0;
                    }

                    $Vb5dthqtenbv = $Voq1154hnlga;
                } else if ($Vqswkdbtte35 === "auto") {
                    if ($Voxz0xor1j4m === "auto") {
                        $Voxz0xor1j4m = 0;
                    }
                    if ($Vinjlszjmu45 === "auto") {
                        $Vinjlszjmu45 = 0;
                    }

                    $Vqswkdbtte35 = $Voq1154hnlga;
                }

            } else {
                
                if ($Vtt4kvdwuqqh === "auto") {
                    $Vtt4kvdwuqqh = $Voq1154hnlga;
                } else if ($Voxz0xor1j4m === "auto" && $Vinjlszjmu45 === "auto") {
                    $Voxz0xor1j4m = $Vinjlszjmu45 = round($Voq1154hnlga / 2);
                } else if ($Voxz0xor1j4m === "auto") {
                    $Voxz0xor1j4m = $Voq1154hnlga;
                } else if ($Vinjlszjmu45 === "auto") {
                    $Vinjlszjmu45 = $Voq1154hnlga;
                }
            }
        } else if ($Voq1154hnlga < 0) {
            
            $Vinjlszjmu45 = $Voq1154hnlga;
        }

        return array(
            "width" => $Vtt4kvdwuqqh,
            "margin_left" => $Voxz0xor1j4m,
            "margin_right" => $Vinjlszjmu45,
            "left" => $Vb5dthqtenbv,
            "right" => $Vqswkdbtte35,
        );
    }

    
    protected function _calculate_restricted_width()
    {
        $Vexjfacrc1d4 = $this->_frame;
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();

        if ($Vkvw5zjrwkdm->position === "fixed") {
            $Ve0njdrnxyyx = $Vexjfacrc1d4->get_root()->get_containing_block();
        }

        
        

        if (!isset($Ve0njdrnxyyx["w"])) {
            throw new Exception("Box property calculation requires containing block width");
        }

        
        if ($Vkvw5zjrwkdm->width === "100%") {
            $Vtt4kvdwuqqh = "auto";
        } else {
            $Vtt4kvdwuqqh = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->width, $Ve0njdrnxyyx["w"]);
        }

        $Vcw3hxxubdh1 = $this->_calculate_width($Vtt4kvdwuqqh);
        $Vs2wi0uctfln = $Vcw3hxxubdh1['margin_left'];
        $Vjp2zywc3plp = $Vcw3hxxubdh1['margin_right'];
        $Vtt4kvdwuqqh =  $Vcw3hxxubdh1['width'];
        $Vb5dthqtenbv =  $Vcw3hxxubdh1['left'];
        $Vqswkdbtte35 =  $Vcw3hxxubdh1['right'];

        
        $V0jbpqbcix1k = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->min_width, $Ve0njdrnxyyx["w"]);
        $Vfxjf4xuzqhr = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->max_width, $Ve0njdrnxyyx["w"]);

        if ($Vfxjf4xuzqhr !== "none" && $V0jbpqbcix1k > $Vfxjf4xuzqhr) {
            list($Vfxjf4xuzqhr, $V0jbpqbcix1k) = array($V0jbpqbcix1k, $Vfxjf4xuzqhr);
        }

        if ($Vfxjf4xuzqhr !== "none" && $Vtt4kvdwuqqh > $Vfxjf4xuzqhr) {
            extract($this->_calculate_width($Vfxjf4xuzqhr));
        }

        if ($Vtt4kvdwuqqh < $V0jbpqbcix1k) {
            $Vcw3hxxubdh1 = $this->_calculate_width($V0jbpqbcix1k);
            $Vs2wi0uctfln = $Vcw3hxxubdh1['margin_left'];
            $Vjp2zywc3plp = $Vcw3hxxubdh1['margin_right'];
            $Vtt4kvdwuqqh =  $Vcw3hxxubdh1['width'];
            $Vb5dthqtenbv =  $Vcw3hxxubdh1['left'];
            $Vqswkdbtte35 =  $Vcw3hxxubdh1['right'];
        }

        return array($Vtt4kvdwuqqh, $Vs2wi0uctfln, $Vjp2zywc3plp, $Vb5dthqtenbv, $Vqswkdbtte35);
    }

    
    protected function _calculate_content_height()
    {
        $Vxtfrabd3i5r = 0;
        $V4owjlhlrka3 = $this->_frame->get_line_boxes();
        if (count($V4owjlhlrka3) > 0) {
            $Veyru1ddhqqj = end($V4owjlhlrka3);
            $Vdo5yueewbh2 = $this->_frame->get_content_box();
            $Vxtfrabd3i5r = $Veyru1ddhqqj->y + $Veyru1ddhqqj->h - $Vdo5yueewbh2["y"];
        }
        return $Vxtfrabd3i5r;
    }

    
    protected function _calculate_restricted_height()
    {
        $Vexjfacrc1d4 = $this->_frame;
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Vf0dppyi23hd = $this->_calculate_content_height();
        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();

        $Vxtfrabd3i5r = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->height, $Ve0njdrnxyyx["h"]);

        $Vzn5k4lefp5v = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->top, $Ve0njdrnxyyx["h"]);
        $V3xygetcwtmz = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->bottom, $Ve0njdrnxyyx["h"]);

        $Vmq2wkw5npmk = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_top, $Ve0njdrnxyyx["h"]);
        $Vt1knyxiv2uq = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_bottom, $Ve0njdrnxyyx["h"]);

        if ($Vexjfacrc1d4->is_absolute()) {

            

            $Vgt3r4xkc5nj = array($Vzn5k4lefp5v !== "auto" ? $Vzn5k4lefp5v : 0,
                $Vkvw5zjrwkdm->margin_top !== "auto" ? $Vkvw5zjrwkdm->margin_top : 0,
                $Vkvw5zjrwkdm->padding_top,
                $Vkvw5zjrwkdm->border_top_width,
                $Vxtfrabd3i5r !== "auto" ? $Vxtfrabd3i5r : 0,
                $Vkvw5zjrwkdm->border_bottom_width,
                $Vkvw5zjrwkdm->padding_bottom,
                $Vkvw5zjrwkdm->margin_bottom !== "auto" ? $Vkvw5zjrwkdm->margin_bottom : 0,
                $V3xygetcwtmz !== "auto" ? $V3xygetcwtmz : 0);

            $V3rvdjymh0pq = (float)$Vkvw5zjrwkdm->length_in_pt($Vgt3r4xkc5nj, $Ve0njdrnxyyx["h"]);

            $Voq1154hnlga = $Ve0njdrnxyyx["h"] - $V3rvdjymh0pq;

            if ($Voq1154hnlga > 0) {
                if ($Vxtfrabd3i5r === "auto" && $Vzn5k4lefp5v === "auto" && $V3xygetcwtmz === "auto") {
                    if ($Vmq2wkw5npmk === "auto") {
                        $Vmq2wkw5npmk = 0;
                    }
                    if ($Vt1knyxiv2uq === "auto") {
                        $Vt1knyxiv2uq = 0;
                    }

                    $Vxtfrabd3i5r = $Voq1154hnlga;
                } else if ($Vxtfrabd3i5r === "auto" && $Vzn5k4lefp5v === "auto") {
                    if ($Vmq2wkw5npmk === "auto") {
                        $Vmq2wkw5npmk = 0;
                    }
                    if ($Vt1knyxiv2uq === "auto") {
                        $Vt1knyxiv2uq = 0;
                    }

                    $Vxtfrabd3i5r = $Vf0dppyi23hd;
                    $Vzn5k4lefp5v = $Voq1154hnlga - $Vf0dppyi23hd;
                } else if ($Vxtfrabd3i5r === "auto" && $V3xygetcwtmz === "auto") {
                    if ($Vmq2wkw5npmk === "auto") {
                        $Vmq2wkw5npmk = 0;
                    }
                    if ($Vt1knyxiv2uq === "auto") {
                        $Vt1knyxiv2uq = 0;
                    }

                    $Vxtfrabd3i5r = $Vf0dppyi23hd;
                    $V3xygetcwtmz = $Voq1154hnlga - $Vf0dppyi23hd;
                } else if ($Vzn5k4lefp5v === "auto" && $V3xygetcwtmz === "auto") {
                    if ($Vmq2wkw5npmk === "auto") {
                        $Vmq2wkw5npmk = 0;
                    }
                    if ($Vt1knyxiv2uq === "auto") {
                        $Vt1knyxiv2uq = 0;
                    }

                    $V3xygetcwtmz = $Voq1154hnlga;
                } else if ($Vzn5k4lefp5v === "auto") {
                    if ($Vmq2wkw5npmk === "auto") {
                        $Vmq2wkw5npmk = 0;
                    }
                    if ($Vt1knyxiv2uq === "auto") {
                        $Vt1knyxiv2uq = 0;
                    }

                    $Vzn5k4lefp5v = $Voq1154hnlga;
                } else if ($Vxtfrabd3i5r === "auto") {
                    if ($Vmq2wkw5npmk === "auto") {
                        $Vmq2wkw5npmk = 0;
                    }
                    if ($Vt1knyxiv2uq === "auto") {
                        $Vt1knyxiv2uq = 0;
                    }

                    $Vxtfrabd3i5r = $Voq1154hnlga;
                } else if ($V3xygetcwtmz === "auto") {
                    if ($Vmq2wkw5npmk === "auto") {
                        $Vmq2wkw5npmk = 0;
                    }
                    if ($Vt1knyxiv2uq === "auto") {
                        $Vt1knyxiv2uq = 0;
                    }

                    $V3xygetcwtmz = $Voq1154hnlga;
                } else {
                    if ($Vkvw5zjrwkdm->overflow === "visible") {
                        
                        if ($Vmq2wkw5npmk === "auto") {
                            $Vmq2wkw5npmk = 0;
                        }
                        if ($Vt1knyxiv2uq === "auto") {
                            $Vt1knyxiv2uq = 0;
                        }
                        if ($Vzn5k4lefp5v === "auto") {
                            $Vzn5k4lefp5v = 0;
                        }
                        if ($V3xygetcwtmz === "auto") {
                            $V3xygetcwtmz = 0;
                        }
                        if ($Vxtfrabd3i5r === "auto") {
                            $Vxtfrabd3i5r = $Vf0dppyi23hd;
                        }
                    }

                    
                }
            }

        } else {
            
            if ($Vxtfrabd3i5r === "auto" && $Vf0dppyi23hd > $Vxtfrabd3i5r ) {
                $Vxtfrabd3i5r = $Vf0dppyi23hd;
            }

            
            

            
            if (!($Vkvw5zjrwkdm->overflow === "visible" || ($Vkvw5zjrwkdm->overflow === "hidden" && $Vxtfrabd3i5r === "auto"))) {
                $Vq4phveyfcky = $Vkvw5zjrwkdm->min_height;
                $V1fpzf3yli20 = $Vkvw5zjrwkdm->max_height;

                if (isset($Ve0njdrnxyyx["h"])) {
                    $Vq4phveyfcky = $Vkvw5zjrwkdm->length_in_pt($Vq4phveyfcky, $Ve0njdrnxyyx["h"]);
                    $V1fpzf3yli20 = $Vkvw5zjrwkdm->length_in_pt($V1fpzf3yli20, $Ve0njdrnxyyx["h"]);
                } else if (isset($Ve0njdrnxyyx["w"])) {
                    if (mb_strpos($Vq4phveyfcky, "%") !== false) {
                        $Vq4phveyfcky = 0;
                    } else {
                        $Vq4phveyfcky = $Vkvw5zjrwkdm->length_in_pt($Vq4phveyfcky, $Ve0njdrnxyyx["w"]);
                    }

                    if (mb_strpos($V1fpzf3yli20, "%") !== false) {
                        $V1fpzf3yli20 = "none";
                    } else {
                        $V1fpzf3yli20 = $Vkvw5zjrwkdm->length_in_pt($V1fpzf3yli20, $Ve0njdrnxyyx["w"]);
                    }
                }

                if ($V1fpzf3yli20 !== "none" && $Vq4phveyfcky > $V1fpzf3yli20) {
                    
                    list($V1fpzf3yli20, $Vq4phveyfcky) = array($Vq4phveyfcky, $V1fpzf3yli20);
                }

                if ($V1fpzf3yli20 !== "none" && $Vxtfrabd3i5r > $V1fpzf3yli20) {
                    $Vxtfrabd3i5r = $V1fpzf3yli20;
                }

                if ($Vxtfrabd3i5r < $Vq4phveyfcky) {
                    $Vxtfrabd3i5r = $Vq4phveyfcky;
                }
            }
        }

        return array($Vxtfrabd3i5r, $Vmq2wkw5npmk, $Vt1knyxiv2uq, $Vzn5k4lefp5v, $V3xygetcwtmz);
    }

    
    protected function _text_align()
    {
        $Vkvw5zjrwkdm = $this->_frame->get_style();
        $V5ymvwogwh5y = $this->_frame->get_containing_block("w");
        $Vtt4kvdwuqqh = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->width, $V5ymvwogwh5y);

        switch ($Vkvw5zjrwkdm->text_align) {
            default:
            case "left":
                foreach ($this->_frame->get_line_boxes() as $V4dr003jf14h) {
                    if (!$V4dr003jf14h->left) {
                        continue;
                    }

                    foreach ($V4dr003jf14h->get_frames() as $Vexjfacrc1d4) {
                        if ($Vexjfacrc1d4 instanceof BlockFrameDecorator) {
                            continue;
                        }
                        $Vexjfacrc1d4->set_position($Vexjfacrc1d4->get_position("x") + $V4dr003jf14h->left);
                    }
                }
                return;

            case "right":
                foreach ($this->_frame->get_line_boxes() as $V4dr003jf14h) {
                    
                    $Vdpjnuewahqw = $Vtt4kvdwuqqh - $V4dr003jf14h->w - $V4dr003jf14h->right;

                    foreach ($V4dr003jf14h->get_frames() as $Vexjfacrc1d4) {
                        
                        if ($Vexjfacrc1d4 instanceof BlockFrameDecorator) {
                            continue;
                        }

                        $Vexjfacrc1d4->set_position($Vexjfacrc1d4->get_position("x") + $Vdpjnuewahqw);
                    }
                }
                break;

            case "justify":
                
                $V4owjlhlrka3 = $this->_frame->get_line_boxes(); 
                $Veyru1ddhqqj = array_pop($V4owjlhlrka3);

                foreach ($V4owjlhlrka3 as $V0ixz2v5mxzy => $V4dr003jf14h) {
                    if ($V4dr003jf14h->br) {
                        unset($V4owjlhlrka3[$V0ixz2v5mxzy]);
                    }
                }

                
                $Vbksedwuuesm = $this->get_dompdf()->getFontMetrics()->getTextWidth(" ", $Vkvw5zjrwkdm->font_family, $Vkvw5zjrwkdm->font_size);

                foreach ($V4owjlhlrka3 as $V4dr003jf14h) {
                    if ($V4dr003jf14h->left) {
                        foreach ($V4dr003jf14h->get_frames() as $Vexjfacrc1d4) {
                            if (!$Vexjfacrc1d4 instanceof TextFrameDecorator) {
                                continue;
                            }

                            $Vexjfacrc1d4->set_position($Vexjfacrc1d4->get_position("x") + $V4dr003jf14h->left);
                        }
                    }

                    
                    if ($V4dr003jf14h->wc > 1) {
                        $Vd1hiq0tzl4w = ($Vtt4kvdwuqqh - ($V4dr003jf14h->left + $V4dr003jf14h->w + $V4dr003jf14h->right) + $Vbksedwuuesm) / ($V4dr003jf14h->wc - 1);
                    } else {
                        $Vd1hiq0tzl4w = 0;
                    }

                    $Vdpjnuewahqw = 0;
                    foreach ($V4dr003jf14h->get_frames() as $Vexjfacrc1d4) {
                        if (!$Vexjfacrc1d4 instanceof TextFrameDecorator) {
                            continue;
                        }

                        $Vnjapcj4bkpc = $Vexjfacrc1d4->get_text();
                        $Vmbtzq2ujh0d = mb_substr_count($Vnjapcj4bkpc, " ");

                        $Vymiqxxasoom = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->letter_spacing);
                        $Viaibh3bsnpy = $Vd1hiq0tzl4w + $Vymiqxxasoom;

                        $Vexjfacrc1d4->set_position($Vexjfacrc1d4->get_position("x") + $Vdpjnuewahqw);
                        $Vexjfacrc1d4->set_text_spacing($Viaibh3bsnpy);

                        $Vdpjnuewahqw += $Vmbtzq2ujh0d * $Viaibh3bsnpy;
                    }

                    
                    $V4dr003jf14h->w = $Vtt4kvdwuqqh;
                }

                
                if ($Veyru1ddhqqj->left) {
                    foreach ($Veyru1ddhqqj->get_frames() as $Vexjfacrc1d4) {
                        if ($Vexjfacrc1d4 instanceof BlockFrameDecorator) {
                            continue;
                        }
                        $Vexjfacrc1d4->set_position($Vexjfacrc1d4->get_position("x") + $Veyru1ddhqqj->left);
                    }
                }
                break;

            case "center":
            case "centre":
                foreach ($this->_frame->get_line_boxes() as $V4dr003jf14h) {
                    
                    $Vdpjnuewahqw = ($Vtt4kvdwuqqh + $V4dr003jf14h->left - $V4dr003jf14h->w - $V4dr003jf14h->right) / 2;

                    foreach ($V4dr003jf14h->get_frames() as $Vexjfacrc1d4) {
                        
                        if ($Vexjfacrc1d4 instanceof BlockFrameDecorator) {
                            continue;
                        }

                        $Vexjfacrc1d4->set_position($Vexjfacrc1d4->get_position("x") + $Vdpjnuewahqw);
                    }
                }
                break;
        }
    }

    
    function vertical_align()
    {
        $Vecmn4cx3vag = null;

        foreach ($this->_frame->get_line_boxes() as $V4dr003jf14h) {

            $Vxtfrabd3i5r = $V4dr003jf14h->h;

            foreach ($V4dr003jf14h->get_frames() as $Vexjfacrc1d4) {
                $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
                $V0ixz2v5mxzysInlineBlock = (
                    '-dompdf-image' === $Vkvw5zjrwkdm->display
                    || 'inline-block' === $Vkvw5zjrwkdm->display
                    || 'inline-table' === $Vkvw5zjrwkdm->display
                );
                if (!$V0ixz2v5mxzysInlineBlock && $Vkvw5zjrwkdm->display !== "inline") {
                    continue;
                }

                if (!isset($Vecmn4cx3vag)) {
                    $Vecmn4cx3vag = $Vexjfacrc1d4->get_root()->get_dompdf()->get_canvas();
                }

                $Vib2t0xt0ns0 = $Vecmn4cx3vag->get_font_baseline($Vkvw5zjrwkdm->font_family, $Vkvw5zjrwkdm->font_size);
                $Vnaokt1s1vzq = 0;

                
                if($V0ixz2v5mxzysInlineBlock) {
                    $V4dr003jf14hFrames = $V4dr003jf14h->get_frames();
                    if (count($V4dr003jf14hFrames) == 1) {
                        continue;
                    }
                    $Vexjfacrc1d4Box = $Vexjfacrc1d4->get_frame()->get_border_box();
                    $V0ixz2v5mxzymageHeightDiff = $Vxtfrabd3i5r * 0.8 - (float)$Vexjfacrc1d4Box['h'];

                    $Vdh52kd3mm3r = $Vexjfacrc1d4->get_style()->vertical_align;
                    if (in_array($Vdh52kd3mm3r, Style::$Ve4opixlv0wf) === true) {
                        switch ($Vdh52kd3mm3r) {
                            case "middle":
                                $Vnaokt1s1vzq = $V0ixz2v5mxzymageHeightDiff / 2;
                                break;

                            case "sub":
                                $Vnaokt1s1vzq = 0.3 * $Vxtfrabd3i5r + $V0ixz2v5mxzymageHeightDiff;
                                break;

                            case "super":
                                $Vnaokt1s1vzq = -0.2 * $Vxtfrabd3i5r + $V0ixz2v5mxzymageHeightDiff;
                                break;

                            case "text-top": 
                                $Vnaokt1s1vzq = $Vxtfrabd3i5r - (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->get_line_height(), $Vkvw5zjrwkdm->font_size);
                                break;

                            case "top":
                                break;

                            case "text-bottom": 
                            case "bottom":
                                $Vnaokt1s1vzq = 0.3 * $Vxtfrabd3i5r + $V0ixz2v5mxzymageHeightDiff;
                                break;

                            case "baseline":
                            default:
                                $Vnaokt1s1vzq = $V0ixz2v5mxzymageHeightDiff;
                                break;
                        }
                    } else {
                        $Vnaokt1s1vzq = $Vib2t0xt0ns0 - (float)$Vkvw5zjrwkdm->length_in_pt($Vdh52kd3mm3r, $Vkvw5zjrwkdm->font_size) - (float)$Vexjfacrc1d4Box['h'];
                    }
                } else {
                    $Vhbd3bset2hu = $Vexjfacrc1d4->get_parent();
                    if ($Vhbd3bset2hu instanceof TableCellFrameDecorator) {
                        $Vdh52kd3mm3r = "baseline";
                    } else {
                        $Vdh52kd3mm3r = $Vhbd3bset2hu->get_style()->vertical_align;
                    }
                    if (in_array($Vdh52kd3mm3r, Style::$Ve4opixlv0wf) === true) {
                        switch ($Vdh52kd3mm3r) {
                            case "middle":
                                $Vnaokt1s1vzq = ($Vxtfrabd3i5r * 0.8 - $Vib2t0xt0ns0) / 2;
                                break;

                            case "sub":
                                $Vnaokt1s1vzq = $Vxtfrabd3i5r * 0.8 - $Vib2t0xt0ns0 * 0.5;
                                break;

                            case "super":
                                $Vnaokt1s1vzq = $Vxtfrabd3i5r * 0.8 - $Vib2t0xt0ns0 * 1.4;
                                break;

                            case "text-top":
                            case "top": 
                                break;

                            case "text-bottom":
                            case "bottom":
                                $Vnaokt1s1vzq = $Vxtfrabd3i5r * 0.8 - $Vib2t0xt0ns0;
                                break;

                            case "baseline":
                            default:
                                $Vnaokt1s1vzq = $Vxtfrabd3i5r * 0.8 - $Vib2t0xt0ns0;
                                break;
                        }
                    } else {
                        $Vnaokt1s1vzq = $Vxtfrabd3i5r * 0.8 - $Vib2t0xt0ns0 - (float)$Vkvw5zjrwkdm->length_in_pt($Vdh52kd3mm3r, $Vkvw5zjrwkdm->font_size);
                    }
                }

                if ($Vnaokt1s1vzq !== 0) {
                    $Vexjfacrc1d4->move(0, $Vnaokt1s1vzq);
                }
            }
        }
    }

    
    function process_clear(Frame $V0mqc4rbglqu)
    {
        $V0mqc4rbglqu_style = $V0mqc4rbglqu->get_style();
        $Vfqvundqbe4u = $this->_frame->get_root();

        
        if ($V0mqc4rbglqu_style->clear !== "none") {
            
            if ($V0mqc4rbglqu->get_prev_sibling() !== null) {
                $this->_frame->add_line();
            }
            if ($V0mqc4rbglqu_style->float !== "none" && $V0mqc4rbglqu->get_next_sibling()) {
                $this->_frame->set_current_line_number($this->_frame->get_current_line_number() - 1);
            }

            $Vwotusl4awc5 = $Vfqvundqbe4u->get_lowest_float_offset($V0mqc4rbglqu);

            
            if ($Vwotusl4awc5) {
                if ($V0mqc4rbglqu->is_in_flow()) {
                    $V4dr003jf14h_box = $this->_frame->get_current_line_box();
                    $V4dr003jf14h_box->y = $Vwotusl4awc5 + $V0mqc4rbglqu->get_margin_height();
                    $V4dr003jf14h_box->left = 0;
                    $V4dr003jf14h_box->right = 0;
                }

                $V0mqc4rbglqu->move(0, $Vwotusl4awc5 - $V0mqc4rbglqu->get_position("y"));
            }
        }
    }

    
    function process_float(Frame $V0mqc4rbglqu, $Ve0njdrnxyyx_x, $Ve0njdrnxyyx_w)
    {
        $V0mqc4rbglqu_style = $V0mqc4rbglqu->get_style();
        $Vfqvundqbe4u = $this->_frame->get_root();

        
        if ($V0mqc4rbglqu_style->float !== "none") {
            $Vfqvundqbe4u->add_floating_frame($V0mqc4rbglqu);

            
            $Ve3fliainba2 = $V0mqc4rbglqu->get_next_sibling();
            if ($Ve3fliainba2 && $Ve3fliainba2 instanceof TextFrameDecorator) {
                $Ve3fliainba2->set_text(ltrim($Ve3fliainba2->get_text()));
            }

            $V4dr003jf14h_box = $this->_frame->get_current_line_box();
            list($V2naqejx1kty, $Vyoqlrt0ydc0) = $V0mqc4rbglqu->get_position();

            $Vwaxvma5shuo = $Ve0njdrnxyyx_x;
            $Vh2owbvdrihj = $Vyoqlrt0ydc0;
            $Vduko45roa0z = $V0mqc4rbglqu->get_margin_width();

            if ($V0mqc4rbglqu_style->clear === "none") {
                switch ($V0mqc4rbglqu_style->float) {
                    case "left":
                        $Vwaxvma5shuo += $V4dr003jf14h_box->left;
                        break;
                    case "right":
                        $Vwaxvma5shuo += ($Ve0njdrnxyyx_w - $V4dr003jf14h_box->right - $Vduko45roa0z);
                        break;
                }
            } else {
                if ($V0mqc4rbglqu_style->float === "right") {
                    $Vwaxvma5shuo += ($Ve0njdrnxyyx_w - $Vduko45roa0z);
                }
            }

            if ($Ve0njdrnxyyx_w < $Vwaxvma5shuo + $Vduko45roa0z - $V2naqejx1kty) {
                
            }

            $V4dr003jf14h_box->get_float_offsets();

            if ($V0mqc4rbglqu->_float_next_line) {
                $Vh2owbvdrihj += $V4dr003jf14h_box->h;
            }

            $V0mqc4rbglqu->set_position($Vwaxvma5shuo, $Vh2owbvdrihj);
            $V0mqc4rbglqu->move($Vwaxvma5shuo - $V2naqejx1kty, $Vh2owbvdrihj - $Vyoqlrt0ydc0, true);
        }
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {

        
        $Vvhh3j3svzeq = $this->_frame->get_root();
        $Vvhh3j3svzeq->check_forced_page_break($this->_frame);

        
        if ($Vvhh3j3svzeq->is_full()) {
            return;
        }

        
        $this->_set_content();

        
        $this->_collapse_margins();

        $Vkvw5zjrwkdm = $this->_frame->get_style();
        $Ve0njdrnxyyx = $this->_frame->get_containing_block();

        if ($Vkvw5zjrwkdm->position === "fixed") {
            $Ve0njdrnxyyx = $this->_frame->get_root()->get_containing_block();
        }

        
        
        list($V5ymvwogwh5y, $Vb5dthqtenbv_margin, $Vqswkdbtte35_margin, $Vb5dthqtenbv, $Vqswkdbtte35) = $this->_calculate_restricted_width();

        
        $Vkvw5zjrwkdm->width = $V5ymvwogwh5y;
        $Vkvw5zjrwkdm->margin_left = $Vb5dthqtenbv_margin;
        $Vkvw5zjrwkdm->margin_right = $Vqswkdbtte35_margin;
        $Vkvw5zjrwkdm->left = $Vb5dthqtenbv;
        $Vkvw5zjrwkdm->right = $Vqswkdbtte35;

        
        $this->_frame->position();
        list($Vmm2pe5l4str, $Vuua0v2znlr5) = $this->_frame->get_position();

        
        $V0ixz2v5mxzyndent = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->text_indent, $Ve0njdrnxyyx["w"]);
        $this->_frame->increase_line_width($V0ixz2v5mxzyndent);

        
        $Vzn5k4lefp5v = (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_top,
            $Vkvw5zjrwkdm->padding_top,
            $Vkvw5zjrwkdm->border_top_width), $Ve0njdrnxyyx["h"]);

        $V3xygetcwtmz = (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->border_bottom_width,
            $Vkvw5zjrwkdm->margin_bottom,
            $Vkvw5zjrwkdm->padding_bottom), $Ve0njdrnxyyx["h"]);

        $Ve0njdrnxyyx_x = $Vmm2pe5l4str + (float)$Vb5dthqtenbv_margin + (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->border_left_width,
                $Vkvw5zjrwkdm->padding_left), $Ve0njdrnxyyx["w"]);

        $Ve0njdrnxyyx_y = $Vuua0v2znlr5 + $Vzn5k4lefp5v;

        $Ve0njdrnxyyx_h = ($Ve0njdrnxyyx["h"] + $Ve0njdrnxyyx["y"]) - $V3xygetcwtmz - $Ve0njdrnxyyx_y;

        
        $V4dr003jf14h_box = $this->_frame->get_current_line_box();
        $V4dr003jf14h_box->y = $Ve0njdrnxyyx_y;
        $V4dr003jf14h_box->get_float_offsets();

        
        foreach ($this->_frame->get_children() as $V0mqc4rbglqu) {

            
            if ($Vvhh3j3svzeq->is_full()) {
                break;
            }

            $V0mqc4rbglqu->set_containing_block($Ve0njdrnxyyx_x, $Ve0njdrnxyyx_y, $V5ymvwogwh5y, $Ve0njdrnxyyx_h);

            $this->process_clear($V0mqc4rbglqu);

            $V0mqc4rbglqu->reflow($this->_frame);

            
            if ($Vvhh3j3svzeq->check_page_break($V0mqc4rbglqu)) {
                break;
            }

            $this->process_float($V0mqc4rbglqu, $Ve0njdrnxyyx_x, $V5ymvwogwh5y);
        }

        
        list($Vxtfrabd3i5r, $Vmq2wkw5npmk, $Vt1knyxiv2uq, $Vzn5k4lefp5v, $V3xygetcwtmz) = $this->_calculate_restricted_height();
        $Vkvw5zjrwkdm->height = $Vxtfrabd3i5r;
        $Vkvw5zjrwkdm->margin_top = $Vmq2wkw5npmk;
        $Vkvw5zjrwkdm->margin_bottom = $Vt1knyxiv2uq;
        $Vkvw5zjrwkdm->top = $Vzn5k4lefp5v;
        $Vkvw5zjrwkdm->bottom = $V3xygetcwtmz;

        $Vbcrj2f5ypbf = $this->_frame->get_original_style();

        $Vr52t42mpjbm = ($Vkvw5zjrwkdm->position === "absolute" && ($Vkvw5zjrwkdm->right !== "auto" || $Vkvw5zjrwkdm->bottom !== "auto"));

        
        if ($Vr52t42mpjbm) {
            if ($Vbcrj2f5ypbf->width === "auto" && ($Vbcrj2f5ypbf->left === "auto" || $Vbcrj2f5ypbf->right === "auto")) {
                $Vtt4kvdwuqqh = 0;
                foreach ($this->_frame->get_line_boxes() as $V4dr003jf14h) {
                    $Vtt4kvdwuqqh = max($V4dr003jf14h->w, $Vtt4kvdwuqqh);
                }
                $Vkvw5zjrwkdm->width = $Vtt4kvdwuqqh;
            }

            $Vkvw5zjrwkdm->left = $Vbcrj2f5ypbf->left;
            $Vkvw5zjrwkdm->right = $Vbcrj2f5ypbf->right;
        }

        
        if (($Vkvw5zjrwkdm->display === "inline-block" || $Vkvw5zjrwkdm->float !== 'none') && $Vbcrj2f5ypbf->width === 'auto') {
            $Vtt4kvdwuqqh = 0;

            foreach ($this->_frame->get_line_boxes() as $V4dr003jf14h) {
                $V4dr003jf14h->recalculate_width();

                $Vtt4kvdwuqqh = max($V4dr003jf14h->w, $Vtt4kvdwuqqh);
            }

            if ($Vtt4kvdwuqqh === 0) {
                foreach ($this->_frame->get_children() as $V0mqc4rbglqu) {
                    $Vtt4kvdwuqqh += $V0mqc4rbglqu->calculate_auto_width();
                }
            }

            $Vkvw5zjrwkdm->width = $Vtt4kvdwuqqh;
        }

        $this->_text_align();
        $this->vertical_align();

        
        if ($Vr52t42mpjbm) {
            list($Vmm2pe5l4str, $Vuua0v2znlr5) = $this->_frame->get_position();
            $this->_frame->position();
            list($V0jvk4q1h2bc, $Vaghl41qjbna) = $this->_frame->get_position();
            $this->_frame->move($V0jvk4q1h2bc - $Vmm2pe5l4str, $Vaghl41qjbna - $Vuua0v2znlr5, true);
        }

        if ($Vynts1bqvpvb && $this->_frame->is_in_flow()) {
            $Vynts1bqvpvb->add_frame_to_line($this->_frame);

            
            if ($Vkvw5zjrwkdm->display === "block") {
                $Vynts1bqvpvb->add_line();
            }
        }
    }

    
    public function calculate_auto_width()
    {
        $Vtt4kvdwuqqh = 0;

        foreach ($this->_frame->get_line_boxes() as $V4dr003jf14h) {
            $V4dr003jf14h_width = 0;

            foreach ($V4dr003jf14h->get_frames() as $Vexjfacrc1d4) {
                if ($Vexjfacrc1d4->get_original_style()->width == 'auto') {
                    $V4dr003jf14h_width += $Vexjfacrc1d4->calculate_auto_width();
                } else {
                    $V4dr003jf14h_width += $Vexjfacrc1d4->get_margin_width();
                }
            }

            $Vtt4kvdwuqqh = max($V4dr003jf14h_width, $Vtt4kvdwuqqh);
        }

        $this->_frame->get_style()->width = $Vtt4kvdwuqqh;

        return $this->_frame->get_margin_width();
    }
}
