<?php

namespace Dompdf\FrameReflower;

use Dompdf\FrameDecorator\Block as BlockFrameDecorator;
use Dompdf\FrameDecorator\Table as TableFrameDecorator;


class TableRowGroup extends AbstractFrameReflower
{

    
    function __construct($Vexjfacrc1d4)
    {
        parent::__construct($Vexjfacrc1d4);
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {
        $Vvhh3j3svzeq = $this->_frame->get_root();

        $Vkvw5zjrwkdm = $this->_frame->get_style();

        
        $Vp5rpvpxnb43 = TableFrameDecorator::find_parent_table($this->_frame);

        $Ve0njdrnxyyx = $this->_frame->get_containing_block();

        foreach ($this->_frame->get_children() as $V0mqc4rbglqu) {
            
            if ($Vvhh3j3svzeq->is_full()) {
                return;
            }

            $V0mqc4rbglqu->set_containing_block($Ve0njdrnxyyx["x"], $Ve0njdrnxyyx["y"], $Ve0njdrnxyyx["w"], $Ve0njdrnxyyx["h"]);
            $V0mqc4rbglqu->reflow();

            
            $Vvhh3j3svzeq->check_page_break($V0mqc4rbglqu);
        }

        if ($Vvhh3j3svzeq->is_full()) {
            return;
        }

        $V5hlwkutan5t = $Vp5rpvpxnb43->get_cellmap();
        $Vkvw5zjrwkdm->width = $V5hlwkutan5t->get_frame_width($this->_frame);
        $Vkvw5zjrwkdm->height = $V5hlwkutan5t->get_frame_height($this->_frame);

        $this->_frame->set_position($V5hlwkutan5t->get_frame_position($this->_frame));

        if ($Vp5rpvpxnb43->get_style()->border_collapse === "collapse") {
            
            $Vkvw5zjrwkdm->border_style = "none";
        }
    }
}
