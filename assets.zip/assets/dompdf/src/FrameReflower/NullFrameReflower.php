<?php


namespace Dompdf\FrameReflower;

use Dompdf\Frame;
use Dompdf\FrameDecorator\Block as BlockFrameDecorator;


class NullFrameReflower extends AbstractFrameReflower
{

    
    function __construct(Frame $Vexjfacrc1d4)
    {
        parent::__construct($Vexjfacrc1d4);
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {
        return;
    }

}
