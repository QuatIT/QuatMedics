<?php

namespace Dompdf\FrameReflower;

use Dompdf\FrameDecorator\Block as BlockFrameDecorator;
use Dompdf\FrameDecorator\Text as TextFrameDecorator;
use Dompdf\FontMetrics;
use Dompdf\Helpers;


class Text extends AbstractFrameReflower
{

    
    protected $Vnacorns3rpz; 

    
    protected $Vzyb2djzba42;

    public static $Vqv2dtpycyba = "/[ \t\r\n\f]+/u";

    
    private $Vnl1binwcwye;

    
    public function __construct(TextFrameDecorator $Vexjfacrc1d4, FontMetrics $Vnl1binwcwye)
    {
        parent::__construct($Vexjfacrc1d4);
        $Vvkqsaecgfirhis->setFontMetrics($Vnl1binwcwye);
    }

    
    protected function _collapse_white_space($Vnjapcj4bkpc)
    {
        


        return preg_replace(self::$Vqv2dtpycyba, " ", $Vnjapcj4bkpc);
    }

    
    protected function _line_break($Vnjapcj4bkpc)
    {
        $Vkvw5zjrwkdm = $Vvkqsaecgfirhis->_frame->get_style();
        $Vkgj34o34uaw = $Vkvw5zjrwkdm->font_size;
        $Vfsinbbqzbga = $Vkvw5zjrwkdm->font_family;
        $V3sydlnnnoip = $Vvkqsaecgfirhis->_block_parent->get_current_line_box();

        
        $Vy2l4ecyg4hr = $Vvkqsaecgfirhis->_frame->get_containing_block("w");
        $V3sydlnnnoip_width = $V3sydlnnnoip->left + $V3sydlnnnoip->w + $V3sydlnnnoip->right;

        $V1z5ctejdq22 = $Vy2l4ecyg4hr - $V3sydlnnnoip_width;

        
        $Vwvfvnewm3zv = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->word_spacing);
        $Vymiqxxasoom = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->letter_spacing);

        
        $Vnjapcj4bkpc_width = $Vvkqsaecgfirhis->getFontMetrics()->getTextWidth($Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);
        $Vfebah0gclir =
            (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_left,
                $Vkvw5zjrwkdm->border_left_width,
                $Vkvw5zjrwkdm->padding_left,
                $Vkvw5zjrwkdm->padding_right,
                $Vkvw5zjrwkdm->border_right_width,
                $Vkvw5zjrwkdm->margin_right), $Vy2l4ecyg4hr);

        $Vexjfacrc1d4_width = $Vnjapcj4bkpc_width + $Vfebah0gclir;












        if ($Vexjfacrc1d4_width <= $V1z5ctejdq22) {
            return false;
        }

        
        $Velhvh4itfkx = preg_split('/([\s-]+)/u', $Vnjapcj4bkpc, -1, PREG_SPLIT_DELIM_CAPTURE);
        $Vwp2ojhdk2ge = count($Velhvh4itfkx);

        
        $Vtt4kvdwuqqh = 0;
        $Vu5vpgek1hmh = "";
        reset($Velhvh4itfkx);

        
        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vwp2ojhdk2ge; $V0ixz2v5mxzy += 2) {
            $V0oby33effyr = $Velhvh4itfkx[$V0ixz2v5mxzy] . (isset($Velhvh4itfkx[$V0ixz2v5mxzy + 1]) ? $Velhvh4itfkx[$V0ixz2v5mxzy + 1] : "");
            $V0oby33effyr_width = $Vvkqsaecgfirhis->getFontMetrics()->getTextWidth($V0oby33effyr, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);
            if ($Vtt4kvdwuqqh + $V0oby33effyr_width + $Vfebah0gclir > $V1z5ctejdq22) {
                break;
            }

            $Vtt4kvdwuqqh += $V0oby33effyr_width;
            $Vu5vpgek1hmh .= $V0oby33effyr;
        }

        $Vsnor5pbc5pb = ($Vkvw5zjrwkdm->word_wrap === "break-word");

        
        if ($V3sydlnnnoip_width == 0 && $Vtt4kvdwuqqh == 0) {
            $V500t5q0ulgs = "";
            $Vbz1u2n5hpae = 0;

            if ($Vsnor5pbc5pb) {
                for ($Vy4wtqjehnh5 = 0; $Vy4wtqjehnh5 < strlen($V0oby33effyr); $Vy4wtqjehnh5++) {
                    $V500t5q0ulgs .= $V0oby33effyr[$Vy4wtqjehnh5];
                    $Vxc0qtxc1w0o = $Vvkqsaecgfirhis->getFontMetrics()->getTextWidth($V500t5q0ulgs, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);
                    if ($Vxc0qtxc1w0o > $V1z5ctejdq22) {
                        break;
                    }

                    $Vbz1u2n5hpae = $Vxc0qtxc1w0o;
                }
            }

            if ($Vsnor5pbc5pb && $Vbz1u2n5hpae > 0) {
                
                $Vu5vpgek1hmh .= substr($V500t5q0ulgs, 0, -1);
            } else {
                
                $Vu5vpgek1hmh .= $V0oby33effyr;
            }
        }

        $Veatxxxrhqpk = mb_strlen($Vu5vpgek1hmh);

        
        
        
        

        return $Veatxxxrhqpk;
    }

    

    
    protected function _newline_break($Vnjapcj4bkpc)
    {
        if (($V0ixz2v5mxzy = mb_strpos($Vnjapcj4bkpc, "\n")) === false) {
            return false;
        }

        return $V0ixz2v5mxzy + 1;
    }

    
    protected function _layout_line()
    {
        $Vexjfacrc1d4 = $Vvkqsaecgfirhis->_frame;
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Vnjapcj4bkpc = $Vexjfacrc1d4->get_text();
        $Vkgj34o34uaw = $Vkvw5zjrwkdm->font_size;
        $Vfsinbbqzbga = $Vkvw5zjrwkdm->font_family;

        
        $Vkvw5zjrwkdm->height = $Vvkqsaecgfirhis->getFontMetrics()->getFontHeight($Vfsinbbqzbga, $Vkgj34o34uaw);

        $V500t5q0ulgsplit = false;
        $V1lo0grr5e44 = false;

        
        
        switch (strtolower($Vkvw5zjrwkdm->text_transform)) {
            default:
                break;
            case "capitalize":
                $Vnjapcj4bkpc = Helpers::mb_ucwords($Vnjapcj4bkpc);
                break;
            case "uppercase":
                $Vnjapcj4bkpc = mb_convert_case($Vnjapcj4bkpc, MB_CASE_UPPER);
                break;
            case "lowercase":
                $Vnjapcj4bkpc = mb_convert_case($Vnjapcj4bkpc, MB_CASE_LOWER);
                break;
        }

        
        
        switch ($Vkvw5zjrwkdm->white_space) {
            default:
            case "normal":
                $Vexjfacrc1d4->set_text($Vnjapcj4bkpc = $Vvkqsaecgfirhis->_collapse_white_space($Vnjapcj4bkpc));
                if ($Vnjapcj4bkpc == "") {
                    break;
                }

                $V500t5q0ulgsplit = $Vvkqsaecgfirhis->_line_break($Vnjapcj4bkpc);
                break;

            case "pre":
                $V500t5q0ulgsplit = $Vvkqsaecgfirhis->_newline_break($Vnjapcj4bkpc);
                $V1lo0grr5e44 = $V500t5q0ulgsplit !== false;
                break;

            case "nowrap":
                $Vexjfacrc1d4->set_text($Vnjapcj4bkpc = $Vvkqsaecgfirhis->_collapse_white_space($Vnjapcj4bkpc));
                break;

            case "pre-wrap":
                $V500t5q0ulgsplit = $Vvkqsaecgfirhis->_newline_break($Vnjapcj4bkpc);

                if (($Vj0eqma35tbv = $Vvkqsaecgfirhis->_line_break($Vnjapcj4bkpc)) !== false) {
                    $V1lo0grr5e44 = $V500t5q0ulgsplit < $Vj0eqma35tbv;
                    $V500t5q0ulgsplit = min($Vj0eqma35tbv, $V500t5q0ulgsplit);
                } else
                    $V1lo0grr5e44 = true;

                break;

            case "pre-line":
                
                $Vexjfacrc1d4->set_text($Vnjapcj4bkpc = preg_replace("/[ \t]+/u", " ", $Vnjapcj4bkpc));

                if ($Vnjapcj4bkpc == "") {
                    break;
                }

                $V500t5q0ulgsplit = $Vvkqsaecgfirhis->_newline_break($Vnjapcj4bkpc);

                if (($Vj0eqma35tbv = $Vvkqsaecgfirhis->_line_break($Vnjapcj4bkpc)) !== false) {
                    $V1lo0grr5e44 = $V500t5q0ulgsplit < $Vj0eqma35tbv;
                    $V500t5q0ulgsplit = min($Vj0eqma35tbv, $V500t5q0ulgsplit);
                } else {
                    $V1lo0grr5e44 = true;
                }

                break;

        }

        
        if ($Vnjapcj4bkpc === "") {
            return;
        }

        if ($V500t5q0ulgsplit !== false) {
            
            if ($V500t5q0ulgsplit == 0 && $Vnjapcj4bkpc === " ") {
                $Vexjfacrc1d4->set_text("");
                return;
            }

            if ($V500t5q0ulgsplit == 0) {
                
                

                $Vvkqsaecgfirhis->_block_parent->maximize_line_height($Vkvw5zjrwkdm->height, $Vexjfacrc1d4);
                $Vvkqsaecgfirhis->_block_parent->add_line();
                $Vexjfacrc1d4->position();

                
                $Vvkqsaecgfirhis->_layout_line();
            } else if ($V500t5q0ulgsplit < mb_strlen($Vexjfacrc1d4->get_text())) {
                
                $Vexjfacrc1d4->split_text($V500t5q0ulgsplit);

                $Vvkqsaecgfir = $Vexjfacrc1d4->get_text();

                
                if ($V500t5q0ulgsplit > 1 && $Vvkqsaecgfir[$V500t5q0ulgsplit - 1] === "\n" && !$Vexjfacrc1d4->is_pre()) {
                    $Vexjfacrc1d4->set_text(mb_substr($Vvkqsaecgfir, 0, -1));
                }

                
                
                
                
                
            }

            if ($V1lo0grr5e44) {
                $Vvkqsaecgfirhis->_block_parent->add_line();
                $Vexjfacrc1d4->position();
            }
        } else {
            
            
            
            $Vvkqsaecgfir = $Vexjfacrc1d4->get_text();
            $Vhbd3bset2hu = $Vexjfacrc1d4->get_parent();
            $V0ixz2v5mxzys_inline_frame = ($Vhbd3bset2hu instanceof \Dompdf\FrameDecorator\Inline);

            if ((!$V0ixz2v5mxzys_inline_frame && !$Vexjfacrc1d4->get_next_sibling()) 
            ) { 
                $Vvkqsaecgfir = rtrim($Vvkqsaecgfir);
            }

            if ((!$V0ixz2v5mxzys_inline_frame && !$Vexjfacrc1d4->get_prev_sibling()) 
            ) { 
                $Vvkqsaecgfir = ltrim($Vvkqsaecgfir);
            }

            $Vexjfacrc1d4->set_text($Vvkqsaecgfir);
        }

        
        $Vtt4kvdwuqqh = $Vexjfacrc1d4->recalculate_width();
    }

    
    function reflow(BlockFrameDecorator $Vynts1bqvpvb = null)
    {
        $Vexjfacrc1d4 = $Vvkqsaecgfirhis->_frame;
        $Vvhh3j3svzeq = $Vexjfacrc1d4->get_root();
        $Vvhh3j3svzeq->check_forced_page_break($Vvkqsaecgfirhis->_frame);

        if ($Vvhh3j3svzeq->is_full()) {
            return;
        }

        $Vvkqsaecgfirhis->_block_parent = 
        $Vexjfacrc1d4->find_block_parent();

        
        






        $Vexjfacrc1d4->position();

        $Vvkqsaecgfirhis->_layout_line();

        if ($Vynts1bqvpvb) {
            $Vynts1bqvpvb->add_frame_to_line($Vexjfacrc1d4);
        }
    }

    

    
    
    function get_min_max_width()
    {
        
        $Vexjfacrc1d4 = $Vvkqsaecgfirhis->_frame;
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Vvkqsaecgfirhis->_block_parent = $Vexjfacrc1d4->find_block_parent();
        $Vy2l4ecyg4hr = $Vexjfacrc1d4->get_containing_block("w");

        $Vu5vpgek1hmh = $Vnjapcj4bkpc = $Vexjfacrc1d4->get_text();
        $Vkgj34o34uaw = $Vkvw5zjrwkdm->font_size;
        $Vfsinbbqzbga = $Vkvw5zjrwkdm->font_family;

        $Vwvfvnewm3zv = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->word_spacing);
        $Vymiqxxasoom = (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->letter_spacing);

        switch ($Vkvw5zjrwkdm->white_space) {
            default:
            case "normal":
                $Vu5vpgek1hmh = preg_replace(self::$Vqv2dtpycyba, " ", $Vu5vpgek1hmh);
            case "pre-wrap":
            case "pre-line":

                

                
                
                
                $Velhvh4itfkx = array_flip(preg_split("/[\s-]+/u", $Vu5vpgek1hmh, -1, PREG_SPLIT_DELIM_CAPTURE));
                $Vfqvundqbe4u = $Vvkqsaecgfirhis;
                array_walk($Velhvh4itfkx, function(&$Vso3o0kfkstx, $Vu5vpgek1hmh) use ($Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom, $Vfqvundqbe4u) {
                    $Vso3o0kfkstx = $Vfqvundqbe4u->getFontMetrics()->getTextWidth($Vu5vpgek1hmh, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);
                });

                arsort($Velhvh4itfkx);
                $Vbvkkidyyo23 = reset($Velhvh4itfkx);
                break;

            case "pre":
                $V4owjlhlrka3 = array_flip(preg_split("/\n/u", $Vu5vpgek1hmh));
                $Vfqvundqbe4u = $Vvkqsaecgfirhis;
                array_walk($V4owjlhlrka3, function(&$Vso3o0kfkstx, $Vu5vpgek1hmh) use ($Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom, $Vfqvundqbe4u) {
                    $Vso3o0kfkstx = $Vfqvundqbe4u->getFontMetrics()->getTextWidth($Vu5vpgek1hmh, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);
                });

                arsort($V4owjlhlrka3);
                $Vbvkkidyyo23 = reset($V4owjlhlrka3);
                break;

            case "nowrap":
                $Vbvkkidyyo23 = $Vvkqsaecgfirhis->getFontMetrics()->getTextWidth($Vvkqsaecgfirhis->_collapse_white_space($Vu5vpgek1hmh), $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);
                break;
        }

        switch ($Vkvw5zjrwkdm->white_space) {
            default:
            case "normal":
            case "nowrap":
                $Vu5vpgek1hmh = preg_replace(self::$Vqv2dtpycyba, " ", $Vnjapcj4bkpc);
                break;

            case "pre-line":
                
                $Vu5vpgek1hmh = preg_replace("/[ \t]+/u", " ", $Vnjapcj4bkpc);

            case "pre-wrap":
                
                $V4owjlhlrka3 = array_flip(preg_split("/\n/", $Vnjapcj4bkpc));
                $Vfqvundqbe4u = $Vvkqsaecgfirhis;
                array_walk($V4owjlhlrka3, function(&$Vso3o0kfkstx, $Vu5vpgek1hmh) use ($Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom, $Vfqvundqbe4u) {
                    $Vso3o0kfkstx = $Vfqvundqbe4u->getFontMetrics()->getTextWidth($Vu5vpgek1hmh, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);
                });
                arsort($V4owjlhlrka3);
                reset($V4owjlhlrka3);
                $Vu5vpgek1hmh = key($V4owjlhlrka3);
                break;
        }

        $V44xdi33bxee = $Vvkqsaecgfirhis->getFontMetrics()->getTextWidth($Vu5vpgek1hmh, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);

        $V0w5rvqizf1i = (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_left,
            $Vkvw5zjrwkdm->border_left_width,
            $Vkvw5zjrwkdm->padding_left,
            $Vkvw5zjrwkdm->padding_right,
            $Vkvw5zjrwkdm->border_right_width,
            $Vkvw5zjrwkdm->margin_right), $Vy2l4ecyg4hr);
        $Vbvkkidyyo23 += $V0w5rvqizf1i;
        $V44xdi33bxee += $V0w5rvqizf1i;

        return $Vvkqsaecgfirhis->_min_max_cache = array($Vbvkkidyyo23, $V44xdi33bxee, "min" => $Vbvkkidyyo23, "max" => $V44xdi33bxee);
    }

    
    public function setFontMetrics(FontMetrics $Vnl1binwcwye)
    {
        $Vvkqsaecgfirhis->fontMetrics = $Vnl1binwcwye;
        return $Vvkqsaecgfirhis;
    }

    
    public function getFontMetrics()
    {
        return $Vvkqsaecgfirhis->fontMetrics;
    }

    
    public function calculate_auto_width()
    {
        return $Vvkqsaecgfirhis->_frame->recalculate_width();
    }
}
