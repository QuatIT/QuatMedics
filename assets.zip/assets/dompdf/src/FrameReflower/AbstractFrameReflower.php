<?php

namespace Dompdf\FrameReflower;

use Dompdf\Adapter\CPDF;
use Dompdf\Css\Style;
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Frame;
use Dompdf\FrameDecorator\Block;
use Dompdf\Frame\Factory;


abstract class AbstractFrameReflower
{

    
    protected $Vzyb2djzba42;

    
    protected $Vdpgfrb1lccd;

    
    function __construct(Frame $Vexjfacrc1d4)
    {
        $Vvkqsaecgfirhis->_frame = $Vexjfacrc1d4;
        $Vvkqsaecgfirhis->_min_max_cache = null;
    }

    function dispose()
    {
    }

    
    function get_dompdf()
    {
        return $Vvkqsaecgfirhis->_frame->get_dompdf();
    }

    
    protected function _collapse_margins()
    {
        $Vexjfacrc1d4 = $Vvkqsaecgfirhis->_frame;
        $Ve0njdrnxyyx = $Vexjfacrc1d4->get_containing_block();
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        
        if (!$Vexjfacrc1d4->is_in_flow() || $Vexjfacrc1d4->is_inline_block()) {
            return;
        }

        $Vvkqsaecgfir = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_top, $Ve0njdrnxyyx["h"]);
        $Vkbvefdrfvxh = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_bottom, $Ve0njdrnxyyx["h"]);

        
        if ($Vvkqsaecgfir === "auto") {
            $Vkvw5zjrwkdm->margin_top = "0pt";
            $Vvkqsaecgfir = 0;
        }

        if ($Vkbvefdrfvxh === "auto") {
            $Vkvw5zjrwkdm->margin_bottom = "0pt";
            $Vkbvefdrfvxh = 0;
        }

        
        $Vu440l53e414 = $Vexjfacrc1d4->get_next_sibling();
        if ( $Vu440l53e414 && !$Vu440l53e414->is_block() & !$Vu440l53e414->is_table() ) {
            while ($Vu440l53e414 = $Vu440l53e414->get_next_sibling()) {
                if ($Vu440l53e414->is_block() || $Vu440l53e414->is_table()) {
                    break;
                }

                if (!$Vu440l53e414->get_first_child()) {
                    $Vu440l53e414 = null;
                    break;
                }
            }
        }

        if ($Vu440l53e414) {
            $Vu440l53e414_style = $Vu440l53e414->get_style();
            $Vu440l53e414_t = (float)$Vu440l53e414_style->length_in_pt($Vu440l53e414_style->margin_top, $Ve0njdrnxyyx["h"]);

            $Vkbvefdrfvxh = $Vvkqsaecgfirhis->_get_collapsed_margin_length($Vkbvefdrfvxh, $Vu440l53e414_t);
            $Vkvw5zjrwkdm->margin_bottom = $Vkbvefdrfvxh . "pt";
            $Vu440l53e414_style->margin_top = "0pt";
        }

        
        if ($Vkvw5zjrwkdm->get_border_top_width() == 0 && $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_top) == 0) {
            $Vtmlsxxw3ne1 = $Vvkqsaecgfirhis->_frame->get_first_child();
            if ( $Vtmlsxxw3ne1 && !$Vtmlsxxw3ne1->is_block() && !$Vtmlsxxw3ne1->is_table() ) {
                while ( $Vtmlsxxw3ne1 = $Vtmlsxxw3ne1->get_next_sibling() ) {
                    if ( $Vtmlsxxw3ne1->is_block() || $Vtmlsxxw3ne1->is_table() ) {
                        break;
                    }

                    if ( !$Vtmlsxxw3ne1->get_first_child() ) {
                        $Vtmlsxxw3ne1 = null;
                        break;
                    }
                }
            }

            
            if ($Vtmlsxxw3ne1) {
                $Vtmlsxxw3ne1_style = $Vtmlsxxw3ne1->get_style();
                $Vtmlsxxw3ne1_t = (float)$Vtmlsxxw3ne1_style->length_in_pt($Vtmlsxxw3ne1_style->margin_top, $Ve0njdrnxyyx["h"]);

                $Vvkqsaecgfir = $Vvkqsaecgfirhis->_get_collapsed_margin_length($Vvkqsaecgfir, $Vtmlsxxw3ne1_t);
                $Vkvw5zjrwkdm->margin_top = $Vvkqsaecgfir."pt";
                $Vtmlsxxw3ne1_style->margin_top = "0pt";
            }
        }

        
        if ($Vkvw5zjrwkdm->get_border_bottom_width() == 0 && $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_bottom) == 0) {
            $V3fvqcsh5wgl = $Vvkqsaecgfirhis->_frame->get_last_child();
            if ( $V3fvqcsh5wgl && !$V3fvqcsh5wgl->is_block() && !$V3fvqcsh5wgl->is_table() ) {
                while ( $V3fvqcsh5wgl = $V3fvqcsh5wgl->get_prev_sibling() ) {
                    if ( $V3fvqcsh5wgl->is_block() || $V3fvqcsh5wgl->is_table() ) {
                        break;
                    }

                    if ( !$V3fvqcsh5wgl->get_last_child() ) {
                        $V3fvqcsh5wgl = null;
                        break;
                    }
                }
            }

            
            if ($V3fvqcsh5wgl) {
                $V3fvqcsh5wgl_style = $V3fvqcsh5wgl->get_style();
                $V3fvqcsh5wgl_b = (float)$V3fvqcsh5wgl_style->length_in_pt($V3fvqcsh5wgl_style->margin_bottom, $Ve0njdrnxyyx["h"]);

                $Vkbvefdrfvxh = $Vvkqsaecgfirhis->_get_collapsed_margin_length($Vkbvefdrfvxh, $V3fvqcsh5wgl_b);
                $Vkvw5zjrwkdm->margin_bottom = $Vkbvefdrfvxh."pt";
                $V3fvqcsh5wgl_style->margin_bottom = "0pt";
            }
        }
    }

    
    private function _get_collapsed_margin_length($V3fvqcsh5wglength1, $V3fvqcsh5wglength2)
    {
        if ($V3fvqcsh5wglength1 < 0 && $V3fvqcsh5wglength2 < 0) {
            return min($V3fvqcsh5wglength1, $V3fvqcsh5wglength2); 
        }

        if ($V3fvqcsh5wglength1 < 0 || $V3fvqcsh5wglength2 < 0) {
            return $V3fvqcsh5wglength1 + $V3fvqcsh5wglength2; 
        }

        return max($V3fvqcsh5wglength1, $V3fvqcsh5wglength2);
    }

    
    abstract function reflow(Block $Vkbvefdrfvxhlock = null);

    
    function get_min_max_width()
    {
        if (!is_null($Vvkqsaecgfirhis->_min_max_cache)) {
            return $Vvkqsaecgfirhis->_min_max_cache;
        }

        $Vkvw5zjrwkdm = $Vvkqsaecgfirhis->_frame->get_style();

        
        $Vgt3r4xkc5nj = array($Vkvw5zjrwkdm->padding_left,
            $Vkvw5zjrwkdm->padding_right,
            $Vkvw5zjrwkdm->border_left_width,
            $Vkvw5zjrwkdm->border_right_width,
            $Vkvw5zjrwkdm->margin_left,
            $Vkvw5zjrwkdm->margin_right);

        $Ve0njdrnxyyx_w = $Vvkqsaecgfirhis->_frame->get_containing_block("w");
        $V0w5rvqizf1i = (float)$Vkvw5zjrwkdm->length_in_pt($Vgt3r4xkc5nj, $Ve0njdrnxyyx_w);

        
        if (!$Vvkqsaecgfirhis->_frame->get_first_child()) {
            return $Vvkqsaecgfirhis->_min_max_cache = array(
                $V0w5rvqizf1i, $V0w5rvqizf1i,
                "min" => $V0w5rvqizf1i,
                "max" => $V0w5rvqizf1i,
            );
        }

        $V3fvqcsh5wglow = array();
        $Vju5euvc4smy = array();

        for ($Vrlw4pv311lc = $Vvkqsaecgfirhis->_frame->get_children()->getIterator(); $Vrlw4pv311lc->valid(); $Vrlw4pv311lc->next()) {
            $Vtwhqiuurcg3 = 0;
            $Vp0zhie31ykp = 0;

            
            while ($Vrlw4pv311lc->valid() && in_array($Vrlw4pv311lc->current()->get_style()->display, Style::$Vumjaagcajbo)) {
                $V0mqc4rbglqu = $Vrlw4pv311lc->current();

                $Vgtxzz4xe2r2 = $V0mqc4rbglqu->get_min_max_width();

                if (in_array($Vrlw4pv311lc->current()->get_style()->white_space, array("pre", "nowrap"))) {
                    $Vtwhqiuurcg3 += $Vgtxzz4xe2r2["min"];
                } else {
                    $V3fvqcsh5wglow[] = $Vgtxzz4xe2r2["min"];
                }

                $Vp0zhie31ykp += $Vgtxzz4xe2r2["max"];
                $Vrlw4pv311lc->next();
            }

            if ($Vp0zhie31ykp > 0) {
                $Vju5euvc4smy[] = $Vp0zhie31ykp;
            }
            if ($Vtwhqiuurcg3 > 0) {
                $V3fvqcsh5wglow[] = $Vtwhqiuurcg3;
            }

            if ($Vrlw4pv311lc->valid()) {
                list($V3fvqcsh5wglow[], $Vju5euvc4smy[]) = $Vrlw4pv311lc->current()->get_min_max_width();
                continue;
            }
        }
        $Vbvkkidyyo23 = count($V3fvqcsh5wglow) ? max($V3fvqcsh5wglow) : 0;
        $V44xdi33bxee = count($Vju5euvc4smy) ? max($Vju5euvc4smy) : 0;

        
        
        $Vtt4kvdwuqqh = $Vkvw5zjrwkdm->width;
        if ($Vtt4kvdwuqqh !== "auto" && !Helpers::is_percent($Vtt4kvdwuqqh)) {
            $Vtt4kvdwuqqh = (float)$Vkvw5zjrwkdm->length_in_pt($Vtt4kvdwuqqh, $Ve0njdrnxyyx_w);
            if ($Vbvkkidyyo23 < $Vtt4kvdwuqqh) {
                $Vbvkkidyyo23 = $Vtt4kvdwuqqh;
            }
            if ($V44xdi33bxee < $Vtt4kvdwuqqh) {
                $V44xdi33bxee = $Vtt4kvdwuqqh;
            }
        }

        $Vbvkkidyyo23 += $V0w5rvqizf1i;
        $V44xdi33bxee += $V0w5rvqizf1i;
        return $Vvkqsaecgfirhis->_min_max_cache = array($Vbvkkidyyo23, $V44xdi33bxee, "min" => $Vbvkkidyyo23, "max" => $V44xdi33bxee);
    }

    
    protected function _parse_string($Vo3pamb05rqg, $Voidscszncy1 = false)
    {
        if ($Voidscszncy1) {
            $Vo3pamb05rqg = preg_replace('/^[\"\']/', "", $Vo3pamb05rqg);
            $Vo3pamb05rqg = preg_replace('/[\"\']$/', "", $Vo3pamb05rqg);
        } else {
            $Vo3pamb05rqg = trim($Vo3pamb05rqg, "'\"");
        }

        $Vo3pamb05rqg = str_replace(array("\\\n", '\\"', "\\'"),
            array("", '"', "'"), $Vo3pamb05rqg);

        
        $Vo3pamb05rqg = preg_replace_callback("/\\\\([0-9a-fA-F]{0,6})/",
            function ($Vgvt1cvsrlfv) { return \Dompdf\Helpers::unichr(hexdec($Vgvt1cvsrlfv[1])); },
            $Vo3pamb05rqg);
        return $Vo3pamb05rqg;
    }

    
    protected function _parse_quotes()
    {
        
        $Vvij5cqnugea = '/(\'[^\']*\')|(\"[^\"]*\")/';

        $Vajx12qs2u4b = $Vvkqsaecgfirhis->_frame->get_style()->quotes;

        
        if (!preg_match_all($Vvij5cqnugea, "$Vajx12qs2u4b", $Vgvt1cvsrlfv, PREG_SET_ORDER)) {
            return null;
        }

        $Vajx12qs2u4b_array = array();
        foreach ($Vgvt1cvsrlfv as $Vh2e1ie42hxc) {
            $Vajx12qs2u4b_array[] = $Vvkqsaecgfirhis->_parse_string($Vh2e1ie42hxc[0], true);
        }

        if (empty($Vajx12qs2u4b_array)) {
            $Vajx12qs2u4b_array = array('"', '"');
        }

        return array_chunk($Vajx12qs2u4b_array, 2);
    }

    
    protected function _parse_content()
    {
        
        $Vvij5cqnugea = "/\n" .
            "\s(counters?\\([^)]*\\))|\n" .
            "\A(counters?\\([^)]*\\))|\n" .
            "\s([\"']) ( (?:[^\"']|\\\\[\"'])+ )(?<!\\\\)\\3|\n" .
            "\A([\"']) ( (?:[^\"']|\\\\[\"'])+ )(?<!\\\\)\\5|\n" .
            "\s([^\s\"']+)|\n" .
            "\A([^\s\"']+)\n" .
            "/xi";

        $Vkgl4yofbmko = $Vvkqsaecgfirhis->_frame->get_style()->content;

        $Vajx12qs2u4b = $Vvkqsaecgfirhis->_parse_quotes();

        
        if (!preg_match_all($Vvij5cqnugea, $Vkgl4yofbmko, $Vgvt1cvsrlfv, PREG_SET_ORDER)) {
            return null;
        }

        $Vvkqsaecgfirext = "";

        foreach ($Vgvt1cvsrlfv as $Vmms5wlre01j) {
            if (isset($Vmms5wlre01j[2]) && $Vmms5wlre01j[2] !== "") {
                $Vmms5wlre01j[1] = $Vmms5wlre01j[2];
            }

            if (isset($Vmms5wlre01j[6]) && $Vmms5wlre01j[6] !== "") {
                $Vmms5wlre01j[4] = $Vmms5wlre01j[6];
            }

            if (isset($Vmms5wlre01j[8]) && $Vmms5wlre01j[8] !== "") {
                $Vmms5wlre01j[7] = $Vmms5wlre01j[8];
            }

            if (isset($Vmms5wlre01j[1]) && $Vmms5wlre01j[1] !== "") {
                
                $Vmms5wlre01j[1] = mb_strtolower(trim($Vmms5wlre01j[1]));

                
                

                $V0ixz2v5mxzy = mb_strpos($Vmms5wlre01j[1], ")");
                if ($V0ixz2v5mxzy === false) {
                    continue;
                }

                preg_match('/(counters?)(^\()*?\(\s*([^\s,]+)\s*(,\s*["\']?([^"\'\)]+)["\']?\s*(,\s*([^\s)]+)\s*)?)?\)/i', $Vmms5wlre01j[1], $V2tbsp04hvsi);
                $Vwkac43ignns = $V2tbsp04hvsi[3];
                if (strtolower($V2tbsp04hvsi[1]) == 'counter') {
                    
                    if (isset($V2tbsp04hvsi[5])) {
                        $Vvkqsaecgfirype = trim($V2tbsp04hvsi[5]);
                    } else {
                        $Vvkqsaecgfirype = null;
                    }
                    $V2d1s45w0hjo = $Vvkqsaecgfirhis->_frame->lookup_counter_frame($Vwkac43ignns);

                    $Vvkqsaecgfirext .= $V2d1s45w0hjo->counter_value($Vwkac43ignns, $Vvkqsaecgfirype);

                } else if (strtolower($V2tbsp04hvsi[1]) == 'counters') {
                    
                    if (isset($V2tbsp04hvsi[5])) {
                        $Vo3pamb05rqg = $Vvkqsaecgfirhis->_parse_string($V2tbsp04hvsi[5]);
                    } else {
                        $Vo3pamb05rqg = "";
                    }

                    if (isset($V2tbsp04hvsi[7])) {
                        $Vvkqsaecgfirype = trim($V2tbsp04hvsi[7]);
                    } else {
                        $Vvkqsaecgfirype = null;
                    }

                    $V2d1s45w0hjo = $Vvkqsaecgfirhis->_frame->lookup_counter_frame($Vwkac43ignns);
                    $Vvkqsaecgfirmp = array();
                    while ($V2d1s45w0hjo) {
                        
                        if (array_key_exists($Vwkac43ignns, $V2d1s45w0hjo->_counters)) {
                            array_unshift($Vvkqsaecgfirmp, $V2d1s45w0hjo->counter_value($Vwkac43ignns, $Vvkqsaecgfirype));
                        }
                        $V2d1s45w0hjo = $V2d1s45w0hjo->lookup_counter_frame($Vwkac43ignns);
                    }
                    $Vvkqsaecgfirext .= implode($Vo3pamb05rqg, $Vvkqsaecgfirmp);
                } else {
                    
                    continue;
                }

            } else if (isset($Vmms5wlre01j[4]) && $Vmms5wlre01j[4] !== "") {
                
                $Vvkqsaecgfirext .= $Vvkqsaecgfirhis->_parse_string($Vmms5wlre01j[4]);
            } else if (isset($Vmms5wlre01j[7]) && $Vmms5wlre01j[7] !== "") {
                

                if ($Vmms5wlre01j[7] === "open-quote") {
                    
                    $Vvkqsaecgfirext .= $Vajx12qs2u4b[0][0];
                } else if ($Vmms5wlre01j[7] === "close-quote") {
                    
                    $Vvkqsaecgfirext .= $Vajx12qs2u4b[0][1];
                } else if ($Vmms5wlre01j[7] === "no-open-quote") {
                    
                } else if ($Vmms5wlre01j[7] === "no-close-quote") {
                    
                } else if (mb_strpos($Vmms5wlre01j[7], "attr(") === 0) {
                    $V0ixz2v5mxzy = mb_strpos($Vmms5wlre01j[7], ")");
                    if ($V0ixz2v5mxzy === false) {
                        continue;
                    }

                    $Vparayyrg1lg = mb_substr($Vmms5wlre01j[7], 5, $V0ixz2v5mxzy - 5);
                    if ($Vparayyrg1lg == "") {
                        continue;
                    }

                    $Vvkqsaecgfirext .= $Vvkqsaecgfirhis->_frame->get_parent()->get_node()->getAttribute($Vparayyrg1lg);
                } else {
                    continue;
                }
            }
        }

        return $Vvkqsaecgfirext;
    }

    
    protected function _set_content()
    {
        $Vexjfacrc1d4 = $Vvkqsaecgfirhis->_frame;
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();

        
        if ($Vkvw5zjrwkdm->counter_reset && ($Vvij5cqnugeaset = $Vkvw5zjrwkdm->counter_reset) !== "none") {
            $Vuuqvgibroyo = preg_split('/\s+/', trim($Vvij5cqnugeaset), 2);
            $Vexjfacrc1d4->reset_counter($Vuuqvgibroyo[0], (isset($Vexjfacrc1d4->_counters['__' . $Vuuqvgibroyo[0]]) ? $Vexjfacrc1d4->_counters['__' . $Vuuqvgibroyo[0]] : (isset($Vuuqvgibroyo[1]) ? $Vuuqvgibroyo[1] : 0)));
        }

        if ($Vkvw5zjrwkdm->counter_increment && ($V0ixz2v5mxzyncrement = $Vkvw5zjrwkdm->counter_increment) !== "none") {
            $Vexjfacrc1d4->increment_counters($V0ixz2v5mxzyncrement);
        }

        if ($Vkvw5zjrwkdm->content && $Vexjfacrc1d4->get_node()->nodeName === "dompdf_generated") {
            $Vkgl4yofbmko = $Vvkqsaecgfirhis->_parse_content();
            
            
            
            if ($Vexjfacrc1d4->get_dompdf()->getOptions()->getIsFontSubsettingEnabled() && $Vexjfacrc1d4->get_dompdf()->get_canvas() instanceof CPDF) {
                $Vexjfacrc1d4->get_dompdf()->get_canvas()->register_string_subset($Vkvw5zjrwkdm->font_family, $Vkgl4yofbmko);
            }

            $Vu440l53e414ode = $Vexjfacrc1d4->get_node()->ownerDocument->createTextNode($Vkgl4yofbmko);

            $Vu440l53e414ew_style = $Vkvw5zjrwkdm->get_stylesheet()->create_style();
            $Vu440l53e414ew_style->inherit($Vkvw5zjrwkdm);

            $Vu440l53e414ew_frame = new Frame($Vu440l53e414ode);
            $Vu440l53e414ew_frame->set_style($Vu440l53e414ew_style);

            Factory::decorate_frame($Vu440l53e414ew_frame, $Vexjfacrc1d4->get_dompdf(), $Vexjfacrc1d4->get_root());
            $Vexjfacrc1d4->append_child($Vu440l53e414ew_frame);
        }
    }

    
    public function calculate_auto_width()
    {
        return $Vvkqsaecgfirhis->_frame->get_margin_width();
    }
}
