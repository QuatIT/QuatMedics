<?php

namespace Dompdf;

use Dompdf\FrameDecorator\Block;
use Dompdf\FrameDecorator\Page;


class LineBox
{

    
    protected $Vkf2shqrbokf;

    
    protected $Vcrwhzao1nyv = array();

    
    public $Vwp2ojhdk2ge = 0;

    
    public $Vuua0v2znlr5 = null;

    
    public $V5ymvwogwh5y = 0.0;

    
    public $V2pgp3ppbjsi = 0.0;

    
    public $Vb5dthqtenbv = 0.0;

    
    public $Vqswkdbtte35 = 0.0;

    
    public $Vrxwwz3g3apu = null;

    
    public $Vfhseb41vust = array();

    
    public $Vbwp1e1ru2dj = false;

    
    public function __construct(Block $Vexjfacrc1d4, $Vuua0v2znlr5 = 0)
    {
        $this->_block_frame = $Vexjfacrc1d4;
        $this->_frames = array();
        $this->y = $Vuua0v2znlr5;

        $this->get_float_offsets();
    }

    
    public function get_floats_inside(Page $Vfqvundqbe4u)
    {
        $Vovojc4t4qhi = $Vfqvundqbe4u->get_floating_frames();

        if (count($Vovojc4t4qhi) == 0) {
            return $Vovojc4t4qhi;
        }

        
        $V2d1s45w0hjo = $this->_block_frame;
        while ($V2d1s45w0hjo->get_style()->float === "none") {
            $V2d1s45w0hjoarent = $V2d1s45w0hjo->get_parent();

            if (!$V2d1s45w0hjoarent) {
                break;
            }

            $V2d1s45w0hjo = $V2d1s45w0hjoarent;
        }

        if ($V2d1s45w0hjo == $Vfqvundqbe4u) {
            return $Vovojc4t4qhi;
        }

        $V2d1s45w0hjoarent = $V2d1s45w0hjo;

        $Viutyd3iavaw = array();

        foreach ($Vovojc4t4qhi as $Vhqmpaptnjdz) {
            $V2d1s45w0hjo = $Vhqmpaptnjdz->get_parent();

            while (($V2d1s45w0hjo = $V2d1s45w0hjo->get_parent()) && $V2d1s45w0hjo !== $V2d1s45w0hjoarent);

            if ($V2d1s45w0hjo) {
                $Viutyd3iavaw[] = $V2d1s45w0hjo;
            }
        }

        return $Viutyd3iavaw;
    }

    
    public function get_float_offsets()
    {
        static $V0ccqlfovbfb = 10000; 

        $Vvep0hy04kvb = $this->_block_frame->get_reflower();

        if (!$Vvep0hy04kvb) {
            return;
        }

        $Vcddyxnftff2 = null;

        $Vynts1bqvpvb = $this->_block_frame;
        $Vfqvundqbe4u = $Vynts1bqvpvb->get_root();

        if (!$Vfqvundqbe4u) {
            return;
        }

        $Vkvw5zjrwkdm = $this->_block_frame->get_style();
        $Vovojc4t4qhi = $this->get_floats_inside($Vfqvundqbe4u);
        $Vfwdmao5p4st = 0;
        $Vu1qy0t3tefn = 0;
        $Vq1yjtl3eupb = 0;
        $Vx2j5zenqzg2 = 0;

        foreach ($Vovojc4t4qhi as $Vwpnifdnmtwp => $Vuti5vt404og) {
            $Vuti5vt404og_parent = $Vuti5vt404og->get_parent();
            $Vawfntrfsy4f = $Vuti5vt404og->get_id();

            if (isset($this->floating_blocks[$Vawfntrfsy4f])) {
                continue;
            }

            $Va2mt4xafrx1 = $Vuti5vt404og->get_style()->float;
            $Va2mt4xafrx1ing_width = $Vuti5vt404og->get_margin_width();

            if (!$Vcddyxnftff2) {
                $Vcddyxnftff2 = $Vuti5vt404og->get_containing_block("w");
            }

            $Vu3six3wvpn2 = $this->get_width();

            if (!$Vuti5vt404og->_float_next_line && ($Vcddyxnftff2 <= $Vu3six3wvpn2 + $Va2mt4xafrx1ing_width) && ($Vcddyxnftff2 > $Vu3six3wvpn2)) {
                $Vuti5vt404og->_float_next_line = true;
                continue;
            }

            
            if ($V0ccqlfovbfb-- > 0 &&
                $Vuti5vt404og->get_position("y") + $Vuti5vt404og->get_margin_height() >= $this->y &&
                $Vynts1bqvpvb->get_position("x") + $Vynts1bqvpvb->get_margin_width() >= $Vuti5vt404og->get_position("x")
            ) {
                if ($Va2mt4xafrx1 === "left") {
                    if ($Vuti5vt404og_parent === $this->_block_frame) {
                        $Vfwdmao5p4st += $Va2mt4xafrx1ing_width;
                    } else {
                        $Vq1yjtl3eupb += $Va2mt4xafrx1ing_width;
                    }
                } elseif ($Va2mt4xafrx1 === "right") {
                    if ($Vuti5vt404og_parent === $this->_block_frame) {
                        $Vu1qy0t3tefn += $Va2mt4xafrx1ing_width;
                    } else {
                        $Vx2j5zenqzg2 += $Va2mt4xafrx1ing_width;
                    }
                }

                $this->floating_blocks[$Vawfntrfsy4f] = true;
            } 
            else {
                $Vfqvundqbe4u->remove_floating_frame($Vwpnifdnmtwp);
            }
        }

        $this->left += $Vfwdmao5p4st;
        if ($Vq1yjtl3eupb > 0 && $Vq1yjtl3eupb > ((float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_left) + (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_left))) {
            $this->left += $Vq1yjtl3eupb - (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_left) - (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_left);
        }
        $this->right += $Vu1qy0t3tefn;
        if ($Vx2j5zenqzg2 > 0 && $Vx2j5zenqzg2 > ((float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_left) + (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_right))) {
            $this->right += $Vx2j5zenqzg2 - (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_right) - (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->padding_right);
        }
    }

    
    public function get_width()
    {
        return $this->left + $this->w + $this->right;
    }

    
    public function get_block_frame()
    {
        return $this->_block_frame;
    }

    
    function &get_frames()
    {
        return $this->_frames;
    }

    
    public function add_frame(Frame $Vexjfacrc1d4)
    {
        $this->_frames[] = $Vexjfacrc1d4;
    }

    
    public function recalculate_width()
    {
        $V5ymvwogwh5yidth = 0;

        foreach ($this->get_frames() as $Vexjfacrc1d4) {
            $V5ymvwogwh5yidth += $Vexjfacrc1d4->calculate_auto_width();
        }

        return $this->w = $V5ymvwogwh5yidth;
    }

    
    public function __toString()
    {
        $V2d1s45w0hjorops = array("wc", "y", "w", "h", "left", "right", "br");
        $V500t5q0ulgs = "";
        foreach ($V2d1s45w0hjorops as $V2d1s45w0hjorop) {
            $V500t5q0ulgs .= "$V2d1s45w0hjorop: " . $this->$V2d1s45w0hjorop . "\n";
        }
        $V500t5q0ulgs .= count($this->_frames) . " frames\n";

        return $V500t5q0ulgs;
    }
    
}


