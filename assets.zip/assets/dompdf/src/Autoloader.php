<?php
namespace Dompdf;


class Autoloader
{
    const PREFIX = 'Dompdf';

    
    public static function register()
    {
        spl_autoload_register(array(new self, 'autoload'));
    }

    
    public static function autoload($Vrptwe2245zq)
    {
        if ($Vrptwe2245zq === 'Cpdf') {
            require_once __DIR__ . "/../lib/Cpdf.php";
            return;
        }

        $Vxmvpu25mlcy = strlen(self::PREFIX);
        if (0 === strncmp(self::PREFIX, $Vrptwe2245zq, $Vxmvpu25mlcy)) {
            $Voheucoc3jxv = str_replace('\\', DIRECTORY_SEPARATOR, substr($Vrptwe2245zq, $Vxmvpu25mlcy));
            $Voheucoc3jxv = realpath(__DIR__ . (empty($Voheucoc3jxv) ? '' : DIRECTORY_SEPARATOR) . $Voheucoc3jxv . '.php');
            if (file_exists($Voheucoc3jxv)) {
                require_once $Voheucoc3jxv;
            }
        }
    }
}
