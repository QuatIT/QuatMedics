<?php

namespace Dompdf;

use DOMDocument;
use DOMNode;
use Dompdf\Adapter\CPDF;
use DOMXPath;
use Dompdf\Frame\Factory;
use Dompdf\Frame\FrameTree;
use HTML5_Tokenizer;
use HTML5_TreeBuilder;
use Dompdf\Image\Cache;
use Dompdf\Renderer\ListBullet;
use Dompdf\Css\Stylesheet;


class Dompdf
{
    
    private $Vnt0z0wrcfrd = 'dompdf';

    
    private $Vpxru0eqkvw5;

    
    private $Vq4fqdfuymzg;

    
    private $Vezwmkkcp5ez;

    
    private $Vecmn4cx3vag;

    
    private $Vlheobjtl3fe;

    
    private $V1aznl3ht2uz = "portrait";

    
    private $Vabtgykcggob = array();

    
    private $Va20d2ffh00p;

    
    private $Vslalnljydcu = "";

    
    private $Vcbi4moyo34u = "";

    
    private $Vz2fphjg3555;

    
    private $V2nd4ekhc1pw;

    
    private $Vayifv2n3xm3 = null;

    
    private $Vusyb0uidcft = null;

    
    private $Vtpcmkjwnm1p = false;

    
    private $Vfqjen4ri3ii = "Fit";

    
    private $Vfqjen4ri3iiOptions = array();

    
    private $Vsm5f2tzhdfy = false;

    
    private $Vgsbp20jsgad = array(null, "", "file://", "http://", "https://");

    
    private $Vhui3mw0bvwu = array("htm", "html");

    
    private $Vgi4r0e5fh11 = array();

    
    private $V3vmzyblbtdy;

    
    private $Vnl1binwcwye;

    
    public static $Viavgb13sq4t = array(
        "courier", "courier-bold", "courier-oblique", "courier-boldoblique",
        "helvetica", "helvetica-bold", "helvetica-oblique", "helvetica-boldoblique",
        "times-roman", "times-bold", "times-italic", "times-bolditalic",
        "symbol", "zapfdinbats"
    );

    
    public static $Vktosnxwbjcy = array(
        "courier", "courier-bold", "courier-oblique", "courier-boldoblique",
        "helvetica", "helvetica-bold", "helvetica-oblique", "helvetica-boldoblique",
        "times-roman", "times-bold", "times-italic", "times-bolditalic",
        "symbol", "zapfdinbats"
    );

    
    public function __construct($V3vmzyblbtdy = null)
    {
        mb_internal_encoding('UTF-8');

        if (isset($V3vmzyblbtdy) && $V3vmzyblbtdy instanceof Options) {
            $this->setOptions($V3vmzyblbtdy);
        } elseif (is_array($V3vmzyblbtdy)) {
            $this->setOptions(new Options($V3vmzyblbtdy));
        } else {
            $this->setOptions(new Options());
        }

        $Vnt0z0wrcfrdFile = realpath(__DIR__ . '/../VERSION');
        if (file_exists($Vnt0z0wrcfrdFile) && ($Vnt0z0wrcfrd = file_get_contents($Vnt0z0wrcfrdFile)) !== false && $Vnt0z0wrcfrd !== '$Virzpq5z1yyz:<%h>$') {
          $this->version = sprintf('dompdf %s', $Vnt0z0wrcfrd);
        }

        $this->localeStandard = sprintf('%.1f', 1.0) == '1.0';
        $this->saveLocale();
        $this->paperSize = $this->options->getDefaultPaperSize();
        $this->paperOrientation = $this->options->getDefaultPaperOrientation();

        $this->setCanvas(CanvasFactory::get_instance($this, $this->paperSize, $this->paperOrientation));
        $this->setFontMetrics(new FontMetrics($this->getCanvas(), $this->getOptions()));
        $this->css = new Stylesheet($this);

        $this->restoreLocale();
    }

    
    private function saveLocale()
    {
        if ($this->localeStandard) {
            return;
        }

        $this->systemLocale = setlocale(LC_NUMERIC, "0");
        setlocale(LC_NUMERIC, "C");
    }

    
    private function restoreLocale()
    {
        if ($this->localeStandard) {
            return;
        }

        setlocale(LC_NUMERIC, $this->systemLocale);
    }

    
    public function load_html_file($Voheucoc3jxv)
    {
        $this->loadHtmlFile($Voheucoc3jxv);
    }

    
    public function loadHtmlFile($Voheucoc3jxv)
    {
        $this->saveLocale();

        if (!$this->protocol && !$this->baseHost && !$this->basePath) {
            list($this->protocol, $this->baseHost, $this->basePath) = Helpers::explode_url($Voheucoc3jxv);
        }
        $Vz2fphjg3555 = strtolower($this->protocol);

        if ( !in_array($Vz2fphjg3555, $this->allowedProtocols) ) {
            throw new Exception("Permission denied on $Voheucoc3jxv. The communication protocol is not supported.");
        }

        if (!$this->options->isRemoteEnabled() && ($Vz2fphjg3555 != "" && $Vz2fphjg3555 !== "file://")) {
            throw new Exception("Remote file requested, but remote file download is disabled.");
        }

        if ($Vz2fphjg3555 == "" || $Vz2fphjg3555 === "file://") {
            $Vlquwnp54g4g = realpath($Voheucoc3jxv);

            $Vbtint2dcjm0 = realpath($this->options->getChroot());
            if ($Vbtint2dcjm0 && strpos($Vlquwnp54g4g, $Vbtint2dcjm0) !== 0) {
                throw new Exception("Permission denied on $Voheucoc3jxv. The file could not be found under the directory specified by Options::chroot.");
            }

            $Vafkpyuxax5a = strtolower(pathinfo($Vlquwnp54g4g, PATHINFO_EXTENSION));
            if (!in_array($Vafkpyuxax5a, $this->allowedLocalFileExtensions)) {
                throw new Exception("Permission denied on $Voheucoc3jxv.");
            }

            if (!$Vlquwnp54g4g) {
                throw new Exception("File '$Voheucoc3jxv' not found.");
            }

            $Voheucoc3jxv = $Vlquwnp54g4g;
        }

        list($Vlqrist1542s, $http_response_header) = Helpers::getFileContent($Voheucoc3jxv, $this->httpContext);
        $Vpxiihrwof30 = 'UTF-8';

        
        if (isset($http_response_header)) {
            foreach ($http_response_header as $Vvm0vapw4lkp) {
                if (preg_match("@Content-Type:\s*[\w/]+;\s*?charset=([^\s]+)@i", $Vvm0vapw4lkp, $Vgvt1cvsrlfv)) {
                    $Vpxiihrwof30 = strtoupper($Vgvt1cvsrlfv[1]);
                    break;
                }
            }
        }

        $this->restoreLocale();

        $this->loadHtml($Vlqrist1542s, $Vpxiihrwof30);
    }

    
    public function load_html($Vu5vpgek1hmh, $Vpxiihrwof30 = 'UTF-8')
    {
        $this->loadHtml($Vu5vpgek1hmh, $Vpxiihrwof30);
    }

    
    public function loadHtml($Vu5vpgek1hmh, $Vpxiihrwof30 = 'UTF-8')
    {
        $this->saveLocale();

        
        $Vbuxibfxdb3h = mb_list_encodings();
        mb_detect_order('auto');
        if (($Voheucoc3jxv_encoding = mb_detect_encoding($Vu5vpgek1hmh, null, true)) === false) {
            $Voheucoc3jxv_encoding = "auto";
        }
        if (in_array(strtoupper($Voheucoc3jxv_encoding), array('UTF-8','UTF8')) === false) {
            $Vu5vpgek1hmh = mb_convert_encoding($Vu5vpgek1hmh, 'UTF-8', $Voheucoc3jxv_encoding);
        }

        $Vyyyjjgpfz0r = array(
            '@<meta\s+http-equiv="Content-Type"\s+content="(?:[\w/]+)(?:;\s*?charset=([^\s"]+))?@i',
            '@<meta\s+content="(?:[\w/]+)(?:;\s*?charset=([^\s"]+))"?\s+http-equiv="Content-Type"@i',
            '@<meta [^>]*charset\s*=\s*["\']?\s*([^"\' ]+)@i',
        );
        foreach ($Vyyyjjgpfz0r as $Vkrhycixg1wh) {
            if (preg_match($Vkrhycixg1wh, $Vu5vpgek1hmh, $Vgvt1cvsrlfv)) {
                if (isset($Vgvt1cvsrlfv[1]) && in_array($Vgvt1cvsrlfv[1], $Vbuxibfxdb3h)) {
                    $V24w02aolar0 = $Vgvt1cvsrlfv[1];
                    break;
                }
            }
        }
        if (isset($V24w02aolar0) && in_array(strtoupper($V24w02aolar0), array('UTF-8','UTF8')) === false) {
            $Vu5vpgek1hmh = preg_replace('/charset=([^\s"]+)/i', 'charset=UTF-8', $Vu5vpgek1hmh);
        } elseif (isset($V24w02aolar0) === false && strpos($Vu5vpgek1hmh, '<head>') !== false) {
            $Vu5vpgek1hmh = str_replace('<head>', '<head><meta http-equiv="Content-Type" content="text/html;charset=UTF-8">', $Vu5vpgek1hmh);
        } elseif (isset($V24w02aolar0) === false) {
            $Vu5vpgek1hmh = '<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">' . $Vu5vpgek1hmh;
        }
        
        $Vpxiihrwof30 = 'UTF-8';

        
        
        if (substr($Vu5vpgek1hmh, 0, 3) == chr(0xEF) . chr(0xBB) . chr(0xBF)) {
            $Vu5vpgek1hmh = substr($Vu5vpgek1hmh, 3);
        }

        
        set_error_handler(array("\\Dompdf\\Helpers", "record_warnings"));

        
        
        
        $Vsm5f2tzhdfy = false;

        if ($this->options->isHtml5ParserEnabled() && class_exists("HTML5_Tokenizer")) {
            $V43w2uv2i0jx = new HTML5_Tokenizer($Vu5vpgek1hmh);
            $V43w2uv2i0jx->parse();
            $Vn53dg3q25ot = $V43w2uv2i0jx->save();

            
            $Vhqjatbhqjqq = array("html", "table", "tbody", "thead", "tfoot", "tr");
            foreach ($Vhqjatbhqjqq as $Vqpkubxgww50) {
                $Vi4j3o5jnxwy = $Vn53dg3q25ot->getElementsByTagName($Vqpkubxgww50);

                foreach ($Vi4j3o5jnxwy as $Vivp5mmrkfpz) {
                    self::removeTextNodes($Vivp5mmrkfpz);
                }
            }

            $Vsm5f2tzhdfy = ($V43w2uv2i0jx->getTree()->getQuirksMode() > HTML5_TreeBuilder::NO_QUIRKS);
        } else {
            
            
            
            $Vn53dg3q25ot = new DOMDocument("1.0", $Vpxiihrwof30);
            $Vn53dg3q25ot->preserveWhiteSpace = true;
            $Vn53dg3q25ot->loadHTML($Vu5vpgek1hmh);
            $Vn53dg3q25ot->encoding = $Vpxiihrwof30;

            
            $Vhqjatbhqjqq = array("html", "table", "tbody", "thead", "tfoot", "tr");
            foreach ($Vhqjatbhqjqq as $Vqpkubxgww50) {
                $Vi4j3o5jnxwy = $Vn53dg3q25ot->getElementsByTagName($Vqpkubxgww50);

                foreach ($Vi4j3o5jnxwy as $Vivp5mmrkfpz) {
                    self::removeTextNodes($Vivp5mmrkfpz);
                }
            }

            
            if (preg_match("/^(.+)<!doctype/i", ltrim($Vu5vpgek1hmh), $Vgvt1cvsrlfv)) {
                $Vsm5f2tzhdfy = true;
            } 
            elseif (!preg_match("/^<!doctype/i", ltrim($Vu5vpgek1hmh), $Vgvt1cvsrlfv)) {
                $Vsm5f2tzhdfy = true;
            } else {
                
                if (!$Vn53dg3q25ot->doctype->publicId && !$Vn53dg3q25ot->doctype->systemId) {
                    $Vsm5f2tzhdfy = false;
                }

                
                if (!preg_match("/xhtml/i", $Vn53dg3q25ot->doctype->publicId)) {
                    $Vsm5f2tzhdfy = true;
                }
            }
        }

        $this->dom = $Vn53dg3q25ot;
        $this->quirksmode = $Vsm5f2tzhdfy;

        $this->tree = new FrameTree($this->dom);

        restore_error_handler();

        $this->restoreLocale();
    }

    
    public static function remove_text_nodes(DOMNode $Vivp5mmrkfpz)
    {
        self::removeTextNodes($Vivp5mmrkfpz);
    }

    
    public static function removeTextNodes(DOMNode $Vivp5mmrkfpz)
    {
        $Vzi1s4z0nu10 = array();
        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vivp5mmrkfpz->childNodes->length; $V0ixz2v5mxzy++) {
            $V0mqc4rbglqu = $Vivp5mmrkfpz->childNodes->item($V0ixz2v5mxzy);
            if ($V0mqc4rbglqu->nodeName === "#text") {
                $Vzi1s4z0nu10[] = $V0mqc4rbglqu;
            }
        }

        foreach ($Vzi1s4z0nu10 as $V0mqc4rbglqu) {
            $Vivp5mmrkfpz->removeChild($V0mqc4rbglqu);
        }
    }

    
    private function processHtml()
    {
        $this->tree->build_tree();

        $this->css->load_css_file(Stylesheet::getDefaultStylesheet(), Stylesheet::ORIG_UA);

        $Vnxax31dhm15 = Stylesheet::$V0puti5o3dds;
        $Vnxax31dhm15[] = $this->options->getDefaultMediaType();

        
        $Vyads0sf3c2g = $this->dom->getElementsByTagName("base");
        if ($Vyads0sf3c2g->length && ($Vewvemwwfucj = $Vyads0sf3c2g->item(0)->getAttribute("href"))) {
            list($this->protocol, $this->baseHost, $this->basePath) = Helpers::explode_url($Vewvemwwfucj);
        }

        
        $this->css->set_protocol($this->protocol);
        $this->css->set_host($this->baseHost);
        $this->css->set_base_path($this->basePath);

        
        $Vd34fc2deeyg = new DOMXPath($this->dom);
        $V41syuusqzpe = $Vd34fc2deeyg->query("//*[name() = 'link' or name() = 'style']");

        
        foreach ($V41syuusqzpe as $Vgvunyxfpvcq) {
            switch (strtolower($Vgvunyxfpvcq->nodeName)) {
                
                case "link":
                    if (mb_strtolower(stripos($Vgvunyxfpvcq->getAttribute("rel"), "stylesheet") !== false) || 
                        mb_strtolower($Vgvunyxfpvcq->getAttribute("type")) === "text/css"
                    ) {
                        
                        
                        $Vzcg4gmiktbo = preg_split("/[\s\n,]/", $Vgvunyxfpvcq->getAttribute("media"), -1, PREG_SPLIT_NO_EMPTY);
                        if (count($Vzcg4gmiktbo) > 0) {
                            $Vpzmwnnnlpx1 = false;
                            foreach ($Vzcg4gmiktbo as $Vky1xzjrvbn4) {
                                if (in_array(mb_strtolower(trim($Vky1xzjrvbn4)), $Vnxax31dhm15)) {
                                    $Vpzmwnnnlpx1 = true;
                                    break;
                                }
                            }

                            if (!$Vpzmwnnnlpx1) {
                                
                                
                                continue;
                            }
                        }

                        $Vop22rgf5euu = $Vgvunyxfpvcq->getAttribute("href");
                        $Vop22rgf5euu = Helpers::build_url($this->protocol, $this->baseHost, $this->basePath, $Vop22rgf5euu);

                        $this->css->load_css_file($Vop22rgf5euu, Stylesheet::ORIG_AUTHOR);
                    }
                    break;

                
                case "style":
                    
                    
                    
                    
                    if ($Vgvunyxfpvcq->hasAttributes() &&
                        ($Vnjcis2fhgxs = $Vgvunyxfpvcq->getAttribute("media")) &&
                        !in_array($Vnjcis2fhgxs, $Vnxax31dhm15)
                    ) {
                        continue;
                    }

                    $Vezwmkkcp5ez = "";
                    if ($Vgvunyxfpvcq->hasChildNodes()) {
                        $V0mqc4rbglqu = $Vgvunyxfpvcq->firstChild;
                        while ($V0mqc4rbglqu) {
                            $Vezwmkkcp5ez .= $V0mqc4rbglqu->nodeValue; 
                            $V0mqc4rbglqu = $V0mqc4rbglqu->nextSibling;
                        }
                    } else {
                        $Vezwmkkcp5ez = $Vgvunyxfpvcq->nodeValue;
                    }

                    $this->css->load_css($Vezwmkkcp5ez, Stylesheet::ORIG_AUTHOR);
                    break;
            }
        }
    }

    
    public function enable_caching($Va20d2ffh00p)
    {
        $this->enableCaching($Va20d2ffh00p);
    }

    
    public function enableCaching($Va20d2ffh00p)
    {
        $this->cacheId = $Va20d2ffh00p;
    }

    
    public function parse_default_view($Veugw2h43vxz)
    {
        return $this->parseDefaultView($Veugw2h43vxz);
    }

    
    public function parseDefaultView($Veugw2h43vxz)
    {
        $Ve0h5jdktcud = array("XYZ", "Fit", "FitH", "FitV", "FitR", "FitB", "FitBH", "FitBV");

        $V3vmzyblbtdy = preg_split("/\s*,\s*/", trim($Veugw2h43vxz));
        $Vfqjen4ri3ii = array_shift($V3vmzyblbtdy);

        if (!in_array($Vfqjen4ri3ii, $Ve0h5jdktcud)) {
            return false;
        }

        $this->setDefaultView($Vfqjen4ri3ii, $V3vmzyblbtdy);
        return true;
    }

    
    public function render()
    {
        $this->saveLocale();
        $V3vmzyblbtdy = $this->options;

        $Vhu1qp33yhja = $V3vmzyblbtdy->getLogOutputFile();
        if ($Vhu1qp33yhja) {
            if (!file_exists($Vhu1qp33yhja) && is_writable(dirname($Vhu1qp33yhja))) {
                touch($Vhu1qp33yhja);
            }

            $this->startTime = microtime(true);
            if (is_writable($Vhu1qp33yhja)) {
                ob_start();
            }
        }

        $this->processHtml();

        $this->css->apply_styles($this->tree);

        
        $V3azzpismi4x = $this->css->get_page_styles();
        $V2f1pdo12q4b = $V3azzpismi4x["base"];
        unset($V3azzpismi4x["base"]);

        foreach ($V3azzpismi4x as $Vpcydsekvn3q) {
            $Vpcydsekvn3q->inherit($V2f1pdo12q4b);
        }

        $Vxc10egrvqg4 = $this->getPaperSize($V3vmzyblbtdy->getDefaultPaperSize());
        
        
        if (is_array($V2f1pdo12q4b->size)) {
            $V2f1pdo12q4bSize = $V2f1pdo12q4b->size;
            $this->setPaper(array(0, 0, $V2f1pdo12q4bSize[0], $V2f1pdo12q4bSize[1]));
        }

        $Vlheobjtl3fe = $this->getPaperSize();
        if (
            $Vxc10egrvqg4[2] !== $Vlheobjtl3fe[2] ||
            $Vxc10egrvqg4[3] !== $Vlheobjtl3fe[3] ||
            $V3vmzyblbtdy->getDefaultPaperOrientation() !== $this->paperOrientation
        ) {
            $this->setCanvas(CanvasFactory::get_instance($this, $this->paperSize, $this->paperOrientation));
            $this->fontMetrics->setCanvas($this->getCanvas());
        }

        $Vecmn4cx3vag = $this->getCanvas();

        if ($V3vmzyblbtdy->isFontSubsettingEnabled() && $Vecmn4cx3vag instanceof CPDF) {
            foreach ($this->tree->get_frames() as $Vexjfacrc1d4) {
                $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
                $Vivp5mmrkfpz = $Vexjfacrc1d4->get_node();

                
                if ($Vivp5mmrkfpz->nodeName === "#text") {
                    $Vdhdb24nw0ka = mb_strtoupper($Vivp5mmrkfpz->nodeValue) . mb_strtolower($Vivp5mmrkfpz->nodeValue);
                    $Vecmn4cx3vag->register_string_subset($Vkvw5zjrwkdm->font_family, $Vdhdb24nw0ka);
                    continue;
                }

                
                if ($Vkvw5zjrwkdm->display === "list-item") {
                    $Vdhdb24nw0ka = ListBullet::get_counter_chars($Vkvw5zjrwkdm->list_style_type);
                    $Vecmn4cx3vag->register_string_subset($Vkvw5zjrwkdm->font_family, $Vdhdb24nw0ka);
                    $Vecmn4cx3vag->register_string_subset($Vkvw5zjrwkdm->font_family, '.');
                    continue;
                }

                
                
                
                
                if ($Vexjfacrc1d4->get_node()->nodeName == "dompdf_generated") {
                    
                    $Vdhdb24nw0ka = ListBullet::get_counter_chars('decimal');
                    $Vecmn4cx3vag->register_string_subset($Vkvw5zjrwkdm->font_family, $Vdhdb24nw0ka);
                    $Vdhdb24nw0ka = ListBullet::get_counter_chars('upper-alpha');
                    $Vecmn4cx3vag->register_string_subset($Vkvw5zjrwkdm->font_family, $Vdhdb24nw0ka);
                    $Vdhdb24nw0ka = ListBullet::get_counter_chars('lower-alpha');
                    $Vecmn4cx3vag->register_string_subset($Vkvw5zjrwkdm->font_family, $Vdhdb24nw0ka);
                    $Vdhdb24nw0ka = ListBullet::get_counter_chars('lower-greek');
                    $Vecmn4cx3vag->register_string_subset($Vkvw5zjrwkdm->font_family, $Vdhdb24nw0ka);

                    
                    $V1xzlptpov2d = preg_replace_callback("/\\\\([0-9a-fA-F]{0,6})/",
                        function ($Vgvt1cvsrlfv) { return \Dompdf\Helpers::unichr(hexdec($Vgvt1cvsrlfv[1])); },
                        $Vkvw5zjrwkdm->content);
                    $Vdhdb24nw0ka = mb_strtoupper($Vkvw5zjrwkdm->content) . mb_strtolower($Vkvw5zjrwkdm->content) . mb_strtoupper($V1xzlptpov2d) . mb_strtolower($V1xzlptpov2d);
                    $Vecmn4cx3vag->register_string_subset($Vkvw5zjrwkdm->font_family, $Vdhdb24nw0ka);
                    continue;
                }
            }
        }

        $Vfqvundqbe4u = null;

        foreach ($this->tree->get_frames() as $Vexjfacrc1d4) {
            
            if (is_null($Vfqvundqbe4u)) {
                $Vfqvundqbe4u = Factory::decorate_root($this->tree->get_root(), $this);
                continue;
            }

            
            Factory::decorate_frame($Vexjfacrc1d4, $this, $Vfqvundqbe4u);
        }

        
        $V4rjhuvxujky = $this->dom->getElementsByTagName("title");
        if ($V4rjhuvxujky->length) {
            $Vecmn4cx3vag->add_info("Title", trim($V4rjhuvxujky->item(0)->nodeValue));
        }

        $Vzpha0gs5sql = $this->dom->getElementsByTagName("meta");
        $Vdfhpnaizq5g = array(
            "author" => "Author",
            "keywords" => "Keywords",
            "description" => "Subject",
        );
        
        foreach ($Vzpha0gs5sql as $Vazzeshtjq43) {
            $Vreuchxnm2nm = mb_strtolower($Vazzeshtjq43->getAttribute("name"));
            $Veugw2h43vxz = trim($Vazzeshtjq43->getAttribute("content"));

            if (isset($Vdfhpnaizq5g[$Vreuchxnm2nm])) {
                $Vecmn4cx3vag->add_info($Vdfhpnaizq5g[$Vreuchxnm2nm], $Veugw2h43vxz);
                continue;
            }

            if ($Vreuchxnm2nm === "dompdf.view" && $this->parseDefaultView($Veugw2h43vxz)) {
                $Vecmn4cx3vag->set_default_view($this->defaultView, $this->defaultViewOptions);
            }
        }

        $Vfqvundqbe4u->set_containing_block(0, 0,$Vecmn4cx3vag->get_width(), $Vecmn4cx3vag->get_height());
        $Vfqvundqbe4u->set_renderer(new Renderer($this));

        
        $Vfqvundqbe4u->reflow();

        
        Cache::clear();

        global $V1vwj3kz31tm, $Vdoojvf2pqdf;
        if ($Vdoojvf2pqdf && isset($V1vwj3kz31tm)) {
            echo '<b>Dompdf Warnings</b><br><pre>';
            foreach ($V1vwj3kz31tm as $V4kq14u5yvh5) {
                echo $V4kq14u5yvh5 . "\n";
            }

            if ($Vecmn4cx3vag instanceof CPDF) {
                echo $Vecmn4cx3vag->get_cpdf()->messages;
            }
            echo '</pre>';
            flush();
        }

        if ($Vhu1qp33yhja && is_writable($Vhu1qp33yhja)) {
            $this->write_log();
            ob_end_clean();
        }

        $this->restoreLocale();
    }

    
    public function add_info($Vovi5zubtdii, $Veugw2h43vxz)
    {
        $Vecmn4cx3vag = $this->getCanvas();
        if (!is_null($Vecmn4cx3vag)) {
            $Vecmn4cx3vag->add_info($Vovi5zubtdii, $Veugw2h43vxz);
        }
    }

    
    private function write_log()
    {
        $Vbbjsthyt4pj = $this->getOptions()->getLogOutputFile();
        if (!$Vbbjsthyt4pj || !is_writable($Vbbjsthyt4pj)) {
            return;
        }

        $Vexjfacrc1d4s = Frame::$V551pywabtkl;
        $V0s0bvwfwsmr = memory_get_peak_usage(true) / 1024;
        $Vgy250y3jfdg = (microtime(true) - $this->startTime) * 1000;

        $Vpsxy0jjygm1 = sprintf(
            "<span style='color: #000' title='Frames'>%6d</span>" .
            "<span style='color: #009' title='Memory'>%10.2f KB</span>" .
            "<span style='color: #900' title='Time'>%10.2f ms</span>" .
            "<span  title='Quirksmode'>  " .
            ($this->quirksmode ? "<span style='color: #d00'> ON</span>" : "<span style='color: #0d0'>OFF</span>") .
            "</span><br />", $Vexjfacrc1d4s, $V0s0bvwfwsmr, $Vgy250y3jfdg);

        $Vpsxy0jjygm1 .= ob_get_contents();
        ob_clean();

        file_put_contents($Vbbjsthyt4pj, $Vpsxy0jjygm1);
    }

    
    public function stream($Voheucoc3jxvname = "document.pdf", $V3vmzyblbtdy = array())
    {
        $this->saveLocale();

        $Vecmn4cx3vag = $this->getCanvas();
        if (!is_null($Vecmn4cx3vag)) {
            $Vecmn4cx3vag->stream($Voheucoc3jxvname, $V3vmzyblbtdy);
        }

        $this->restoreLocale();
    }

    
    public function output($V3vmzyblbtdy = array())
    {
        $this->saveLocale();

        $Vecmn4cx3vag = $this->getCanvas();
        if (is_null($Vecmn4cx3vag)) {
            return null;
        }

        $Vpsxy0jjygm1put = $Vecmn4cx3vag->output($V3vmzyblbtdy);

        $this->restoreLocale();

        return $Vpsxy0jjygm1put;
    }

    
    public function output_html()
    {
        return $this->outputHtml();
    }

    
    public function outputHtml()
    {
        return $this->dom->saveHTML();
    }

    
    public function get_option($Vbd2mxirzq2d)
    {
        return $this->options->get($Vbd2mxirzq2d);
    }

    
    public function set_option($Vbd2mxirzq2d, $Veugw2h43vxz)
    {
        $this->options->set($Vbd2mxirzq2d, $Veugw2h43vxz);
        return $this;
    }

    
    public function set_options(array $V3vmzyblbtdy)
    {
        $this->options->set($V3vmzyblbtdy);
        return $this;
    }

    
    public function set_paper($Vkgj34o34uaw, $V00gcroe4i4s = "portrait")
    {
        $this->setPaper($Vkgj34o34uaw, $V00gcroe4i4s);
    }

    
    public function setPaper($Vkgj34o34uaw, $V00gcroe4i4s = "portrait")
    {
        $this->paperSize = $Vkgj34o34uaw;
        $this->paperOrientation = $V00gcroe4i4s;
        return $this;
    }

    
    public function getPaperSize($Vlheobjtl3fe = null)
    {
        $Vkgj34o34uaw = $Vlheobjtl3fe !== null ? $Vlheobjtl3fe : $this->paperSize;
        if (is_array($Vkgj34o34uaw)) {
            return $Vkgj34o34uaw;
        } else if (isset(Adapter\CPDF::$Vfh5zaiuo2gy[mb_strtolower($Vkgj34o34uaw)])) {
            return Adapter\CPDF::$Vfh5zaiuo2gy[mb_strtolower($Vkgj34o34uaw)];
        } else {
            return Adapter\CPDF::$Vfh5zaiuo2gy["letter"];
        }
    }

    
    public function getPaperOrientation()
    {
        return $this->paperOrientation;
    }

    
    public function setTree(FrameTree $Vq4fqdfuymzg)
    {
        $this->tree = $Vq4fqdfuymzg;
        return $this;
    }

    
    public function get_tree()
    {
        return $this->getTree();
    }

    
    public function getTree()
    {
        return $this->tree;
    }

    
    public function set_protocol($Vz2fphjg3555)
    {
        return $this->setProtocol($Vz2fphjg3555);
    }

    
    public function setProtocol($Vz2fphjg3555)
    {
        $this->protocol = $Vz2fphjg3555;
        return $this;
    }

    
    public function get_protocol()
    {
        return $this->getProtocol();
    }

    
    public function getProtocol()
    {
        return $this->protocol;
    }

    
    public function set_host($Vskypresjwem)
    {
        $this->setBaseHost($Vskypresjwem);
    }

    
    public function setBaseHost($Vslalnljydcu)
    {
        $this->baseHost = $Vslalnljydcu;
        return $this;
    }

    
    public function get_host()
    {
        return $this->getBaseHost();
    }

    
    public function getBaseHost()
    {
        return $this->baseHost;
    }

    
    public function set_base_path($Vt321vu1jwdw)
    {
        $this->setBasePath($Vt321vu1jwdw);
    }

    
    public function setBasePath($Vcbi4moyo34u)
    {
        $this->basePath = $Vcbi4moyo34u;
        return $this;
    }

    
    public function get_base_path()
    {
        return $this->getBasePath();
    }

    
    public function getBasePath()
    {
        return $this->basePath;
    }

    
    public function set_default_view($Vknypbdww0qh, $V3vmzyblbtdy)
    {
        return $this->setDefaultView($Vknypbdww0qh, $V3vmzyblbtdy);
    }

    
    public function setDefaultView($Vfqjen4ri3ii, $V3vmzyblbtdy)
    {
        $this->defaultView = $Vfqjen4ri3ii;
        $this->defaultViewOptions = $V3vmzyblbtdy;
        return $this;
    }

    
    public function set_http_context($V5hufv5wd3sj)
    {
        return $this->setHttpContext($V5hufv5wd3sj);
    }

    
    public function setHttpContext($V2nd4ekhc1pw)
    {
        $this->httpContext = $V2nd4ekhc1pw;
        return $this;
    }

    
    public function get_http_context()
    {
        return $this->getHttpContext();
    }

    
    public function getHttpContext()
    {
        return $this->httpContext;
    }

    
    public function setCanvas(Canvas $Vecmn4cx3vag)
    {
        $this->canvas = $Vecmn4cx3vag;
        return $this;
    }

    
    public function get_canvas()
    {
        return $this->getCanvas();
    }

    
    public function getCanvas()
    {
        return $this->canvas;
    }

    
    public function setCss(Stylesheet $Vezwmkkcp5ez)
    {
        $this->css = $Vezwmkkcp5ez;
        return $this;
    }

    
    public function get_css()
    {
        return $this->getCss();
    }

    
    public function getCss()
    {
        return $this->css;
    }

    
    public function setDom(DOMDocument $Vpxru0eqkvw5)
    {
        $this->dom = $Vpxru0eqkvw5;
        return $this;
    }

    
    public function get_dom()
    {
        return $this->getDom();
    }

    
    public function getDom()
    {
        return $this->dom;
    }

    
    public function setOptions(Options $V3vmzyblbtdy)
    {
        $this->options = $V3vmzyblbtdy;
        $Vnl1binwcwye = $this->getFontMetrics();
        if (isset($Vnl1binwcwye)) {
            $Vnl1binwcwye->setOptions($V3vmzyblbtdy);
        }
        return $this;
    }

    
    public function getOptions()
    {
        return $this->options;
    }

    
    public function get_callbacks()
    {
        return $this->getCallbacks();
    }

    
    public function getCallbacks()
    {
        return $this->callbacks;
    }

    
    public function set_callbacks($Vabtgykcggob)
    {
        $this->setCallbacks($Vabtgykcggob);
    }

    
    public function setCallbacks($Vabtgykcggob)
    {
        if (is_array($Vabtgykcggob)) {
            $this->callbacks = array();
            foreach ($Vabtgykcggob as $Vdiqkcy1hsm4) {
                if (is_array($Vdiqkcy1hsm4) && isset($Vdiqkcy1hsm4['event']) && isset($Vdiqkcy1hsm4['f'])) {
                    $Vnd23tleybdf = $Vdiqkcy1hsm4['event'];
                    $Vtmlsxxw3ne1 = $Vdiqkcy1hsm4['f'];
                    if (is_callable($Vtmlsxxw3ne1) && is_string($Vnd23tleybdf)) {
                        $this->callbacks[$Vnd23tleybdf][] = $Vtmlsxxw3ne1;
                    }
                }
            }
        }
    }

    
    public function get_quirksmode()
    {
        return $this->getQuirksmode();
    }

    
    public function getQuirksmode()
    {
        return $this->quirksmode;
    }

    
    public function setFontMetrics(FontMetrics $Vnl1binwcwye)
    {
        $this->fontMetrics = $Vnl1binwcwye;
        return $this;
    }

    
    public function getFontMetrics()
    {
        return $this->fontMetrics;
    }

    
    function __get($Vbmjcu43y45m)
    {
        switch ($Vbmjcu43y45m)
        {
            case 'version' :
                return $this->version;
            default:
                throw new Exception( 'Invalid property: ' . $Vbmjcu43y45m );
        }
    }
}
