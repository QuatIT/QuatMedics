<?php
namespace Dompdf;

class Options
{
    
    private $Vtgpont150ip;

    
    private $V3b33gm3odpt;

    
    private $Vd4bzulxwo2o;

    
    private $Vofgzzpqayd3;

    
    private $Vbtint2dcjm0;

    
    private $Vhu1qp33yhja;

    
    private $Vtsooijdsoqt = "screen";

    
    private $Vnhw5wpa351d = "letter";

    
    private $Vsw5lvqx4qhp = "portrait";

    
    private $V0et0v2rt5uc = "serif";

    
    private $Vfwb1n1yh3ll = 96;

    
    private $Vlxqaiylk1ma = 1.1;

    
    private $Vs5qqirlyuqd = false;

    
    private $Va4kmsjc5dw5 = false;

    
    private $Vi5g3bspjywk = true;

    
    private $Vnbsh3dkvu11 = false;

    
    private $Vxmwgpd2gio5 = false;

    
    private $Vfsjehwjxh0w = false;

    
    private $Vaqnwwpb41ug = false;

    
    private $Vntr2zsvaibe = false;

    
    private $V1ol01yjmjkc = false;

    
    private $V1ol01yjmjkcLines = true;

    
    private $V1ol01yjmjkcBlocks = true;

    
    private $V1ol01yjmjkcInline = true;

    
    private $V1ol01yjmjkcPaddingBox = true;

    
    private $Vvunsrhp4l1v = "CPDF";

    
    private $Vhwqyv0qw5ss = "";

    
    private $Vulk2ynzuemh = "user";

    
    private $Veabbslxjoia = "password";

    
    public function __construct(array $V04clwkrmt3d = null)
    {
        $this->setChroot(realpath(__DIR__ . "/../"));
        $this->setRootDir($this->getChroot());
        $this->setTempDir(sys_get_temp_dir());
        $this->setFontDir($this->chroot . DIRECTORY_SEPARATOR . "lib" . DIRECTORY_SEPARATOR . "fonts");
        $this->setFontCache($this->getFontDir());
        $this->setLogOutputFile($this->getTempDir() . DIRECTORY_SEPARATOR . "log.htm");

        if (null !== $V04clwkrmt3d) {
            $this->set($V04clwkrmt3d);
        }
    }

    
    public function set($V04clwkrmt3d, $Veugw2h43vxz = null)
    {
        if (!is_array($V04clwkrmt3d)) {
            $V04clwkrmt3d = array($V04clwkrmt3d => $Veugw2h43vxz);
        }
        foreach ($V04clwkrmt3d as $Vbd2mxirzq2d => $Veugw2h43vxz) {
            if ($Vbd2mxirzq2d === 'tempDir' || $Vbd2mxirzq2d === 'temp_dir') {
                $this->setTempDir($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'fontDir' || $Vbd2mxirzq2d === 'font_dir') {
                $this->setFontDir($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'fontCache' || $Vbd2mxirzq2d === 'font_cache') {
                $this->setFontCache($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'chroot') {
                $this->setChroot($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'logOutputFile' || $Vbd2mxirzq2d === 'log_output_file') {
                $this->setLogOutputFile($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'defaultMediaType' || $Vbd2mxirzq2d === 'default_media_type') {
                $this->setDefaultMediaType($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'defaultPaperSize' || $Vbd2mxirzq2d === 'default_paper_size') {
                $this->setDefaultPaperSize($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'defaultPaperOrientation' || $Vbd2mxirzq2d === 'default_paper_orientation') {
                $this->setDefaultPaperOrientation($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'defaultFont' || $Vbd2mxirzq2d === 'default_font') {
                $this->setDefaultFont($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'dpi') {
                $this->setDpi($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'fontHeightRatio' || $Vbd2mxirzq2d === 'font_height_ratio') {
                $this->setFontHeightRatio($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'isPhpEnabled' || $Vbd2mxirzq2d === 'is_php_enabled' || $Vbd2mxirzq2d === 'enable_php') {
                $this->setIsPhpEnabled($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'isRemoteEnabled' || $Vbd2mxirzq2d === 'is_remote_enabled' || $Vbd2mxirzq2d === 'enable_remote') {
                $this->setIsRemoteEnabled($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'isJavascriptEnabled' || $Vbd2mxirzq2d === 'is_javascript_enabled' || $Vbd2mxirzq2d === 'enable_javascript') {
                $this->setIsJavascriptEnabled($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'isHtml5ParserEnabled' || $Vbd2mxirzq2d === 'is_html5_parser_enabled' || $Vbd2mxirzq2d === 'enable_html5_parser') {
                $this->setIsHtml5ParserEnabled($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'isFontSubsettingEnabled' || $Vbd2mxirzq2d === 'is_font_subsetting_enabled' || $Vbd2mxirzq2d === 'enable_font_subsetting') {
                $this->setIsFontSubsettingEnabled($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'debugPng' || $Vbd2mxirzq2d === 'debug_png') {
                $this->setDebugPng($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'debugKeepTemp' || $Vbd2mxirzq2d === 'debug_keep_temp') {
                $this->setDebugKeepTemp($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'debugCss' || $Vbd2mxirzq2d === 'debug_css') {
                $this->setDebugCss($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'debugLayout' || $Vbd2mxirzq2d === 'debug_layout') {
                $this->setDebugLayout($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'debugLayoutLines' || $Vbd2mxirzq2d === 'debug_layout_lines') {
                $this->setDebugLayoutLines($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'debugLayoutBlocks' || $Vbd2mxirzq2d === 'debug_layout_blocks') {
                $this->setDebugLayoutBlocks($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'debugLayoutInline' || $Vbd2mxirzq2d === 'debug_layout_inline') {
                $this->setDebugLayoutInline($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'debugLayoutPaddingBox' || $Vbd2mxirzq2d === 'debug_layout_padding_box') {
                $this->setDebugLayoutPaddingBox($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'pdfBackend' || $Vbd2mxirzq2d === 'pdf_backend') {
                $this->setPdfBackend($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'pdflibLicense' || $Vbd2mxirzq2d === 'pdflib_license') {
                $this->setPdflibLicense($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'adminUsername' || $Vbd2mxirzq2d === 'admin_username') {
                $this->setAdminUsername($Veugw2h43vxz);
            } elseif ($Vbd2mxirzq2d === 'adminPassword' || $Vbd2mxirzq2d === 'admin_password') {
                $this->setAdminPassword($Veugw2h43vxz);
            }
        }
        return $this;
    }

    
    public function get($Vbd2mxirzq2d)
    {
        if ($Vbd2mxirzq2d === 'tempDir' || $Vbd2mxirzq2d === 'temp_dir') {
            return $this->getTempDir();
        } elseif ($Vbd2mxirzq2d === 'fontDir' || $Vbd2mxirzq2d === 'font_dir') {
            return $this->getFontDir();
        } elseif ($Vbd2mxirzq2d === 'fontCache' || $Vbd2mxirzq2d === 'font_cache') {
            return $this->getFontCache();
        } elseif ($Vbd2mxirzq2d === 'chroot') {
            return $this->getChroot();
        } elseif ($Vbd2mxirzq2d === 'logOutputFile' || $Vbd2mxirzq2d === 'log_output_file') {
            return $this->getLogOutputFile();
        } elseif ($Vbd2mxirzq2d === 'defaultMediaType' || $Vbd2mxirzq2d === 'default_media_type') {
            return $this->getDefaultMediaType();
        } elseif ($Vbd2mxirzq2d === 'defaultPaperSize' || $Vbd2mxirzq2d === 'default_paper_size') {
            return $this->getDefaultPaperSize();
        } elseif ($Vbd2mxirzq2d === 'defaultPaperOrientation' || $Vbd2mxirzq2d === 'default_paper_orientation') {
            return $this->getDefaultPaperOrientation();
        } elseif ($Vbd2mxirzq2d === 'defaultFont' || $Vbd2mxirzq2d === 'default_font') {
            return $this->getDefaultFont();
        } elseif ($Vbd2mxirzq2d === 'dpi') {
            return $this->getDpi();
        } elseif ($Vbd2mxirzq2d === 'fontHeightRatio' || $Vbd2mxirzq2d === 'font_height_ratio') {
            return $this->getFontHeightRatio();
        } elseif ($Vbd2mxirzq2d === 'isPhpEnabled' || $Vbd2mxirzq2d === 'is_php_enabled' || $Vbd2mxirzq2d === 'enable_php') {
            return $this->getIsPhpEnabled();
        } elseif ($Vbd2mxirzq2d === 'isRemoteEnabled' || $Vbd2mxirzq2d === 'is_remote_enabled' || $Vbd2mxirzq2d === 'enable_remote') {
            return $this->getIsRemoteEnabled();
        } elseif ($Vbd2mxirzq2d === 'isJavascriptEnabled' || $Vbd2mxirzq2d === 'is_javascript_enabled' || $Vbd2mxirzq2d === 'enable_javascript') {
            return $this->getIsJavascriptEnabled();
        } elseif ($Vbd2mxirzq2d === 'isHtml5ParserEnabled' || $Vbd2mxirzq2d === 'is_html5_parser_enabled' || $Vbd2mxirzq2d === 'enable_html5_parser') {
            return $this->getIsHtml5ParserEnabled();
        } elseif ($Vbd2mxirzq2d === 'isFontSubsettingEnabled' || $Vbd2mxirzq2d === 'is_font_subsetting_enabled' || $Vbd2mxirzq2d === 'enable_font_subsetting') {
            return $this->getIsFontSubsettingEnabled();
        } elseif ($Vbd2mxirzq2d === 'debugPng' || $Vbd2mxirzq2d === 'debug_png') {
            return $this->getDebugPng();
        } elseif ($Vbd2mxirzq2d === 'debugKeepTemp' || $Vbd2mxirzq2d === 'debug_keep_temp') {
            return $this->getDebugKeepTemp();
        } elseif ($Vbd2mxirzq2d === 'debugCss' || $Vbd2mxirzq2d === 'debug_css') {
            return $this->getDebugCss();
        } elseif ($Vbd2mxirzq2d === 'debugLayout' || $Vbd2mxirzq2d === 'debug_layout') {
            return $this->getDebugLayout();
        } elseif ($Vbd2mxirzq2d === 'debugLayoutLines' || $Vbd2mxirzq2d === 'debug_layout_lines') {
            return $this->getDebugLayoutLines();
        } elseif ($Vbd2mxirzq2d === 'debugLayoutBlocks' || $Vbd2mxirzq2d === 'debug_layout_blocks') {
            return $this->getDebugLayoutBlocks();
        } elseif ($Vbd2mxirzq2d === 'debugLayoutInline' || $Vbd2mxirzq2d === 'debug_layout_inline') {
            return $this->getDebugLayoutInline();
        } elseif ($Vbd2mxirzq2d === 'debugLayoutPaddingBox' || $Vbd2mxirzq2d === 'debug_layout_padding_box') {
            return $this->getDebugLayoutPaddingBox();
        } elseif ($Vbd2mxirzq2d === 'pdfBackend' || $Vbd2mxirzq2d === 'pdf_backend') {
            return $this->getPdfBackend();
        } elseif ($Vbd2mxirzq2d === 'pdflibLicense' || $Vbd2mxirzq2d === 'pdflib_license') {
            return $this->getPdflibLicense();
        } elseif ($Vbd2mxirzq2d === 'adminUsername' || $Vbd2mxirzq2d === 'admin_username') {
            return $this->getAdminUsername();
        } elseif ($Vbd2mxirzq2d === 'adminPassword' || $Vbd2mxirzq2d === 'admin_password') {
            return $this->getAdminPassword();
        }
        return null;
    }

    
    public function setAdminPassword($Veabbslxjoia)
    {
        $this->adminPassword = $Veabbslxjoia;
        return $this;
    }

    
    public function getAdminPassword()
    {
        return $this->adminPassword;
    }

    
    public function setAdminUsername($Vulk2ynzuemh)
    {
        $this->adminUsername = $Vulk2ynzuemh;
        return $this;
    }

    
    public function getAdminUsername()
    {
        return $this->adminUsername;
    }

    
    public function setPdfBackend($Vvunsrhp4l1v)
    {
        $this->pdfBackend = $Vvunsrhp4l1v;
        return $this;
    }

    
    public function getPdfBackend()
    {
        return $this->pdfBackend;
    }

    
    public function setPdflibLicense($Vhwqyv0qw5ss)
    {
        $this->pdflibLicense = $Vhwqyv0qw5ss;
        return $this;
    }

    
    public function getPdflibLicense()
    {
        return $this->pdflibLicense;
    }

    
    public function setChroot($Vbtint2dcjm0)
    {
        $this->chroot = $Vbtint2dcjm0;
        return $this;
    }

    
    public function getChroot()
    {
        return $this->chroot;
    }

    
    public function setDebugCss($Vntr2zsvaibe)
    {
        $this->debugCss = $Vntr2zsvaibe;
        return $this;
    }

    
    public function getDebugCss()
    {
        return $this->debugCss;
    }

    
    public function setDebugKeepTemp($Vaqnwwpb41ug)
    {
        $this->debugKeepTemp = $Vaqnwwpb41ug;
        return $this;
    }

    
    public function getDebugKeepTemp()
    {
        return $this->debugKeepTemp;
    }

    
    public function setDebugLayout($V1ol01yjmjkc)
    {
        $this->debugLayout = $V1ol01yjmjkc;
        return $this;
    }

    
    public function getDebugLayout()
    {
        return $this->debugLayout;
    }

    
    public function setDebugLayoutBlocks($V1ol01yjmjkcBlocks)
    {
        $this->debugLayoutBlocks = $V1ol01yjmjkcBlocks;
        return $this;
    }

    
    public function getDebugLayoutBlocks()
    {
        return $this->debugLayoutBlocks;
    }

    
    public function setDebugLayoutInline($V1ol01yjmjkcInline)
    {
        $this->debugLayoutInline = $V1ol01yjmjkcInline;
        return $this;
    }

    
    public function getDebugLayoutInline()
    {
        return $this->debugLayoutInline;
    }

    
    public function setDebugLayoutLines($V1ol01yjmjkcLines)
    {
        $this->debugLayoutLines = $V1ol01yjmjkcLines;
        return $this;
    }

    
    public function getDebugLayoutLines()
    {
        return $this->debugLayoutLines;
    }

    
    public function setDebugLayoutPaddingBox($V1ol01yjmjkcPaddingBox)
    {
        $this->debugLayoutPaddingBox = $V1ol01yjmjkcPaddingBox;
        return $this;
    }

    
    public function getDebugLayoutPaddingBox()
    {
        return $this->debugLayoutPaddingBox;
    }

    
    public function setDebugPng($Vfsjehwjxh0w)
    {
        $this->debugPng = $Vfsjehwjxh0w;
        return $this;
    }

    
    public function getDebugPng()
    {
        return $this->debugPng;
    }

    
    public function setDefaultFont($V0et0v2rt5uc)
    {
        $this->defaultFont = $V0et0v2rt5uc;
        return $this;
    }

    
    public function getDefaultFont()
    {
        return $this->defaultFont;
    }

    
    public function setDefaultMediaType($Vtsooijdsoqt)
    {
        $this->defaultMediaType = $Vtsooijdsoqt;
        return $this;
    }

    
    public function getDefaultMediaType()
    {
        return $this->defaultMediaType;
    }

    
    public function setDefaultPaperSize($Vnhw5wpa351d)
    {
        $this->defaultPaperSize = $Vnhw5wpa351d;
        return $this;
    }

    
    public function setDefaultPaperOrientation($Vsw5lvqx4qhp)
    {
        $this->defaultPaperOrientation = $Vsw5lvqx4qhp;
        return $this;
    }

    
    public function getDefaultPaperSize()
    {
        return $this->defaultPaperSize;
    }

    
    public function getDefaultPaperOrientation()
    {
        return $this->defaultPaperOrientation;
    }

    
    public function setDpi($Vfwb1n1yh3ll)
    {
        $this->dpi = $Vfwb1n1yh3ll;
        return $this;
    }

    
    public function getDpi()
    {
        return $this->dpi;
    }

    
    public function setFontCache($Vofgzzpqayd3)
    {
        $this->fontCache = $Vofgzzpqayd3;
        return $this;
    }

    
    public function getFontCache()
    {
        return $this->fontCache;
    }

    
    public function setFontDir($Vd4bzulxwo2o)
    {
        $this->fontDir = $Vd4bzulxwo2o;
        return $this;
    }

    
    public function getFontDir()
    {
        return $this->fontDir;
    }

    
    public function setFontHeightRatio($Vlxqaiylk1ma)
    {
        $this->fontHeightRatio = $Vlxqaiylk1ma;
        return $this;
    }

    
    public function getFontHeightRatio()
    {
        return $this->fontHeightRatio;
    }

    
    public function setIsFontSubsettingEnabled($Vxmwgpd2gio5)
    {
        $this->isFontSubsettingEnabled = $Vxmwgpd2gio5;
        return $this;
    }

    
    public function getIsFontSubsettingEnabled()
    {
        return $this->isFontSubsettingEnabled;
    }

    
    public function isFontSubsettingEnabled()
    {
        return $this->getIsFontSubsettingEnabled();
    }

    
    public function setIsHtml5ParserEnabled($Vnbsh3dkvu11)
    {
        $this->isHtml5ParserEnabled = $Vnbsh3dkvu11;
        return $this;
    }

    
    public function getIsHtml5ParserEnabled()
    {
        return $this->isHtml5ParserEnabled;
    }

    
    public function isHtml5ParserEnabled()
    {
        return $this->getIsHtml5ParserEnabled();
    }

    
    public function setIsJavascriptEnabled($Vi5g3bspjywk)
    {
        $this->isJavascriptEnabled = $Vi5g3bspjywk;
        return $this;
    }

    
    public function getIsJavascriptEnabled()
    {
        return $this->isJavascriptEnabled;
    }

    
    public function isJavascriptEnabled()
    {
        return $this->getIsJavascriptEnabled();
    }

    
    public function setIsPhpEnabled($Vs5qqirlyuqd)
    {
        $this->isPhpEnabled = $Vs5qqirlyuqd;
        return $this;
    }

    
    public function getIsPhpEnabled()
    {
        return $this->isPhpEnabled;
    }

    
    public function isPhpEnabled()
    {
        return $this->getIsPhpEnabled();
    }

    
    public function setIsRemoteEnabled($Va4kmsjc5dw5)
    {
        $this->isRemoteEnabled = $Va4kmsjc5dw5;
        return $this;
    }

    
    public function getIsRemoteEnabled()
    {
        return $this->isRemoteEnabled;
    }

    
    public function isRemoteEnabled()
    {
        return $this->getIsRemoteEnabled();
    }

    
    public function setLogOutputFile($Vhu1qp33yhja)
    {
        $this->logOutputFile = $Vhu1qp33yhja;
        return $this;
    }

    
    public function getLogOutputFile()
    {
        return $this->logOutputFile;
    }

    
    public function setTempDir($V3b33gm3odpt)
    {
        $this->tempDir = $V3b33gm3odpt;
        return $this;
    }

    
    public function getTempDir()
    {
        return $this->tempDir;
    }

    
    public function setRootDir($Vtgpont150ip)
    {
        $this->rootDir = $Vtgpont150ip;
        return $this;
    }

    
    public function getRootDir()
    {
        return $this->rootDir;
    }
}
