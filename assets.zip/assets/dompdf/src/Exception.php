<?php


namespace Dompdf;


class Exception extends \Exception
{

    
    public function __construct($V1ocy1gakxau = null, $Vlrwwrp5keo0 = 0)
    {
        parent::__construct($V1ocy1gakxau, $Vlrwwrp5keo0);
    }
}
