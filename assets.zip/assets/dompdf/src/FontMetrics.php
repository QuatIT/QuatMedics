<?php


namespace Dompdf;

use FontLib\Font;


class FontMetrics
{
    
    const CACHE_FILE = "dompdf_font_family_cache.php";

    
    protected $V0xtvw1d0eq2;

    
    protected $Vecmn4cx3vag;

    
    protected $Vf5fljbmf01o = array();

    
    private $V3vmzyblbtdy;

    
    public function __construct(Canvas $Vecmn4cx3vag, Options $V3vmzyblbtdy)
    {
        $this->setCanvas($Vecmn4cx3vag);
        $this->setOptions($V3vmzyblbtdy);
        $this->loadFontFamilies();
    }

    
    public function save_font_families()
    {
        $this->saveFontFamilies();
    }

    
    public function saveFontFamilies()
    {
        
        $Vix2mne4wzla = sprintf("<?php return array (%s", PHP_EOL);
        foreach ($this->fontLookup as $V2jlfa3zutex => $Vpsiulji22hc) {
            $Vix2mne4wzla .= sprintf("  '%s' => array(%s", addslashes($V2jlfa3zutex), PHP_EOL);
            foreach ($Vpsiulji22hc as $Vsyoyqgxu10l => $Vt321vu1jwdw) {
                $Vt321vu1jwdw = sprintf("'%s'", $Vt321vu1jwdw);
                $Vt321vu1jwdw = str_replace('\'' . $this->getOptions()->getFontDir() , '$Vd4bzulxwo2o . \'' , $Vt321vu1jwdw);
                $Vt321vu1jwdw = str_replace('\'' . $this->getOptions()->getRootDir() , '$Vtgpont150ip . \'' , $Vt321vu1jwdw);
                $Vix2mne4wzla .= sprintf("    '%s' => %s,%s", $Vsyoyqgxu10l, $Vt321vu1jwdw, PHP_EOL);
            }
            $Vix2mne4wzla .= sprintf("  ),%s", PHP_EOL);
        }
        $Vix2mne4wzla .= ") ?>";
        file_put_contents($this->getCacheFile(), $Vix2mne4wzla);
    }

    
    public function load_font_families()
    {
        $this->loadFontFamilies();
    }

    
    public function loadFontFamilies()
    {
        $Vd4bzulxwo2o = $this->getOptions()->getFontDir();
        $Vtgpont150ip = $this->getOptions()->getRootDir();

        
        if (!defined("DOMPDF_DIR")) { define("DOMPDF_DIR", $Vtgpont150ip); }
        if (!defined("DOMPDF_FONT_DIR")) { define("DOMPDF_FONT_DIR", $Vd4bzulxwo2o); }

        $Voheucoc3jxv = $Vtgpont150ip . "/lib/fonts/dompdf_font_family_cache.dist.php";
        $Vp4dpaz2z2d4 = require $Voheucoc3jxv;

        if (!is_readable($this->getCacheFile())) {
            $this->fontLookup = $Vp4dpaz2z2d4;
            return;
        }

        $Vix2mne4wzla = require $this->getCacheFile();

        $this->fontLookup = array();
        if (is_array($this->fontLookup)) {
            foreach ($Vix2mne4wzla as $Vbd2mxirzq2d => $Veugw2h43vxz) {
                $this->fontLookup[stripslashes($Vbd2mxirzq2d)] = $Veugw2h43vxz;
            }
        }

        
        $this->fontLookup += $Vp4dpaz2z2d4;
    }

    
    public function register_font($Vkvw5zjrwkdm, $Vpbv2bmtdrjm, $Vamhuzg5mfpy = null)
    {
        return $this->registerFont($Vkvw5zjrwkdm, $Vpbv2bmtdrjm);
    }

    
    public function registerFont($Vkvw5zjrwkdm, $Vrz1maejy4qr, $Vamhuzg5mfpy = null)
    {
        $Vdulmkzrluhf = mb_strtolower($Vkvw5zjrwkdm["family"]);
        $Vijnp4pplof2 = $this->getFontFamilies();

        $Vpgjgw4fmq0o = array();
        if (isset($Vijnp4pplof2[$Vdulmkzrluhf])) {
            $Vpgjgw4fmq0o = $Vijnp4pplof2[$Vdulmkzrluhf];
        }

        $Vkvw5zjrwkdmString = $this->getType("{$Vkvw5zjrwkdm['weight']} {$Vkvw5zjrwkdm['style']}");
        if (isset($Vpgjgw4fmq0o[$Vkvw5zjrwkdmString])) {
            return true;
        }

        $Vd4bzulxwo2o = $this->getOptions()->getFontDir();
        $Vqjaafcnhrvv = md5($Vrz1maejy4qr);
        $Vmxoaqvp5hea = $Vd4bzulxwo2o . DIRECTORY_SEPARATOR . $Vqjaafcnhrvv;
        $Vdz2jcmwiihf = tempnam($this->options->get("tempDir"), "dompdf-font-");

        $Veuemkbejxhm = $Vmxoaqvp5hea;
        $Vmxoaqvp5hea .= ".".strtolower(pathinfo(parse_url($Vrz1maejy4qr, PHP_URL_PATH),PATHINFO_EXTENSION));

        $Vpgjgw4fmq0o[$Vkvw5zjrwkdmString] = $Veuemkbejxhm;

        
        list($Vrz1maejy4qrContent, $http_response_header) = @Helpers::getFileContent($Vrz1maejy4qr, $Vamhuzg5mfpy);
        if (false === $Vrz1maejy4qrContent) {
            return false;
        }
        file_put_contents($Vdz2jcmwiihf, $Vrz1maejy4qrContent);

        $Vfsinbbqzbga = Font::load($Vdz2jcmwiihf);

        if (!$Vfsinbbqzbga) {
            unlink($Vdz2jcmwiihf);
            return false;
        }

        $Vfsinbbqzbga->parse();
        $Vfsinbbqzbga->saveAdobeFontMetrics("$Veuemkbejxhm.ufm");
        $Vfsinbbqzbga->close();

        unlink($Vdz2jcmwiihf);

        if ( !file_exists("$Veuemkbejxhm.ufm") ) {
            return false;
        }

        
        file_put_contents($Vmxoaqvp5hea, $Vrz1maejy4qrContent);

        if ( !file_exists($Vmxoaqvp5hea) ) {
            unlink("$Veuemkbejxhm.ufm");
            return false;
        }

        $this->setFontFamily($Vdulmkzrluhf, $Vpgjgw4fmq0o);
        $this->saveFontFamilies();

        return true;
    }

    
    public function get_text_width($Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv = 0.0, $Vymiqxxasoom = 0.0)
    {
        
        return $this->getTextWidth($Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvfvnewm3zv, $Vymiqxxasoom);
    }

    
    public function getTextWidth($Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvzw1ewjqls = 0.0, $Vlnswyofvfd3 = 0.0)
    {
        
        static $Vpqxygdkkwnh = array();

        if ($Vnjapcj4bkpc === "") {
            return 0;
        }

        
        $Vq0ruob1apqz = !isset($Vnjapcj4bkpc[50]); 

        $Vbd2mxirzq2d = "$Vfsinbbqzbga/$Vkgj34o34uaw/$Vwvzw1ewjqls/$Vlnswyofvfd3";

        if ($Vq0ruob1apqz && isset($Vpqxygdkkwnh[$Vbd2mxirzq2d][$Vnjapcj4bkpc])) {
            return $Vpqxygdkkwnh[$Vbd2mxirzq2d]["$Vnjapcj4bkpc"];
        }

        $Vtt4kvdwuqqh = $this->getCanvas()->get_text_width($Vnjapcj4bkpc, $Vfsinbbqzbga, $Vkgj34o34uaw, $Vwvzw1ewjqls, $Vlnswyofvfd3);

        if ($Vq0ruob1apqz) {
            $Vpqxygdkkwnh[$Vbd2mxirzq2d][$Vnjapcj4bkpc] = $Vtt4kvdwuqqh;
        }

        return $Vtt4kvdwuqqh;
    }

    
    public function get_font_height($Vfsinbbqzbga, $Vkgj34o34uaw)
    {
        return $this->getFontHeight($Vfsinbbqzbga, $Vkgj34o34uaw);
    }

    
    public function getFontHeight($Vfsinbbqzbga, $Vkgj34o34uaw)
    {
        return $this->getCanvas()->get_font_height($Vfsinbbqzbga, $Vkgj34o34uaw);
    }

    
    public function get_font($V2jlfa3zutex_raw, $Vlzvsv34enw1 = "normal")
    {
        return $this->getFont($V2jlfa3zutex_raw, $Vlzvsv34enw1);
    }

    
    public function getFont($V2jlfa3zutexRaw, $Vf5xr3iwtcud = "normal")
    {
        static $Vpqxygdkkwnh = array();

        if (isset($Vpqxygdkkwnh[$V2jlfa3zutexRaw][$Vf5xr3iwtcud])) {
            return $Vpqxygdkkwnh[$V2jlfa3zutexRaw][$Vf5xr3iwtcud];
        }

        

        $V4445zgqkfdm = strtolower($Vf5xr3iwtcud);

        if ($V2jlfa3zutexRaw) {
            $V2jlfa3zutex = str_replace(array("'", '"'), "", strtolower($V2jlfa3zutexRaw));

            if (isset($this->fontLookup[$V2jlfa3zutex][$V4445zgqkfdm])) {
                return $Vpqxygdkkwnh[$V2jlfa3zutexRaw][$Vf5xr3iwtcud] = $this->fontLookup[$V2jlfa3zutex][$V4445zgqkfdm];
            }

            return null;
        }

        $V2jlfa3zutex = "serif";

        if (isset($this->fontLookup[$V2jlfa3zutex][$V4445zgqkfdm])) {
            return $Vpqxygdkkwnh[$V2jlfa3zutexRaw][$Vf5xr3iwtcud] = $this->fontLookup[$V2jlfa3zutex][$V4445zgqkfdm];
        }

        if (!isset($this->fontLookup[$V2jlfa3zutex])) {
            return null;
        }

        $V2jlfa3zutex = $this->fontLookup[$V2jlfa3zutex];

        foreach ($V2jlfa3zutex as $Vxtzktiv4mkl => $Vfsinbbqzbga) {
            if (strpos($V4445zgqkfdm, $Vxtzktiv4mkl) !== false) {
                return $Vpqxygdkkwnh[$V2jlfa3zutexRaw][$Vf5xr3iwtcud] = $Vfsinbbqzbga;
            }
        }

        if ($V4445zgqkfdm !== "normal") {
            foreach ($V2jlfa3zutex as $Vxtzktiv4mkl => $Vfsinbbqzbga) {
                if ($Vxtzktiv4mkl !== "normal") {
                    return $Vpqxygdkkwnh[$V2jlfa3zutexRaw][$Vf5xr3iwtcud] = $Vfsinbbqzbga;
                }
            }
        }

        $V4445zgqkfdm = "normal";

        if (isset($V2jlfa3zutex[$V4445zgqkfdm])) {
            return $Vpqxygdkkwnh[$V2jlfa3zutexRaw][$Vf5xr3iwtcud] = $V2jlfa3zutex[$V4445zgqkfdm];
        }

        return null;
    }

    
    public function get_family($V2jlfa3zutex)
    {
        return $this->getFamily($V2jlfa3zutex);
    }

    
    public function getFamily($V2jlfa3zutex)
    {
        $V2jlfa3zutex = str_replace(array("'", '"'), "", mb_strtolower($V2jlfa3zutex));

        if (isset($this->fontLookup[$V2jlfa3zutex])) {
            return $this->fontLookup[$V2jlfa3zutex];
        }

        return null;
    }

    
    public function get_type($Vky1xzjrvbn4)
    {
        return $this->getType($Vky1xzjrvbn4);
    }

    
    public function getType($Vky1xzjrvbn4)
    {
        if (preg_match("/bold/i", $Vky1xzjrvbn4)) {
            if (preg_match("/italic|oblique/i", $Vky1xzjrvbn4)) {
                $Vky1xzjrvbn4 = "bold_italic";
            } else {
                $Vky1xzjrvbn4 = "bold";
            }
        } elseif (preg_match("/italic|oblique/i", $Vky1xzjrvbn4)) {
            $Vky1xzjrvbn4 = "italic";
        } else {
            $Vky1xzjrvbn4 = "normal";
        }

        return $Vky1xzjrvbn4;
    }

    
    public function get_font_families()
    {
        return $this->getFontFamilies();
    }

    
    public function getFontFamilies()
    {
        return $this->fontLookup;
    }

    
    public function set_font_family($Vdulmkzrluhf, $Vpgjgw4fmq0o)
    {
        $this->setFontFamily($Vdulmkzrluhf, $Vpgjgw4fmq0o);
    }

    
    public function setFontFamily($Vdulmkzrluhf, $Vpgjgw4fmq0o)
    {
        $this->fontLookup[mb_strtolower($Vdulmkzrluhf)] = $Vpgjgw4fmq0o;
    }

    
    public function getCacheFile()
    {
        return $this->getOptions()->getFontDir() . DIRECTORY_SEPARATOR . self::CACHE_FILE;
    }

    
    public function setOptions(Options $V3vmzyblbtdy)
    {
        $this->options = $V3vmzyblbtdy;
        return $this;
    }

    
    public function getOptions()
    {
        return $this->options;
    }

    
    public function setCanvas(Canvas $Vecmn4cx3vag)
    {
        $this->canvas = $Vecmn4cx3vag;
        
        $this->pdf = $Vecmn4cx3vag;
        return $this;
    }

    
    public function getCanvas()
    {
        return $this->canvas;
    }
}
