<?php

namespace Dompdf;


class PhpEvaluator
{

    
    protected $V2ndtbforzqn;

    
    public function __construct(Canvas $Vecmn4cx3vag)
    {
        $this->_canvas = $Vecmn4cx3vag;
    }

    
    public function evaluate($Vlrwwrp5keo0, $Vuuqvgibroyo = array())
    {
        if (!$this->_canvas->get_dompdf()->getOptions()->getIsPhpEnabled()) {
            return;
        }

        
        $V0xtvw1d0eq2 = $this->_canvas;
        $Vnl1binwcwye = $V0xtvw1d0eq2->get_dompdf()->getFontMetrics();
        $Vtykkbxp5jgb = $V0xtvw1d0eq2->get_page_number();
        $Va5jnoc0bvsq = $V0xtvw1d0eq2->get_page_count();

        
        foreach ($Vuuqvgibroyo as $Vawllmnnfede => $Vfanetclug4s) {
            $$Vawllmnnfede = $Vfanetclug4s;
        }

        eval($Vlrwwrp5keo0);
    }

    
    public function render(Frame $Vexjfacrc1d4)
    {
        $this->evaluate($Vexjfacrc1d4->get_node()->nodeValue);
    }
}
