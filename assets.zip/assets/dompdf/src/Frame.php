<?php

namespace Dompdf;

use Dompdf\Css\Style;
use Dompdf\Frame\FrameList;




class Frame
{
    const WS_TEXT = 1;
    const WS_SPACE = 2;

    
    protected $Vwpxjydnz1pv;

    
    protected $V1o4lewj2fmf;

    
    public static $V551pywabtkl = 0; 

    
    protected $Vnymdfwn02z4;

    
    protected $Vwblnftko3z5;

    
    protected $Vt4rxuuezyra;

    
    protected $Ve44ugbah4ct;

    
    protected $Vhbfegy2dy4e;

    
    protected $Vqhlomrxoblq;

    
    protected $Vfff4nswn2pf;

    
    protected $V3iad0ruehgm;

    
    protected $Vlxuspdovb0o;

    
    protected $Vgg2w4yoms3k;

    
    protected $Vjfcaylv2xjf;

    
    protected $Vk1nxe3p1iwh;

    
    protected $Vj3uognhopd2;

    
    protected $Vgg3sgclc1v4 = array();

    
    public $Vgegr1yzcwbj = false;

    
    public $V4h2aclmt4nb = false;

    
    public $Vxrweuofopcn;

    
    public static $Vjq513cgc5d0 = self::WS_SPACE;

    
    public function __construct(\DOMNode $Vivp5mmrkfpz)
    {
        $this->_node = $Vivp5mmrkfpz;

        $this->_parent = null;
        $this->_first_child = null;
        $this->_last_child = null;
        $this->_prev_sibling = $this->_next_sibling = null;

        $this->_style = null;
        $this->_original_style = null;

        $this->_containing_block = array(
            "x" => null,
            "y" => null,
            "w" => null,
            "h" => null,
        );

        $this->_containing_block[0] =& $this->_containing_block["x"];
        $this->_containing_block[1] =& $this->_containing_block["y"];
        $this->_containing_block[2] =& $this->_containing_block["w"];
        $this->_containing_block[3] =& $this->_containing_block["h"];

        $this->_position = array(
            "x" => null,
            "y" => null,
        );

        $this->_position[0] =& $this->_position["x"];
        $this->_position[1] =& $this->_position["y"];

        $this->_opacity = 1.0;
        $this->_decorator = null;

        $this->set_id(self::$V551pywabtkl++);
    }

    
    protected function ws_trim()
    {
        if ($this->ws_keep()) {
            return;
        }

        if (self::$Vjq513cgc5d0 === self::WS_SPACE) {
            $Vivp5mmrkfpz = $this->_node;

            if ($Vivp5mmrkfpz->nodeName === "#text" && !empty($Vivp5mmrkfpz->nodeValue)) {
                $Vivp5mmrkfpz->nodeValue = preg_replace("/[ \t\r\n\f]+/u", " ", trim($Vivp5mmrkfpz->nodeValue));
                self::$Vjq513cgc5d0 = self::WS_TEXT;
            }
        }
    }

    
    protected function ws_keep()
    {
        $V0u2ervttfwm = $this->get_style()->white_space;

        return in_array($V0u2ervttfwm, array("pre", "pre-wrap", "pre-line"));
    }

    
    protected function ws_is_text()
    {
        $Vivp5mmrkfpz = $this->get_node();

        if ($Vivp5mmrkfpz->nodeName === "img") {
            return true;
        }

        if (!$this->is_in_flow()) {
            return false;
        }

        if ($this->is_text_node()) {
            return trim($Vivp5mmrkfpz->nodeValue) !== "";
        }

        return true;
    }

    
    public function dispose($Vii3tktgpo24 = false)
    {
        if ($Vii3tktgpo24) {
            while ($V0mqc4rbglqu = $this->_first_child) {
                $V0mqc4rbglqu->dispose(true);
            }
        }

        
        if ($this->_prev_sibling) {
            $this->_prev_sibling->_next_sibling = $this->_next_sibling;
        }

        if ($this->_next_sibling) {
            $this->_next_sibling->_prev_sibling = $this->_prev_sibling;
        }

        if ($this->_parent && $this->_parent->_first_child === $this) {
            $this->_parent->_first_child = $this->_next_sibling;
        }

        if ($this->_parent && $this->_parent->_last_child === $this) {
            $this->_parent->_last_child = $this->_prev_sibling;
        }

        if ($this->_parent) {
            $this->_parent->get_node()->removeChild($this->_node);
        }

        $this->_style->dispose();
        $this->_style = null;
        unset($this->_style);

        $this->_original_style->dispose();
        $this->_original_style = null;
        unset($this->_original_style);

    }

    
    public function reset()
    {
        $this->_position["x"] = null;
        $this->_position["y"] = null;

        $this->_containing_block["x"] = null;
        $this->_containing_block["y"] = null;
        $this->_containing_block["w"] = null;
        $this->_containing_block["h"] = null;

        $this->_style = null;
        unset($this->_style);
        $this->_style = clone $this->_original_style;

        
        
        if ($this->_node->nodeName === "dompdf_generated" && $this->_style->content != "normal") {
            foreach ($this->get_children() as $V0mqc4rbglqu) {
                $this->remove_child($V0mqc4rbglqu);
            }
        }
    }

    
    public function get_node()
    {
        return $this->_node;
    }

    
    public function get_id()
    {
        return $this->_id;
    }

    
    public function get_style()
    {
        return $this->_style;
    }

    
    public function get_original_style()
    {
        return $this->_original_style;
    }

    
    public function get_parent()
    {
        return $this->_parent;
    }

    
    public function get_decorator()
    {
        return $this->_decorator;
    }

    
    public function get_first_child()
    {
        return $this->_first_child;
    }

    
    public function get_last_child()
    {
        return $this->_last_child;
    }

    
    public function get_prev_sibling()
    {
        return $this->_prev_sibling;
    }

    
    public function get_next_sibling()
    {
        return $this->_next_sibling;
    }

    
    public function get_children()
    {
        if (isset($this->_frame_list)) {
            return $this->_frame_list;
        }

        $this->_frame_list = new FrameList($this);

        return $this->_frame_list;
    }

    

    
    public function get_containing_block($V0ixz2v5mxzy = null)
    {
        if (isset($V0ixz2v5mxzy)) {
            return $this->_containing_block[$V0ixz2v5mxzy];
        }

        return $this->_containing_block;
    }

    
    public function get_position($V0ixz2v5mxzy = null)
    {
        if (isset($V0ixz2v5mxzy)) {
            return $this->_position[$V0ixz2v5mxzy];
        }

        return $this->_position;
    }

    

    
    public function get_margin_height()
    {
        $Vkvw5zjrwkdm = $this->_style;

        return (float)$Vkvw5zjrwkdm->length_in_pt(array(
            $Vkvw5zjrwkdm->height,
            $Vkvw5zjrwkdm->margin_top,
            $Vkvw5zjrwkdm->margin_bottom,
            $Vkvw5zjrwkdm->border_top_width,
            $Vkvw5zjrwkdm->border_bottom_width,
            $Vkvw5zjrwkdm->padding_top,
            $Vkvw5zjrwkdm->padding_bottom
        ), $this->_containing_block["h"]);
    }

    
    public function get_margin_width()
    {
        $Vkvw5zjrwkdm = $this->_style;

        return (float)$Vkvw5zjrwkdm->length_in_pt(array(
            $Vkvw5zjrwkdm->width,
            $Vkvw5zjrwkdm->margin_left,
            $Vkvw5zjrwkdm->margin_right,
            $Vkvw5zjrwkdm->border_left_width,
            $Vkvw5zjrwkdm->border_right_width,
            $Vkvw5zjrwkdm->padding_left,
            $Vkvw5zjrwkdm->padding_right
        ), $this->_containing_block["w"]);
    }

    
    public function get_break_margins()
    {
        $Vkvw5zjrwkdm = $this->_style;

        return (float)$Vkvw5zjrwkdm->length_in_pt(array(
            
            $Vkvw5zjrwkdm->margin_top,
            $Vkvw5zjrwkdm->margin_bottom,
            $Vkvw5zjrwkdm->border_top_width,
            $Vkvw5zjrwkdm->border_bottom_width,
            $Vkvw5zjrwkdm->padding_top,
            $Vkvw5zjrwkdm->padding_bottom
        ), $this->_containing_block["h"]);
    }

    
    public function get_content_box()
    {
        $Vkvw5zjrwkdm = $this->_style;
        $Ve0njdrnxyyx = $this->_containing_block;

        $Vmm2pe5l4str = $this->_position["x"] +
            (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_left,
                    $Vkvw5zjrwkdm->border_left_width,
                    $Vkvw5zjrwkdm->padding_left),
                $Ve0njdrnxyyx["w"]);

        $Vuua0v2znlr5 = $this->_position["y"] +
            (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_top,
                    $Vkvw5zjrwkdm->border_top_width,
                    $Vkvw5zjrwkdm->padding_top),
                $Ve0njdrnxyyx["h"]);

        $V5ymvwogwh5y = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->width, $Ve0njdrnxyyx["w"]);

        $V2pgp3ppbjsi = $Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->height, $Ve0njdrnxyyx["h"]);

        return array(0 => $Vmm2pe5l4str, "x" => $Vmm2pe5l4str,
            1 => $Vuua0v2znlr5, "y" => $Vuua0v2znlr5,
            2 => $V5ymvwogwh5y, "w" => $V5ymvwogwh5y,
            3 => $V2pgp3ppbjsi, "h" => $V2pgp3ppbjsi);
    }

    
    public function get_padding_box()
    {
        $Vkvw5zjrwkdm = $this->_style;
        $Ve0njdrnxyyx = $this->_containing_block;

        $Vmm2pe5l4str = $this->_position["x"] +
            (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_left,
                    $Vkvw5zjrwkdm->border_left_width),
                $Ve0njdrnxyyx["w"]);

        $Vuua0v2znlr5 = $this->_position["y"] +
            (float)$Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->margin_top,
                    $Vkvw5zjrwkdm->border_top_width),
                $Ve0njdrnxyyx["h"]);

        $V5ymvwogwh5y = $Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->padding_left,
                $Vkvw5zjrwkdm->width,
                $Vkvw5zjrwkdm->padding_right),
            $Ve0njdrnxyyx["w"]);

        $V2pgp3ppbjsi = $Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->padding_top,
                $Vkvw5zjrwkdm->height,
                $Vkvw5zjrwkdm->padding_bottom),
            $Ve0njdrnxyyx["h"]);

        return array(0 => $Vmm2pe5l4str, "x" => $Vmm2pe5l4str,
            1 => $Vuua0v2znlr5, "y" => $Vuua0v2znlr5,
            2 => $V5ymvwogwh5y, "w" => $V5ymvwogwh5y,
            3 => $V2pgp3ppbjsi, "h" => $V2pgp3ppbjsi);
    }

    
    public function get_border_box()
    {
        $Vkvw5zjrwkdm = $this->_style;
        $Ve0njdrnxyyx = $this->_containing_block;

        $Vmm2pe5l4str = $this->_position["x"] + (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_left, $Ve0njdrnxyyx["w"]);

        $Vuua0v2znlr5 = $this->_position["y"] + (float)$Vkvw5zjrwkdm->length_in_pt($Vkvw5zjrwkdm->margin_top, $Ve0njdrnxyyx["h"]);

        $V5ymvwogwh5y = $Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->border_left_width,
                $Vkvw5zjrwkdm->padding_left,
                $Vkvw5zjrwkdm->width,
                $Vkvw5zjrwkdm->padding_right,
                $Vkvw5zjrwkdm->border_right_width),
            $Ve0njdrnxyyx["w"]);

        $V2pgp3ppbjsi = $Vkvw5zjrwkdm->length_in_pt(array($Vkvw5zjrwkdm->border_top_width,
                $Vkvw5zjrwkdm->padding_top,
                $Vkvw5zjrwkdm->height,
                $Vkvw5zjrwkdm->padding_bottom,
                $Vkvw5zjrwkdm->border_bottom_width),
            $Ve0njdrnxyyx["h"]);

        return array(0 => $Vmm2pe5l4str, "x" => $Vmm2pe5l4str,
            1 => $Vuua0v2znlr5, "y" => $Vuua0v2znlr5,
            2 => $V5ymvwogwh5y, "w" => $V5ymvwogwh5y,
            3 => $V2pgp3ppbjsi, "h" => $V2pgp3ppbjsi);
    }

    
    public function get_opacity($Vhrfbgup2xix = null)
    {
        if ($Vhrfbgup2xix !== null) {
            $this->set_opacity($Vhrfbgup2xix);
        }

        return $this->_opacity;
    }

    
    public function &get_containing_line()
    {
        return $this->_containing_line;
    }

    

    
    
    public function set_id($V0ixz2v5mxzyd)
    {
        $this->_id = $V0ixz2v5mxzyd;

        
        
        
        if ($this->_node->nodeType == XML_ELEMENT_NODE) {
            $this->_node->setAttribute("frame_id", $V0ixz2v5mxzyd);
        }
    }

    
    public function set_style(Style $Vkvw5zjrwkdm)
    {
        if (is_null($this->_style)) {
            $this->_original_style = clone $Vkvw5zjrwkdm;
        }

        
        $this->_style = $Vkvw5zjrwkdm;
    }

    
    public function set_decorator(FrameDecorator\AbstractFrameDecorator $Vmgxucbvd04y)
    {
        $this->_decorator = $Vmgxucbvd04y;
    }

    
    public function set_containing_block($Vmm2pe5l4str = null, $Vuua0v2znlr5 = null, $V5ymvwogwh5y = null, $V2pgp3ppbjsi = null)
    {
        if (is_array($Vmm2pe5l4str)) {
            foreach ($Vmm2pe5l4str as $Vbd2mxirzq2d => $Vso3o0kfkstx) {
                $$Vbd2mxirzq2d = $Vso3o0kfkstx;
            }
        }

        if (is_numeric($Vmm2pe5l4str)) {
            $this->_containing_block["x"] = $Vmm2pe5l4str;
        }

        if (is_numeric($Vuua0v2znlr5)) {
            $this->_containing_block["y"] = $Vuua0v2znlr5;
        }

        if (is_numeric($V5ymvwogwh5y)) {
            $this->_containing_block["w"] = $V5ymvwogwh5y;
        }

        if (is_numeric($V2pgp3ppbjsi)) {
            $this->_containing_block["h"] = $V2pgp3ppbjsi;
        }
    }

    
    public function set_position($Vmm2pe5l4str = null, $Vuua0v2znlr5 = null)
    {
        if (is_array($Vmm2pe5l4str)) {
            list($Vmm2pe5l4str, $Vuua0v2znlr5) = array($Vmm2pe5l4str["x"], $Vmm2pe5l4str["y"]);
        }

        if (is_numeric($Vmm2pe5l4str)) {
            $this->_position["x"] = $Vmm2pe5l4str;
        }

        if (is_numeric($Vuua0v2znlr5)) {
            $this->_position["y"] = $Vuua0v2znlr5;
        }
    }

    
    public function set_opacity($Vhrfbgup2xix)
    {
        $Vhbd3bset2hu = $this->get_parent();
        $V0biklzpbchs = (($Vhbd3bset2hu && $Vhbd3bset2hu->_opacity !== null) ? $Vhbd3bset2hu->_opacity : 1.0);
        $this->_opacity = $V0biklzpbchs * $Vhrfbgup2xix;
    }

    
    public function set_containing_line(LineBox $V4dr003jf14h)
    {
        $this->_containing_line = $V4dr003jf14h;
    }

    
    public function is_auto_height()
    {
        $Vkvw5zjrwkdm = $this->_style;

        return in_array(
            "auto",
            array(
                $Vkvw5zjrwkdm->height,
                $Vkvw5zjrwkdm->margin_top,
                $Vkvw5zjrwkdm->margin_bottom,
                $Vkvw5zjrwkdm->border_top_width,
                $Vkvw5zjrwkdm->border_bottom_width,
                $Vkvw5zjrwkdm->padding_top,
                $Vkvw5zjrwkdm->padding_bottom,
                $this->_containing_block["h"]
            ),
            true
        );
    }

    
    public function is_auto_width()
    {
        $Vkvw5zjrwkdm = $this->_style;

        return in_array(
            "auto",
            array(
                $Vkvw5zjrwkdm->width,
                $Vkvw5zjrwkdm->margin_left,
                $Vkvw5zjrwkdm->margin_right,
                $Vkvw5zjrwkdm->border_left_width,
                $Vkvw5zjrwkdm->border_right_width,
                $Vkvw5zjrwkdm->padding_left,
                $Vkvw5zjrwkdm->padding_right,
                $this->_containing_block["w"]
            ),
            true
        );
    }

    
    public function is_text_node()
    {
        if (isset($this->_is_cache["text_node"])) {
            return $this->_is_cache["text_node"];
        }

        return $this->_is_cache["text_node"] = ($this->get_node()->nodeName === "#text");
    }

    
    public function is_positionned()
    {
        if (isset($this->_is_cache["positionned"])) {
            return $this->_is_cache["positionned"];
        }

        $Vhyprn5v4f3y = $this->get_style()->position;

        return $this->_is_cache["positionned"] = in_array($Vhyprn5v4f3y, Style::$Vlcojnozlwvg);
    }

    
    public function is_absolute()
    {
        if (isset($this->_is_cache["absolute"])) {
            return $this->_is_cache["absolute"];
        }

        $Vhyprn5v4f3y = $this->get_style()->position;

        return $this->_is_cache["absolute"] = ($Vhyprn5v4f3y === "absolute" || $Vhyprn5v4f3y === "fixed");
    }

    
    public function is_block()
    {
        if (isset($this->_is_cache["block"])) {
            return $this->_is_cache["block"];
        }

        return $this->_is_cache["block"] = in_array($this->get_style()->display, Style::$V4ljaw3znygd);
    }

    
    public function is_inline_block()
    {
        if (isset($this->_is_cache["inline_block"])) {
            return $this->_is_cache["inline_block"];
        }

        return $this->_is_cache["inline_block"] = ($this->get_style()->display === 'inline-block');
    }

    
    public function is_in_flow()
    {
        if (isset($this->_is_cache["in_flow"])) {
            return $this->_is_cache["in_flow"];
        }
        return $this->_is_cache["in_flow"] = !($this->get_style()->float !== "none" || $this->is_absolute());
    }

    
    public function is_pre()
    {
        if (isset($this->_is_cache["pre"])) {
            return $this->_is_cache["pre"];
        }

        $V5ymvwogwh5yhite_space = $this->get_style()->white_space;

        return $this->_is_cache["pre"] = in_array($V5ymvwogwh5yhite_space, array("pre", "pre-wrap"));
    }

    
    public function is_table()
    {
        if (isset($this->_is_cache["table"])) {
            return $this->_is_cache["table"];
        }

        $Vqzifj31psr1 = $this->get_style()->display;

        return $this->_is_cache["table"] = in_array($Vqzifj31psr1, Style::$V1kgzsc154dh);
    }


    
    public function prepend_child(Frame $V0mqc4rbglqu, $Vki3dyk1gmh5 = true)
    {
        if ($Vki3dyk1gmh5) {
            $this->_node->insertBefore($V0mqc4rbglqu->_node, $this->_first_child ? $this->_first_child->_node : null);
        }

        
        if ($V0mqc4rbglqu->_parent) {
            $V0mqc4rbglqu->_parent->remove_child($V0mqc4rbglqu, false);
        }

        $V0mqc4rbglqu->_parent = $this;
        $V0mqc4rbglqu->_prev_sibling = null;

        
        if (!$this->_first_child) {
            $this->_first_child = $V0mqc4rbglqu;
            $this->_last_child = $V0mqc4rbglqu;
            $V0mqc4rbglqu->_next_sibling = null;
        } else {
            $this->_first_child->_prev_sibling = $V0mqc4rbglqu;
            $V0mqc4rbglqu->_next_sibling = $this->_first_child;
            $this->_first_child = $V0mqc4rbglqu;
        }
    }

    
    public function append_child(Frame $V0mqc4rbglqu, $Vki3dyk1gmh5 = true)
    {
        if ($Vki3dyk1gmh5) {
            $this->_node->appendChild($V0mqc4rbglqu->_node);
        }

        
        if ($V0mqc4rbglqu->_parent) {
            $V0mqc4rbglqu->_parent->remove_child($V0mqc4rbglqu, false);
        }

        $V0mqc4rbglqu->_parent = $this;
        $Vmgxucbvd04y = $V0mqc4rbglqu->get_decorator();
        
        if ($Vmgxucbvd04y !== null) {
            $Vmgxucbvd04y->get_parent(false);
        }
        $V0mqc4rbglqu->_next_sibling = null;

        
        if (!$this->_last_child) {
            $this->_first_child = $V0mqc4rbglqu;
            $this->_last_child = $V0mqc4rbglqu;
            $V0mqc4rbglqu->_prev_sibling = null;
        } else {
            $this->_last_child->_next_sibling = $V0mqc4rbglqu;
            $V0mqc4rbglqu->_prev_sibling = $this->_last_child;
            $this->_last_child = $V0mqc4rbglqu;
        }
    }

    
    public function insert_child_before(Frame $Ved1ducby00s, Frame $Va3fv30cr5cz, $Vki3dyk1gmh5 = true)
    {
        if ($Va3fv30cr5cz === $this->_first_child) {
            $this->prepend_child($Ved1ducby00s, $Vki3dyk1gmh5);

            return;
        }

        if (is_null($Va3fv30cr5cz)) {
            $this->append_child($Ved1ducby00s, $Vki3dyk1gmh5);

            return;
        }

        if ($Va3fv30cr5cz->_parent !== $this) {
            throw new Exception("Reference child is not a child of this node.");
        }

        
        if ($Vki3dyk1gmh5) {
            $this->_node->insertBefore($Ved1ducby00s->_node, $Va3fv30cr5cz->_node);
        }

        
        if ($Ved1ducby00s->_parent) {
            $Ved1ducby00s->_parent->remove_child($Ved1ducby00s, false);
        }

        $Ved1ducby00s->_parent = $this;
        $Ved1ducby00s->_next_sibling = $Va3fv30cr5cz;
        $Ved1ducby00s->_prev_sibling = $Va3fv30cr5cz->_prev_sibling;

        if ($Va3fv30cr5cz->_prev_sibling) {
            $Va3fv30cr5cz->_prev_sibling->_next_sibling = $Ved1ducby00s;
        }

        $Va3fv30cr5cz->_prev_sibling = $Ved1ducby00s;
    }

    
    public function insert_child_after(Frame $Ved1ducby00s, Frame $Va3fv30cr5cz, $Vki3dyk1gmh5 = true)
    {
        if ($Va3fv30cr5cz === $this->_last_child) {
            $this->append_child($Ved1ducby00s, $Vki3dyk1gmh5);

            return;
        }

        if (is_null($Va3fv30cr5cz)) {
            $this->prepend_child($Ved1ducby00s, $Vki3dyk1gmh5);

            return;
        }

        if ($Va3fv30cr5cz->_parent !== $this) {
            throw new Exception("Reference child is not a child of this node.");
        }

        
        if ($Vki3dyk1gmh5) {
            if ($Va3fv30cr5cz->_next_sibling) {
                $V0xmmeziodtr = $Va3fv30cr5cz->_next_sibling->_node;
                $this->_node->insertBefore($Ved1ducby00s->_node, $V0xmmeziodtr);
            } else {
                $Ved1ducby00s->_node = $this->_node->appendChild($Ved1ducby00s->_node);
            }
        }

        
        if ($Ved1ducby00s->_parent) {
            $Ved1ducby00s->_parent->remove_child($Ved1ducby00s, false);
        }

        $Ved1ducby00s->_parent = $this;
        $Ved1ducby00s->_prev_sibling = $Va3fv30cr5cz;
        $Ved1ducby00s->_next_sibling = $Va3fv30cr5cz->_next_sibling;

        if ($Va3fv30cr5cz->_next_sibling) {
            $Va3fv30cr5cz->_next_sibling->_prev_sibling = $Ved1ducby00s;
        }

        $Va3fv30cr5cz->_next_sibling = $Ved1ducby00s;
    }

    
    public function remove_child(Frame $V0mqc4rbglqu, $Vki3dyk1gmh5 = true)
    {
        if ($V0mqc4rbglqu->_parent !== $this) {
            throw new Exception("Child not found in this frame");
        }

        if ($Vki3dyk1gmh5) {
            $this->_node->removeChild($V0mqc4rbglqu->_node);
        }

        if ($V0mqc4rbglqu === $this->_first_child) {
            $this->_first_child = $V0mqc4rbglqu->_next_sibling;
        }

        if ($V0mqc4rbglqu === $this->_last_child) {
            $this->_last_child = $V0mqc4rbglqu->_prev_sibling;
        }

        if ($V0mqc4rbglqu->_prev_sibling) {
            $V0mqc4rbglqu->_prev_sibling->_next_sibling = $V0mqc4rbglqu->_next_sibling;
        }

        if ($V0mqc4rbglqu->_next_sibling) {
            $V0mqc4rbglqu->_next_sibling->_prev_sibling = $V0mqc4rbglqu->_prev_sibling;
        }

        $V0mqc4rbglqu->_next_sibling = null;
        $V0mqc4rbglqu->_prev_sibling = null;
        $V0mqc4rbglqu->_parent = null;

        return $V0mqc4rbglqu;
    }

    

    
    
    public function __toString()
    {
        





        $Vu5vpgek1hmh = "<b>" . $this->_node->nodeName . ":</b><br/>";
        
        $Vu5vpgek1hmh .= "Id: " . $this->get_id() . "<br/>";
        $Vu5vpgek1hmh .= "Class: " . get_class($this) . "<br/>";

        if ($this->is_text_node()) {
            $Vj0eqma35tbv = htmlspecialchars($this->_node->nodeValue);
            $Vu5vpgek1hmh .= "<pre>'" . mb_substr($Vj0eqma35tbv, 0, 70) .
                (mb_strlen($Vj0eqma35tbv) > 70 ? "..." : "") . "'</pre>";
        } elseif ($Vzc0wi0rekbe = $this->_node->getAttribute("class")) {
            $Vu5vpgek1hmh .= "CSS class: '$Vzc0wi0rekbe'<br/>";
        }

        if ($this->_parent) {
            $Vu5vpgek1hmh .= "\nParent:" . $this->_parent->_node->nodeName .
                " (" . spl_object_hash($this->_parent->_node) . ") " .
                "<br/>";
        }

        if ($this->_prev_sibling) {
            $Vu5vpgek1hmh .= "Prev: " . $this->_prev_sibling->_node->nodeName .
                " (" . spl_object_hash($this->_prev_sibling->_node) . ") " .
                "<br/>";
        }

        if ($this->_next_sibling) {
            $Vu5vpgek1hmh .= "Next: " . $this->_next_sibling->_node->nodeName .
                " (" . spl_object_hash($this->_next_sibling->_node) . ") " .
                "<br/>";
        }

        $Vngrhfhlmiyg = $this->get_decorator();
        while ($Vngrhfhlmiyg && $Vngrhfhlmiyg != $Vngrhfhlmiyg->get_decorator()) {
            $Vu5vpgek1hmh .= "Decorator: " . get_class($Vngrhfhlmiyg) . "<br/>";
            $Vngrhfhlmiyg = $Vngrhfhlmiyg->get_decorator();
        }

        $Vu5vpgek1hmh .= "Position: " . Helpers::pre_r($this->_position, true);
        $Vu5vpgek1hmh .= "\nContaining block: " . Helpers::pre_r($this->_containing_block, true);
        $Vu5vpgek1hmh .= "\nMargin width: " . Helpers::pre_r($this->get_margin_width(), true);
        $Vu5vpgek1hmh .= "\nMargin height: " . Helpers::pre_r($this->get_margin_height(), true);

        $Vu5vpgek1hmh .= "\nStyle: <pre>" . $this->_style->__toString() . "</pre>";

        if ($this->_decorator instanceof FrameDecorator\Block) {
            $Vu5vpgek1hmh .= "Lines:<pre>";
            foreach ($this->_decorator->get_line_boxes() as $V4dr003jf14h) {
                foreach ($V4dr003jf14h->get_frames() as $Vexjfacrc1d4) {
                    if ($Vexjfacrc1d4 instanceof FrameDecorator\Text) {
                        $Vu5vpgek1hmh .= "\ntext: ";
                        $Vu5vpgek1hmh .= "'" . htmlspecialchars($Vexjfacrc1d4->get_text()) . "'";
                    } else {
                        $Vu5vpgek1hmh .= "\nBlock: " . $Vexjfacrc1d4->get_node()->nodeName . " (" . spl_object_hash($Vexjfacrc1d4->get_node()) . ")";
                    }
                }

                $Vu5vpgek1hmh .=
                    "\ny => " . $V4dr003jf14h->y . "\n" .
                    "w => " . $V4dr003jf14h->w . "\n" .
                    "h => " . $V4dr003jf14h->h . "\n" .
                    "left => " . $V4dr003jf14h->left . "\n" .
                    "right => " . $V4dr003jf14h->right . "\n";
            }
            $Vu5vpgek1hmh .= "</pre>";
        }

        $Vu5vpgek1hmh .= "\n";
        if (php_sapi_name() === "cli") {
            $Vu5vpgek1hmh = strip_tags(str_replace(array("<br/>", "<b>", "</b>"),
                array("\n", "", ""),
                $Vu5vpgek1hmh));
        }

        return $Vu5vpgek1hmh;
    }
}
