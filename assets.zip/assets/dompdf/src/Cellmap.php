<?php

namespace Dompdf;

use Dompdf\FrameDecorator\Table as TableFrameDecorator;
use Dompdf\FrameDecorator\TableCell as TableCellFrameDecorator;


class Cellmap
{
    
    protected static $Vytwape3tf2p = array(
        "inset"  => 1,
        "groove" => 2,
        "outset" => 3,
        "ridge"  => 4,
        "dotted" => 5,
        "dashed" => 6,
        "solid"  => 7,
        "double" => 8,
        "hidden" => 9,
        "none"   => 0,
    );

    
    protected $Vfg34sjkuzsi;

    
    protected $Vpzeeulsx0hm;

    
    protected $Vk3n1bi3100j;

    
    protected $Vxbvqahg5pj1;

    
    protected $Vl4kdl0gv2jw;

    
    protected $Vn4rehaije5f;

    
    protected $Vmufyjd2cdkn;

    
    protected $Vcrwhzao1nyv;

    
    private $Vg0uzitea2nb;

    
    private $Vv5aruzncxof;

    
    private $Vl4kdl0gv2jw_locked = false;

    
    private $Vlgw25xoeqsr = false;

    
    public function __construct(TableFrameDecorator $Vp5rpvpxnb43)
    {
        $this->_table = $Vp5rpvpxnb43;
        $this->reset();
    }

    
    public function reset()
    {
        $this->_num_rows = 0;
        $this->_num_cols = 0;

        $this->_cells = array();
        $this->_frames = array();

        if (!$this->_columns_locked) {
            $this->_columns = array();
        }

        $this->_rows = array();

        $this->_borders = array();

        $this->__col = $this->__row = 0;
    }

    
    public function lock_columns()
    {
        $this->_columns_locked = true;
    }

    
    public function is_columns_locked()
    {
        return $this->_columns_locked;
    }

    
    public function set_layout_fixed($Vcchq0v2ai4t)
    {
        $this->_fixed_layout = $Vcchq0v2ai4t;
    }

    
    public function is_layout_fixed()
    {
        return $this->_fixed_layout;
    }

    
    public function get_num_rows()
    {
        return $this->_num_rows;
    }

    
    public function get_num_cols()
    {
        return $this->_num_cols;
    }

    
    public function &get_columns()
    {
        return $this->_columns;
    }

    
    public function set_columns($Vwq0k2uyyc4q)
    {
        $this->_columns = $Vwq0k2uyyc4q;
    }

    
    public function &get_column($V0ixz2v5mxzy)
    {
        if (!isset($this->_columns[$V0ixz2v5mxzy])) {
            $this->_columns[$V0ixz2v5mxzy] = array(
                "x"          => 0,
                "min-width"  => 0,
                "max-width"  => 0,
                "used-width" => null,
                "absolute"   => 0,
                "percent"    => 0,
                "auto"       => true,
            );
        }

        return $this->_columns[$V0ixz2v5mxzy];
    }

    
    public function &get_rows()
    {
        return $this->_rows;
    }

    
    public function &get_row($Vy4wtqjehnh5)
    {
        if (!isset($this->_rows[$Vy4wtqjehnh5])) {
            $this->_rows[$Vy4wtqjehnh5] = array(
                "y"            => 0,
                "first-column" => 0,
                "height"       => null,
            );
        }

        return $this->_rows[$Vy4wtqjehnh5];
    }

    
    public function get_border($V0ixz2v5mxzy, $Vy4wtqjehnh5, $V5ofdbigwhhz, $Vbmjcu43y45m = null)
    {
        if (!isset($this->_borders[$V0ixz2v5mxzy][$Vy4wtqjehnh5][$V5ofdbigwhhz])) {
            $this->_borders[$V0ixz2v5mxzy][$Vy4wtqjehnh5][$V5ofdbigwhhz] = array(
                "width" => 0,
                "style" => "solid",
                "color" => "black",
            );
        }

        if (isset($Vbmjcu43y45m)) {
            return $this->_borders[$V0ixz2v5mxzy][$Vy4wtqjehnh5][$V5ofdbigwhhz][$Vbmjcu43y45m];
        }

        return $this->_borders[$V0ixz2v5mxzy][$Vy4wtqjehnh5][$V5ofdbigwhhz];
    }

    
    public function get_border_properties($V0ixz2v5mxzy, $Vy4wtqjehnh5)
    {
        return array(
            "top"    => $this->get_border($V0ixz2v5mxzy, $Vy4wtqjehnh5, "horizontal"),
            "right"  => $this->get_border($V0ixz2v5mxzy, $Vy4wtqjehnh5 + 1, "vertical"),
            "bottom" => $this->get_border($V0ixz2v5mxzy + 1, $Vy4wtqjehnh5, "horizontal"),
            "left"   => $this->get_border($V0ixz2v5mxzy, $Vy4wtqjehnh5, "vertical"),
        );
    }

    
    public function get_spanned_cells(Frame $Vexjfacrc1d4)
    {
        $Vbd2mxirzq2d = $Vexjfacrc1d4->get_id();

        if (isset($this->_frames[$Vbd2mxirzq2d])) {
            return $this->_frames[$Vbd2mxirzq2d];
        }

        return null;
    }

    
    public function frame_exists_in_cellmap(Frame $Vexjfacrc1d4)
    {
        $Vbd2mxirzq2d = $Vexjfacrc1d4->get_id();

        return isset($this->_frames[$Vbd2mxirzq2d]);
    }

    
    public function get_frame_position(Frame $Vexjfacrc1d4)
    {
        global $V1vwj3kz31tm;

        $Vbd2mxirzq2d = $Vexjfacrc1d4->get_id();

        if (!isset($this->_frames[$Vbd2mxirzq2d])) {
            throw new Exception("Frame not found in cellmap");
        }

        $Vqpgfq33o1wo = $this->_frames[$Vbd2mxirzq2d]["columns"][0];
        $Vcqwpvcjcqxw = $this->_frames[$Vbd2mxirzq2d]["rows"][0];

        if (!isset($this->_columns[$Vqpgfq33o1wo])) {
            $V1vwj3kz31tm[] = "Frame not found in columns array.  Check your table layout for missing or extra TDs.";
            $Vmm2pe5l4str = 0;
        } else {
            $Vmm2pe5l4str = $this->_columns[$Vqpgfq33o1wo]["x"];
        }

        if (!isset($this->_rows[$Vcqwpvcjcqxw])) {
            $V1vwj3kz31tm[] = "Frame not found in row array.  Check your table layout for missing or extra TDs.";
            $Vuua0v2znlr5 = 0;
        } else {
            $Vuua0v2znlr5 = $this->_rows[$Vcqwpvcjcqxw]["y"];
        }

        return array($Vmm2pe5l4str, $Vuua0v2znlr5, "x" => $Vmm2pe5l4str, "y" => $Vuua0v2znlr5);
    }

    
    public function get_frame_width(Frame $Vexjfacrc1d4)
    {
        $Vbd2mxirzq2d = $Vexjfacrc1d4->get_id();

        if (!isset($this->_frames[$Vbd2mxirzq2d])) {
            throw new Exception("Frame not found in cellmap");
        }

        $Vqpgfq33o1wos = $this->_frames[$Vbd2mxirzq2d]["columns"];
        $V5ymvwogwh5y = 0;
        foreach ($Vqpgfq33o1wos as $V0ixz2v5mxzy) {
            $V5ymvwogwh5y += $this->_columns[$V0ixz2v5mxzy]["used-width"];
        }

        return $V5ymvwogwh5y;
    }

    
    public function get_frame_height(Frame $Vexjfacrc1d4)
    {
        $Vbd2mxirzq2d = $Vexjfacrc1d4->get_id();

        if (!isset($this->_frames[$Vbd2mxirzq2d])) {
            throw new Exception("Frame not found in cellmap");
        }

        $Vcqwpvcjcqxws = $this->_frames[$Vbd2mxirzq2d]["rows"];
        $V2pgp3ppbjsi = 0;
        foreach ($Vcqwpvcjcqxws as $V0ixz2v5mxzy) {
            if (!isset($this->_rows[$V0ixz2v5mxzy])) {
                throw new Exception("The row #$V0ixz2v5mxzy could not be found, please file an issue in the tracker with the HTML code");
            }

            $V2pgp3ppbjsi += $this->_rows[$V0ixz2v5mxzy]["height"];
        }

        return $V2pgp3ppbjsi;
    }

    
    public function set_column_width($Vy4wtqjehnh5, $V5ymvwogwh5yidth)
    {
        if ($this->_columns_locked) {
            return;
        }

        $Vqpgfq33o1wo =& $this->get_column($Vy4wtqjehnh5);
        $Vqpgfq33o1wo["used-width"] = $V5ymvwogwh5yidth;
        $Ve55apws1wea =& $this->get_column($Vy4wtqjehnh5 + 1);
        $Ve55apws1wea["x"] = $Ve55apws1wea["x"] + $V5ymvwogwh5yidth;
    }

    
    public function set_row_height($V0ixz2v5mxzy, $V2pgp3ppbjsieight)
    {
        $Vcqwpvcjcqxw =& $this->get_row($V0ixz2v5mxzy);

        if ($Vcqwpvcjcqxw["height"] !== null && $V2pgp3ppbjsieight <= $Vcqwpvcjcqxw["height"]) {
            return;
        }

        $Vcqwpvcjcqxw["height"] = $V2pgp3ppbjsieight;
        $Vn45ab4uaidy =& $this->get_row($V0ixz2v5mxzy + 1);
        $Vn45ab4uaidy["y"] = $Vcqwpvcjcqxw["y"] + $V2pgp3ppbjsieight;

    }

    
    protected function _resolve_border($V0ixz2v5mxzy, $Vy4wtqjehnh5, $V5ofdbigwhhz, $V5bfp4hxgu3a)
    {
        $Vdvpisu00qlm = $V5bfp4hxgu3a["width"];
        $V1jy0xecr41t = $V5bfp4hxgu3a["style"];

        if (!isset($this->_borders[$V0ixz2v5mxzy][$Vy4wtqjehnh5][$V5ofdbigwhhz])) {
            $this->_borders[$V0ixz2v5mxzy][$Vy4wtqjehnh5][$V5ofdbigwhhz] = $V5bfp4hxgu3a;

            return $this->_borders[$V0ixz2v5mxzy][$Vy4wtqjehnh5][$V5ofdbigwhhz]["width"];
        }

        $Vfslf2riij4t = & $this->_borders[$V0ixz2v5mxzy][$Vy4wtqjehnh5][$V5ofdbigwhhz];

        $Vlvwqjwvczqz = $Vfslf2riij4t["width"];
        $Vvn4bsxs2zra = $Vfslf2riij4t["style"];

        if (($V1jy0xecr41t === "hidden" ||
                $Vdvpisu00qlm > $Vlvwqjwvczqz ||
                $Vvn4bsxs2zra === "none")

            or

            ($Vlvwqjwvczqz == $Vdvpisu00qlm &&
                in_array($V1jy0xecr41t, self::$Vytwape3tf2p) &&
                self::$Vytwape3tf2p[$V1jy0xecr41t] > self::$Vytwape3tf2p[$Vvn4bsxs2zra])
        ) {
            $Vfslf2riij4t = $V5bfp4hxgu3a;
        }

        return $Vfslf2riij4t["width"];
    }

    
    public function add_frame(Frame $Vexjfacrc1d4)
    {
        $Vkvw5zjrwkdm = $Vexjfacrc1d4->get_style();
        $Vqzifj31psr1 = $Vkvw5zjrwkdm->display;

        $Vqpgfq33o1wolapse = $this->_table->get_style()->border_collapse == "collapse";

        
        if ($Vqzifj31psr1 === "table-row" ||
            $Vqzifj31psr1 === "table" ||
            $Vqzifj31psr1 === "inline-table" ||
            in_array($Vqzifj31psr1, TableFrameDecorator::$V420otj4lzb1)
        ) {
            $Vwfmdnx4nfci = $this->__row;
            foreach ($Vexjfacrc1d4->get_children() as $V0mqc4rbglqu) {
                
                if (!($V0mqc4rbglqu instanceof FrameDecorator\Text) && $V0mqc4rbglqu->get_node()->nodeName !== 'dompdf_generated') {
                    $this->add_frame($V0mqc4rbglqu);
                }
            }

            if ($Vqzifj31psr1 === "table-row") {
                $this->add_row();
            }

            $Vgo25rmzptcl = $this->__row - $Vwfmdnx4nfci - 1;
            $Vbd2mxirzq2d = $Vexjfacrc1d4->get_id();

            
            $this->_frames[$Vbd2mxirzq2d]["columns"] = range(0, max(0, $this->_num_cols - 1));
            $this->_frames[$Vbd2mxirzq2d]["rows"] = range($Vwfmdnx4nfci, max(0, $this->__row - 1));
            $this->_frames[$Vbd2mxirzq2d]["frame"] = $Vexjfacrc1d4;

            if ($Vqzifj31psr1 !== "table-row" && $Vqpgfq33o1wolapse) {
                $Vjbw5irva2if = $Vkvw5zjrwkdm->get_border_properties();

                
                for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vgo25rmzptcl + 1; $V0ixz2v5mxzy++) {
                    $this->_resolve_border($Vwfmdnx4nfci + $V0ixz2v5mxzy, 0, "vertical", $Vjbw5irva2if["left"]);
                    $this->_resolve_border($Vwfmdnx4nfci + $V0ixz2v5mxzy, $this->_num_cols, "vertical", $Vjbw5irva2if["right"]);
                }

                for ($Vy4wtqjehnh5 = 0; $Vy4wtqjehnh5 < $this->_num_cols; $Vy4wtqjehnh5++) {
                    $this->_resolve_border($Vwfmdnx4nfci, $Vy4wtqjehnh5, "horizontal", $Vjbw5irva2if["top"]);
                    $this->_resolve_border($this->__row, $Vy4wtqjehnh5, "horizontal", $Vjbw5irva2if["bottom"]);
                }
            }
            return;
        }

        $Vivp5mmrkfpz = $Vexjfacrc1d4->get_node();

        
        $Vqpgfq33o1wospan = $Vivp5mmrkfpz->getAttribute("colspan");
        $Vcqwpvcjcqxwspan = $Vivp5mmrkfpz->getAttribute("rowspan");

        if (!$Vqpgfq33o1wospan) {
            $Vqpgfq33o1wospan = 1;
            $Vivp5mmrkfpz->setAttribute("colspan", 1);
        }

        if (!$Vcqwpvcjcqxwspan) {
            $Vcqwpvcjcqxwspan = 1;
            $Vivp5mmrkfpz->setAttribute("rowspan", 1);
        }
        $Vbd2mxirzq2d = $Vexjfacrc1d4->get_id();

        $Vjbw5irva2if = $Vkvw5zjrwkdm->get_border_properties();


        
        $Vd4bmwonmk42 = $Vtoraec5025n = 0;

        
        $Vxecs0jvizlk = $this->__col;
        while (isset($this->_cells[$this->__row][$Vxecs0jvizlk])) {
            $Vxecs0jvizlk++;
        }

        $this->__col = $Vxecs0jvizlk;

        
        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vcqwpvcjcqxwspan; $V0ixz2v5mxzy++) {
            $Vcqwpvcjcqxw = $this->__row + $V0ixz2v5mxzy;

            $this->_frames[$Vbd2mxirzq2d]["rows"][] = $Vcqwpvcjcqxw;

            for ($Vy4wtqjehnh5 = 0; $Vy4wtqjehnh5 < $Vqpgfq33o1wospan; $Vy4wtqjehnh5++) {
                $this->_cells[$Vcqwpvcjcqxw][$this->__col + $Vy4wtqjehnh5] = $Vexjfacrc1d4;
            }

            if ($Vqpgfq33o1wolapse) {
                
                $Vd4bmwonmk42 = max($Vd4bmwonmk42, $this->_resolve_border($Vcqwpvcjcqxw, $this->__col, "vertical", $Vjbw5irva2if["left"]));
                $Vtoraec5025n = max($Vtoraec5025n, $this->_resolve_border($Vcqwpvcjcqxw, $this->__col + $Vqpgfq33o1wospan, "vertical", $Vjbw5irva2if["right"]));
            }
        }

        $Vuv05cdddrtq = $V4rd05nbyquz = 0;

        
        for ($Vy4wtqjehnh5 = 0; $Vy4wtqjehnh5 < $Vqpgfq33o1wospan; $Vy4wtqjehnh5++) {
            $Vqpgfq33o1wo = $this->__col + $Vy4wtqjehnh5;
            $this->_frames[$Vbd2mxirzq2d]["columns"][] = $Vqpgfq33o1wo;

            if ($Vqpgfq33o1wolapse) {
                
                $Vuv05cdddrtq = max($Vuv05cdddrtq, $this->_resolve_border($this->__row, $Vqpgfq33o1wo, "horizontal", $Vjbw5irva2if["top"]));
                $V4rd05nbyquz = max($V4rd05nbyquz, $this->_resolve_border($this->__row + $Vcqwpvcjcqxwspan, $Vqpgfq33o1wo, "horizontal", $Vjbw5irva2if["bottom"]));
            }
        }

        $this->_frames[$Vbd2mxirzq2d]["frame"] = $Vexjfacrc1d4;

        
        if (!$Vqpgfq33o1wolapse) {
            list($V2pgp3ppbjsi, $Vfanetclug4s) = $this->_table->get_style()->border_spacing;

            
            $Vfanetclug4s = $Vkvw5zjrwkdm->length_in_pt($Vfanetclug4s);
            if (is_numeric($Vfanetclug4s)) {
                $Vfanetclug4s = $Vfanetclug4s / 2;
            }
            $V2pgp3ppbjsi = $Vkvw5zjrwkdm->length_in_pt($V2pgp3ppbjsi);
            if (is_numeric($V2pgp3ppbjsi)) {
                $V2pgp3ppbjsi = $V2pgp3ppbjsi / 2;
            }
            $Vkvw5zjrwkdm->margin = "$Vfanetclug4s $V2pgp3ppbjsi";

            
        } else {
            
            $Vkvw5zjrwkdm->border_left_width = $Vd4bmwonmk42 / 2;
            $Vkvw5zjrwkdm->border_right_width = $Vtoraec5025n / 2;
            $Vkvw5zjrwkdm->border_top_width = $Vuv05cdddrtq / 2;
            $Vkvw5zjrwkdm->border_bottom_width = $V4rd05nbyquz / 2;
            $Vkvw5zjrwkdm->margin = "none";
        }

        if (!$this->_columns_locked) {
            
            if ($this->_fixed_layout) {
                list($Vexjfacrc1d4_min, $Vexjfacrc1d4_max) = array(0, 10e-10);
            } else {
                list($Vexjfacrc1d4_min, $Vexjfacrc1d4_max) = $Vexjfacrc1d4->get_min_max_width();
            }

            $V5ymvwogwh5yidth = $Vkvw5zjrwkdm->width;

            $Vfanetclug4sal = null;
            if (Helpers::is_percent($V5ymvwogwh5yidth)) {
                $Vfanetclug4sar = "percent";
                $Vfanetclug4sal = (float)rtrim($V5ymvwogwh5yidth, "% ") / $Vqpgfq33o1wospan;
            } else if ($V5ymvwogwh5yidth !== "auto") {
                $Vfanetclug4sar = "absolute";
                $Vfanetclug4sal = $Vkvw5zjrwkdm->length_in_pt($Vexjfacrc1d4_min) / $Vqpgfq33o1wospan;
            }

            $Vbvkkidyyo23 = 0;
            $V44xdi33bxee = 0;
            for ($Vfayy1hmoeg3 = 0; $Vfayy1hmoeg3 < $Vqpgfq33o1wospan; $Vfayy1hmoeg3++) {

                
                $Vqpgfq33o1wo =& $this->get_column($this->__col + $Vfayy1hmoeg3);

                
                
                
                if (isset($Vfanetclug4sar) && $Vfanetclug4sal > $Vqpgfq33o1wo[$Vfanetclug4sar]) {
                    $Vqpgfq33o1wo[$Vfanetclug4sar] = $Vfanetclug4sal;
                    $Vqpgfq33o1wo["auto"] = false;
                }

                $Vbvkkidyyo23 += $Vqpgfq33o1wo["min-width"];
                $V44xdi33bxee += $Vqpgfq33o1wo["max-width"];
            }

            if ($Vexjfacrc1d4_min > $Vbvkkidyyo23) {
                
                
                $V0ixz2v5mxzync = ($this->is_layout_fixed() ? 10e-10 : ($Vexjfacrc1d4_min - $Vbvkkidyyo23) / $Vqpgfq33o1wospan);
                for ($Vdiqkcy1hsm4 = 0; $Vdiqkcy1hsm4 < $Vqpgfq33o1wospan; $Vdiqkcy1hsm4++) {
                    $Vqpgfq33o1wo =& $this->get_column($this->__col + $Vdiqkcy1hsm4);
                    $Vqpgfq33o1wo["min-width"] += $V0ixz2v5mxzync;
                }
            }

            if ($Vexjfacrc1d4_max > $V44xdi33bxee) {
                
                $V0ixz2v5mxzync = ($this->is_layout_fixed() ? 10e-10 : ($Vexjfacrc1d4_max - $V44xdi33bxee) / $Vqpgfq33o1wospan);
                for ($Vdiqkcy1hsm4 = 0; $Vdiqkcy1hsm4 < $Vqpgfq33o1wospan; $Vdiqkcy1hsm4++) {
                    $Vqpgfq33o1wo =& $this->get_column($this->__col + $Vdiqkcy1hsm4);
                    $Vqpgfq33o1wo["max-width"] += $V0ixz2v5mxzync;
                }
            }
        }

        $this->__col += $Vqpgfq33o1wospan;
        if ($this->__col > $this->_num_cols) {
            $this->_num_cols = $this->__col;
        }
    }

    
    public function add_row()
    {
        $this->__row++;
        $this->_num_rows++;

        
        $V0ixz2v5mxzy = 0;
        while (isset($this->_cells[$this->__row][$V0ixz2v5mxzy])) {
            $V0ixz2v5mxzy++;
        }

        $this->__col = $V0ixz2v5mxzy;
    }

    
    public function remove_row(Frame $Vcqwpvcjcqxw)
    {
        $Vbd2mxirzq2d = $Vcqwpvcjcqxw->get_id();
        if (!isset($this->_frames[$Vbd2mxirzq2d])) {
            return; 
        }

        $this->__row = $this->_num_rows--;

        $Vcqwpvcjcqxws = $this->_frames[$Vbd2mxirzq2d]["rows"];
        $Vwq0k2uyyc4q = $this->_frames[$Vbd2mxirzq2d]["columns"];

        
        foreach ($Vcqwpvcjcqxws as $Vapkwgsb3w3r) {
            foreach ($Vwq0k2uyyc4q as $Vdiqkcy1hsm4) {
                if (isset($this->_cells[$Vapkwgsb3w3r][$Vdiqkcy1hsm4])) {
                    $V0ixz2v5mxzyd = $this->_cells[$Vapkwgsb3w3r][$Vdiqkcy1hsm4]->get_id();

                    $this->_cells[$Vapkwgsb3w3r][$Vdiqkcy1hsm4] = null;
                    unset($this->_cells[$Vapkwgsb3w3r][$Vdiqkcy1hsm4]);

                    
                    if (isset($this->_frames[$V0ixz2v5mxzyd]) && count($this->_frames[$V0ixz2v5mxzyd]["rows"]) > 1) {
                        
                        if (($Vcqwpvcjcqxw_key = array_search($Vapkwgsb3w3r, $this->_frames[$V0ixz2v5mxzyd]["rows"])) !== false) {
                            unset($this->_frames[$V0ixz2v5mxzyd]["rows"][$Vcqwpvcjcqxw_key]);
                        }
                        continue;
                    }

                    $this->_frames[$V0ixz2v5mxzyd] = null;
                    unset($this->_frames[$V0ixz2v5mxzyd]);
                }
            }

            $this->_rows[$Vapkwgsb3w3r] = null;
            unset($this->_rows[$Vapkwgsb3w3r]);
        }

        $this->_frames[$Vbd2mxirzq2d] = null;
        unset($this->_frames[$Vbd2mxirzq2d]);
    }

    
    public function remove_row_group(Frame $Vwk1a2omlzok)
    {
        $Vbd2mxirzq2d = $Vwk1a2omlzok->get_id();
        if (!isset($this->_frames[$Vbd2mxirzq2d])) {
            return; 
        }

        $V0ixz2v5mxzyter = $Vwk1a2omlzok->get_first_child();
        while ($V0ixz2v5mxzyter) {
            $this->remove_row($V0ixz2v5mxzyter);
            $V0ixz2v5mxzyter = $V0ixz2v5mxzyter->get_next_sibling();
        }

        $this->_frames[$Vbd2mxirzq2d] = null;
        unset($this->_frames[$Vbd2mxirzq2d]);
    }

    
    public function update_row_group(Frame $Vwk1a2omlzok, Frame $Vm4iapukeufw)
    {
        $Vamtczdmvi2o = $Vwk1a2omlzok->get_id();
        $Vapkwgsb3w3r_key = $Vm4iapukeufw->get_id();

        $Vapkwgsb3w3r_rows = $this->_frames[$Vamtczdmvi2o]["rows"];
        $this->_frames[$Vamtczdmvi2o]["rows"] = range($this->_frames[$Vamtczdmvi2o]["rows"][0], end($Vapkwgsb3w3r_rows));
    }

    
    public function assign_x_positions()
    {
        
        

        if ($this->_columns_locked) {
            return;
        }

        $Vmm2pe5l4str = $this->_columns[0]["x"];
        foreach (array_keys($this->_columns) as $Vy4wtqjehnh5) {
            $this->_columns[$Vy4wtqjehnh5]["x"] = $Vmm2pe5l4str;
            $Vmm2pe5l4str += $this->_columns[$Vy4wtqjehnh5]["used-width"];
        }
    }

    
    public function assign_frame_heights()
    {
        
        
        foreach ($this->_frames as $Vkmcaia35nsn) {
            $Vexjfacrc1d4 = $Vkmcaia35nsn["frame"];

            $V2pgp3ppbjsi = 0;
            foreach ($Vkmcaia35nsn["rows"] as $Vcqwpvcjcqxw) {
                if (!isset($this->_rows[$Vcqwpvcjcqxw])) {
                    
                    continue;
                }

                $V2pgp3ppbjsi += $this->_rows[$Vcqwpvcjcqxw]["height"];
            }

            if ($Vexjfacrc1d4 instanceof TableCellFrameDecorator) {
                $Vexjfacrc1d4->set_cell_height($V2pgp3ppbjsi);
            } else {
                $Vexjfacrc1d4->get_style()->height = $V2pgp3ppbjsi;
            }
        }
    }

    
    public function set_frame_heights($Vp5rpvpxnb43_height, $Vdiqkcy1hsm4ontent_height)
    {
        
        foreach ($this->_frames as $Vkmcaia35nsn) {
            $Vexjfacrc1d4 = $Vkmcaia35nsn["frame"];

            $V2pgp3ppbjsi = 0;
            foreach ($Vkmcaia35nsn["rows"] as $Vcqwpvcjcqxw) {
                if (!isset($this->_rows[$Vcqwpvcjcqxw])) {
                    continue;
                }

                $V2pgp3ppbjsi += $this->_rows[$Vcqwpvcjcqxw]["height"];
            }

            if ($Vdiqkcy1hsm4ontent_height > 0) {
                $V0szsvgefcc2 = ($V2pgp3ppbjsi / $Vdiqkcy1hsm4ontent_height) * $Vp5rpvpxnb43_height;
            } else {
                $V0szsvgefcc2 = 0;
            }

            if ($Vexjfacrc1d4 instanceof TableCellFrameDecorator) {
                $Vexjfacrc1d4->set_cell_height($V0szsvgefcc2);
            } else {
                $Vexjfacrc1d4->get_style()->height = $V0szsvgefcc2;
            }
        }
    }

    
    public function __toString()
    {
        $Vu5vpgek1hmh = "";
        $Vu5vpgek1hmh .= "Columns:<br/>";
        $Vu5vpgek1hmh .= Helpers::pre_r($this->_columns, true);
        $Vu5vpgek1hmh .= "Rows:<br/>";
        $Vu5vpgek1hmh .= Helpers::pre_r($this->_rows, true);

        $Vu5vpgek1hmh .= "Frames:<br/>";
        $Vkmcaia35nsn = array();
        foreach ($this->_frames as $Vbd2mxirzq2d => $Vfanetclug4sal) {
            $Vkmcaia35nsn[$Vbd2mxirzq2d] = array("columns" => $Vfanetclug4sal["columns"], "rows" => $Vfanetclug4sal["rows"]);
        }

        $Vu5vpgek1hmh .= Helpers::pre_r($Vkmcaia35nsn, true);

        if (php_sapi_name() == "cli") {
            $Vu5vpgek1hmh = strip_tags(str_replace(array("<br/>", "<b>", "</b>"),
                array("\n", chr(27) . "[01;33m", chr(27) . "[0m"),
                $Vu5vpgek1hmh));
        }

        return $Vu5vpgek1hmh;
    }
}
