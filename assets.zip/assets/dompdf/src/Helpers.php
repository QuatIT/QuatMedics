<?php
namespace Dompdf;

class Helpers
{
    
    public static function pre_r($Vrxxpdgukzw4, $Vadilnif24ss = false)
    {
        if ($Vadilnif24ss) {
            return "<pre>" . print_r($Vrxxpdgukzw4, true) . "</pre>";
        }

        if (php_sapi_name() !== "cli") {
            echo "<pre>";
        }

        print_r($Vrxxpdgukzw4);

        if (php_sapi_name() !== "cli") {
            echo "</pre>";
        } else {
            echo "\n";
        }

        flush();

        return null;
    }

      
    public static function build_url($Vz2fphjg3555, $Vskypresjwem, $Vjzg0yr1b2nq, $Vop22rgf5euu)
    {
        $Vz2fphjg3555 = mb_strtolower($Vz2fphjg3555);
        if (strlen($Vop22rgf5euu) == 0) {
            
            return $Vz2fphjg3555 . $Vskypresjwem . $Vjzg0yr1b2nq;
        }

        
        if (mb_strpos($Vop22rgf5euu, "://") !== false || mb_substr($Vop22rgf5euu, 0, 1) === "#" || mb_strpos($Vop22rgf5euu, "data:") === 0 || mb_strpos($Vop22rgf5euu, "mailto:") === 0) {
            return $Vop22rgf5euu;
        }

        $Vaamzcof1atz = $Vz2fphjg3555;

        if (!in_array(mb_strtolower($Vz2fphjg3555), array("http://", "https://", "ftp://", "ftps://"))) {
            
            
            
            
            if ($Vop22rgf5euu[0] !== '/' && (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN' || (mb_strlen($Vop22rgf5euu) > 1 && $Vop22rgf5euu[0] !== '\\' && $Vop22rgf5euu[1] !== ':'))) {
                
                $Vaamzcof1atz .= realpath($Vjzg0yr1b2nq) . '/';
            }
            $Vaamzcof1atz .= $Vop22rgf5euu;
            $Vaamzcof1atz = preg_replace('/\?(.*)$/', "", $Vaamzcof1atz);
            return $Vaamzcof1atz;
        }

        
        if (strpos($Vop22rgf5euu, '//') === 0) {
            $Vaamzcof1atz .= substr($Vop22rgf5euu, 2);
            
        } elseif ($Vop22rgf5euu[0] === '/' || $Vop22rgf5euu[0] === '\\') {
            
            $Vaamzcof1atz .= $Vskypresjwem . $Vop22rgf5euu;
        } else {
            
            
            $Vaamzcof1atz .= $Vskypresjwem . $Vjzg0yr1b2nq . $Vop22rgf5euu;
        }

        return $Vaamzcof1atz;
    }

    
    public static function buildContentDispositionHeader($Vhyijnmyqfgi, $Vnbqjwe42int)
    {
        $Vpxiihrwof30 = mb_detect_encoding($Vnbqjwe42int);
        $Vjnduidtzzbp = mb_convert_encoding($Vnbqjwe42int, "ISO-8859-1", $Vpxiihrwof30);
        $Vjnduidtzzbp = str_replace("\"", "", $Vjnduidtzzbp);
        $Vmm1r0at23av = rawurlencode($Vnbqjwe42int);

        $Vku44keldhxo = "Content-Disposition: $Vhyijnmyqfgi; filename=\"$Vjnduidtzzbp\"";
        if ($Vjnduidtzzbp !== $Vnbqjwe42int) {
            $Vku44keldhxo .= "; filename*=UTF-8''$Vmm1r0at23av";
        }

        return $Vku44keldhxo;
    }

    
    public static function dec2roman($Vaucqj0hftp5)
    {

        static $Vxltbt5gg505 = array("", "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix");
        static $Vxuzro4apf4t = array("", "x", "xx", "xxx", "xl", "l", "lx", "lxx", "lxxx", "xc");
        static $Vxdbeiwktrnk = array("", "c", "cc", "ccc", "cd", "d", "dc", "dcc", "dccc", "cm");
        static $Vajfwoe2hlml = array("", "m", "mm", "mmm");

        if (!is_numeric($Vaucqj0hftp5)) {
            throw new Exception("dec2roman() requires a numeric argument.");
        }

        if ($Vaucqj0hftp5 > 4000 || $Vaucqj0hftp5 < 0) {
            return "(out of range)";
        }

        $Vaucqj0hftp5 = strrev((string)$Vaucqj0hftp5);

        $Vaamzcof1atz = "";
        switch (mb_strlen($Vaucqj0hftp5)) {
            
            case 4:
                $Vaamzcof1atz .= $Vajfwoe2hlml[$Vaucqj0hftp5[3]];
            
            case 3:
                $Vaamzcof1atz .= $Vxdbeiwktrnk[$Vaucqj0hftp5[2]];
            
            case 2:
                $Vaamzcof1atz .= $Vxuzro4apf4t[$Vaucqj0hftp5[1]];
            
            case 1:
                $Vaamzcof1atz .= $Vxltbt5gg505[$Vaucqj0hftp5[0]];
            default:
                break;
        }

        return $Vaamzcof1atz;
    }

    
    public static function is_percent($Veugw2h43vxz)
    {
        return false !== mb_strpos($Veugw2h43vxz, "%");
    }

    
    public static function parse_data_uri($Vy5ir01oay0q)
    {
        if (!preg_match('/^data:(?P<mime>[a-z0-9\/+-.]+)(;charset=(?P<charset>[a-z0-9-])+)?(?P<base64>;base64)?\,(?P<data>.*)?/is', $Vy5ir01oay0q, $Vmms5wlre01j)) {
            return false;
        }

        $Vmms5wlre01j['data'] = rawurldecode($Vmms5wlre01j['data']);
        $Vji4j1ie4mwl = array(
            'charset' => $Vmms5wlre01j['charset'] ? $Vmms5wlre01j['charset'] : 'US-ASCII',
            'mime' => $Vmms5wlre01j['mime'] ? $Vmms5wlre01j['mime'] : 'text/plain',
            'data' => $Vmms5wlre01j['base64'] ? base64_decode($Vmms5wlre01j['data']) : $Vmms5wlre01j['data'],
        );

        return $Vji4j1ie4mwl;
    }

    
    public static function encodeURI($Vnogiydwdyzh) {
        $Vxnk5tcgonnc = array(
            '%2D'=>'-','%5F'=>'_','%2E'=>'.','%21'=>'!', '%7E'=>'~',
            '%2A'=>'*', '%27'=>"'", '%28'=>'(', '%29'=>')'
        );
        $Vpvrggup4hyi = array(
            '%3B'=>';','%2C'=>',','%2F'=>'/','%3F'=>'?','%3A'=>':',
            '%40'=>'@','%26'=>'&','%3D'=>'=','%2B'=>'+','%24'=>'$'
        );
        $Vpr3ilddj3ca = array(
            '%23'=>'#'
        );
        return strtr(rawurlencode(rawurldecode($Vnogiydwdyzh)), array_merge($Vpvrggup4hyi,$Vxnk5tcgonnc,$Vpr3ilddj3ca));
    }

    
    public static function rle8_decode($Vu5vpgek1hmh, $Vtt4kvdwuqqh)
    {
        $Vnyvvzqv5i21 = $Vtt4kvdwuqqh + (3 - ($Vtt4kvdwuqqh - 1) % 4);
        $Vpsxy0jjygm1 = '';
        $Vtjgi2jv35gd = strlen($Vu5vpgek1hmh);

        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vtjgi2jv35gd; $V0ixz2v5mxzy++) {
            $Vyea2e2tvrvz = ord($Vu5vpgek1hmh[$V0ixz2v5mxzy]);
            switch ($Vyea2e2tvrvz) {
                case 0: # ESCAPE
                    $V0ixz2v5mxzy++;
                    switch (ord($Vu5vpgek1hmh[$V0ixz2v5mxzy])) {
                        case 0: # NEW LINE
                            $Vahk2ebkr4gw = $Vnyvvzqv5i21 - strlen($Vpsxy0jjygm1) % $Vnyvvzqv5i21;
                            if ($Vahk2ebkr4gw < $Vnyvvzqv5i21) {
                                $Vpsxy0jjygm1 .= str_repeat(chr(0), $Vahk2ebkr4gw); # pad line
                            }
                            break;
                        case 1: # END OF FILE
                            $Vahk2ebkr4gw = $Vnyvvzqv5i21 - strlen($Vpsxy0jjygm1) % $Vnyvvzqv5i21;
                            if ($Vahk2ebkr4gw < $Vnyvvzqv5i21) {
                                $Vpsxy0jjygm1 .= str_repeat(chr(0), $Vahk2ebkr4gw); # pad line
                            }
                            break 3;
                        case 2: # DELTA
                            $V0ixz2v5mxzy += 2;
                            break;
                        default: # ABSOLUTE MODE
                            $Vaucqj0hftp5 = ord($Vu5vpgek1hmh[$V0ixz2v5mxzy]);
                            for ($Vy4wtqjehnh5 = 0; $Vy4wtqjehnh5 < $Vaucqj0hftp5; $Vy4wtqjehnh5++) {
                                $Vpsxy0jjygm1 .= $Vu5vpgek1hmh[++$V0ixz2v5mxzy];
                            }
                            if ($Vaucqj0hftp5 % 2) {
                                $V0ixz2v5mxzy++;
                            }
                    }
                    break;
                default:
                    $Vpsxy0jjygm1 .= str_repeat($Vu5vpgek1hmh[++$V0ixz2v5mxzy], $Vyea2e2tvrvz);
            }
        }
        return $Vpsxy0jjygm1;
    }

    
    public static function rle4_decode($Vu5vpgek1hmh, $Vtt4kvdwuqqh)
    {
        $V5ymvwogwh5y = floor($Vtt4kvdwuqqh / 2) + ($Vtt4kvdwuqqh % 2);
        $Vnyvvzqv5i21 = $V5ymvwogwh5y + (3 - (($Vtt4kvdwuqqh - 1) / 2) % 4);
        $Vceif1pgkxoq = array();
        $Vtjgi2jv35gd = strlen($Vu5vpgek1hmh);
        $Vdiqkcy1hsm4 = 0;

        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vtjgi2jv35gd; $V0ixz2v5mxzy++) {
            $Vyea2e2tvrvz = ord($Vu5vpgek1hmh[$V0ixz2v5mxzy]);
            switch ($Vyea2e2tvrvz) {
                case 0: # ESCAPE
                    $V0ixz2v5mxzy++;
                    switch (ord($Vu5vpgek1hmh[$V0ixz2v5mxzy])) {
                        case 0: # NEW LINE
                            while (count($Vceif1pgkxoq) % $Vnyvvzqv5i21 != 0) {
                                $Vceif1pgkxoq[] = 0;
                            }
                            break;
                        case 1: # END OF FILE
                            while (count($Vceif1pgkxoq) % $Vnyvvzqv5i21 != 0) {
                                $Vceif1pgkxoq[] = 0;
                            }
                            break 3;
                        case 2: # DELTA
                            $V0ixz2v5mxzy += 2;
                            break;
                        default: # ABSOLUTE MODE
                            $Vaucqj0hftp5 = ord($Vu5vpgek1hmh[$V0ixz2v5mxzy]);
                            for ($Vy4wtqjehnh5 = 0; $Vy4wtqjehnh5 < $Vaucqj0hftp5; $Vy4wtqjehnh5++) {
                                if ($Vy4wtqjehnh5 % 2 == 0) {
                                    $Vdiqkcy1hsm4 = ord($Vu5vpgek1hmh[++$V0ixz2v5mxzy]);
                                    $Vceif1pgkxoq[] = ($Vdiqkcy1hsm4 & 240) >> 4;
                                } else {
                                    $Vceif1pgkxoq[] = $Vdiqkcy1hsm4 & 15;
                                }
                            }

                            if ($Vaucqj0hftp5 % 2 == 0) {
                                $V0ixz2v5mxzy++;
                            }
                    }
                    break;
                default:
                    $Vdiqkcy1hsm4 = ord($Vu5vpgek1hmh[++$V0ixz2v5mxzy]);
                    for ($Vy4wtqjehnh5 = 0; $Vy4wtqjehnh5 < $Vyea2e2tvrvz; $Vy4wtqjehnh5++) {
                        $Vceif1pgkxoq[] = ($Vy4wtqjehnh5 % 2 == 0 ? ($Vdiqkcy1hsm4 & 240) >> 4 : $Vdiqkcy1hsm4 & 15);
                    }
            }
        }

        $Vpsxy0jjygm1 = '';
        if (count($Vceif1pgkxoq) % 2) {
            $Vceif1pgkxoq[] = 0;
        }

        $Vtjgi2jv35gd = count($Vceif1pgkxoq) / 2;

        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vtjgi2jv35gd; $V0ixz2v5mxzy++) {
            $Vpsxy0jjygm1 .= chr(16 * $Vceif1pgkxoq[2 * $V0ixz2v5mxzy] + $Vceif1pgkxoq[2 * $V0ixz2v5mxzy + 1]);
        }

        return $Vpsxy0jjygm1;
    }

    
    public static function explode_url($Vop22rgf5euu)
    {
        $Vz2fphjg3555 = "";
        $Vskypresjwem = "";
        $Vt321vu1jwdw = "";
        $Voheucoc3jxv = "";

        $Vkmcaia35nsn = parse_url($Vop22rgf5euu);
        if ( isset($Vkmcaia35nsn["scheme"]) ) {
            $Vkmcaia35nsn["scheme"] = mb_strtolower($Vkmcaia35nsn["scheme"]);
        }

        
        if (isset($Vkmcaia35nsn["scheme"]) && $Vkmcaia35nsn["scheme"] !== "file" && strlen($Vkmcaia35nsn["scheme"]) > 1) {
            $Vz2fphjg3555 = $Vkmcaia35nsn["scheme"] . "://";

            if (isset($Vkmcaia35nsn["user"])) {
                $Vskypresjwem .= $Vkmcaia35nsn["user"];

                if (isset($Vkmcaia35nsn["pass"])) {
                    $Vskypresjwem .= ":" . $Vkmcaia35nsn["pass"];
                }

                $Vskypresjwem .= "@";
            }

            if (isset($Vkmcaia35nsn["host"])) {
                $Vskypresjwem .= $Vkmcaia35nsn["host"];
            }

            if (isset($Vkmcaia35nsn["port"])) {
                $Vskypresjwem .= ":" . $Vkmcaia35nsn["port"];
            }

            if (isset($Vkmcaia35nsn["path"]) && $Vkmcaia35nsn["path"] !== "") {
                
                if ($Vkmcaia35nsn["path"][mb_strlen($Vkmcaia35nsn["path"]) - 1] === "/") {
                    $Vt321vu1jwdw = $Vkmcaia35nsn["path"];
                    $Voheucoc3jxv = "";
                } else {
                    $Vt321vu1jwdw = rtrim(dirname($Vkmcaia35nsn["path"]), '/\\') . "/";
                    $Voheucoc3jxv = basename($Vkmcaia35nsn["path"]);
                }
            }

            if (isset($Vkmcaia35nsn["query"])) {
                $Voheucoc3jxv .= "?" . $Vkmcaia35nsn["query"];
            }

            if (isset($Vkmcaia35nsn["fragment"])) {
                $Voheucoc3jxv .= "#" . $Vkmcaia35nsn["fragment"];
            }

        } else {

            $V0ixz2v5mxzy = mb_stripos($Vop22rgf5euu, "file://");
            if ($V0ixz2v5mxzy !== false) {
                $Vop22rgf5euu = mb_substr($Vop22rgf5euu, $V0ixz2v5mxzy + 7);
            }

            $Vz2fphjg3555 = ""; 
            

            $Vskypresjwem = ""; 
            $Voheucoc3jxv = basename($Vop22rgf5euu);

            $Vt321vu1jwdw = dirname($Vop22rgf5euu);

            
            if ($Vt321vu1jwdw !== false) {
                $Vt321vu1jwdw .= '/';

            } else {
                
                $Vz2fphjg3555 = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';

                $Vskypresjwem = isset($_SERVER["HTTP_HOST"]) ? $_SERVER["HTTP_HOST"] : php_uname("n");

                if (substr($Vkmcaia35nsn["path"], 0, 1) === '/') {
                    $Vt321vu1jwdw = dirname($Vkmcaia35nsn["path"]);
                } else {
                    $Vt321vu1jwdw = '/' . rtrim(dirname($_SERVER["SCRIPT_NAME"]), '/') . '/' . $Vkmcaia35nsn["path"];
                }
            }
        }

        $Vaamzcof1atz = array($Vz2fphjg3555, $Vskypresjwem, $Vt321vu1jwdw, $Voheucoc3jxv,
            "protocol" => $Vz2fphjg3555,
            "host" => $Vskypresjwem,
            "path" => $Vt321vu1jwdw,
            "file" => $Voheucoc3jxv);
        return $Vaamzcof1atz;
    }

    
    public static function dompdf_debug($Vky1xzjrvbn4, $V4kq14u5yvh5)
    {
        global $Vds50rvbzfwa, $Vdoojvf2pqdf, $Vqg3ys0emmj5;
        if (isset($Vds50rvbzfwa[$Vky1xzjrvbn4]) && ($Vdoojvf2pqdf || $Vqg3ys0emmj5)) {
            $Vkmcaia35nsn = debug_backtrace();

            echo basename($Vkmcaia35nsn[0]["file"]) . " (" . $Vkmcaia35nsn[0]["line"] . "): " . $Vkmcaia35nsn[1]["function"] . ": ";
            Helpers::pre_r($V4kq14u5yvh5);
        }
    }

    
    public static function record_warnings($Vrctdhiixpl5, $Vpkkloai3uad, $Vzj3cy533ndl, $Vtqat0kvwffg)
    {
        
        if (!($Vrctdhiixpl5 & (E_WARNING | E_NOTICE | E_USER_NOTICE | E_USER_WARNING))) {
            throw new Exception($Vpkkloai3uad . " $Vrctdhiixpl5");
        }

        global $V1vwj3kz31tm;
        global $Vdoojvf2pqdf;

        if ($Vdoojvf2pqdf) {
            echo $Vpkkloai3uad . "\n";
        }

        $V1vwj3kz31tm[] = $Vpkkloai3uad;
    }

    
    public static function unichr($Vdiqkcy1hsm4)
    {
        if ($Vdiqkcy1hsm4 <= 0x7F) {
            return chr($Vdiqkcy1hsm4);
        } else if ($Vdiqkcy1hsm4 <= 0x7FF) {
            return chr(0xC0 | $Vdiqkcy1hsm4 >> 6) . chr(0x80 | $Vdiqkcy1hsm4 & 0x3F);
        } else if ($Vdiqkcy1hsm4 <= 0xFFFF) {
            return chr(0xE0 | $Vdiqkcy1hsm4 >> 12) . chr(0x80 | $Vdiqkcy1hsm4 >> 6 & 0x3F)
            . chr(0x80 | $Vdiqkcy1hsm4 & 0x3F);
        } else if ($Vdiqkcy1hsm4 <= 0x10FFFF) {
            return chr(0xF0 | $Vdiqkcy1hsm4 >> 18) . chr(0x80 | $Vdiqkcy1hsm4 >> 12 & 0x3F)
            . chr(0x80 | $Vdiqkcy1hsm4 >> 6 & 0x3F)
            . chr(0x80 | $Vdiqkcy1hsm4 & 0x3F);
        }
        return false;
    }

    
    public static function cmyk_to_rgb($Vdiqkcy1hsm4, $Vesx3wzwpu4i = null, $Vuua0v2znlr5 = null, $Vawllmnnfede = null)
    {
        if (is_array($Vdiqkcy1hsm4)) {
            list($Vdiqkcy1hsm4, $Vesx3wzwpu4i, $Vuua0v2znlr5, $Vawllmnnfede) = $Vdiqkcy1hsm4;
        }

        $Vdiqkcy1hsm4 *= 255;
        $Vesx3wzwpu4i *= 255;
        $Vuua0v2znlr5 *= 255;
        $Vawllmnnfede *= 255;

        $Vapkwgsb3w3r = (1 - round(2.55 * ($Vdiqkcy1hsm4 + $Vawllmnnfede)));
        $Vlqbrj3xtbjj = (1 - round(2.55 * ($Vesx3wzwpu4i + $Vawllmnnfede)));
        $Vkbvefdrfvxh = (1 - round(2.55 * ($Vuua0v2znlr5 + $Vawllmnnfede)));

        if ($Vapkwgsb3w3r < 0) {
            $Vapkwgsb3w3r = 0;
        }
        if ($Vlqbrj3xtbjj < 0) {
            $Vlqbrj3xtbjj = 0;
        }
        if ($Vkbvefdrfvxh < 0) {
            $Vkbvefdrfvxh = 0;
        }

        return array(
            $Vapkwgsb3w3r, $Vlqbrj3xtbjj, $Vkbvefdrfvxh,
            "r" => $Vapkwgsb3w3r, "g" => $Vlqbrj3xtbjj, "b" => $Vkbvefdrfvxh
        );
    }

    
    public static function dompdf_getimagesize($Vnbqjwe42int, $Vdiqkcy1hsm4ontext = null)
    {
        static $Vdiqkcy1hsm4ache = array();

        if (isset($Vdiqkcy1hsm4ache[$Vnbqjwe42int])) {
            return $Vdiqkcy1hsm4ache[$Vnbqjwe42int];
        }

        list($Vtt4kvdwuqqh, $Vxtfrabd3i5r, $Vky1xzjrvbn4) = getimagesize($Vnbqjwe42int);

        
        $Vky1xzjrvbn4s = array(
            IMAGETYPE_JPEG => "jpeg",
            IMAGETYPE_GIF  => "gif",
            IMAGETYPE_BMP  => "bmp",
            IMAGETYPE_PNG  => "png",
        );

        $Vky1xzjrvbn4 = isset($Vky1xzjrvbn4s[$Vky1xzjrvbn4]) ? $Vky1xzjrvbn4s[$Vky1xzjrvbn4] : null;

        if ($Vtt4kvdwuqqh == null || $Vxtfrabd3i5r == null) {
            list($V3o5lzcfvwzz, $Vjo4gjilc3cj) = Helpers::getFileContent($Vnbqjwe42int, $Vdiqkcy1hsm4ontext);

            if (substr($V3o5lzcfvwzz, 0, 2) === "BM") {
                $Vesx3wzwpu4ieta = unpack('vtype/Vfilesize/Vreserved/Voffset/Vheadersize/Vwidth/Vheight', $V3o5lzcfvwzz);
                $Vtt4kvdwuqqh = (int)$Vesx3wzwpu4ieta['width'];
                $Vxtfrabd3i5r = (int)$Vesx3wzwpu4ieta['height'];
                $Vky1xzjrvbn4 = "bmp";
            }
            else {
                if (strpos($V3o5lzcfvwzz, "<svg") !== false) {
                    $Vn53dg3q25ot = new \Svg\Document();
                    $Vn53dg3q25ot->loadFile($Vnbqjwe42int);

                    list($Vtt4kvdwuqqh, $Vxtfrabd3i5r) = $Vn53dg3q25ot->getDimensions();
                    $Vky1xzjrvbn4 = "svg";
                }
            }

        }

        return $Vdiqkcy1hsm4ache[$Vnbqjwe42int] = array($Vtt4kvdwuqqh, $Vxtfrabd3i5r, $Vky1xzjrvbn4);
    }

    
    public static function imagecreatefrombmp($Vnbqjwe42int, $Vdiqkcy1hsm4ontext = null)
    {
        if (!function_exists("imagecreatetruecolor")) {
            trigger_error("The PHP GD extension is required, but is not installed.", E_ERROR);
            return false;
        }

        
        if (!($Vxisppwpu2uj = fopen($Vnbqjwe42int, 'rb'))) {
            trigger_error('imagecreatefrombmp: Can not open ' . $Vnbqjwe42int, E_USER_WARNING);
            return false;
        }

        $Vkbvefdrfvxhytes_read = 0;

        
        $Vesx3wzwpu4ieta = unpack('vtype/Vfilesize/Vreserved/Voffset', fread($Vxisppwpu2uj, 14));

        
        if ($Vesx3wzwpu4ieta['type'] != 19778) {
            trigger_error('imagecreatefrombmp: ' . $Vnbqjwe42int . ' is not a bitmap!', E_USER_WARNING);
            return false;
        }

        
        $Vesx3wzwpu4ieta += unpack('Vheadersize/Vwidth/Vheight/vplanes/vbits/Vcompression/Vimagesize/Vxres/Vyres/Vcolors/Vimportant', fread($Vxisppwpu2uj, 40));
        $Vkbvefdrfvxhytes_read += 40;

        
        if ($Vesx3wzwpu4ieta['compression'] == 3) {
            $Vesx3wzwpu4ieta += unpack('VrMask/VgMask/VbMask', fread($Vxisppwpu2uj, 12));
            $Vkbvefdrfvxhytes_read += 12;
        }

        
        $Vesx3wzwpu4ieta['bytes'] = $Vesx3wzwpu4ieta['bits'] / 8;
        $Vesx3wzwpu4ieta['decal'] = 4 - (4 * (($Vesx3wzwpu4ieta['width'] * $Vesx3wzwpu4ieta['bytes'] / 4) - floor($Vesx3wzwpu4ieta['width'] * $Vesx3wzwpu4ieta['bytes'] / 4)));
        if ($Vesx3wzwpu4ieta['decal'] == 4) {
            $Vesx3wzwpu4ieta['decal'] = 0;
        }

        
        if ($Vesx3wzwpu4ieta['imagesize'] < 1) {
            $Vesx3wzwpu4ieta['imagesize'] = $Vesx3wzwpu4ieta['filesize'] - $Vesx3wzwpu4ieta['offset'];
            
            if ($Vesx3wzwpu4ieta['imagesize'] < 1) {
                $Vesx3wzwpu4ieta['imagesize'] = @filesize($Vnbqjwe42int) - $Vesx3wzwpu4ieta['offset'];
                if ($Vesx3wzwpu4ieta['imagesize'] < 1) {
                    trigger_error('imagecreatefrombmp: Can not obtain filesize of ' . $Vnbqjwe42int . '!', E_USER_WARNING);
                    return false;
                }
            }
        }

        
        $Vesx3wzwpu4ieta['colors'] = !$Vesx3wzwpu4ieta['colors'] ? pow(2, $Vesx3wzwpu4ieta['bits']) : $Vesx3wzwpu4ieta['colors'];

        
        $Vop1dukmrlvz = array();
        if ($Vesx3wzwpu4ieta['bits'] < 16) {
            $Vop1dukmrlvz = unpack('l' . $Vesx3wzwpu4ieta['colors'], fread($Vxisppwpu2uj, $Vesx3wzwpu4ieta['colors'] * 4));
            
            if ($Vop1dukmrlvz[1] < 0) {
                foreach ($Vop1dukmrlvz as $V0ixz2v5mxzy => $Vdiqkcy1hsm4olor) {
                    $Vop1dukmrlvz[$V0ixz2v5mxzy] = $Vdiqkcy1hsm4olor + 16777216;
                }
            }
        }

        
        if ($Vesx3wzwpu4ieta['headersize'] > $Vkbvefdrfvxhytes_read) {
            fread($Vxisppwpu2uj, $Vesx3wzwpu4ieta['headersize'] - $Vkbvefdrfvxhytes_read);
        }

        
        $V0ixz2v5mxzym = imagecreatetruecolor($Vesx3wzwpu4ieta['width'], $Vesx3wzwpu4ieta['height']);
        $V3o5lzcfvwzz = fread($Vxisppwpu2uj, $Vesx3wzwpu4ieta['imagesize']);

        
        switch ($Vesx3wzwpu4ieta['compression']) {
            case 1:
                $V3o5lzcfvwzz = Helpers::rle8_decode($V3o5lzcfvwzz, $Vesx3wzwpu4ieta['width']);
                break;
            case 2:
                $V3o5lzcfvwzz = Helpers::rle4_decode($V3o5lzcfvwzz, $Vesx3wzwpu4ieta['width']);
                break;
        }

        $V2d1s45w0hjo = 0;
        $Vwfrnlj04n41 = chr(0);
        $Vuua0v2znlr5 = $Vesx3wzwpu4ieta['height'] - 1;
        $Vropiebcst33 = 'imagecreatefrombmp: ' . $Vnbqjwe42int . ' has not enough data!';

        
        while ($Vuua0v2znlr5 >= 0) {
            $Vmm2pe5l4str = 0;
            while ($Vmm2pe5l4str < $Vesx3wzwpu4ieta['width']) {
                switch ($Vesx3wzwpu4ieta['bits']) {
                    case 32:
                    case 24:
                        if (!($V2d1s45w0hjoart = substr($V3o5lzcfvwzz, $V2d1s45w0hjo, 3 ))) {
                            trigger_error($Vropiebcst33, E_USER_WARNING);
                            return $V0ixz2v5mxzym;
                        }
                        $Vdiqkcy1hsm4olor = unpack('V', $V2d1s45w0hjoart . $Vwfrnlj04n41);
                        break;
                    case 16:
                        if (!($V2d1s45w0hjoart = substr($V3o5lzcfvwzz, $V2d1s45w0hjo, 2 ))) {
                            trigger_error($Vropiebcst33, E_USER_WARNING);
                            return $V0ixz2v5mxzym;
                        }
                        $Vdiqkcy1hsm4olor = unpack('v', $V2d1s45w0hjoart);

                        if (empty($Vesx3wzwpu4ieta['rMask']) || $Vesx3wzwpu4ieta['rMask'] != 0xf800) {
                            $Vdiqkcy1hsm4olor[1] = (($Vdiqkcy1hsm4olor[1] & 0x7c00) >> 7) * 65536 + (($Vdiqkcy1hsm4olor[1] & 0x03e0) >> 2) * 256 + (($Vdiqkcy1hsm4olor[1] & 0x001f) << 3); 
                        } else {
                            $Vdiqkcy1hsm4olor[1] = (($Vdiqkcy1hsm4olor[1] & 0xf800) >> 8) * 65536 + (($Vdiqkcy1hsm4olor[1] & 0x07e0) >> 3) * 256 + (($Vdiqkcy1hsm4olor[1] & 0x001f) << 3); 
                        }
                        break;
                    case 8:
                        $Vdiqkcy1hsm4olor = unpack('n', $Vwfrnlj04n41 . substr($V3o5lzcfvwzz, $V2d1s45w0hjo, 1));
                        $Vdiqkcy1hsm4olor[1] = $Vop1dukmrlvz[$Vdiqkcy1hsm4olor[1] + 1];
                        break;
                    case 4:
                        $Vdiqkcy1hsm4olor = unpack('n', $Vwfrnlj04n41 . substr($V3o5lzcfvwzz, floor($V2d1s45w0hjo), 1));
                        $Vdiqkcy1hsm4olor[1] = ($V2d1s45w0hjo * 2) % 2 == 0 ? $Vdiqkcy1hsm4olor[1] >> 4 : $Vdiqkcy1hsm4olor[1] & 0x0F;
                        $Vdiqkcy1hsm4olor[1] = $Vop1dukmrlvz[$Vdiqkcy1hsm4olor[1] + 1];
                        break;
                    case 1:
                        $Vdiqkcy1hsm4olor = unpack('n', $Vwfrnlj04n41 . substr($V3o5lzcfvwzz, floor($V2d1s45w0hjo), 1));
                        switch (($V2d1s45w0hjo * 8) % 8) {
                            case 0:
                                $Vdiqkcy1hsm4olor[1] = $Vdiqkcy1hsm4olor[1] >> 7;
                                break;
                            case 1:
                                $Vdiqkcy1hsm4olor[1] = ($Vdiqkcy1hsm4olor[1] & 0x40) >> 6;
                                break;
                            case 2:
                                $Vdiqkcy1hsm4olor[1] = ($Vdiqkcy1hsm4olor[1] & 0x20) >> 5;
                                break;
                            case 3:
                                $Vdiqkcy1hsm4olor[1] = ($Vdiqkcy1hsm4olor[1] & 0x10) >> 4;
                                break;
                            case 4:
                                $Vdiqkcy1hsm4olor[1] = ($Vdiqkcy1hsm4olor[1] & 0x8) >> 3;
                                break;
                            case 5:
                                $Vdiqkcy1hsm4olor[1] = ($Vdiqkcy1hsm4olor[1] & 0x4) >> 2;
                                break;
                            case 6:
                                $Vdiqkcy1hsm4olor[1] = ($Vdiqkcy1hsm4olor[1] & 0x2) >> 1;
                                break;
                            case 7:
                                $Vdiqkcy1hsm4olor[1] = ($Vdiqkcy1hsm4olor[1] & 0x1);
                                break;
                        }
                        $Vdiqkcy1hsm4olor[1] = $Vop1dukmrlvz[$Vdiqkcy1hsm4olor[1] + 1];
                        break;
                    default:
                        trigger_error('imagecreatefrombmp: ' . $Vnbqjwe42int . ' has ' . $Vesx3wzwpu4ieta['bits'] . ' bits and this is not supported!', E_USER_WARNING);
                        return false;
                }
                imagesetpixel($V0ixz2v5mxzym, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vdiqkcy1hsm4olor[1]);
                $Vmm2pe5l4str++;
                $V2d1s45w0hjo += $Vesx3wzwpu4ieta['bytes'];
            }
            $Vuua0v2znlr5--;
            $V2d1s45w0hjo += $Vesx3wzwpu4ieta['decal'];
        }
        fclose($Vxisppwpu2uj);
        return $V0ixz2v5mxzym;
    }

    
    public static function getFileContent($Vnogiydwdyzh, $Vdiqkcy1hsm4ontext = null, $Vyea2e2tvrvzffset = 0, $Vesx3wzwpu4iaxlen = null)
    {
        $Vji4j1ie4mwl = false;
        $Vjo4gjilc3cj = null;
        list($V2d1s45w0hjoroto, $Vskypresjwem, $Vt321vu1jwdw, $Voheucoc3jxv) = Helpers::explode_url($Vnogiydwdyzh);
        $V0ixz2v5mxzys_local_path = ($V2d1s45w0hjoroto == "" || $V2d1s45w0hjoroto === "file://");

        set_error_handler(array("\\Dompdf\\Helpers", "record_warnings"));

        if ($V0ixz2v5mxzys_local_path || ini_get("allow_url_fopen")) {
            if ($V0ixz2v5mxzys_local_path === false) {
                $Vnogiydwdyzh = Helpers::encodeURI($Vnogiydwdyzh);
            }
            if (isset($Vesx3wzwpu4iaxlen)) {
                $Vji4j1ie4mwl = file_get_contents($Vnogiydwdyzh, null, $Vdiqkcy1hsm4ontext, $Vyea2e2tvrvzffset, $Vesx3wzwpu4iaxlen);
            } else {
                $Vji4j1ie4mwl = file_get_contents($Vnogiydwdyzh, null, $Vdiqkcy1hsm4ontext, $Vyea2e2tvrvzffset);
            }
            if (isset($http_response_header)) {
                $Vjo4gjilc3cj = $http_response_header;
            }

        } elseif (function_exists("curl_exec")) {
            $Vdiqkcy1hsm4url = curl_init($Vnogiydwdyzh);

            
            curl_setopt($Vdiqkcy1hsm4url, CURLOPT_TIMEOUT, 10);
            curl_setopt($Vdiqkcy1hsm4url, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($Vdiqkcy1hsm4url, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($Vdiqkcy1hsm4url, CURLOPT_HEADER, true);
            if ($Vyea2e2tvrvzffset > 0) {
                curl_setopt($Vdiqkcy1hsm4url, CURLOPT_RESUME_FROM, $Vyea2e2tvrvzffset);
            }

            $V3o5lzcfvwzz = curl_exec($Vdiqkcy1hsm4url);
            $Vapkwgsb3w3raw_headers = substr($V3o5lzcfvwzz, 0, curl_getinfo($Vdiqkcy1hsm4url, CURLINFO_HEADER_SIZE));
            $Vjo4gjilc3cj = preg_split("/[\n\r]+/", trim($Vapkwgsb3w3raw_headers));
            $Vji4j1ie4mwl = substr($V3o5lzcfvwzz, curl_getinfo($Vdiqkcy1hsm4url, CURLINFO_HEADER_SIZE));
            curl_close($Vdiqkcy1hsm4url);
        }

        restore_error_handler();

        return array($Vji4j1ie4mwl, $Vjo4gjilc3cj);
    }

    public static function mb_ucwords($Vu5vpgek1hmh) {
        $Vesx3wzwpu4iax_len = mb_strlen($Vu5vpgek1hmh);
        if ($Vesx3wzwpu4iax_len === 1) {
            return mb_strtoupper($Vu5vpgek1hmh);
        }

        $Vu5vpgek1hmh = mb_strtoupper(mb_substr($Vu5vpgek1hmh, 0, 1)) . mb_substr($Vu5vpgek1hmh, 1);

        foreach (array(' ', '.', ',', '!', '?', '-', '+') as $V500t5q0ulgs) {
            $V2d1s45w0hjoos = 0;
            while (($V2d1s45w0hjoos = mb_strpos($Vu5vpgek1hmh, $V500t5q0ulgs, $V2d1s45w0hjoos)) !== false) {
                $V2d1s45w0hjoos++;
                
                if ($V2d1s45w0hjoos !== false && $V2d1s45w0hjoos < $Vesx3wzwpu4iax_len) {
                    
                    if ($V2d1s45w0hjoos + 1 < $Vesx3wzwpu4iax_len) {
                        $Vu5vpgek1hmh = mb_substr($Vu5vpgek1hmh, 0, $V2d1s45w0hjoos) . mb_strtoupper(mb_substr($Vu5vpgek1hmh, $V2d1s45w0hjoos, 1)) . mb_substr($Vu5vpgek1hmh, $V2d1s45w0hjoos + 1);
                    } else {
                        $Vu5vpgek1hmh = mb_substr($Vu5vpgek1hmh, 0, $V2d1s45w0hjoos) . mb_strtoupper(mb_substr($Vu5vpgek1hmh, $V2d1s45w0hjoos, 1));
                    }
                }
            }
        }

        return $Vu5vpgek1hmh;
    }
}
