<?php

namespace Dompdf;


class CanvasFactory
{
    
    private function __construct()
    {
    }

    
    static function get_instance(Dompdf $Vodc45cwlwwh, $V54vxutwmj54 = null, $V00gcroe4i4s = null, $Vrptwe2245zq = null)
    {
        $Vtqijwtd4yux = strtolower($Vodc45cwlwwh->getOptions()->getPdfBackend());

        if (isset($Vrptwe2245zq) && class_exists($Vrptwe2245zq, false)) {
            $Vrptwe2245zq .= "_Adapter";
        } else {
            if (($Vtqijwtd4yux === "auto" || $Vtqijwtd4yux === "pdflib") &&
                class_exists("PDFLib", false)
            ) {
                $Vrptwe2245zq = "Dompdf\\Adapter\\PDFLib";
            }

            else {
                if ($Vtqijwtd4yux === "gd") {
                    $Vrptwe2245zq = "Dompdf\\Adapter\\GD";
                } else {
                    $Vrptwe2245zq = "Dompdf\\Adapter\\CPDF";
                }
            }
        }

        return new $Vrptwe2245zq($V54vxutwmj54, $V00gcroe4i4s, $Vodc45cwlwwh);
    }
}
