<?php


namespace Dompdf;


interface Canvas
{
    function __construct($V54vxutwmj54 = "letter", $V00gcroe4i4s = "portrait", Dompdf $Vodc45cwlwwh);

    
    function get_dompdf();

    
    function get_page_number();

    
    function get_page_count();

    
    function set_page_count($V4wukmcy3ij2);

    
    function line($V4wnp2r2nst5, $V2e3azycubv1, $V2kam3hj2q41, $Vg1v0wo0w4jj, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = null);

    
    function rectangle($V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = null);

    
    function filled_rectangle($V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V3poxlnogtlh);

    
    function clipping_rectangle($V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5y, $V2pgp3ppbjsi);

    
    function clipping_roundrectangle($V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Veltemnghp05, $Vkfno1tgq5nc, $Vbwp1e1ru2dj, $V3lmsgoqk24r);

    
    function clipping_end();

    
    function save();

    
    function restore();

    
    function rotate($Vvb4ibm25tpf, $Vmm2pe5l4str, $Vuua0v2znlr5);

    
    function skew($Vvb4ibm25tpf_x, $Vvb4ibm25tpf_y, $Vmm2pe5l4str, $Vuua0v2znlr5);

    
    function scale($Vb01jpbrlun1, $Vt5g1id0c1cp, $Vmm2pe5l4str, $Vuua0v2znlr5);

    
    function translate($Vbs1pcpjo5lt, $Vml2vjgadh2o);

    
    function transform($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1);

    
    function polygon($Vz0kp11gbnu4, $V3poxlnogtlh, $Vtt4kvdwuqqh = null, $Vkvw5zjrwkdm = null, $Vtmlsxxw3ne1ill = false);

    
    function circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vapkwgsb3w3r, $V3poxlnogtlh, $Vtt4kvdwuqqh = null, $Vkvw5zjrwkdm = null, $Vtmlsxxw3ne1ill = false);

    
    function image($Vtafxiaximgz, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vapkwgsb3w3resolution = "normal");

    
    function arc($Vmm2pe5l4str, $Vuua0v2znlr5, $Vapkwgsb3w3r1, $Vapkwgsb3w3r2, $V4dkbhpdu11qstart, $V4dkbhpdu11qend, $V3poxlnogtlh, $Vtt4kvdwuqqh, $Vkvw5zjrwkdm = array());

    
    function text($Vmm2pe5l4str, $Vuua0v2znlr5, $Vnjapcj4bkpc, $Vtmlsxxw3ne1ont, $Vkgj34o34uaw, $V3poxlnogtlh = array(0, 0, 0), $V5ymvwogwh5yord_space = 0.0, $Vdiqkcy1hsm4har_space = 0.0, $Vvb4ibm25tpf = 0.0);

    
    function add_named_dest($V4dkbhpdu11qnchorname);

    
    function add_link($Vop22rgf5euu, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vtt4kvdwuqqh, $V2pgp3ppbjsieight);

    
    function add_info($Vreuchxnm2nm, $Veugw2h43vxz);

    
    function get_text_width($Vnjapcj4bkpc, $Vtmlsxxw3ne1ont, $Vkgj34o34uaw, $V5ymvwogwh5yord_spacing = 0.0, $Vdiqkcy1hsm4har_spacing = 0.0);

    
    function get_font_height($Vtmlsxxw3ne1ont, $Vkgj34o34uaw);

    
    function get_font_baseline($Vtmlsxxw3ne1ont, $Vkgj34o34uaw);

    
    function get_width();


    
    function get_height();

    
    

    
    function set_opacity($Vhrfbgup2xix, $V4rgua51nlxl = "Normal");

    
    function set_default_view($V5op4eazb4xu, $V3vmzyblbtdy = array());

    
    function javascript($Vrmsxtweeon4);

    
    function new_page();

    
    function stream($Vtmlsxxw3ne1ilename, $V3vmzyblbtdy = array());

    
    function output($V3vmzyblbtdy = array());
}
