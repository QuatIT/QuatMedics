<?php

namespace FontLib\Tests;

use FontLib\Font;

class FontTest extends \PHPUnit_Framework_TestCase
{
    
    public function testLoadFileNotFound()
    {
        Font::load('non-existing/font.ttf');
    }

    public function testLoadTTFFontSuccessfully()
    {
        $V2bz2xsw1p3l = Font::load('sample-fonts/IntelClear-Light.ttf');

        $this->assertInstanceOf('FontLib\TrueType\File', $V2bz2xsw1p3l);
    }

    public function test12CmapFormat()
    {
        $V2bz2xsw1p3l = Font::load('sample-fonts/NotoSansShavian-Regular.ttf');

        $V2bz2xsw1p3l->parse();

        $V1ublpa0jvoy = $V2bz2xsw1p3l->getData("cmap", "subtables");

        $Vwxwah4vupg3 = $V1ublpa0jvoy[0];

        $this->assertEquals(4, $Vwxwah4vupg3['format']);
        $this->assertEquals(6, $Vwxwah4vupg3['segCount']);
        $this->assertEquals($Vwxwah4vupg3['segCount'], count($Vwxwah4vupg3['startCode']));
        $this->assertEquals($Vwxwah4vupg3['segCount'], count($Vwxwah4vupg3['endCode']));

        $Vijryft0q3ye = $V1ublpa0jvoy[1];

        $this->assertEquals(12, $Vijryft0q3ye['format']);
        $this->assertEquals(6, $Vijryft0q3ye['ngroups']);
        $this->assertEquals(6, count($Vijryft0q3ye['startCode']));
        $this->assertEquals(6, count($Vijryft0q3ye['endCode']));
        $this->assertEquals(53, count($Vijryft0q3ye['glyphIndexArray']));
    }

}
