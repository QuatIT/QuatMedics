<?php


namespace FontLib\TrueType;

use FontLib\AdobeFontMetrics;
use FontLib\Font;
use FontLib\BinaryStream;
use FontLib\Table\Table;
use FontLib\Table\DirectoryEntry;
use FontLib\Table\Type\glyf;
use FontLib\Table\Type\name;
use FontLib\Table\Type\nameRecord;


class File extends BinaryStream {
  
  public $Vkwhjduzezf4 = array();

  private $Vg45gdv2kmyx = 0; 

  private static $Vod2vbre0iqs = false;

  protected $Vmcylazx3pdy = array();
  protected $V3o5lzcfvwzz = array();

  protected $V2f5csc5emdp = array();

  public $Vkr4p3c2xj3z = array();

  static $Vtcvwjmpn3so = array(
    ".notdef", ".null", "CR",
    "space", "exclam", "quotedbl", "numbersign",
    "dollar", "percent", "ampersand", "quotesingle",
    "parenleft", "parenright", "asterisk", "plus",
    "comma", "hyphen", "period", "slash",
    "zero", "one", "two", "three",
    "four", "five", "six", "seven",
    "eight", "nine", "colon", "semicolon",
    "less", "equal", "greater", "question",
    "at", "A", "B", "C", "D", "E", "F", "G",
    "H", "I", "J", "K", "L", "M", "N", "O",
    "P", "Q", "R", "S", "T", "U", "V", "W",
    "X", "Y", "Z", "bracketleft",
    "backslash", "bracketright", "asciicircum", "underscore",
    "grave", "a", "b", "c", "d", "e", "f", "g",
    "h", "i", "j", "k", "l", "m", "n", "o",
    "p", "q", "r", "s", "t", "u", "v", "w",
    "x", "y", "z", "braceleft",
    "bar", "braceright", "asciitilde", "Adieresis",
    "Aring", "Ccedilla", "Eacute", "Ntilde",
    "Odieresis", "Udieresis", "aacute", "agrave",
    "acircumflex", "adieresis", "atilde", "aring",
    "ccedilla", "eacute", "egrave", "ecircumflex",
    "edieresis", "iacute", "igrave", "icircumflex",
    "idieresis", "ntilde", "oacute", "ograve",
    "ocircumflex", "odieresis", "otilde", "uacute",
    "ugrave", "ucircumflex", "udieresis", "dagger",
    "degree", "cent", "sterling", "section",
    "bullet", "paragraph", "germandbls", "registered",
    "copyright", "trademark", "acute", "dieresis",
    "notequal", "AE", "Oslash", "infinity",
    "plusminus", "lessequal", "greaterequal", "yen",
    "mu", "partialdiff", "summation", "product",
    "pi", "integral", "ordfeminine", "ordmasculine",
    "Omega", "ae", "oslash", "questiondown",
    "exclamdown", "logicalnot", "radical", "florin",
    "approxequal", "increment", "guillemotleft", "guillemotright",
    "ellipsis", "nbspace", "Agrave", "Atilde",
    "Otilde", "OE", "oe", "endash",
    "emdash", "quotedblleft", "quotedblright", "quoteleft",
    "quoteright", "divide", "lozenge", "ydieresis",
    "Ydieresis", "fraction", "currency", "guilsinglleft",
    "guilsinglright", "fi", "fl", "daggerdbl",
    "periodcentered", "quotesinglbase", "quotedblbase", "perthousand",
    "Acircumflex", "Ecircumflex", "Aacute", "Edieresis",
    "Egrave", "Iacute", "Icircumflex", "Idieresis",
    "Igrave", "Oacute", "Ocircumflex", "applelogo",
    "Ograve", "Uacute", "Ucircumflex", "Ugrave",
    "dotlessi", "circumflex", "tilde", "macron",
    "breve", "dotaccent", "ring", "cedilla",
    "hungarumlaut", "ogonek", "caron", "Lslash",
    "lslash", "Scaron", "scaron", "Zcaron",
    "zcaron", "brokenbar", "Eth", "eth",
    "Yacute", "yacute", "Thorn", "thorn",
    "minus", "multiply", "onesuperior", "twosuperior",
    "threesuperior", "onehalf", "onequarter", "threequarters",
    "franc", "Gbreve", "gbreve", "Idot",
    "Scedilla", "scedilla", "Cacute", "cacute",
    "Ccaron", "ccaron", "dmacron"
  );

  function getTable() {
    $this->parseTableEntries();

    return $this->directory;
  }

  function setTableOffset($Veatxxxrhqpk) {
    $this->tableOffset = $Veatxxxrhqpk;
  }

  function parse() {
    $this->parseTableEntries();

    $this->data = array();

    foreach ($this->directory as $Vgvunyxfpvcq => $Vp5rpvpxnb43) {
      if (empty($this->data[$Vgvunyxfpvcq])) {
        $this->readTable($Vgvunyxfpvcq);
      }
    }
  }

  function utf8toUnicode($Vu5vpgek1hmh) {
    $Vukikbvg40ol = strlen($Vu5vpgek1hmh);
    $Vpsxy0jjygm1 = array();

    for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vukikbvg40ol; $V0ixz2v5mxzy++) {
      $Vbklpuccugfm = -1;
      $V2pgp3ppbjsi   = ord($Vu5vpgek1hmh[$V0ixz2v5mxzy]);

      if ($V2pgp3ppbjsi <= 0x7F) {
        $Vbklpuccugfm = $V2pgp3ppbjsi;
      }
      elseif ($V2pgp3ppbjsi >= 0xC2) {
        if (($V2pgp3ppbjsi <= 0xDF) && ($V0ixz2v5mxzy < $Vukikbvg40ol - 1)) {
          $Vbklpuccugfm = ($V2pgp3ppbjsi & 0x1F) << 6 | (ord($Vu5vpgek1hmh[++$V0ixz2v5mxzy]) & 0x3F);
        }
        elseif (($V2pgp3ppbjsi <= 0xEF) && ($V0ixz2v5mxzy < $Vukikbvg40ol - 2)) {
          $Vbklpuccugfm = ($V2pgp3ppbjsi & 0x0F) << 12 | (ord($Vu5vpgek1hmh[++$V0ixz2v5mxzy]) & 0x3F) << 6 | (ord($Vu5vpgek1hmh[++$V0ixz2v5mxzy]) & 0x3F);
        }
        elseif (($V2pgp3ppbjsi <= 0xF4) && ($V0ixz2v5mxzy < $Vukikbvg40ol - 3)) {
          $Vbklpuccugfm = ($V2pgp3ppbjsi & 0x0F) << 18 | (ord($Vu5vpgek1hmh[++$V0ixz2v5mxzy]) & 0x3F) << 12 | (ord($Vu5vpgek1hmh[++$V0ixz2v5mxzy]) & 0x3F) << 6 | (ord($Vu5vpgek1hmh[++$V0ixz2v5mxzy]) & 0x3F);
        }
      }

      if ($Vbklpuccugfm >= 0) {
        $Vpsxy0jjygm1[] = $Vbklpuccugfm;
      }
    }

    return $Vpsxy0jjygm1;
  }

  function getUnicodeCharMap() {
    $Vxd4s5gofbp5 = null;
    foreach ($this->getData("cmap", "subtables") as $Vosvsokzeg25) {
      if ($Vosvsokzeg25["platformID"] == 0 || $Vosvsokzeg25["platformID"] == 3 && $Vosvsokzeg25["platformSpecificID"] == 1) {
        $Vxd4s5gofbp5 = $Vosvsokzeg25;
        break;
      }
    }

    if ($Vxd4s5gofbp5) {
      return $Vxd4s5gofbp5["glyphIndexArray"];
    }

    return null;
  }

  function setSubset($Vc2pexddbgmh) {
    if (!is_array($Vc2pexddbgmh)) {
      $Vc2pexddbgmh = $this->utf8toUnicode($Vc2pexddbgmh);
    }

    $Vc2pexddbgmh = array_unique($Vc2pexddbgmh);

    $Vgqdxnsnc0on = $this->getUnicodeCharMap();

    if (!$Vgqdxnsnc0on) {
      return;
    }

    $Vlpl3brjtqps = array(
      0, 
      1, 
    );

    foreach ($Vc2pexddbgmh as $Vlrwwrp5keo0) {
      if (!isset($Vgqdxnsnc0on[$Vlrwwrp5keo0])) {
        continue;
      }

      $V2hwvubg2icz        = $Vgqdxnsnc0on[$Vlrwwrp5keo0];
      $Vlpl3brjtqps[$V2hwvubg2icz] = $V2hwvubg2icz;
    }

    
    $Valansrsxpo4 = $this->getTableObject("glyf");
    $Vlpl3brjtqps = $Valansrsxpo4->getGlyphIDs($Vlpl3brjtqps);

    sort($Vlpl3brjtqps);

    $this->glyph_subset = $Vlpl3brjtqps;
    $this->glyph_all    = array_values($Vgqdxnsnc0on); 
  }

  function getSubset() {
    if (empty($this->glyph_subset)) {
      return $this->glyph_all;
    }

    return $this->glyph_subset;
  }

  function encode($Vgvunyxfpvcqs = array()) {
    if (!self::$Vod2vbre0iqs) {
      $Vgvunyxfpvcqs = array_merge(array("head", "hhea", "cmap", "hmtx", "maxp", "glyf", "loca", "name", "post"), $Vgvunyxfpvcqs);
    }
    else {
      $Vgvunyxfpvcqs = array_keys($this->directory);
    }

    $Vt3phu1t2vwr = count($Vgvunyxfpvcqs);
    $Vu440l53e414          = 16; 

    Font::d("Tables : " . implode(", ", $Vgvunyxfpvcqs));

    
    $Vu325ut4svxk = array();
    foreach ($Vgvunyxfpvcqs as $Vgvunyxfpvcq) {
      if (!isset($this->directory[$Vgvunyxfpvcq])) {
        Font::d("  >> '$Vgvunyxfpvcq' table doesn't exist");
        continue;
      }

      $Vu325ut4svxk[$Vgvunyxfpvcq] = $this->directory[$Vgvunyxfpvcq];
    }

    $this->header->data["numTables"] = $Vt3phu1t2vwr;
    $this->header->encode();

    $Vmcylazx3pdy_offset = $this->pos();
    $Veatxxxrhqpk           = $Vmcylazx3pdy_offset + $Vt3phu1t2vwr * $Vu440l53e414;
    $this->seek($Veatxxxrhqpk);

    $V0ixz2v5mxzy = 0;
    foreach ($Vu325ut4svxk as $Vpgjgw4fmq0o) {
      $Vpgjgw4fmq0o->encode($Vmcylazx3pdy_offset + $V0ixz2v5mxzy * $Vu440l53e414);
      $V0ixz2v5mxzy++;
    }
  }

  function parseHeader() {
    if (!empty($this->header)) {
      return;
    }

    $this->seek($this->tableOffset);

    $this->header = new Header($this);
    $this->header->parse();
  }

  function getFontType(){
    $Vwodxpsnnwkf = explode("\\", get_class($this));
    return $Vwodxpsnnwkf[1];
  }

  function parseTableEntries() {
    $this->parseHeader();

    if (!empty($this->directory)) {
      return;
    }

    if (empty($this->header->data["numTables"])) {
      return;
    }


    $Vky1xzjrvbn4 = $this->getFontType();
    $Vrptwe2245zq = "FontLib\\$Vky1xzjrvbn4\\TableDirectoryEntry";

    for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $this->header->data["numTables"]; $V0ixz2v5mxzy++) {
      
      $Vpgjgw4fmq0o = new $Vrptwe2245zq($this);
      $Vpgjgw4fmq0o->parse();

      $this->directory[$Vpgjgw4fmq0o->tag] = $Vpgjgw4fmq0o;
    }
  }

  function normalizeFUnit($Veugw2h43vxz, $Vavgn2zl5gq1 = 1000) {
    return round($Veugw2h43vxz * ($Vavgn2zl5gq1 / $this->getData("head", "unitsPerEm")));
  }

  protected function readTable($Vgvunyxfpvcq) {
    $this->parseTableEntries();

    if (!self::$Vod2vbre0iqs) {
      $Vu440l53e414ame_canon = preg_replace("/[^a-z0-9]/", "", strtolower($Vgvunyxfpvcq));

      $Vrptwe2245zq = "FontLib\\Table\\Type\\$Vu440l53e414ame_canon";

      if (!isset($this->directory[$Vgvunyxfpvcq]) || !@class_exists($Vrptwe2245zq)) {
        return;
      }
    }
    else {
      $Vrptwe2245zq = "FontLib\\Table\\Table";
    }

    
    $Vp5rpvpxnb43 = new $Vrptwe2245zq($this->directory[$Vgvunyxfpvcq]);
    $Vp5rpvpxnb43->parse();

    $this->data[$Vgvunyxfpvcq] = $Vp5rpvpxnb43;
  }

  
  public function getTableObject($Vu440l53e414ame) {
    return $this->data[$Vu440l53e414ame];
  }

  public function setTableObject($Vu440l53e414ame, Table $V3o5lzcfvwzz) {
    $this->data[$Vu440l53e414ame] = $V3o5lzcfvwzz;
  }

  public function getData($Vu440l53e414ame, $Vbd2mxirzq2d = null) {
    $this->parseTableEntries();

    if (empty($this->data[$Vu440l53e414ame])) {
      $this->readTable($Vu440l53e414ame);
    }

    if (!isset($this->data[$Vu440l53e414ame])) {
      return null;
    }

    if (!$Vbd2mxirzq2d) {
      return $this->data[$Vu440l53e414ame]->data;
    }
    else {
      return $this->data[$Vu440l53e414ame]->data[$Vbd2mxirzq2d];
    }
  }

  function addDirectoryEntry(DirectoryEntry $Vpgjgw4fmq0o) {
    $this->directory[$Vpgjgw4fmq0o->tag] = $Vpgjgw4fmq0o;
  }

  function saveAdobeFontMetrics($Voheucoc3jxv, $Vpxiihrwof30 = null) {
    $Vougvkmrdlgv = new AdobeFontMetrics($this);
    $Vougvkmrdlgv->write($Voheucoc3jxv, $Vpxiihrwof30);
  }

  
  function getNameTableString($Vu440l53e414ameID) {
    
    $Vbmma234ka01 = $this->getData("name", "records");

    if (!isset($Vbmma234ka01[$Vu440l53e414ameID])) {
      return null;
    }

    return $Vbmma234ka01[$Vu440l53e414ameID]->string;
  }

  
  function getFontCopyright() {
    return $this->getNameTableString(name::NAME_COPYRIGHT);
  }

  
  function getFontName() {
    return $this->getNameTableString(name::NAME_NAME);
  }

  
  function getFontSubfamily() {
    return $this->getNameTableString(name::NAME_SUBFAMILY);
  }

  
  function getFontSubfamilyID() {
    return $this->getNameTableString(name::NAME_SUBFAMILY_ID);
  }

  
  function getFontFullName() {
    return $this->getNameTableString(name::NAME_FULL_NAME);
  }

  
  function getFontVersion() {
    return $this->getNameTableString(name::NAME_VERSION);
  }

  
  function getFontWeight() {
    return $this->getTableObject("OS/2")->data["usWeightClass"];
  }

  
  function getFontPostscriptName() {
    return $this->getNameTableString(name::NAME_POSTSCRIPT_NAME);
  }

  function reduce() {
    $Vu440l53e414ames_to_keep = array(
      name::NAME_COPYRIGHT,
      name::NAME_NAME,
      name::NAME_SUBFAMILY,
      name::NAME_SUBFAMILY_ID,
      name::NAME_FULL_NAME,
      name::NAME_VERSION,
      name::NAME_POSTSCRIPT_NAME,
    );

    foreach ($this->data["name"]->data["records"] as $V0ixz2v5mxzyd => $V2c5wnac1lry) {
      if (!in_array($V0ixz2v5mxzyd, $Vu440l53e414ames_to_keep)) {
        unset($this->data["name"]->data["records"][$V0ixz2v5mxzyd]);
      }
    }
  }
}
