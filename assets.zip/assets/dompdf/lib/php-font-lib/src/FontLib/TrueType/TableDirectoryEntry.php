<?php


namespace FontLib\TrueType;

use FontLib\Table\DirectoryEntry;


class TableDirectoryEntry extends DirectoryEntry {
  function __construct(File $Vfsinbbqzbga) {
    parent::__construct($Vfsinbbqzbga);
  }

  function parse() {
    parent::parse();

    $Vfsinbbqzbga           = $this->font;
    $this->checksum = $Vfsinbbqzbga->readUInt32();
    $this->offset   = $Vfsinbbqzbga->readUInt32();
    $this->length   = $Vfsinbbqzbga->readUInt32();
    $this->entryLength += 12;
  }
}

