<?php


namespace FontLib\Table\Type;
use FontLib\Table\Table;


class hmtx extends Table {
  protected function _parse() {
    $Vfsinbbqzbga   = $this->getFont();
    $Veatxxxrhqpk = $Vfsinbbqzbga->pos();

    $Vfqyn1v0vnl4 = $Vfsinbbqzbga->getData("hhea", "numOfLongHorMetrics");
    $Vhkgus5skleu           = $Vfsinbbqzbga->getData("maxp", "numGlyphs");

    $Vfsinbbqzbga->seek($Veatxxxrhqpk);

    $V3o5lzcfvwzz = array();
    $V3vxwpvspqfh = $Vfsinbbqzbga->readUInt16Many($Vfqyn1v0vnl4 * 2);
    for ($V2hwvubg2icz = 0, $V11xvcx2tqrj = 0; $V2hwvubg2icz < $Vfqyn1v0vnl4; $V2hwvubg2icz++) {
      $Vpw25gci3yhr    = isset($V3vxwpvspqfh[$V11xvcx2tqrj]) ? $V3vxwpvspqfh[$V11xvcx2tqrj] : 0;
      $V11xvcx2tqrj += 1;
      $Vcykcq54yptr = isset($V3vxwpvspqfh[$V11xvcx2tqrj]) ? $V3vxwpvspqfh[$V11xvcx2tqrj] : 0;
      $V11xvcx2tqrj += 1;
      $V3o5lzcfvwzz[$V2hwvubg2icz]      = array($Vpw25gci3yhr, $Vcykcq54yptr);
    }

    if ($Vfqyn1v0vnl4 < $Vhkgus5skleu) {
      $Vieiejbbhkk1 = end($V3o5lzcfvwzz);
      $V3o5lzcfvwzz      = array_pad($V3o5lzcfvwzz, $Vhkgus5skleu, $Vieiejbbhkk1);
    }

    $this->data = $V3o5lzcfvwzz;
  }

  protected function _encode() {
    $Vfsinbbqzbga   = $this->getFont();
    $Vc2pexddbgmh = $Vfsinbbqzbga->getSubset();
    $V3o5lzcfvwzz   = $this->data;

    $Vyfoeno5vtuw = 0;

    foreach ($Vc2pexddbgmh as $V2hwvubg2icz) {
      $Vyfoeno5vtuw += $Vfsinbbqzbga->writeUInt16($V3o5lzcfvwzz[$V2hwvubg2icz][0]);
      $Vyfoeno5vtuw += $Vfsinbbqzbga->writeUInt16($V3o5lzcfvwzz[$V2hwvubg2icz][1]);
    }

    return $Vyfoeno5vtuw;
  }
}
