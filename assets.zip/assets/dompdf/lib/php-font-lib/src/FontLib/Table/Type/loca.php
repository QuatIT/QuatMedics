<?php


namespace FontLib\Table\Type;
use FontLib\Table\Table;


class loca extends Table {
  protected function _parse() {
    $Vfsinbbqzbga   = $this->getFont();
    $Veatxxxrhqpk = $Vfsinbbqzbga->pos();

    $Voyglc4mcmcw = $Vfsinbbqzbga->getData("head", "indexToLocFormat");
    $Vhkgus5skleu        = $Vfsinbbqzbga->getData("maxp", "numGlyphs");

    $Vfsinbbqzbga->seek($Veatxxxrhqpk);

    $V3o5lzcfvwzz = array();

    
    if ($Voyglc4mcmcw == 0) {
      $Vngrhfhlmiyg   = $Vfsinbbqzbga->read(($Vhkgus5skleu + 1) * 2);
      $V0ju4qj3x3d3 = unpack("n*", $Vngrhfhlmiyg);

      for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy <= $Vhkgus5skleu; $V0ixz2v5mxzy++) {
        $V3o5lzcfvwzz[] = isset($V0ju4qj3x3d3[$V0ixz2v5mxzy + 1]) ?  $V0ju4qj3x3d3[$V0ixz2v5mxzy + 1] * 2 : 0;
      }
    }

    
    else {
      if ($Voyglc4mcmcw == 1) {
        $Vngrhfhlmiyg   = $Vfsinbbqzbga->read(($Vhkgus5skleu + 1) * 4);
        $V0ju4qj3x3d3 = unpack("N*", $Vngrhfhlmiyg);

        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy <= $Vhkgus5skleu; $V0ixz2v5mxzy++) {
          $V3o5lzcfvwzz[] = isset($V0ju4qj3x3d3[$V0ixz2v5mxzy + 1]) ? $V0ju4qj3x3d3[$V0ixz2v5mxzy + 1] : 0;
        }
      }
    }

    $this->data = $V3o5lzcfvwzz;
  }

  function _encode() {
    $Vfsinbbqzbga = $this->getFont();
    $V3o5lzcfvwzz = $this->data;

    $Voyglc4mcmcw = $Vfsinbbqzbga->getData("head", "indexToLocFormat");
    $Vhkgus5skleu        = $Vfsinbbqzbga->getData("maxp", "numGlyphs");
    $Vyfoeno5vtuw           = 0;

    
    if ($Voyglc4mcmcw == 0) {
      for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy <= $Vhkgus5skleu; $V0ixz2v5mxzy++) {
        $Vyfoeno5vtuw += $Vfsinbbqzbga->writeUInt16($V3o5lzcfvwzz[$V0ixz2v5mxzy] / 2);
      }
    }

    
    else {
      if ($Voyglc4mcmcw == 1) {
        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy <= $Vhkgus5skleu; $V0ixz2v5mxzy++) {
          $Vyfoeno5vtuw += $Vfsinbbqzbga->writeUInt32($V3o5lzcfvwzz[$V0ixz2v5mxzy]);
        }
      }
    }

    return $Vyfoeno5vtuw;
  }
}
