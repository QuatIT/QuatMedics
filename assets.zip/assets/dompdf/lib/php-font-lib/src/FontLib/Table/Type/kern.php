<?php


namespace FontLib\Table\Type;
use FontLib\Table\Table;


class kern extends Table {
  protected function _parse() {
    $Vfsinbbqzbga = $this->getFont();

    $V3o5lzcfvwzz = $Vfsinbbqzbga->unpack(array(
      "version"         => self::uint16,
      "nTables"         => self::uint16,

      
      "subtableVersion" => self::uint16,
      "length"          => self::uint16,
      "coverage"        => self::uint16,
    ));

    $V3o5lzcfvwzz["format"] = ($V3o5lzcfvwzz["coverage"] >> 8);

    $Vxd4s5gofbp5 = array();

    switch ($V3o5lzcfvwzz["format"]) {
      case 0:
        $Vxd4s5gofbp5 = $Vfsinbbqzbga->unpack(array(
          "nPairs"        => self::uint16,
          "searchRange"   => self::uint16,
          "entrySelector" => self::uint16,
          "rangeShift"    => self::uint16,
        ));

        $Vfwgpwcye1sn = array();
        $Vq4fqdfuymzg  = array();

        $Vtb2d1vzec35 = $Vfsinbbqzbga->readUInt16Many($Vxd4s5gofbp5["nPairs"] * 3);
        for ($V0ixz2v5mxzy = 0, $V0ixz2v5mxzydx = 0; $V0ixz2v5mxzy < $Vxd4s5gofbp5["nPairs"]; $V0ixz2v5mxzy++) {
          $Vb5dthqtenbv  = $Vtb2d1vzec35[$V0ixz2v5mxzydx++];
          $Vqswkdbtte35 = $Vtb2d1vzec35[$V0ixz2v5mxzydx++];
          $Veugw2h43vxz = $Vtb2d1vzec35[$V0ixz2v5mxzydx++];

          if ($Veugw2h43vxz >= 0x8000) {
            $Veugw2h43vxz -= 0x10000;
          }

          $Vfwgpwcye1sn[] = array(
            "left"  => $Vb5dthqtenbv,
            "right" => $Vqswkdbtte35,
            "value" => $Veugw2h43vxz,
          );

          $Vq4fqdfuymzg[$Vb5dthqtenbv][$Vqswkdbtte35] = $Veugw2h43vxz;
        }

        
        $Vxd4s5gofbp5["tree"] = $Vq4fqdfuymzg;
        break;

      case 1:
      case 2:
      case 3:
        break;
    }

    $V3o5lzcfvwzz["subtable"] = $Vxd4s5gofbp5;

    $this->data = $V3o5lzcfvwzz;
  }
}
