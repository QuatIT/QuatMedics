<?php

namespace FontLib\Table\Type;

use FontLib\Font;
use FontLib\BinaryStream;


class nameRecord extends BinaryStream {
  public $V01jyzttjfoy;
  public $Vq4i3qww5x3u;
  public $V3qhbscq2mok;
  public $Vebc2hifsmgo;
  public $Vyfoeno5vtuw;
  public $Veatxxxrhqpk;
  public $Vo3pamb05rqg;

  public static $Vqidphaqys5l = array(
    "platformID"         => self::uint16,
    "platformSpecificID" => self::uint16,
    "languageID"         => self::uint16,
    "nameID"             => self::uint16,
    "length"             => self::uint16,
    "offset"             => self::uint16,
  );

  public function map($V3o5lzcfvwzz) {
    foreach ($V3o5lzcfvwzz as $Vbd2mxirzq2d => $Veugw2h43vxz) {
      $this->$Vbd2mxirzq2d = $Veugw2h43vxz;
    }
  }

  public function getUTF8() {
    return $this->string;
  }

  public function getUTF16() {
    return Font::UTF8ToUTF16($this->string);
  }

  function __toString() {
    return $this->string;
  }
}
