<?php


namespace FontLib\Table\Type;

use FontLib\Table\Table;
use FontLib\Font;


class name extends Table {
  private static $Vljzywdwvbiz = array(
    "format"       => self::uint16,
    "count"        => self::uint16,
    "stringOffset" => self::uint16,
  );

  const NAME_COPYRIGHT          = 0;
  const NAME_NAME               = 1;
  const NAME_SUBFAMILY          = 2;
  const NAME_SUBFAMILY_ID       = 3;
  const NAME_FULL_NAME          = 4;
  const NAME_VERSION            = 5;
  const NAME_POSTSCRIPT_NAME    = 6;
  const NAME_TRADEMARK          = 7;
  const NAME_MANUFACTURER       = 8;
  const NAME_DESIGNER           = 9;
  const NAME_DESCRIPTION        = 10;
  const NAME_VENDOR_URL         = 11;
  const NAME_DESIGNER_URL       = 12;
  const NAME_LICENSE            = 13;
  const NAME_LICENSE_URL        = 14;
  const NAME_PREFERRE_FAMILY    = 16;
  const NAME_PREFERRE_SUBFAMILY = 17;
  const NAME_COMPAT_FULL_NAME   = 18;
  const NAME_SAMPLE_TEXT        = 19;

  static $Vcpi3ahpl5sc = array(
    0  => "Copyright",
    1  => "FontName",
    2  => "FontSubfamily",
    3  => "UniqueID",
    4  => "FullName",
    5  => "Version",
    6  => "PostScriptName",
    7  => "Trademark",
    8  => "Manufacturer",
    9  => "Designer",
    10 => "Description",
    11 => "FontVendorURL",
    12 => "FontDesignerURL",
    13 => "LicenseDescription",
    14 => "LicenseURL",
    
    16 => "PreferredFamily",
    17 => "PreferredSubfamily",
    18 => "CompatibleFullName",
    19 => "SampleText",
  );

  static $Vxyts1ayvfe1 = array(
    0 => "Unicode",
    1 => "Macintosh",
    
    3 => "Microsoft",
  );

  static $Vkfc0vbtrhcx = array(
    
    0 => array(
      0 => "Default semantics",
      1 => "Version 1.1 semantics",
      2 => "ISO 10646 1993 semantics (deprecated)",
      3 => "Unicode 2.0 or later semantics",
    ),

    
    1 => array(
      0  => "Roman",
      1  => "Japanese",
      2  => "Traditional Chinese",
      3  => "Korean",
      4  => "Arabic",
      5  => "Hebrew",
      6  => "Greek",
      7  => "Russian",
      8  => "RSymbol",
      9  => "Devanagari",
      10 => "Gurmukhi",
      11 => "Gujarati",
      12 => "Oriya",
      13 => "Bengali",
      14 => "Tamil",
      15 => "Telugu",
      16 => "Kannada",
      17 => "Malayalam",
      18 => "Sinhalese",
      19 => "Burmese",
      20 => "Khmer",
      21 => "Thai",
      22 => "Laotian",
      23 => "Georgian",
      24 => "Armenian",
      25 => "Simplified Chinese",
      26 => "Tibetan",
      27 => "Mongolian",
      28 => "Geez",
      29 => "Slavic",
      30 => "Vietnamese",
      31 => "Sindhi",
    ),

    
    3 => array(
      0  => "Symbol",
      1  => "Unicode BMP (UCS-2)",
      2  => "ShiftJIS",
      3  => "PRC",
      4  => "Big5",
      5  => "Wansung",
      6  => "Johab",
      
      
      
      10 => "Unicode UCS-4",
    ),
  );

  protected function _parse() {
    $Vfsinbbqzbga = $this->getFont();

    $Vg45gdv2kmyx = $Vfsinbbqzbga->pos();

    $V3o5lzcfvwzz = $Vfsinbbqzbga->unpack(self::$Vljzywdwvbiz);

    $Vbmma234ka01 = array();
    for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $V3o5lzcfvwzz["count"]; $V0ixz2v5mxzy++) {
      $V2rc5jfhove3      = new nameRecord();
      $V2rc5jfhove3_data = $Vfsinbbqzbga->unpack(nameRecord::$Vqidphaqys5l);
      $V2rc5jfhove3->map($V2rc5jfhove3_data);

      $Vbmma234ka01[] = $V2rc5jfhove3;
    }

    $Vojo5cktcmvh = array();
    foreach ($Vbmma234ka01 as $V2rc5jfhove3) {
      $Vfsinbbqzbga->seek($Vg45gdv2kmyx + $V3o5lzcfvwzz["stringOffset"] + $V2rc5jfhove3->offset);
      $V500t5q0ulgs                      = $Vfsinbbqzbga->read($V2rc5jfhove3->length);
      $V2rc5jfhove3->string         = Font::UTF16ToUTF8($V500t5q0ulgs);
      $Vojo5cktcmvh[$V2rc5jfhove3->nameID] = $V2rc5jfhove3;
    }

    $V3o5lzcfvwzz["records"] = $Vojo5cktcmvh;

    $this->data = $V3o5lzcfvwzz;
  }

  protected function _encode() {
    $Vfsinbbqzbga = $this->getFont();

    
    $Vbmma234ka01       = $this->data["records"];
    $Vzeiukh2imex = count($Vbmma234ka01);

    $this->data["count"]        = $Vzeiukh2imex;
    $this->data["stringOffset"] = 6 + $Vzeiukh2imex * 12; 

    $Vyfoeno5vtuw = $Vfsinbbqzbga->pack(self::$Vljzywdwvbiz, $this->data);

    $Veatxxxrhqpk = 0;
    foreach ($Vbmma234ka01 as $V2rc5jfhove3) {
      $V2rc5jfhove3->length = mb_strlen($V2rc5jfhove3->getUTF16(), "8bit");
      $V2rc5jfhove3->offset = $Veatxxxrhqpk;
      $Veatxxxrhqpk += $V2rc5jfhove3->length;
      $Vyfoeno5vtuw += $Vfsinbbqzbga->pack(nameRecord::$Vqidphaqys5l, (array)$V2rc5jfhove3);
    }

    foreach ($Vbmma234ka01 as $V2rc5jfhove3) {
      $V500t5q0ulgstr = $V2rc5jfhove3->getUTF16();
      $Vyfoeno5vtuw += $Vfsinbbqzbga->write($V500t5q0ulgstr, mb_strlen($V500t5q0ulgstr, "8bit"));
    }

    return $Vyfoeno5vtuw;
  }
}
