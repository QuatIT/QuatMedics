<?php


namespace FontLib\WOFF;

use FontLib\Table\DirectoryEntry;


class File extends \FontLib\TrueType\File {
  function parseHeader() {
    if (!empty($this->header)) {
      return;
    }

    $this->header = new Header($this);
    $this->header->parse();
  }

  public function load($Voheucoc3jxv) {
    parent::load($Voheucoc3jxv);

    $this->parseTableEntries();
    $Vhz3b34ny01k = $this->pos() + count($this->directory) * 20;

    $Vmopc1z0a5sz = $this->getTempFile(false);
    $Vyazvf24pfrd = $this->f;

    $this->f = $Vmopc1z0a5sz;
    $Veatxxxrhqpk  = $this->header->encode();

    foreach ($this->directory as $Vpgjgw4fmq0o) {
      
      $this->f = $Vyazvf24pfrd;
      $this->seek($Vpgjgw4fmq0o->offset);
      $V3o5lzcfvwzz = $this->read($Vpgjgw4fmq0o->length);

      if ($Vpgjgw4fmq0o->length < $Vpgjgw4fmq0o->origLength) {
        $V3o5lzcfvwzz = gzuncompress($V3o5lzcfvwzz);
      }

      
      $Vyfoeno5vtuw        = strlen($V3o5lzcfvwzz);
      $Vpgjgw4fmq0o->length = $Vpgjgw4fmq0o->origLength = $Vyfoeno5vtuw;
      $Vpgjgw4fmq0o->offset = $Vhz3b34ny01k;

      
      $this->f = $Vmopc1z0a5sz;

      
      $this->seek($Veatxxxrhqpk);
      $Veatxxxrhqpk += $this->write($Vpgjgw4fmq0o->tag, 4); 
      $Veatxxxrhqpk += $this->writeUInt32($Vhz3b34ny01k); 
      $Veatxxxrhqpk += $this->writeUInt32($Vyfoeno5vtuw); 
      $Veatxxxrhqpk += $this->writeUInt32($Vyfoeno5vtuw); 
      $Veatxxxrhqpk += $this->writeUInt32(DirectoryEntry::computeChecksum($V3o5lzcfvwzz)); 

      
      $this->seek($Vhz3b34ny01k);
      $Vhz3b34ny01k += $this->write($V3o5lzcfvwzz, $Vyfoeno5vtuw);
    }

    $this->f = $Vmopc1z0a5sz;
    $this->seek(0);

    
    $this->header    = null;
    $this->directory = array();
    $this->parseTableEntries();
  }
}
