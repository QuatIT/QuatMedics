<?php


namespace FontLib\WOFF;

use FontLib\Table\DirectoryEntry;


class TableDirectoryEntry extends DirectoryEntry {
  public $Vxsl113z1uav;

  function __construct(File $Vfsinbbqzbga) {
    parent::__construct($Vfsinbbqzbga);
  }

  function parse() {
    parent::parse();

    $Vfsinbbqzbga             = $this->font;
    $this->offset     = $Vfsinbbqzbga->readUInt32();
    $this->length     = $Vfsinbbqzbga->readUInt32();
    $this->origLength = $Vfsinbbqzbga->readUInt32();
    $this->checksum   = $Vfsinbbqzbga->readUInt32();
  }
}
