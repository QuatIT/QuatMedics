<?php


spl_autoload_register(function($Vrptwe2245zq) {
  if (0 === strpos($Vrptwe2245zq, "Svg")) {
    $Voheucoc3jxv = str_replace('\\', DIRECTORY_SEPARATOR, $Vrptwe2245zq);
    $Voheucoc3jxv = realpath(__DIR__ . DIRECTORY_SEPARATOR . $Voheucoc3jxv . '.php');
    if (file_exists($Voheucoc3jxv)) {
      include_once $Voheucoc3jxv;
    }
  }
});
