<?php


namespace Svg;

class DefaultStyle extends Style
{
    public $V3poxlnogtlh = '';
    public $Vhrfbgup2xix = 1.0;
    public $Vqzifj31psr1 = 'inline';

    public $Vbopclc0ksnj = 'black';
    public $Vbopclc0ksnjOpacity = 1.0;
    public $Vbopclc0ksnjRule = 'nonzero';

    public $Vleb2mixglzb = 'none';
    public $Vleb2mixglzbOpacity = 1.0;
    public $Vleb2mixglzbLinecap = 'butt';
    public $Vleb2mixglzbLinejoin = 'miter';
    public $Vleb2mixglzbMiterlimit = 4;
    public $Vleb2mixglzbWidth = 1.0;
    public $Vleb2mixglzbDasharray = 0;
    public $Vleb2mixglzbDashoffset = 0;
}
