<?php


namespace Svg\Surface;

use Svg\Style;
use Svg\Document;

class SurfacePDFLib implements SurfaceInterface
{
    const DEBUG = false;

    private $Vecmn4cx3vag;

    private $Vtt4kvdwuqqh;
    private $Vxtfrabd3i5r;

    
    private $Vkvw5zjrwkdm;

    public function __construct(Document $Vn53dg3q25ot, $Vecmn4cx3vag = null)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $Vhcmoq1fgvta = $Vn53dg3q25ot->getDimensions();
        $V5ymvwogwh5y = $Vhcmoq1fgvta["width"];
        $V2pgp3ppbjsi = $Vhcmoq1fgvta["height"];

        if (!$Vecmn4cx3vag) {
            $Vecmn4cx3vag = new \PDFlib();

            
            $Vecmn4cx3vag->set_option("stringformat=utf8");
            $Vecmn4cx3vag->set_option("errorpolicy=return");

            
            if ($Vecmn4cx3vag->begin_document("", "") == 0) {
                die("Error: " . $Vecmn4cx3vag->get_errmsg());
            }
            $Vecmn4cx3vag->set_info("Creator", "PDFlib starter sample");
            $Vecmn4cx3vag->set_info("Title", "starter_graphics");

            $Vecmn4cx3vag->begin_page_ext($V5ymvwogwh5y, $V2pgp3ppbjsi, "");
        }

        
        
        $Vecmn4cx3vag->setmatrix(
            1, 0,
            0, -1,
            0, $V2pgp3ppbjsi
        );

        $this->width  = $V5ymvwogwh5y;
        $this->height = $V2pgp3ppbjsi;

        $this->canvas = $Vecmn4cx3vag;
    }

    function out()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $this->canvas->end_page_ext("");
        $this->canvas->end_document("");

        return $this->canvas->get_buffer();
    }

    public function save()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->save();
    }

    public function restore()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->restore();
    }

    public function scale($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->scale($Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function rotate($Vvb4ibm25tpf)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->rotate($Vvb4ibm25tpf);
    }

    public function translate($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->translate($Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function transform($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->concat($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1);
    }

    public function beginPath()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        
    }

    public function closePath()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->closepath();
    }

    public function fillStroke()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->fill_stroke();
    }

    public function clip()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->clip();
    }

    public function fillText($Vnjapcj4bkpc, $Vmm2pe5l4str, $Vuua0v2znlr5, $Voqn2ztf5uzl = null)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->set_text_pos($Vmm2pe5l4str, $Vuua0v2znlr5);
        $this->canvas->show($Vnjapcj4bkpc);
    }

    public function strokeText($Vnjapcj4bkpc, $Vmm2pe5l4str, $Vuua0v2znlr5, $Voqn2ztf5uzl = null)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        
    }

    public function drawImage($Vsc2xappb1ws, $V30sf4kzdv2b, $Vgd1odlz3me2, $Vzpffdqrlqug = null, $V42oss4ur1nw = null, $Vngrhfhlmiygx = null, $Vngrhfhlmiygy = null, $Vngrhfhlmiygw = null, $Vngrhfhlmiygh = null)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        if (strpos($Vsc2xappb1ws, "data:") === 0) {
            $Vngrhfhlmiygata = substr($Vsc2xappb1ws, strpos($Vsc2xappb1ws, ";") + 1);
            if (strpos($Vngrhfhlmiygata, "base64") === 0) {
                $Vngrhfhlmiygata = base64_decode(substr($Vngrhfhlmiygata, 7));
            }
        }
        else {
            $Vngrhfhlmiygata = file_get_contents($Vsc2xappb1ws);
        }

        $Vsc2xappb1ws = tempnam("", "svg");
        file_put_contents($Vsc2xappb1ws, $Vngrhfhlmiygata);

        $Vz1jukgekuy3 = $this->canvas->load_image("auto", $Vsc2xappb1ws, "");

        $Vgd1odlz3me2 = $Vgd1odlz3me2 - $V42oss4ur1nw;
        $this->canvas->fit_image($Vz1jukgekuy3, $V30sf4kzdv2b, $Vgd1odlz3me2, 'boxsize={' . "$Vzpffdqrlqug $V42oss4ur1nw" . '} fitmethod=entire');

        unlink($Vsc2xappb1ws);
    }

    public function lineTo($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->lineto($Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function moveTo($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->moveto($Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function quadraticCurveTo($Vdiqkcy1hsm4px, $Vdiqkcy1hsm4py, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        
        $this->canvas->curveTo($Vdiqkcy1hsm4px, $Vdiqkcy1hsm4py, $Vdiqkcy1hsm4px, $Vdiqkcy1hsm4py, $Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function bezierCurveTo($Vdiqkcy1hsm4p1x, $Vdiqkcy1hsm4p1y, $Vdiqkcy1hsm4p2x, $Vdiqkcy1hsm4p2y, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->curveto($Vdiqkcy1hsm4p1x, $Vdiqkcy1hsm4p1y, $Vdiqkcy1hsm4p2x, $Vdiqkcy1hsm4p2y, $Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function arcTo($Vmm2pe5l4str1, $Vuua0v2znlr51, $Vmm2pe5l4str2, $Vuua0v2znlr52, $Vc4ozih12zue)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
    }

    public function arc($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue, $Vm3t2pidpc0a, $VqfltxpxjekkndAngle, $V4dkbhpdu11qnticlockwise = false)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->arc($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue, $Vm3t2pidpc0a, $VqfltxpxjekkndAngle);
    }

    public function circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue);
    }

    public function ellipse($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zueX, $Vc4ozih12zueY, $Vzq3npyo4slb, $Vm3t2pidpc0a, $VqfltxpxjekkndAngle, $V4dkbhpdu11qnticlockwise)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->ellipse($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zueX, $Vc4ozih12zueY);
    }

    public function fillRect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->rect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        $this->fill();
    }

    public function rect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Ved15tbp0gam = 0, $Vud2tyg4u1vh = 0)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $Vecmn4cx3vag = $this->canvas;

        if ($Ved15tbp0gam <= 0.000001) {
            $Vecmn4cx3vag->rect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);

            return;
        }

        
        $Vecmn4cx3vag->moveto($Vmm2pe5l4str + $Ved15tbp0gam, $Vuua0v2znlr5);

        
        $Vecmn4cx3vag->lineto($Vmm2pe5l4str + $V5ymvwogwh5y - $Ved15tbp0gam, $Vuua0v2znlr5);

        
        $Vecmn4cx3vag->arc($Vmm2pe5l4str + $V5ymvwogwh5y - $Ved15tbp0gam, $Vuua0v2znlr5 + $Ved15tbp0gam, $Ved15tbp0gam, 270, 360);

        
        $Vecmn4cx3vag->lineto($Vmm2pe5l4str + $V5ymvwogwh5y, $Vuua0v2znlr5 + $V2pgp3ppbjsi - $Ved15tbp0gam );

        
        $Vecmn4cx3vag->arc($Vmm2pe5l4str + $V5ymvwogwh5y - $Ved15tbp0gam, $Vuua0v2znlr5 + $V2pgp3ppbjsi - $Ved15tbp0gam, $Ved15tbp0gam, 0, 90);

        
        $Vecmn4cx3vag->lineto($Vmm2pe5l4str + $Ved15tbp0gam, $Vuua0v2znlr5 + $V2pgp3ppbjsi);

        
        $Vecmn4cx3vag->arc($Vmm2pe5l4str + $Ved15tbp0gam, $Vuua0v2znlr5 + $V2pgp3ppbjsi - $Ved15tbp0gam, $Ved15tbp0gam, 90, 180);

        
        $Vecmn4cx3vag->lineto($Vmm2pe5l4str , $Vuua0v2znlr5 + $Ved15tbp0gam);

        
        $Vecmn4cx3vag->arc($Vmm2pe5l4str + $Ved15tbp0gam, $Vuua0v2znlr5 + $Ved15tbp0gam, $Ved15tbp0gam, 180, 270);
    }

    public function fill()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->fill();
    }

    public function strokeRect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->rect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        $this->stroke();
    }

    public function stroke()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->stroke();
    }

    public function endPath()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->endPath();
    }

    public function measureText($Vnjapcj4bkpc)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $Vkvw5zjrwkdm = $this->getStyle();
        $Vtmlsxxw3ne1ont = $this->getFont($Vkvw5zjrwkdm->fontFamily, $Vkvw5zjrwkdm->fontStyle);

        return $this->canvas->stringwidth($Vnjapcj4bkpc, $Vtmlsxxw3ne1ont, $this->getStyle()->fontSize);
    }

    public function getStyle()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        return $this->style;
    }

    public function setStyle(Style $Vkvw5zjrwkdm)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $this->style = $Vkvw5zjrwkdm;
        $Vecmn4cx3vag = $this->canvas;

        if ($Vleb2mixglzb = $Vkvw5zjrwkdm->stroke && is_array($Vkvw5zjrwkdm->stroke)) {
            $Vecmn4cx3vag->setcolor(
                "stroke",
                "rgb",
                $Vleb2mixglzb[0] / 255,
                $Vleb2mixglzb[1] / 255,
                $Vleb2mixglzb[2] / 255,
                null
            );
        }

        if ($Vtmlsxxw3ne1ill = $Vkvw5zjrwkdm->fill && is_array($Vkvw5zjrwkdm->fill)) {
            $Vecmn4cx3vag->setcolor(
                "fill",
                "rgb",
                $Vtmlsxxw3ne1ill[0] / 255,
                $Vtmlsxxw3ne1ill[1] / 255,
                $Vtmlsxxw3ne1ill[2] / 255,
                null
            );
        }

        if ($Vtmlsxxw3ne1illRule = strtolower($Vkvw5zjrwkdm->fillRule)) {
            $Vgxq50e2jnhe = array(
                "nonzero" => "winding",
                "evenodd" => "evenodd",
            );

            if (isset($Vgxq50e2jnhe[$Vtmlsxxw3ne1illRule])) {
                $Vtmlsxxw3ne1illRule = $Vgxq50e2jnhe[$Vtmlsxxw3ne1illRule];

                $Vecmn4cx3vag->set_parameter("fillrule", $Vtmlsxxw3ne1illRule);
            }
        }

        $Vse510aojg05 = array();
        if ($Vkvw5zjrwkdm->strokeWidth > 0.000001) {
            $Vse510aojg05[] = "linewidth=$Vkvw5zjrwkdm->strokeWidth";
        }

        if (in_array($Vkvw5zjrwkdm->strokeLinecap, array("butt", "round", "projecting"))) {
            $Vse510aojg05[] = "linecap=$Vkvw5zjrwkdm->strokeLinecap";
        }

        if (in_array($Vkvw5zjrwkdm->strokeLinejoin, array("miter", "round", "bevel"))) {
            $Vse510aojg05[] = "linejoin=$Vkvw5zjrwkdm->strokeLinejoin";
        }

        $Vecmn4cx3vag->set_graphics_option(implode(" ", $Vse510aojg05));

        $Vse510aojg05 = array();
        $Vhrfbgup2xix = $Vkvw5zjrwkdm->opacity;
        if ($Vhrfbgup2xix !== null && $Vhrfbgup2xix < 1.0) {
            $Vse510aojg05[] = "opacityfill=$Vhrfbgup2xix";
            $Vse510aojg05[] = "opacitystroke=$Vhrfbgup2xix";
        }
        else {
            $Vtmlsxxw3ne1illOpacity = $Vkvw5zjrwkdm->fillOpacity;
            if ($Vtmlsxxw3ne1illOpacity !== null && $Vtmlsxxw3ne1illOpacity < 1.0) {
                $Vse510aojg05[] = "opacityfill=$Vtmlsxxw3ne1illOpacity";
            }

            $Vleb2mixglzbOpacity = $Vkvw5zjrwkdm->strokeOpacity;
            if ($Vleb2mixglzbOpacity !== null && $Vleb2mixglzbOpacity < 1.0) {
                $Vse510aojg05[] = "opacitystroke=$Vleb2mixglzbOpacity";
            }
        }

        if (count($Vse510aojg05)) {
            $Vhancmmiv50o = $Vecmn4cx3vag->create_gstate(implode(" ", $Vse510aojg05));
            $Vecmn4cx3vag->set_gstate($Vhancmmiv50o);
        }

        $Vtmlsxxw3ne1ont = $this->getFont($Vkvw5zjrwkdm->fontFamily, $Vkvw5zjrwkdm->fontStyle);
        if ($Vtmlsxxw3ne1ont) {
            $Vecmn4cx3vag->setfont($Vtmlsxxw3ne1ont, $Vkvw5zjrwkdm->fontSize);
        }
    }

    private function getFont($Vtmlsxxw3ne1amily, $Vkvw5zjrwkdm)
    {
        $Vgxq50e2jnhe = array(
            "serif"      => "Times",
            "sans-serif" => "Helvetica",
            "fantasy"    => "Symbol",
            "cursive"    => "Times",
            "monospace"  => "Courier",

            "arial"      => "Helvetica",
            "verdana"    => "Helvetica",
        );

        $Vtmlsxxw3ne1amily = strtolower($Vtmlsxxw3ne1amily);
        if (isset($Vgxq50e2jnhe[$Vtmlsxxw3ne1amily])) {
            $Vtmlsxxw3ne1amily = $Vgxq50e2jnhe[$Vtmlsxxw3ne1amily];
        }

        return $this->canvas->load_font($Vtmlsxxw3ne1amily, "unicode", "fontstyle=$Vkvw5zjrwkdm");
    }

    public function setFont($Vtmlsxxw3ne1amily, $Vkvw5zjrwkdm, $V5ymvwogwh5yeight)
    {
        
    }
}
