<?php


namespace Svg\Surface;

class CPdf
{

    
    public $Vjg5iw1hexg5 = 0;

    
    public $V5lpqn21v1nz = array();

    
    public $Vsnyj4jw51d0;

    
    public $Viv5w5i0mlcf = array();

    
    public $V0et0v2rt5uc = './fonts/Helvetica.afm';

    
    public $Vssclshfgjzn = '';

    
    public $V5girauddhf0 = '';

    
    public $VssclshfgjznNum = 0;

    
    public $Vlokatwykivs;

    
    public $Vcvhqa0xphdo;

    
    public $Vpzy30da1s5y;

    
    public $Vxbrjboyflrb = 0;

    
    private $Vc2m4n1nkiyw = 0;

    
    public $Vhdc5pr0mjvi = null;

    
    public $Vhrrdmbfdnur = "nonzero";

    
    public $Vkfxkrkv4n5m = null;

    
    public $Vm2hq5xc2ncv = '';

    
    public $V3m11iet1smy = array("mode" => "Normal", "opacity" => 1.0);

    
    public $Vedtdl43u4hz = array("mode" => "Normal", "opacity" => 1.0);

    
    public $Vuquinccklp1 = array();

    
    public $Vipyvoamk5zy = 0;

    
    public $Vv0k0ovkeoex = 0;

    
    public $Vo1vhygcjja1 = array();

    
    public $Vflhscnmdp3d = 0;

    
    public $V1zhoupfybrl = array();

    
    public $Vrp0vboswtkf = array();

    
    public $Val2mdtbec4d = 0;

    
    public $Vtcflr0au42g = 0;

    
    public $V3vmzyblbtdy = array('compression' => true);

    
    public $Veiecr5r0bnw;

    
    public $Vb4t3wdrzwyn = 0;

    
    public $Vx4imetagn3p = 0;

    
    public $Vtqzeqfjtpk1;

    
    public $Vwih4dpicimq = array();

    
    public $Vi4nmsrluxec = '';

    
    public $Vi4nmsrluxecVersion = 6;

    
    public $Vj0eqma35tbv = '';

    
    public $Vohgtbtpaop4 = '';

    
    public $Vgi4r0e5fh11 = '';

    
    public $Vxj3lzbohcic = '';

    
    public $Vxj3lzbohcic_objnum = 0;

    
    public $V350ua2kkas4 = '';

    
    public $Vyher1me0ybi = false;

    
    public $Vfnmcqixg25d = '';

    
    public $Vydl3gn01f2j = array();

    
    public $Vstsdoocq40l = 0;

    
    public $Vuzaihcp25cv = array();

    
    public $Vqaiez4ar5cc = '';

    
    public $Voarkb3sr5np = array();

    
    public $Vzfurmqmwpmy = false;

    
    public $V0d5bfbwlmxj = '';

    
    protected $Vz002haaiwbs = false;

    
    protected $Vcvhqa0xphdoSize = array("width" => 0, "height" => 0);

    
    protected $Vqk1fs12lfsq = array();

    
    static protected $Vot44mazdlom = 'iso-8859-1';

    
    static protected $Vjtfix3mp15d = array(
        'courier',
        'courier-bold',
        'courier-oblique',
        'courier-boldoblique',
        'helvetica',
        'helvetica-bold',
        'helvetica-oblique',
        'helvetica-boldoblique',
        'times-roman',
        'times-bold',
        'times-italic',
        'times-bolditalic',
        'symbol',
        'zapfdingbats'
    );

    
    function __construct($Vdwyhv40m15a = array(0, 0, 612, 792), $Vzfurmqmwpmy = false, $Vi4nmsrluxec = '', $Vj0eqma35tbv = '')
    {
        $Vvkqsaecgfirhis->isUnicode = $Vzfurmqmwpmy;
        $Vvkqsaecgfirhis->fontcache = $Vi4nmsrluxec;
        $Vvkqsaecgfirhis->tmp = $Vj0eqma35tbv;
        $Vvkqsaecgfirhis->newDocument($Vdwyhv40m15a);

        $Vvkqsaecgfirhis->compressionReady = function_exists('gzcompress');

        if (in_array('Windows-1252', mb_list_encodings())) {
            self::$Vot44mazdlom = 'Windows-1252';
        }

        
        $Vvkqsaecgfirhis->setFontFamily('init');
        
    }

    

    
    protected function o_destination($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'destination', 'info' => array());
                $Vj0eqma35tbv = '';
                switch ($V3vmzyblbtdy['type']) {
                    case 'XYZ':
                    case 'FitR':
                        $Vj0eqma35tbv = ' ' . $V3vmzyblbtdy['p3'] . $Vj0eqma35tbv;
                    case 'FitH':
                    case 'FitV':
                    case 'FitBH':
                    case 'FitBV':
                        $Vj0eqma35tbv = ' ' . $V3vmzyblbtdy['p1'] . ' ' . $V3vmzyblbtdy['p2'] . $Vj0eqma35tbv;
                    case 'Fit':
                    case 'FitB':
                        $Vj0eqma35tbv = $V3vmzyblbtdy['type'] . $Vj0eqma35tbv;
                        $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['string'] = $Vj0eqma35tbv;
                        $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['page'] = $V3vmzyblbtdy['page'];
                }
                break;

            case 'out':
                $Vj0eqma35tbv = $Vyea2e2tvrvz['info'];
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n" . '[' . $Vj0eqma35tbv['page'] . ' 0 R /' . $Vj0eqma35tbv['string'] . "]\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_viewerPreferences($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'viewerPreferences', 'info' => array());
                break;

            case 'add':
                foreach ($V3vmzyblbtdy as $Vawllmnnfede => $Vfanetclug4s) {
                    switch ($Vawllmnnfede) {
                        case 'HideToolbar':
                        case 'HideMenubar':
                        case 'HideWindowUI':
                        case 'FitWindow':
                        case 'CenterWindow':
                        case 'NonFullScreenPageMode':
                        case 'Direction':
                            $Vyea2e2tvrvz['info'][$Vawllmnnfede] = $Vfanetclug4s;
                            break;
                    }
                }
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< ";
                foreach ($Vyea2e2tvrvz['info'] as $Vawllmnnfede => $Vfanetclug4s) {
                    $Vxux0evl2mvh .= "\n/$Vawllmnnfede $Vfanetclug4s";
                }
                $Vxux0evl2mvh .= "\n>>\n";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_catalog($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'catalog', 'info' => array());
                $Vvkqsaecgfirhis->catalogId = $Vawfntrfsy4f;
                break;

            case 'outlines':
            case 'pages':
            case 'openHere':
            case 'javascript':
                $Vyea2e2tvrvz['info'][$Vxkdu2igbqng] = $V3vmzyblbtdy;
                break;

            case 'viewerPreferences':
                if (!isset($Vyea2e2tvrvz['info']['viewerPreferences'])) {
                    $Vvkqsaecgfirhis->numObj++;
                    $Vvkqsaecgfirhis->o_viewerPreferences($Vvkqsaecgfirhis->numObj, 'new');
                    $Vyea2e2tvrvz['info']['viewerPreferences'] = $Vvkqsaecgfirhis->numObj;
                }

                $Vfanetclug4sp = $Vyea2e2tvrvz['info']['viewerPreferences'];
                $Vvkqsaecgfirhis->o_viewerPreferences($Vfanetclug4sp, 'add', $V3vmzyblbtdy);

                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Catalog";

                foreach ($Vyea2e2tvrvz['info'] as $Vawllmnnfede => $Vfanetclug4s) {
                    switch ($Vawllmnnfede) {
                        case 'outlines':
                            $Vxux0evl2mvh .= "\n/Outlines $Vfanetclug4s 0 R";
                            break;

                        case 'pages':
                            $Vxux0evl2mvh .= "\n/Pages $Vfanetclug4s 0 R";
                            break;

                        case 'viewerPreferences':
                            $Vxux0evl2mvh .= "\n/ViewerPreferences $Vfanetclug4s 0 R";
                            break;

                        case 'openHere':
                            $Vxux0evl2mvh .= "\n/OpenAction $Vfanetclug4s 0 R";
                            break;

                        case 'javascript':
                            $Vxux0evl2mvh .= "\n/Names <</JavaScript $Vfanetclug4s 0 R>>";
                            break;
                    }
                }

                $Vxux0evl2mvh .= " >>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_pages($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'pages', 'info' => array());
                $Vvkqsaecgfirhis->o_catalog($Vvkqsaecgfirhis->catalogId, 'pages', $Vawfntrfsy4f);
                break;

            case 'page':
                if (!is_array($V3vmzyblbtdy)) {
                    
                    $Vyea2e2tvrvz['info']['pages'][] = $V3vmzyblbtdy;
                } else {
                    
                    
                    if (isset($V3vmzyblbtdy['id']) && isset($V3vmzyblbtdy['rid']) && isset($V3vmzyblbtdy['pos'])) {
                        $V0ixz2v5mxzy = array_search($V3vmzyblbtdy['rid'], $Vyea2e2tvrvz['info']['pages']);
                        if (isset($Vyea2e2tvrvz['info']['pages'][$V0ixz2v5mxzy]) && $Vyea2e2tvrvz['info']['pages'][$V0ixz2v5mxzy] == $V3vmzyblbtdy['rid']) {

                            
                            
                            switch ($V3vmzyblbtdy['pos']) {
                                case 'before':
                                    $Vawllmnnfede = $V0ixz2v5mxzy;
                                    break;

                                case 'after':
                                    $Vawllmnnfede = $V0ixz2v5mxzy + 1;
                                    break;

                                default:
                                    $Vawllmnnfede = -1;
                                    break;
                            }

                            if ($Vawllmnnfede >= 0) {
                                for ($Vy4wtqjehnh5 = count($Vyea2e2tvrvz['info']['pages']) - 1; $Vy4wtqjehnh5 >= $Vawllmnnfede; $Vy4wtqjehnh5--) {
                                    $Vyea2e2tvrvz['info']['pages'][$Vy4wtqjehnh5 + 1] = $Vyea2e2tvrvz['info']['pages'][$Vy4wtqjehnh5];
                                }

                                $Vyea2e2tvrvz['info']['pages'][$Vawllmnnfede] = $V3vmzyblbtdy['id'];
                            }
                        }
                    }
                }
                break;

            case 'procset':
                $Vyea2e2tvrvz['info']['procset'] = $V3vmzyblbtdy;
                break;

            case 'mediaBox':
                $Vyea2e2tvrvz['info']['mediaBox'] = $V3vmzyblbtdy;
                
                $Vvkqsaecgfirhis->currentPageSize = array('width' => $V3vmzyblbtdy[2], 'height' => $V3vmzyblbtdy[3]);
                break;

            case 'font':
                $Vyea2e2tvrvz['info']['fonts'][] = array('objNum' => $V3vmzyblbtdy['objNum'], 'fontNum' => $V3vmzyblbtdy['fontNum']);
                break;

            case 'extGState':
                $Vyea2e2tvrvz['info']['extGStates'][] = array('objNum' => $V3vmzyblbtdy['objNum'], 'stateNum' => $V3vmzyblbtdy['stateNum']);
                break;

            case 'xObject':
                $Vyea2e2tvrvz['info']['xObjects'][] = array('objNum' => $V3vmzyblbtdy['objNum'], 'label' => $V3vmzyblbtdy['label']);
                break;

            case 'out':
                if (count($Vyea2e2tvrvz['info']['pages'])) {
                    $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Pages\n/Kids [";
                    foreach ($Vyea2e2tvrvz['info']['pages'] as $Vfanetclug4s) {
                        $Vxux0evl2mvh .= "$Vfanetclug4s 0 R\n";
                    }

                    $Vxux0evl2mvh .= "]\n/Count " . count($Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['pages']);

                    if ((isset($Vyea2e2tvrvz['info']['fonts']) && count($Vyea2e2tvrvz['info']['fonts'])) ||
                        isset($Vyea2e2tvrvz['info']['procset']) ||
                        (isset($Vyea2e2tvrvz['info']['extGStates']) && count($Vyea2e2tvrvz['info']['extGStates']))
                    ) {
                        $Vxux0evl2mvh .= "\n/Resources <<";

                        if (isset($Vyea2e2tvrvz['info']['procset'])) {
                            $Vxux0evl2mvh .= "\n/ProcSet " . $Vyea2e2tvrvz['info']['procset'] . " 0 R";
                        }

                        if (isset($Vyea2e2tvrvz['info']['fonts']) && count($Vyea2e2tvrvz['info']['fonts'])) {
                            $Vxux0evl2mvh .= "\n/Font << ";
                            foreach ($Vyea2e2tvrvz['info']['fonts'] as $Vdw0en1w1uoy) {
                                $Vxux0evl2mvh .= "\n/F" . $Vdw0en1w1uoy['fontNum'] . " " . $Vdw0en1w1uoy['objNum'] . " 0 R";
                            }
                            $Vxux0evl2mvh .= "\n>>";
                        }

                        if (isset($Vyea2e2tvrvz['info']['xObjects']) && count($Vyea2e2tvrvz['info']['xObjects'])) {
                            $Vxux0evl2mvh .= "\n/XObject << ";
                            foreach ($Vyea2e2tvrvz['info']['xObjects'] as $Vdw0en1w1uoy) {
                                $Vxux0evl2mvh .= "\n/" . $Vdw0en1w1uoy['label'] . " " . $Vdw0en1w1uoy['objNum'] . " 0 R";
                            }
                            $Vxux0evl2mvh .= "\n>>";
                        }

                        if (isset($Vyea2e2tvrvz['info']['extGStates']) && count($Vyea2e2tvrvz['info']['extGStates'])) {
                            $Vxux0evl2mvh .= "\n/ExtGState << ";
                            foreach ($Vyea2e2tvrvz['info']['extGStates'] as $Vs5kiplwjh4v) {
                                $Vxux0evl2mvh .= "\n/GS" . $Vs5kiplwjh4v['stateNum'] . " " . $Vs5kiplwjh4v['objNum'] . " 0 R";
                            }
                            $Vxux0evl2mvh .= "\n>>";
                        }

                        $Vxux0evl2mvh .= "\n>>";
                        if (isset($Vyea2e2tvrvz['info']['mediaBox'])) {
                            $Vj0eqma35tbv = $Vyea2e2tvrvz['info']['mediaBox'];
                            $Vxux0evl2mvh .= "\n/MediaBox [" . sprintf(
                                    '%.3F %.3F %.3F %.3F',
                                    $Vj0eqma35tbv[0],
                                    $Vj0eqma35tbv[1],
                                    $Vj0eqma35tbv[2],
                                    $Vj0eqma35tbv[3]
                                ) . ']';
                        }
                    }

                    $Vxux0evl2mvh .= "\n >>\nendobj";
                } else {
                    $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Pages\n/Count 0\n>>\nendobj";
                }

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_outlines($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'outlines', 'info' => array('outlines' => array()));
                $Vvkqsaecgfirhis->o_catalog($Vvkqsaecgfirhis->catalogId, 'outlines', $Vawfntrfsy4f);
                break;

            case 'outline':
                $Vyea2e2tvrvz['info']['outlines'][] = $V3vmzyblbtdy;
                break;

            case 'out':
                if (count($Vyea2e2tvrvz['info']['outlines'])) {
                    $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Outlines /Kids [";
                    foreach ($Vyea2e2tvrvz['info']['outlines'] as $Vfanetclug4s) {
                        $Vxux0evl2mvh .= "$Vfanetclug4s 0 R ";
                    }

                    $Vxux0evl2mvh .= "] /Count " . count($Vyea2e2tvrvz['info']['outlines']) . " >>\nendobj";
                } else {
                    $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Outlines /Count 0 >>\nendobj";
                }

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_font($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array(
                    't'    => 'font',
                    'info' => array(
                        'name'         => $V3vmzyblbtdy['name'],
                        'fontFileName' => $V3vmzyblbtdy['fontFileName'],
                        'SubType'      => 'Type1'
                    )
                );
                $Vstvrpwejj5k = $Vvkqsaecgfirhis->numFonts;
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['fontNum'] = $Vstvrpwejj5k;

                
                if (isset($V3vmzyblbtdy['differences'])) {
                    
                    $Vvkqsaecgfirhis->numObj++;
                    $Vvkqsaecgfirhis->o_fontEncoding($Vvkqsaecgfirhis->numObj, 'new', $V3vmzyblbtdy);
                    $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['encodingDictionary'] = $Vvkqsaecgfirhis->numObj;
                } else {
                    if (isset($V3vmzyblbtdy['encoding'])) {
                        
                        switch ($V3vmzyblbtdy['encoding']) {
                            case 'WinAnsiEncoding':
                            case 'MacRomanEncoding':
                            case 'MacExpertEncoding':
                                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['encoding'] = $V3vmzyblbtdy['encoding'];
                                break;

                            case 'none':
                                break;

                            default:
                                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['encoding'] = 'WinAnsiEncoding';
                                break;
                        }
                    } else {
                        $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['encoding'] = 'WinAnsiEncoding';
                    }
                }

                if ($Vvkqsaecgfirhis->fonts[$V3vmzyblbtdy['fontFileName']]['isUnicode']) {
                    
                    
                    
                    
                    
                    
                    

                    $Vbs4kkwa23ph = ++$Vvkqsaecgfirhis->numObj;
                    $Vvkqsaecgfirhis->o_contents($Vbs4kkwa23ph, 'new', 'raw');
                    $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['toUnicode'] = $Vbs4kkwa23ph;

                    $Vq1jhce3sl3k = <<<EOT
/CIDInit /ProcSet findresource begin
12 dict begin
begincmap
/CIDSystemInfo
<</Registry (Adobe)
/Ordering (UCS)
/Supplement 0
>> def
/CMapName /Adobe-Identity-UCS def
/CMapType 2 def
1 begincodespacerange
<0000> <FFFF>
endcodespacerange
1 beginbfrange
<0000> <FFFF> <0000>
endbfrange
endcmap
CMapName currentdict /CMap defineresource pop
end
end
EOT;

                    $Vxux0evl2mvh = "<</Length " . mb_strlen($Vq1jhce3sl3k, '8bit') . " >>\n";
                    $Vxux0evl2mvh .= "stream\n" . $Vq1jhce3sl3k . "endstream";

                    $Vvkqsaecgfirhis->objects[$Vbs4kkwa23ph]['c'] = $Vxux0evl2mvh;

                    $Vibpu1nk3nfk = ++$Vvkqsaecgfirhis->numObj;
                    $Vvkqsaecgfirhis->o_fontDescendentCID($Vibpu1nk3nfk, 'new', $V3vmzyblbtdy);
                    $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['cidFont'] = $Vibpu1nk3nfk;
                }

                
                $Vvkqsaecgfirhis->o_pages($Vvkqsaecgfirhis->currentNode, 'font', array('fontNum' => $Vstvrpwejj5k, 'objNum' => $Vawfntrfsy4f));
                break;

            case 'add':
                foreach ($V3vmzyblbtdy as $Vawllmnnfede => $Vfanetclug4s) {
                    switch ($Vawllmnnfede) {
                        case 'BaseFont':
                            $Vyea2e2tvrvz['info']['name'] = $Vfanetclug4s;
                            break;
                        case 'FirstChar':
                        case 'LastChar':
                        case 'Widths':
                        case 'FontDescriptor':
                        case 'SubType':
                            $Vvkqsaecgfirhis->addMessage('o_font ' . $Vawllmnnfede . " : " . $Vfanetclug4s);
                            $Vyea2e2tvrvz['info'][$Vawllmnnfede] = $Vfanetclug4s;
                            break;
                    }
                }

                
                if (isset($Vyea2e2tvrvz['info']['cidFont'])) {
                    $Vvkqsaecgfirhis->o_fontDescendentCID($Vyea2e2tvrvz['info']['cidFont'], 'add', $V3vmzyblbtdy);
                }
                break;

            case 'out':
                if ($Vvkqsaecgfirhis->fonts[$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['fontFileName']]['isUnicode']) {
                    
                    
                    
                    
                    
                    
                    

                    $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<</Type /Font\n/Subtype /Type0\n";
                    $Vxux0evl2mvh .= "/BaseFont /" . $Vyea2e2tvrvz['info']['name'] . "\n";

                    
                    
                    $Vxux0evl2mvh .= "/Encoding /Identity-H\n";
                    $Vxux0evl2mvh .= "/DescendantFonts [" . $Vyea2e2tvrvz['info']['cidFont'] . " 0 R]\n";
                    $Vxux0evl2mvh .= "/ToUnicode " . $Vyea2e2tvrvz['info']['toUnicode'] . " 0 R\n";
                    $Vxux0evl2mvh .= ">>\n";
                    $Vxux0evl2mvh .= "endobj";
                } else {
                    $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Font\n/Subtype /" . $Vyea2e2tvrvz['info']['SubType'] . "\n";
                    $Vxux0evl2mvh .= "/Name /F" . $Vyea2e2tvrvz['info']['fontNum'] . "\n";
                    $Vxux0evl2mvh .= "/BaseFont /" . $Vyea2e2tvrvz['info']['name'] . "\n";

                    if (isset($Vyea2e2tvrvz['info']['encodingDictionary'])) {
                        
                        $Vxux0evl2mvh .= "/Encoding " . $Vyea2e2tvrvz['info']['encodingDictionary'] . " 0 R\n";
                    } else {
                        if (isset($Vyea2e2tvrvz['info']['encoding'])) {
                            
                            $Vxux0evl2mvh .= "/Encoding /" . $Vyea2e2tvrvz['info']['encoding'] . "\n";
                        }
                    }

                    if (isset($Vyea2e2tvrvz['info']['FirstChar'])) {
                        $Vxux0evl2mvh .= "/FirstChar " . $Vyea2e2tvrvz['info']['FirstChar'] . "\n";
                    }

                    if (isset($Vyea2e2tvrvz['info']['LastChar'])) {
                        $Vxux0evl2mvh .= "/LastChar " . $Vyea2e2tvrvz['info']['LastChar'] . "\n";
                    }

                    if (isset($Vyea2e2tvrvz['info']['Widths'])) {
                        $Vxux0evl2mvh .= "/Widths " . $Vyea2e2tvrvz['info']['Widths'] . " 0 R\n";
                    }

                    if (isset($Vyea2e2tvrvz['info']['FontDescriptor'])) {
                        $Vxux0evl2mvh .= "/FontDescriptor " . $Vyea2e2tvrvz['info']['FontDescriptor'] . " 0 R\n";
                    }

                    $Vxux0evl2mvh .= ">>\n";
                    $Vxux0evl2mvh .= "endobj";
                }

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_fontDescriptor($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'fontDescriptor', 'info' => $V3vmzyblbtdy);
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /FontDescriptor\n";
                foreach ($Vyea2e2tvrvz['info'] as $Vovi5zubtdii => $Vfanetclug4salue) {
                    switch ($Vovi5zubtdii) {
                        case 'Ascent':
                        case 'CapHeight':
                        case 'Descent':
                        case 'Flags':
                        case 'ItalicAngle':
                        case 'StemV':
                        case 'AvgWidth':
                        case 'Leading':
                        case 'MaxWidth':
                        case 'MissingWidth':
                        case 'StemH':
                        case 'XHeight':
                        case 'CharSet':
                            if (mb_strlen($Vfanetclug4salue, '8bit')) {
                                $Vxux0evl2mvh .= "/$Vovi5zubtdii $Vfanetclug4salue\n";
                            }

                            break;
                        case 'FontFile':
                        case 'FontFile2':
                        case 'FontFile3':
                            $Vxux0evl2mvh .= "/$Vovi5zubtdii $Vfanetclug4salue 0 R\n";
                            break;

                        case 'FontBBox':
                            $Vxux0evl2mvh .= "/$Vovi5zubtdii [$Vfanetclug4salue[0] $Vfanetclug4salue[1] $Vfanetclug4salue[2] $Vfanetclug4salue[3]]\n";
                            break;

                        case 'FontName':
                            $Vxux0evl2mvh .= "/$Vovi5zubtdii /$Vfanetclug4salue\n";
                            break;
                    }
                }

                $Vxux0evl2mvh .= ">>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_fontEncoding($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'fontEncoding', 'info' => $V3vmzyblbtdy);
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Encoding\n";
                if (!isset($Vyea2e2tvrvz['info']['encoding'])) {
                    $Vyea2e2tvrvz['info']['encoding'] = 'WinAnsiEncoding';
                }

                if ($Vyea2e2tvrvz['info']['encoding'] !== 'none') {
                    $Vxux0evl2mvh .= "/BaseEncoding /" . $Vyea2e2tvrvz['info']['encoding'] . "\n";
                }

                $Vxux0evl2mvh .= "/Differences \n[";

                $Vyea2e2tvrvznum = -100;

                foreach ($Vyea2e2tvrvz['info']['differences'] as $Vaucqj0hftp5 => $Vovi5zubtdii) {
                    if ($Vaucqj0hftp5 != $Vyea2e2tvrvznum + 1) {
                        
                        $Vxux0evl2mvh .= "\n$Vaucqj0hftp5 /$Vovi5zubtdii";
                    } else {
                        $Vxux0evl2mvh .= " /$Vovi5zubtdii";
                    }

                    $Vyea2e2tvrvznum = $Vaucqj0hftp5;
                }

                $Vxux0evl2mvh .= "\n]\n>>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_fontDescendentCID($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'fontDescendentCID', 'info' => $V3vmzyblbtdy);

                
                $Vv3ytd5i5pil = ++$Vvkqsaecgfirhis->numObj;
                $Vvkqsaecgfirhis->o_contents($Vv3ytd5i5pil, 'new', 'raw');
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['cidSystemInfo'] = $Vv3ytd5i5pil;
                $Vxux0evl2mvh = "<</Registry (Adobe)\n"; 
                $Vxux0evl2mvh .= "/Ordering (UCS)\n"; 
                $Vxux0evl2mvh .= "/Supplement 0\n"; 
                $Vxux0evl2mvh .= ">>";
                $Vvkqsaecgfirhis->objects[$Vv3ytd5i5pil]['c'] = $Vxux0evl2mvh;

                
                $Vgvjkzl31e0a = ++$Vvkqsaecgfirhis->numObj;
                $Vvkqsaecgfirhis->o_fontGIDtoCIDMap($Vgvjkzl31e0a, 'new', $V3vmzyblbtdy);
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['cidToGidMap'] = $Vgvjkzl31e0a;
                break;

            case 'add':
                foreach ($V3vmzyblbtdy as $Vawllmnnfede => $Vfanetclug4s) {
                    switch ($Vawllmnnfede) {
                        case 'BaseFont':
                            $Vyea2e2tvrvz['info']['name'] = $Vfanetclug4s;
                            break;

                        case 'FirstChar':
                        case 'LastChar':
                        case 'MissingWidth':
                        case 'FontDescriptor':
                        case 'SubType':
                            $Vvkqsaecgfirhis->addMessage("o_fontDescendentCID $Vawllmnnfede : $Vfanetclug4s");
                            $Vyea2e2tvrvz['info'][$Vawllmnnfede] = $Vfanetclug4s;
                            break;
                    }
                }

                
                $Vvkqsaecgfirhis->o_fontGIDtoCIDMap($Vyea2e2tvrvz['info']['cidToGidMap'], 'add', $V3vmzyblbtdy);
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n";
                $Vxux0evl2mvh .= "<</Type /Font\n";
                $Vxux0evl2mvh .= "/Subtype /CIDFontType2\n";
                $Vxux0evl2mvh .= "/BaseFont /" . $Vyea2e2tvrvz['info']['name'] . "\n";
                $Vxux0evl2mvh .= "/CIDSystemInfo " . $Vyea2e2tvrvz['info']['cidSystemInfo'] . " 0 R\n";







                if (isset($Vyea2e2tvrvz['info']['FontDescriptor'])) {
                    $Vxux0evl2mvh .= "/FontDescriptor " . $Vyea2e2tvrvz['info']['FontDescriptor'] . " 0 R\n";
                }

                if (isset($Vyea2e2tvrvz['info']['MissingWidth'])) {
                    $Vxux0evl2mvh .= "/DW " . $Vyea2e2tvrvz['info']['MissingWidth'] . "\n";
                }

                if (isset($Vyea2e2tvrvz['info']['fontFileName']) && isset($Vvkqsaecgfirhis->fonts[$Vyea2e2tvrvz['info']['fontFileName']]['CIDWidths'])) {
                    $Vn4yxa1pskaa = &$Vvkqsaecgfirhis->fonts[$Vyea2e2tvrvz['info']['fontFileName']]['CIDWidths'];
                    $V5ymvwogwh5y = '';
                    foreach ($Vn4yxa1pskaa as $Vonrbka2saaq => $V5ymvwogwh5yidth) {
                        $V5ymvwogwh5y .= "$Vonrbka2saaq [$V5ymvwogwh5yidth] ";
                    }
                    $Vxux0evl2mvh .= "/W [$V5ymvwogwh5y]\n";
                }

                $Vxux0evl2mvh .= "/CIDToGIDMap " . $Vyea2e2tvrvz['info']['cidToGidMap'] . " 0 R\n";
                $Vxux0evl2mvh .= ">>\n";
                $Vxux0evl2mvh .= "endobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_fontGIDtoCIDMap($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'fontGIDtoCIDMap', 'info' => $V3vmzyblbtdy);
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n";
                $Vpjgonmtsz3h = $Vyea2e2tvrvz['info']['fontFileName'];
                $Vj0eqma35tbv = $Vvkqsaecgfirhis->fonts[$Vpjgonmtsz3h]['CIDtoGID'] = base64_decode($Vvkqsaecgfirhis->fonts[$Vpjgonmtsz3h]['CIDtoGID']);

                $Vggzspwt45yj = isset($Vvkqsaecgfirhis->fonts[$Vpjgonmtsz3h]['CIDtoGID_Compressed']) &&
                    $Vvkqsaecgfirhis->fonts[$Vpjgonmtsz3h]['CIDtoGID_Compressed'];

                if (!$Vggzspwt45yj && isset($Vyea2e2tvrvz['raw'])) {
                    $Vxux0evl2mvh .= $Vj0eqma35tbv;
                } else {
                    $Vxux0evl2mvh .= "<<";

                    if (!$Vggzspwt45yj && $Vvkqsaecgfirhis->compressionReady && $Vvkqsaecgfirhis->options['compression']) {
                        
                        $Vggzspwt45yj = true;
                        $Vj0eqma35tbv = gzcompress($Vj0eqma35tbv, 6);
                    }
                    if ($Vggzspwt45yj) {
                        $Vxux0evl2mvh .= "\n/Filter /FlateDecode";
                    }

                    $Vxux0evl2mvh .= "\n/Length " . mb_strlen($Vj0eqma35tbv, '8bit') . ">>\nstream\n$Vj0eqma35tbv\nendstream";
                }

                $Vxux0evl2mvh .= "\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_procset($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'procset', 'info' => array('PDF' => 1, 'Text' => 1));
                $Vvkqsaecgfirhis->o_pages($Vvkqsaecgfirhis->currentNode, 'procset', $Vawfntrfsy4f);
                $Vvkqsaecgfirhis->procsetObjectId = $Vawfntrfsy4f;
                break;

            case 'add':
                
                
                switch ($V3vmzyblbtdy) {
                    case 'ImageB':
                    case 'ImageC':
                    case 'ImageI':
                        $Vyea2e2tvrvz['info'][$V3vmzyblbtdy] = 1;
                        break;
                }
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n[";
                foreach ($Vyea2e2tvrvz['info'] as $Vovi5zubtdii => $Vfanetclug4sal) {
                    $Vxux0evl2mvh .= "/$Vovi5zubtdii ";
                }
                $Vxux0evl2mvh .= "]\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_info($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->infoObject = $Vawfntrfsy4f;
                $V05hsygpnzv5 = 'D:' . @date('Ymd');
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array(
                    't'    => 'info',
                    'info' => array(
                        'Creator'      => 'R and OS php pdf writer, http://www.ros.co.nz',
                        'CreationDate' => $V05hsygpnzv5
                    )
                );
                break;
            case 'Title':
            case 'Author':
            case 'Subject':
            case 'Keywords':
            case 'Creator':
            case 'Producer':
            case 'CreationDate':
            case 'ModDate':
            case 'Trapped':
                $Vyea2e2tvrvz['info'][$Vxkdu2igbqng] = $V3vmzyblbtdy;
                break;

            case 'out':
                if ($Vvkqsaecgfirhis->encrypted) {
                    $Vvkqsaecgfirhis->encryptInit($Vawfntrfsy4f);
                }

                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<<\n";
                foreach ($Vyea2e2tvrvz['info'] as $Vawllmnnfede => $Vfanetclug4s) {
                    $Vxux0evl2mvh .= "/$Vawllmnnfede (";

                    if ($Vvkqsaecgfirhis->encrypted) {
                        $Vfanetclug4s = $Vvkqsaecgfirhis->ARC4($Vfanetclug4s);
                    } 
                    elseif (!in_array($Vawllmnnfede, array('CreationDate', 'ModDate'))) {
                        $Vfanetclug4s = $Vvkqsaecgfirhis->filterText($Vfanetclug4s);
                    }

                    $Vxux0evl2mvh .= $Vfanetclug4s;
                    $Vxux0evl2mvh .= ")\n";
                }

                $Vxux0evl2mvh .= ">>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_action($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                if (is_array($V3vmzyblbtdy)) {
                    $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'action', 'info' => $V3vmzyblbtdy, 'type' => $V3vmzyblbtdy['type']);
                } else {
                    
                    $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'action', 'info' => $V3vmzyblbtdy, 'type' => 'URI');
                }
                break;

            case 'out':
                if ($Vvkqsaecgfirhis->encrypted) {
                    $Vvkqsaecgfirhis->encryptInit($Vawfntrfsy4f);
                }

                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Action";
                switch ($Vyea2e2tvrvz['type']) {
                    case 'ilink':
                        if (!isset($Vvkqsaecgfirhis->destinations[(string)$Vyea2e2tvrvz['info']['label']])) {
                            break;
                        }

                        
                        $Vxux0evl2mvh .= "\n/S /GoTo\n/D " . $Vvkqsaecgfirhis->destinations[(string)$Vyea2e2tvrvz['info']['label']] . " 0 R";
                        break;

                    case 'URI':
                        $Vxux0evl2mvh .= "\n/S /URI\n/URI (";
                        if ($Vvkqsaecgfirhis->encrypted) {
                            $Vxux0evl2mvh .= $Vvkqsaecgfirhis->filterText($Vvkqsaecgfirhis->ARC4($Vyea2e2tvrvz['info']), true, false);
                        } else {
                            $Vxux0evl2mvh .= $Vvkqsaecgfirhis->filterText($Vyea2e2tvrvz['info'], true, false);
                        }

                        $Vxux0evl2mvh .= ")";
                        break;
                }

                $Vxux0evl2mvh .= "\n>>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_annotation($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                
                $Vhclor3ojwko = $Vvkqsaecgfirhis->currentPage;
                $Vvkqsaecgfirhis->o_page($Vhclor3ojwko, 'annot', $Vawfntrfsy4f);

                
                switch ($V3vmzyblbtdy['type']) {
                    case 'link':
                        $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'annotation', 'info' => $V3vmzyblbtdy);
                        $Vvkqsaecgfirhis->numObj++;
                        $Vvkqsaecgfirhis->o_action($Vvkqsaecgfirhis->numObj, 'new', $V3vmzyblbtdy['url']);
                        $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['actionId'] = $Vvkqsaecgfirhis->numObj;
                        break;

                    case 'ilink':
                        
                        $Vovi5zubtdii = $V3vmzyblbtdy['label'];
                        $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'annotation', 'info' => $V3vmzyblbtdy);
                        $Vvkqsaecgfirhis->numObj++;
                        $Vvkqsaecgfirhis->o_action($Vvkqsaecgfirhis->numObj, 'new', array('type' => 'ilink', 'label' => $Vovi5zubtdii));
                        $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['actionId'] = $Vvkqsaecgfirhis->numObj;
                        break;
                }
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Annot";
                switch ($Vyea2e2tvrvz['info']['type']) {
                    case 'link':
                    case 'ilink':
                        $Vxux0evl2mvh .= "\n/Subtype /Link";
                        break;
                }
                $Vxux0evl2mvh .= "\n/A " . $Vyea2e2tvrvz['info']['actionId'] . " 0 R";
                $Vxux0evl2mvh .= "\n/Border [0 0 0]";
                $Vxux0evl2mvh .= "\n/H /I";
                $Vxux0evl2mvh .= "\n/Rect [ ";

                foreach ($Vyea2e2tvrvz['info']['rect'] as $Vfanetclug4s) {
                    $Vxux0evl2mvh .= sprintf("%.4F ", $Vfanetclug4s);
                }

                $Vxux0evl2mvh .= "]";
                $Vxux0evl2mvh .= "\n>>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_page($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->numPages++;
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array(
                    't'    => 'page',
                    'info' => array(
                        'parent'  => $Vvkqsaecgfirhis->currentNode,
                        'pageNum' => $Vvkqsaecgfirhis->numPages
                    )
                );

                if (is_array($V3vmzyblbtdy)) {
                    
                    $V3vmzyblbtdy['id'] = $Vawfntrfsy4f;
                    $Vvkqsaecgfirhis->o_pages($Vvkqsaecgfirhis->currentNode, 'page', $V3vmzyblbtdy);
                } else {
                    $Vvkqsaecgfirhis->o_pages($Vvkqsaecgfirhis->currentNode, 'page', $Vawfntrfsy4f);
                }

                $Vvkqsaecgfirhis->currentPage = $Vawfntrfsy4f;
                
                $Vvkqsaecgfirhis->numObj++;
                $Vvkqsaecgfirhis->o_contents($Vvkqsaecgfirhis->numObj, 'new', $Vawfntrfsy4f);
                $Vvkqsaecgfirhis->currentContents = $Vvkqsaecgfirhis->numObj;
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['contents'] = array();
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['contents'][] = $Vvkqsaecgfirhis->numObj;

                $Vmms5wlre01j = ($Vvkqsaecgfirhis->numPages % 2 ? 'odd' : 'even');
                foreach ($Vvkqsaecgfirhis->addLooseObjects as $Vyea2e2tvrvzId => $V4jfxynob0vk) {
                    if ($V4jfxynob0vk === 'all' || $Vmms5wlre01j === $V4jfxynob0vk) {
                        $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['contents'][] = $Vyea2e2tvrvzId;
                    }
                }
                break;

            case 'content':
                $Vyea2e2tvrvz['info']['contents'][] = $V3vmzyblbtdy;
                break;

            case 'annot':
                
                if (!isset($Vyea2e2tvrvz['info']['annot'])) {
                    $Vyea2e2tvrvz['info']['annot'] = array();
                }

                
                $Vyea2e2tvrvz['info']['annot'][] = $V3vmzyblbtdy;
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /Page";
                $Vxux0evl2mvh .= "\n/Parent " . $Vyea2e2tvrvz['info']['parent'] . " 0 R";

                if (isset($Vyea2e2tvrvz['info']['annot'])) {
                    $Vxux0evl2mvh .= "\n/Annots [";
                    foreach ($Vyea2e2tvrvz['info']['annot'] as $Vsx5o1sfjjsa) {
                        $Vxux0evl2mvh .= " $Vsx5o1sfjjsa 0 R";
                    }
                    $Vxux0evl2mvh .= " ]";
                }

                $V4wukmcy3ij2 = count($Vyea2e2tvrvz['info']['contents']);
                if ($V4wukmcy3ij2 == 1) {
                    $Vxux0evl2mvh .= "\n/Contents " . $Vyea2e2tvrvz['info']['contents'][0] . " 0 R";
                } else {
                    if ($V4wukmcy3ij2 > 1) {
                        $Vxux0evl2mvh .= "\n/Contents [\n";

                        
                        
                        
                        foreach ($Vyea2e2tvrvz['info']['contents'] as $Vu4m0umxvlha) {
                            $Vxux0evl2mvh .= "$Vu4m0umxvlha 0 R\n";
                        }
                        $Vxux0evl2mvh .= "]";
                    }
                }

                $Vxux0evl2mvh .= "\n>>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_contents($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'contents', 'c' => '', 'info' => array());
                if (mb_strlen($V3vmzyblbtdy, '8bit') && intval($V3vmzyblbtdy)) {
                    
                    $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['onPage'] = $V3vmzyblbtdy;
                } else {
                    if ($V3vmzyblbtdy === 'raw') {
                        
                        $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['raw'] = 1;
                    }
                }
                break;

            case 'add':
                
                foreach ($V3vmzyblbtdy as $Vawllmnnfede => $Vfanetclug4s) {
                    $Vyea2e2tvrvz['info'][$Vawllmnnfede] = $Vfanetclug4s;
                }

            case 'out':
                $Vj0eqma35tbv = $Vyea2e2tvrvz['c'];
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n";

                if (isset($Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['raw'])) {
                    $Vxux0evl2mvh .= $Vj0eqma35tbv;
                } else {
                    $Vxux0evl2mvh .= "<<";
                    if ($Vvkqsaecgfirhis->compressionReady && $Vvkqsaecgfirhis->options['compression']) {
                        
                        $Vxux0evl2mvh .= " /Filter /FlateDecode";
                        $Vj0eqma35tbv = gzcompress($Vj0eqma35tbv, 6);
                    }

                    if ($Vvkqsaecgfirhis->encrypted) {
                        $Vvkqsaecgfirhis->encryptInit($Vawfntrfsy4f);
                        $Vj0eqma35tbv = $Vvkqsaecgfirhis->ARC4($Vj0eqma35tbv);
                    }

                    foreach ($Vyea2e2tvrvz['info'] as $Vawllmnnfede => $Vfanetclug4s) {
                        $Vxux0evl2mvh .= "\n/$Vawllmnnfede $Vfanetclug4s";
                    }

                    $Vxux0evl2mvh .= "\n/Length " . mb_strlen($Vj0eqma35tbv, '8bit') . " >>\nstream\n$Vj0eqma35tbv\nendstream";
                }

                $Vxux0evl2mvh .= "\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    protected function o_embedjs($Vawfntrfsy4f, $Vxkdu2igbqng)
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array(
                    't'    => 'embedjs',
                    'info' => array(
                        'Names' => '[(EmbeddedJS) ' . ($Vawfntrfsy4f + 1) . ' 0 R]'
                    )
                );
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< ";
                foreach ($Vyea2e2tvrvz['info'] as $Vawllmnnfede => $Vfanetclug4s) {
                    $Vxux0evl2mvh .= "\n/$Vawllmnnfede $Vfanetclug4s";
                }
                $Vxux0evl2mvh .= "\n>>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    protected function o_javascript($Vawfntrfsy4f, $Vxkdu2igbqng, $Vlrwwrp5keo0 = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array(
                    't'    => 'javascript',
                    'info' => array(
                        'S'  => '/JavaScript',
                        'JS' => '(' . $Vvkqsaecgfirhis->filterText($Vlrwwrp5keo0) . ')',
                    )
                );
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< ";
                foreach ($Vyea2e2tvrvz['info'] as $Vawllmnnfede => $Vfanetclug4s) {
                    $Vxux0evl2mvh .= "\n/$Vawllmnnfede $Vfanetclug4s";
                }
                $Vxux0evl2mvh .= "\n>>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_image($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'image', 'data' => &$V3vmzyblbtdy['data'], 'info' => array());

                $V0ixz2v5mxzynfo =& $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info'];

                $V0ixz2v5mxzynfo['Type'] = '/XObject';
                $V0ixz2v5mxzynfo['Subtype'] = '/Image';
                $V0ixz2v5mxzynfo['Width'] = $V3vmzyblbtdy['iw'];
                $V0ixz2v5mxzynfo['Height'] = $V3vmzyblbtdy['ih'];

                if (isset($V3vmzyblbtdy['masked']) && $V3vmzyblbtdy['masked']) {
                    $V0ixz2v5mxzynfo['SMask'] = ($Vvkqsaecgfirhis->numObj - 1) . ' 0 R';
                }

                if (!isset($V3vmzyblbtdy['type']) || $V3vmzyblbtdy['type'] === 'jpg') {
                    if (!isset($V3vmzyblbtdy['channels'])) {
                        $V3vmzyblbtdy['channels'] = 3;
                    }

                    switch ($V3vmzyblbtdy['channels']) {
                        case  1:
                            $V0ixz2v5mxzynfo['ColorSpace'] = '/DeviceGray';
                            break;
                        case  4:
                            $V0ixz2v5mxzynfo['ColorSpace'] = '/DeviceCMYK';
                            break;
                        default:
                            $V0ixz2v5mxzynfo['ColorSpace'] = '/DeviceRGB';
                            break;
                    }

                    if ($V0ixz2v5mxzynfo['ColorSpace'] === '/DeviceCMYK') {
                        $V0ixz2v5mxzynfo['Decode'] = '[1 0 1 0 1 0 1 0]';
                    }

                    $V0ixz2v5mxzynfo['Filter'] = '/DCTDecode';
                    $V0ixz2v5mxzynfo['BitsPerComponent'] = 8;
                } else {
                    if ($V3vmzyblbtdy['type'] === 'png') {
                        $V0ixz2v5mxzynfo['Filter'] = '/FlateDecode';
                        $V0ixz2v5mxzynfo['DecodeParms'] = '<< /Predictor 15 /Colors ' . $V3vmzyblbtdy['ncolor'] . ' /Columns ' . $V3vmzyblbtdy['iw'] . ' /BitsPerComponent ' . $V3vmzyblbtdy['bitsPerComponent'] . '>>';

                        if ($V3vmzyblbtdy['isMask']) {
                            $V0ixz2v5mxzynfo['ColorSpace'] = '/DeviceGray';
                        } else {
                            if (mb_strlen($V3vmzyblbtdy['pdata'], '8bit')) {
                                $Vj0eqma35tbv = ' [ /Indexed /DeviceRGB ' . (mb_strlen($V3vmzyblbtdy['pdata'], '8bit') / 3 - 1) . ' ';
                                $Vvkqsaecgfirhis->numObj++;
                                $Vvkqsaecgfirhis->o_contents($Vvkqsaecgfirhis->numObj, 'new');
                                $Vvkqsaecgfirhis->objects[$Vvkqsaecgfirhis->numObj]['c'] = $V3vmzyblbtdy['pdata'];
                                $Vj0eqma35tbv .= $Vvkqsaecgfirhis->numObj . ' 0 R';
                                $Vj0eqma35tbv .= ' ]';
                                $V0ixz2v5mxzynfo['ColorSpace'] = $Vj0eqma35tbv;

                                if (isset($V3vmzyblbtdy['transparency'])) {
                                    $Vswcdcl1pznz = $V3vmzyblbtdy['transparency'];
                                    switch ($Vswcdcl1pznz['type']) {
                                        case 'indexed':
                                            $Vj0eqma35tbv = ' [ ' . $Vswcdcl1pznz['data'] . ' ' . $Vswcdcl1pznz['data'] . '] ';
                                            $V0ixz2v5mxzynfo['Mask'] = $Vj0eqma35tbv;
                                            break;

                                        case 'color-key':
                                            $Vj0eqma35tbv = ' [ ' .
                                                $Vswcdcl1pznz['r'] . ' ' . $Vswcdcl1pznz['r'] .
                                                $Vswcdcl1pznz['g'] . ' ' . $Vswcdcl1pznz['g'] .
                                                $Vswcdcl1pznz['b'] . ' ' . $Vswcdcl1pznz['b'] .
                                                ' ] ';
                                            $V0ixz2v5mxzynfo['Mask'] = $Vj0eqma35tbv;
                                            break;
                                    }
                                }
                            } else {
                                if (isset($V3vmzyblbtdy['transparency'])) {
                                    $Vswcdcl1pznz = $V3vmzyblbtdy['transparency'];

                                    switch ($Vswcdcl1pznz['type']) {
                                        case 'indexed':
                                            $Vj0eqma35tbv = ' [ ' . $Vswcdcl1pznz['data'] . ' ' . $Vswcdcl1pznz['data'] . '] ';
                                            $V0ixz2v5mxzynfo['Mask'] = $Vj0eqma35tbv;
                                            break;

                                        case 'color-key':
                                            $Vj0eqma35tbv = ' [ ' .
                                                $Vswcdcl1pznz['r'] . ' ' . $Vswcdcl1pznz['r'] . ' ' .
                                                $Vswcdcl1pznz['g'] . ' ' . $Vswcdcl1pznz['g'] . ' ' .
                                                $Vswcdcl1pznz['b'] . ' ' . $Vswcdcl1pznz['b'] .
                                                ' ] ';
                                            $V0ixz2v5mxzynfo['Mask'] = $Vj0eqma35tbv;
                                            break;
                                    }
                                }
                                $V0ixz2v5mxzynfo['ColorSpace'] = '/' . $V3vmzyblbtdy['color'];
                            }
                        }

                        $V0ixz2v5mxzynfo['BitsPerComponent'] = $V3vmzyblbtdy['bitsPerComponent'];
                    }
                }

                
                
                $Vvkqsaecgfirhis->o_pages($Vvkqsaecgfirhis->currentNode, 'xObject', array('label' => $V3vmzyblbtdy['label'], 'objNum' => $Vawfntrfsy4f));

                
                $Vvkqsaecgfirhis->o_procset($Vvkqsaecgfirhis->procsetObjectId, 'add', 'ImageC');
                break;

            case 'out':
                $Vj0eqma35tbv = &$Vyea2e2tvrvz['data'];
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<<";

                foreach ($Vyea2e2tvrvz['info'] as $Vawllmnnfede => $Vfanetclug4s) {
                    $Vxux0evl2mvh .= "\n/$Vawllmnnfede $Vfanetclug4s";
                }

                if ($Vvkqsaecgfirhis->encrypted) {
                    $Vvkqsaecgfirhis->encryptInit($Vawfntrfsy4f);
                    $Vj0eqma35tbv = $Vvkqsaecgfirhis->ARC4($Vj0eqma35tbv);
                }

                $Vxux0evl2mvh .= "\n/Length " . mb_strlen($Vj0eqma35tbv, '8bit') . ">>\nstream\n$Vj0eqma35tbv\nendstream\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_extGState($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = "")
    {
        static $Vfanetclug4salid_params = array(
            "LW",
            "LC",
            "LC",
            "LJ",
            "ML",
            "D",
            "RI",
            "OP",
            "op",
            "OPM",
            "Font",
            "BG",
            "BG2",
            "UCR",
            "TR",
            "TR2",
            "HT",
            "FL",
            "SM",
            "SA",
            "BM",
            "SMask",
            "CA",
            "ca",
            "AIS",
            "TK"
        );

        if ($Vxkdu2igbqng !== "new") {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case "new":
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'extGState', 'info' => $V3vmzyblbtdy);

                
                $Vvkqsaecgfirhis->numStates++;
                $Vvkqsaecgfirhis->o_pages($Vvkqsaecgfirhis->currentNode, 'extGState', array("objNum" => $Vawfntrfsy4f, "stateNum" => $Vvkqsaecgfirhis->numStates));
                break;

            case "out":
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<< /Type /ExtGState\n";

                foreach ($Vyea2e2tvrvz["info"] as $Vawllmnnfede => $Vfanetclug4s) {
                    if (!in_array($Vawllmnnfede, $Vfanetclug4salid_params)) {
                        continue;
                    }
                    $Vxux0evl2mvh .= "/$Vawllmnnfede $Vfanetclug4s\n";
                }

                $Vxux0evl2mvh .= ">>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    
    protected function o_encryption($Vawfntrfsy4f, $Vxkdu2igbqng, $V3vmzyblbtdy = '')
    {
        if ($Vxkdu2igbqng !== 'new') {
            $Vyea2e2tvrvz = &$Vvkqsaecgfirhis->objects[$Vawfntrfsy4f];
        }

        switch ($Vxkdu2igbqng) {
            case 'new':
                
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f] = array('t' => 'encryption', 'info' => $V3vmzyblbtdy);
                $Vvkqsaecgfirhis->arc4_objnum = $Vawfntrfsy4f;

                
                $Viwtkcmztr2m = chr(0x28) . chr(0xBF) . chr(0x4E) . chr(0x5E) . chr(0x4E) . chr(0x75) . chr(0x8A) . chr(0x41)
                    . chr(0x64) . chr(0x00) . chr(0x4E) . chr(0x56) . chr(0xFF) . chr(0xFA) . chr(0x01) . chr(0x08)
                    . chr(0x2E) . chr(0x2E) . chr(0x00) . chr(0xB6) . chr(0xD0) . chr(0x68) . chr(0x3E) . chr(0x80)
                    . chr(0x2F) . chr(0x0C) . chr(0xA9) . chr(0xFE) . chr(0x64) . chr(0x53) . chr(0x69) . chr(0x7A);

                $Vukikbvg40ol = mb_strlen($V3vmzyblbtdy['owner'], '8bit');

                if ($Vukikbvg40ol > 32) {
                    $Vyea2e2tvrvzwner = substr($V3vmzyblbtdy['owner'], 0, 32);
                } else {
                    if ($Vukikbvg40ol < 32) {
                        $Vyea2e2tvrvzwner = $V3vmzyblbtdy['owner'] . substr($Viwtkcmztr2m, 0, 32 - $Vukikbvg40ol);
                    } else {
                        $Vyea2e2tvrvzwner = $V3vmzyblbtdy['owner'];
                    }
                }

                $Vukikbvg40ol = mb_strlen($V3vmzyblbtdy['user'], '8bit');
                if ($Vukikbvg40ol > 32) {
                    $Vx1zyypptawk = substr($V3vmzyblbtdy['user'], 0, 32);
                } else {
                    if ($Vukikbvg40ol < 32) {
                        $Vx1zyypptawk = $V3vmzyblbtdy['user'] . substr($Viwtkcmztr2m, 0, 32 - $Vukikbvg40ol);
                    } else {
                        $Vx1zyypptawk = $V3vmzyblbtdy['user'];
                    }
                }

                $Vj0eqma35tbv = $Vvkqsaecgfirhis->md5_16($Vyea2e2tvrvzwner);
                $Vyea2e2tvrvzkey = substr($Vj0eqma35tbv, 0, 5);
                $Vvkqsaecgfirhis->ARC4_init($Vyea2e2tvrvzkey);
                $Vyea2e2tvrvzvalue = $Vvkqsaecgfirhis->ARC4($Vx1zyypptawk);
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['O'] = $Vyea2e2tvrvzvalue;

                
                $Vj0eqma35tbv = $Vvkqsaecgfirhis->md5_16(
                    $Vx1zyypptawk . $Vyea2e2tvrvzvalue . chr($V3vmzyblbtdy['p']) . chr(255) . chr(255) . chr(255) . $Vvkqsaecgfirhis->fileIdentifier
                );

                $Vnn4n1og2snd = substr($Vj0eqma35tbv, 0, 5);
                $Vvkqsaecgfirhis->ARC4_init($Vnn4n1og2snd);
                $Vvkqsaecgfirhis->encryptionKey = $Vnn4n1og2snd;
                $Vvkqsaecgfirhis->encrypted = true;
                $Vsx1w2y2dtgn = $Vvkqsaecgfirhis->ARC4($Viwtkcmztr2m);
                $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['info']['U'] = $Vsx1w2y2dtgn;
                $Vvkqsaecgfirhis->encryptionKey = $Vnn4n1og2snd;
                
                break;

            case 'out':
                $Vxux0evl2mvh = "\n$Vawfntrfsy4f 0 obj\n<<";
                $Vxux0evl2mvh .= "\n/Filter /Standard";
                $Vxux0evl2mvh .= "\n/V 1";
                $Vxux0evl2mvh .= "\n/R 2";
                $Vxux0evl2mvh .= "\n/O (" . $Vvkqsaecgfirhis->filterText($Vyea2e2tvrvz['info']['O'], true, false) . ')';
                $Vxux0evl2mvh .= "\n/U (" . $Vvkqsaecgfirhis->filterText($Vyea2e2tvrvz['info']['U'], true, false) . ')';
                
                $Vyea2e2tvrvz['info']['p'] = (($Vyea2e2tvrvz['info']['p'] ^ 255) + 1) * -1;
                $Vxux0evl2mvh .= "\n/P " . ($Vyea2e2tvrvz['info']['p']);
                $Vxux0evl2mvh .= "\n>>\nendobj";

                return $Vxux0evl2mvh;
        }
    }

    

    
    function md5_16($Vo3pamb05rqg)
    {
        $Vj0eqma35tbv = md5($Vo3pamb05rqg);
        $Vyea2e2tvrvzut = '';
        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy <= 30; $V0ixz2v5mxzy = $V0ixz2v5mxzy + 2) {
            $Vyea2e2tvrvzut .= chr(hexdec(substr($Vj0eqma35tbv, $V0ixz2v5mxzy, 2)));
        }

        return $Vyea2e2tvrvzut;
    }

    
    function encryptInit($Vawfntrfsy4f)
    {
        $Vj0eqma35tbv = $Vvkqsaecgfirhis->encryptionKey;
        $Vhf40vq4bysn = dechex($Vawfntrfsy4f);
        if (mb_strlen($Vhf40vq4bysn, '8bit') < 6) {
            $Vhf40vq4bysn = substr('000000', 0, 6 - mb_strlen($Vhf40vq4bysn, '8bit')) . $Vhf40vq4bysn;
        }
        $Vj0eqma35tbv .= chr(hexdec(substr($Vhf40vq4bysn, 4, 2))) . chr(hexdec(substr($Vhf40vq4bysn, 2, 2))) . chr(
                hexdec(substr($Vhf40vq4bysn, 0, 2))
            ) . chr(0) . chr(0);
        $Vawllmnnfedeey = $Vvkqsaecgfirhis->md5_16($Vj0eqma35tbv);
        $Vvkqsaecgfirhis->ARC4_init(substr($Vawllmnnfedeey, 0, 10));
    }

    
    function ARC4_init($Vawllmnnfedeey = '')
    {
        $Vvkqsaecgfirhis->arc4 = '';

        
        if (mb_strlen($Vawllmnnfedeey, '8bit') == 0) {
            return;
        }

        $Vawllmnnfede = '';
        while (mb_strlen($Vawllmnnfede, '8bit') < 256) {
            $Vawllmnnfede .= $Vawllmnnfedeey;
        }

        $Vawllmnnfede = substr($Vawllmnnfede, 0, 256);
        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < 256; $V0ixz2v5mxzy++) {
            $Vvkqsaecgfirhis->arc4 .= chr($V0ixz2v5mxzy);
        }

        $Vy4wtqjehnh5 = 0;

        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < 256; $V0ixz2v5mxzy++) {
            $Vvkqsaecgfir = $Vvkqsaecgfirhis->arc4[$V0ixz2v5mxzy];
            $Vy4wtqjehnh5 = ($Vy4wtqjehnh5 + ord($Vvkqsaecgfir) + ord($Vawllmnnfede[$V0ixz2v5mxzy])) % 256;
            $Vvkqsaecgfirhis->arc4[$V0ixz2v5mxzy] = $Vvkqsaecgfirhis->arc4[$Vy4wtqjehnh5];
            $Vvkqsaecgfirhis->arc4[$Vy4wtqjehnh5] = $Vvkqsaecgfir;
        }
    }

    
    function ARC4($Vvkqsaecgfirext)
    {
        $Vukikbvg40ol = mb_strlen($Vvkqsaecgfirext, '8bit');
        $V4dkbhpdu11q = 0;
        $Vkbvefdrfvxh = 0;
        $Vdiqkcy1hsm4 = $Vvkqsaecgfirhis->arc4;
        $Vyea2e2tvrvzut = '';
        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vukikbvg40ol; $V0ixz2v5mxzy++) {
            $V4dkbhpdu11q = ($V4dkbhpdu11q + 1) % 256;
            $Vvkqsaecgfir = $Vdiqkcy1hsm4[$V4dkbhpdu11q];
            $Vkbvefdrfvxh = ($Vkbvefdrfvxh + ord($Vvkqsaecgfir)) % 256;
            $Vdiqkcy1hsm4[$V4dkbhpdu11q] = $Vdiqkcy1hsm4[$Vkbvefdrfvxh];
            $Vdiqkcy1hsm4[$Vkbvefdrfvxh] = $Vvkqsaecgfir;
            $Vawllmnnfede = ord($Vdiqkcy1hsm4[(ord($Vdiqkcy1hsm4[$V4dkbhpdu11q]) + ord($Vdiqkcy1hsm4[$Vkbvefdrfvxh])) % 256]);
            $Vyea2e2tvrvzut .= chr(ord($Vvkqsaecgfirext[$V0ixz2v5mxzy]) ^ $Vawllmnnfede);
        }

        return $Vyea2e2tvrvzut;
    }

    

    
    function addLink($Vop22rgf5euu, $Vo0naudmyq00, $Viibdokojojj, $V4wnp2r2nst5, $V2e3azycubv1)
    {
        $Vvkqsaecgfirhis->numObj++;
        $V0ixz2v5mxzynfo = array('type' => 'link', 'url' => $Vop22rgf5euu, 'rect' => array($Vo0naudmyq00, $Viibdokojojj, $V4wnp2r2nst5, $V2e3azycubv1));
        $Vvkqsaecgfirhis->o_annotation($Vvkqsaecgfirhis->numObj, 'new', $V0ixz2v5mxzynfo);
    }

    
    function addInternalLink($Vovi5zubtdii, $Vo0naudmyq00, $Viibdokojojj, $V4wnp2r2nst5, $V2e3azycubv1)
    {
        $Vvkqsaecgfirhis->numObj++;
        $V0ixz2v5mxzynfo = array('type' => 'ilink', 'label' => $Vovi5zubtdii, 'rect' => array($Vo0naudmyq00, $Viibdokojojj, $V4wnp2r2nst5, $V2e3azycubv1));
        $Vvkqsaecgfirhis->o_annotation($Vvkqsaecgfirhis->numObj, 'new', $V0ixz2v5mxzynfo);
    }

    
    function setEncryption($Vx1zyypptawkPass = '', $Vyea2e2tvrvzwnerPass = '', $Vd3wvkqsk5a4 = array())
    {
        $V2d1s45w0hjo = bindec("11000000");

        $V3vmzyblbtdy = array('print' => 4, 'modify' => 8, 'copy' => 16, 'add' => 32);

        foreach ($Vd3wvkqsk5a4 as $Vawllmnnfede => $Vfanetclug4s) {
            if ($Vfanetclug4s && isset($V3vmzyblbtdy[$Vawllmnnfede])) {
                $V2d1s45w0hjo += $V3vmzyblbtdy[$Vawllmnnfede];
            } else {
                if (isset($V3vmzyblbtdy[$Vfanetclug4s])) {
                    $V2d1s45w0hjo += $V3vmzyblbtdy[$Vfanetclug4s];
                }
            }
        }

        
        if ($Vvkqsaecgfirhis->arc4_objnum == 0) {
            
            $Vvkqsaecgfirhis->numObj++;
            if (mb_strlen($Vyea2e2tvrvzwnerPass) == 0) {
                $Vyea2e2tvrvzwnerPass = $Vx1zyypptawkPass;
            }

            $Vvkqsaecgfirhis->o_encryption($Vvkqsaecgfirhis->numObj, 'new', array('user' => $Vx1zyypptawkPass, 'owner' => $Vyea2e2tvrvzwnerPass, 'p' => $V2d1s45w0hjo));
        }
    }

    
    function checkAllHere()
    {
    }

    
    function output($V5hve4hi5ntx = false)
    {
        if ($V5hve4hi5ntx) {
            
            $Vvkqsaecgfirhis->options['compression'] = false;
        }

        if ($Vvkqsaecgfirhis->javascript) {
            $Vvkqsaecgfirhis->numObj++;

            $Vy4wtqjehnh5s_id = $Vvkqsaecgfirhis->numObj;
            $Vvkqsaecgfirhis->o_embedjs($Vy4wtqjehnh5s_id, 'new');
            $Vvkqsaecgfirhis->o_javascript(++$Vvkqsaecgfirhis->numObj, 'new', $Vvkqsaecgfirhis->javascript);

            $Vawfntrfsy4f = $Vvkqsaecgfirhis->catalogId;

            $Vvkqsaecgfirhis->o_catalog($Vawfntrfsy4f, 'javascript', $Vy4wtqjehnh5s_id);
        }

        if ($Vvkqsaecgfirhis->arc4_objnum) {
            $Vvkqsaecgfirhis->ARC4_init($Vvkqsaecgfirhis->encryptionKey);
        }

        $Vvkqsaecgfirhis->checkAllHere();

        $Vkz15z1lqws2 = array();
        $Vdiqkcy1hsm4ontent = '%PDF-1.3';
        $V2d1s45w0hjoos = mb_strlen($Vdiqkcy1hsm4ontent, '8bit');

        foreach ($Vvkqsaecgfirhis->objects as $Vawllmnnfede => $Vfanetclug4s) {
            $Vj0eqma35tbv = 'o_' . $Vfanetclug4s['t'];
            $Vdiqkcy1hsm4ont = $Vvkqsaecgfirhis->$Vj0eqma35tbv($Vawllmnnfede, 'out');
            $Vdiqkcy1hsm4ontent .= $Vdiqkcy1hsm4ont;
            $Vkz15z1lqws2[] = $V2d1s45w0hjoos;
            $V2d1s45w0hjoos += mb_strlen($Vdiqkcy1hsm4ont, '8bit');
        }

        $Vdiqkcy1hsm4ontent .= "\nxref\n0 " . (count($Vkz15z1lqws2) + 1) . "\n0000000000 65535 f \n";

        foreach ($Vkz15z1lqws2 as $V2d1s45w0hjo) {
            $Vdiqkcy1hsm4ontent .= str_pad($V2d1s45w0hjo, 10, "0", STR_PAD_LEFT) . " 00000 n \n";
        }

        $Vdiqkcy1hsm4ontent .= "trailer\n<<\n/Size " . (count($Vkz15z1lqws2) + 1) . "\n/Root 1 0 R\n/Info $Vvkqsaecgfirhis->infoObject 0 R\n";

        
        if ($Vvkqsaecgfirhis->arc4_objnum > 0) {
            $Vdiqkcy1hsm4ontent .= "/Encrypt $Vvkqsaecgfirhis->arc4_objnum 0 R\n";
        }

        if (mb_strlen($Vvkqsaecgfirhis->fileIdentifier, '8bit')) {
            $Vdiqkcy1hsm4ontent .= "/ID[<$Vvkqsaecgfirhis->fileIdentifier><$Vvkqsaecgfirhis->fileIdentifier>]\n";
        }

        
        $V2d1s45w0hjoos++;

        $Vdiqkcy1hsm4ontent .= ">>\nstartxref\n$V2d1s45w0hjoos\n%%EOF\n";

        return $Vdiqkcy1hsm4ontent;
    }

    
    private function newDocument($Vdwyhv40m15a = array(0, 0, 612, 792))
    {
        $Vvkqsaecgfirhis->numObj = 0;
        $Vvkqsaecgfirhis->objects = array();

        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_catalog($Vvkqsaecgfirhis->numObj, 'new');

        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_outlines($Vvkqsaecgfirhis->numObj, 'new');

        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_pages($Vvkqsaecgfirhis->numObj, 'new');

        $Vvkqsaecgfirhis->o_pages($Vvkqsaecgfirhis->numObj, 'mediaBox', $Vdwyhv40m15a);
        $Vvkqsaecgfirhis->currentNode = 3;

        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_procset($Vvkqsaecgfirhis->numObj, 'new');

        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_info($Vvkqsaecgfirhis->numObj, 'new');

        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_page($Vvkqsaecgfirhis->numObj, 'new');

        
        
        $Vvkqsaecgfirhis->firstPageId = $Vvkqsaecgfirhis->currentContents;
    }

    
    private function openFont($Vfsinbbqzbga)
    {
        
        $V2d1s45w0hjoos = strrpos($Vfsinbbqzbga, '/');

        if ($V2d1s45w0hjoos === false) {
            $Valss1lkhn2k = './';
            $Vreuchxnm2nm = $Vfsinbbqzbga;
        } else {
            $Valss1lkhn2k = substr($Vfsinbbqzbga, 0, $V2d1s45w0hjoos + 1);
            $Vreuchxnm2nm = substr($Vfsinbbqzbga, $V2d1s45w0hjoos + 1);
        }

        $Vi4nmsrluxec = $Vvkqsaecgfirhis->fontcache;
        if ($Vi4nmsrluxec == '') {
            $Vi4nmsrluxec = $Valss1lkhn2k;
        }

        
        
        
        
        

        $Vvkqsaecgfirhis->addMessage("openFont: $Vfsinbbqzbga - $Vreuchxnm2nm");

        if (!$Vvkqsaecgfirhis->isUnicode || in_array(mb_strtolower(basename($Vreuchxnm2nm)), self::$Vjtfix3mp15d)) {
            $Vgrd5kmqtfu3 = "$Vreuchxnm2nm.afm";
        } else {
            $Vgrd5kmqtfu3 = "$Vreuchxnm2nm.ufm";
        }

        $Vdiqkcy1hsm4ache_name = "$Vgrd5kmqtfu3.php";
        $Vvkqsaecgfirhis->addMessage("metrics: $Vgrd5kmqtfu3, cache: $Vdiqkcy1hsm4ache_name");

        if (file_exists($Vi4nmsrluxec . $Vdiqkcy1hsm4ache_name)) {
            $Vvkqsaecgfirhis->addMessage("openFont: php file exists $Vi4nmsrluxec$Vdiqkcy1hsm4ache_name");
            $Vvkqsaecgfirhis->fonts[$Vfsinbbqzbga] = require($Vi4nmsrluxec . $Vdiqkcy1hsm4ache_name);

            if (!isset($Vvkqsaecgfirhis->fonts[$Vfsinbbqzbga]['_version_']) || $Vvkqsaecgfirhis->fonts[$Vfsinbbqzbga]['_version_'] != $Vvkqsaecgfirhis->fontcacheVersion) {
                
                $Vvkqsaecgfirhis->addMessage('openFont: clear out, make way for new version.');
                $Vvkqsaecgfirhis->fonts[$Vfsinbbqzbga] = null;
                unset($Vvkqsaecgfirhis->fonts[$Vfsinbbqzbga]);
            }
        } else {
            $Vyea2e2tvrvzld_cache_name = "php_$Vgrd5kmqtfu3";
            if (file_exists($Vi4nmsrluxec . $Vyea2e2tvrvzld_cache_name)) {
                $Vvkqsaecgfirhis->addMessage(
                    "openFont: php file doesn't exist $Vi4nmsrluxec$Vdiqkcy1hsm4ache_name, creating it from the old format"
                );
                $Vyea2e2tvrvzld_cache = file_get_contents($Vi4nmsrluxec . $Vyea2e2tvrvzld_cache_name);
                file_put_contents($Vi4nmsrluxec . $Vdiqkcy1hsm4ache_name, '<?php return ' . $Vyea2e2tvrvzld_cache . ';');

                return $Vvkqsaecgfirhis->openFont($Vfsinbbqzbga);
            }
        }

        if (!isset($Vvkqsaecgfirhis->fonts[$Vfsinbbqzbga]) && file_exists($Valss1lkhn2k . $Vgrd5kmqtfu3)) {
            
            $Vvkqsaecgfirhis->addMessage("openFont: build php file from $Valss1lkhn2k$Vgrd5kmqtfu3");
            $V3o5lzcfvwzz = array();

            
            $V3o5lzcfvwzz['codeToName'] = array();

            
            
            $V3o5lzcfvwzz['isUnicode'] = (strtolower(substr($Vgrd5kmqtfu3, -3)) !== 'afm');

            $Vonrbka2saaqtogid = '';
            if ($V3o5lzcfvwzz['isUnicode']) {
                $Vonrbka2saaqtogid = str_pad('', 256 * 256 * 2, "\x00");
            }

            $Voheucoc3jxv = file($Valss1lkhn2k . $Vgrd5kmqtfu3);

            foreach ($Voheucoc3jxv as $Vwypx3uuz2jy) {
                $Vcqwpvcjcqxw = trim($Vwypx3uuz2jy);
                $V2d1s45w0hjoos = strpos($Vcqwpvcjcqxw, ' ');

                if ($V2d1s45w0hjoos) {
                    
                    $Vawllmnnfedeey = substr($Vcqwpvcjcqxw, 0, $V2d1s45w0hjoos);
                    switch ($Vawllmnnfedeey) {
                        case 'FontName':
                        case 'FullName':
                        case 'FamilyName':
                        case 'PostScriptName':
                        case 'Weight':
                        case 'ItalicAngle':
                        case 'IsFixedPitch':
                        case 'CharacterSet':
                        case 'UnderlinePosition':
                        case 'UnderlineThickness':
                        case 'Version':
                        case 'EncodingScheme':
                        case 'CapHeight':
                        case 'XHeight':
                        case 'Ascender':
                        case 'Descender':
                        case 'StdHW':
                        case 'StdVW':
                        case 'StartCharMetrics':
                        case 'FontHeightOffset': 
                            $V3o5lzcfvwzz[$Vawllmnnfedeey] = trim(substr($Vcqwpvcjcqxw, $V2d1s45w0hjoos));
                            break;

                        case 'FontBBox':
                            $V3o5lzcfvwzz[$Vawllmnnfedeey] = explode(' ', trim(substr($Vcqwpvcjcqxw, $V2d1s45w0hjoos)));
                            break;

                        
                        case 'C': 
                            $Vkbvefdrfvxhits = explode(';', trim($Vcqwpvcjcqxw));
                            $Vtu31jaewztx = array();

                            foreach ($Vkbvefdrfvxhits as $Vkbvefdrfvxhit) {
                                $Vkbvefdrfvxhits2 = explode(' ', trim($Vkbvefdrfvxhit));
                                if (mb_strlen($Vkbvefdrfvxhits2[0], '8bit') == 0) {
                                    continue;
                                }

                                if (count($Vkbvefdrfvxhits2) > 2) {
                                    $Vtu31jaewztx[$Vkbvefdrfvxhits2[0]] = array();
                                    for ($V0ixz2v5mxzy = 1; $V0ixz2v5mxzy < count($Vkbvefdrfvxhits2); $V0ixz2v5mxzy++) {
                                        $Vtu31jaewztx[$Vkbvefdrfvxhits2[0]][] = $Vkbvefdrfvxhits2[$V0ixz2v5mxzy];
                                    }
                                } else {
                                    if (count($Vkbvefdrfvxhits2) == 2) {
                                        $Vtu31jaewztx[$Vkbvefdrfvxhits2[0]] = $Vkbvefdrfvxhits2[1];
                                    }
                                }
                            }

                            $Vdiqkcy1hsm4 = (int)$Vtu31jaewztx['C'];
                            $Vu440l53e414 = $Vtu31jaewztx['N'];
                            $V5ymvwogwh5yidth = floatval($Vtu31jaewztx['WX']);

                            if ($Vdiqkcy1hsm4 >= 0) {
                                if ($Vdiqkcy1hsm4 != hexdec($Vu440l53e414)) {
                                    $V3o5lzcfvwzz['codeToName'][$Vdiqkcy1hsm4] = $Vu440l53e414;
                                }
                                $V3o5lzcfvwzz['C'][$Vdiqkcy1hsm4] = $V5ymvwogwh5yidth;
                            } else {
                                $V3o5lzcfvwzz['C'][$Vu440l53e414] = $V5ymvwogwh5yidth;
                            }

                            if (!isset($V3o5lzcfvwzz['MissingWidth']) && $Vdiqkcy1hsm4 == -1 && $Vu440l53e414 === '.notdef') {
                                $V3o5lzcfvwzz['MissingWidth'] = $V5ymvwogwh5yidth;
                            }

                            break;

                        
                        case 'U': 
                            if (!$V3o5lzcfvwzz['isUnicode']) {
                                break;
                            }

                            $Vkbvefdrfvxhits = explode(';', trim($Vcqwpvcjcqxw));
                            $Vtu31jaewztx = array();

                            foreach ($Vkbvefdrfvxhits as $Vkbvefdrfvxhit) {
                                $Vkbvefdrfvxhits2 = explode(' ', trim($Vkbvefdrfvxhit));
                                if (mb_strlen($Vkbvefdrfvxhits2[0], '8bit') === 0) {
                                    continue;
                                }

                                if (count($Vkbvefdrfvxhits2) > 2) {
                                    $Vtu31jaewztx[$Vkbvefdrfvxhits2[0]] = array();
                                    for ($V0ixz2v5mxzy = 1; $V0ixz2v5mxzy < count($Vkbvefdrfvxhits2); $V0ixz2v5mxzy++) {
                                        $Vtu31jaewztx[$Vkbvefdrfvxhits2[0]][] = $Vkbvefdrfvxhits2[$V0ixz2v5mxzy];
                                    }
                                } else {
                                    if (count($Vkbvefdrfvxhits2) == 2) {
                                        $Vtu31jaewztx[$Vkbvefdrfvxhits2[0]] = $Vkbvefdrfvxhits2[1];
                                    }
                                }
                            }

                            $Vdiqkcy1hsm4 = (int)$Vtu31jaewztx['U'];
                            $Vu440l53e414 = $Vtu31jaewztx['N'];
                            $Vllkwhuxxhtb = $Vtu31jaewztx['G'];
                            $V5ymvwogwh5yidth = floatval($Vtu31jaewztx['WX']);

                            if ($Vdiqkcy1hsm4 >= 0) {
                                
                                if ($Vdiqkcy1hsm4 >= 0 && $Vdiqkcy1hsm4 < 0xFFFF && $Vllkwhuxxhtb) {
                                    $Vonrbka2saaqtogid[$Vdiqkcy1hsm4 * 2] = chr($Vllkwhuxxhtb >> 8);
                                    $Vonrbka2saaqtogid[$Vdiqkcy1hsm4 * 2 + 1] = chr($Vllkwhuxxhtb & 0xFF);
                                }

                                if ($Vdiqkcy1hsm4 != hexdec($Vu440l53e414)) {
                                    $V3o5lzcfvwzz['codeToName'][$Vdiqkcy1hsm4] = $Vu440l53e414;
                                }
                                $V3o5lzcfvwzz['C'][$Vdiqkcy1hsm4] = $V5ymvwogwh5yidth;
                            } else {
                                $V3o5lzcfvwzz['C'][$Vu440l53e414] = $V5ymvwogwh5yidth;
                            }

                            if (!isset($V3o5lzcfvwzz['MissingWidth']) && $Vdiqkcy1hsm4 == -1 && $Vu440l53e414 === '.notdef') {
                                $V3o5lzcfvwzz['MissingWidth'] = $V5ymvwogwh5yidth;
                            }

                            break;

                        case 'KPX':
                            break; 
                            
                            $Vkbvefdrfvxhits = explode(' ', trim($Vcqwpvcjcqxw));
                            $V3o5lzcfvwzz['KPX'][$Vkbvefdrfvxhits[1]][$Vkbvefdrfvxhits[2]] = $Vkbvefdrfvxhits[3];
                            break;
                    }
                }
            }

            if ($Vvkqsaecgfirhis->compressionReady && $Vvkqsaecgfirhis->options['compression']) {
                
                $V3o5lzcfvwzz['CIDtoGID_Compressed'] = true;
                $Vonrbka2saaqtogid = gzcompress($Vonrbka2saaqtogid, 6);
            }
            $V3o5lzcfvwzz['CIDtoGID'] = base64_encode($Vonrbka2saaqtogid);
            $V3o5lzcfvwzz['_version_'] = $Vvkqsaecgfirhis->fontcacheVersion;
            $Vvkqsaecgfirhis->fonts[$Vfsinbbqzbga] = $V3o5lzcfvwzz;

            
            
            if (is_dir(substr($Vi4nmsrluxec, 0, -1)) && is_writable(substr($Vi4nmsrluxec, 0, -1))) {
                file_put_contents($Vi4nmsrluxec . $Vdiqkcy1hsm4ache_name, '<?php return ' . var_export($V3o5lzcfvwzz, true) . ';');
            }
            $V3o5lzcfvwzz = null;
        }

        if (!isset($Vvkqsaecgfirhis->fonts[$Vfsinbbqzbga])) {
            $Vvkqsaecgfirhis->addMessage("openFont: no font file found for $Vfsinbbqzbga. Do you need to run load_font.php?");
        }

        
    }

    
    function selectFont($VfsinbbqzbgaName, $Vpxiihrwof30 = '', $Vzftygch2mns = true)
    {
        $Vafkpyuxax5a = substr($VfsinbbqzbgaName, -4);
        if ($Vafkpyuxax5a === '.afm' || $Vafkpyuxax5a === '.ufm') {
            $VfsinbbqzbgaName = substr($VfsinbbqzbgaName, 0, mb_strlen($VfsinbbqzbgaName) - 4);
        }

        if (!isset($Vvkqsaecgfirhis->fonts[$VfsinbbqzbgaName])) {
            $Vvkqsaecgfirhis->addMessage("selectFont: selecting - $VfsinbbqzbgaName - $Vpxiihrwof30, $Vzftygch2mns");

            
            $Vvkqsaecgfirhis->openFont($VfsinbbqzbgaName);

            if (isset($Vvkqsaecgfirhis->fonts[$VfsinbbqzbgaName])) {
                $Vvkqsaecgfirhis->numObj++;
                $Vvkqsaecgfirhis->numFonts++;

                $Vfsinbbqzbga = &$Vvkqsaecgfirhis->fonts[$VfsinbbqzbgaName];

                
                $V2d1s45w0hjoos = strrpos($VfsinbbqzbgaName, '/');
                
                $Vreuchxnm2nm = substr($VfsinbbqzbgaName, $V2d1s45w0hjoos + 1);
                $V3vmzyblbtdy = array('name' => $Vreuchxnm2nm, 'fontFileName' => $VfsinbbqzbgaName);

                if (is_array($Vpxiihrwof30)) {
                    
                    if (isset($Vpxiihrwof30['encoding'])) {
                        $V3vmzyblbtdy['encoding'] = $Vpxiihrwof30['encoding'];
                    }

                    if (isset($Vpxiihrwof30['differences'])) {
                        $V3vmzyblbtdy['differences'] = $Vpxiihrwof30['differences'];
                    }
                } else {
                    if (mb_strlen($Vpxiihrwof30, '8bit')) {
                        
                        $V3vmzyblbtdy['encoding'] = $Vpxiihrwof30;
                    }
                }

                $VfsinbbqzbgaObj = $Vvkqsaecgfirhis->numObj;
                $Vvkqsaecgfirhis->o_font($Vvkqsaecgfirhis->numObj, 'new', $V3vmzyblbtdy);
                $Vfsinbbqzbga['fontNum'] = $Vvkqsaecgfirhis->numFonts;

                
                
                
                $Vkbvefdrfvxhasefile = $VfsinbbqzbgaName;

                $Vsqo1hwhyl1b = '';
                if (file_exists("$Vkbvefdrfvxhasefile.pfb")) {
                    $Vsqo1hwhyl1b = 'pfb';
                } else {
                    if (file_exists("$Vkbvefdrfvxhasefile.ttf")) {
                        $Vsqo1hwhyl1b = 'ttf';
                    }
                }

                $Vit1vhtmie0t = "$Vkbvefdrfvxhasefile.$Vsqo1hwhyl1b";

                
                
                $Vvkqsaecgfirhis->addMessage('selectFont: checking for - ' . $Vit1vhtmie0t);

                
                
                if ($Vsqo1hwhyl1b) {
                    $V4dkbhpdu11qdobeFontName = isset($Vfsinbbqzbga['PostScriptName']) ? $Vfsinbbqzbga['PostScriptName'] : $Vfsinbbqzbga['FontName'];
                    
                    $Vvkqsaecgfirhis->addMessage("selectFont: adding font file - $Vit1vhtmie0t - $V4dkbhpdu11qdobeFontName");

                    
                    $Vqicu5kp3ypq = -1;
                    $Vr31otg5kji1 = 0;
                    $V5ymvwogwh5yidths = array();
                    $Vn4yxa1pskaa = array();

                    foreach ($Vfsinbbqzbga['C'] as $Vaucqj0hftp5 => $Vngrhfhlmiyg) {
                        if (intval($Vaucqj0hftp5) > 0 || $Vaucqj0hftp5 == '0') {
                            if (!$Vfsinbbqzbga['isUnicode']) {
                                
                                if ($Vr31otg5kji1 > 0 && $Vaucqj0hftp5 > $Vr31otg5kji1 + 1) {
                                    for ($V0ixz2v5mxzy = $Vr31otg5kji1 + 1; $V0ixz2v5mxzy < $Vaucqj0hftp5; $V0ixz2v5mxzy++) {
                                        $V5ymvwogwh5yidths[] = 0;
                                    }
                                }
                            }

                            $V5ymvwogwh5yidths[] = $Vngrhfhlmiyg;

                            if ($Vfsinbbqzbga['isUnicode']) {
                                $Vn4yxa1pskaa[$Vaucqj0hftp5] = $Vngrhfhlmiyg;
                            }

                            if ($Vqicu5kp3ypq == -1) {
                                $Vqicu5kp3ypq = $Vaucqj0hftp5;
                            }

                            $Vr31otg5kji1 = $Vaucqj0hftp5;
                        }
                    }

                    
                    if (isset($V3vmzyblbtdy['differences'])) {
                        foreach ($V3vmzyblbtdy['differences'] as $Vdiqkcy1hsm4harNum => $Vdiqkcy1hsm4harName) {
                            if ($Vdiqkcy1hsm4harNum > $Vr31otg5kji1) {
                                if (!$Vfsinbbqzbga['isUnicode']) {
                                    
                                    for ($V0ixz2v5mxzy = $Vr31otg5kji1 + 1; $V0ixz2v5mxzy <= $Vdiqkcy1hsm4harNum; $V0ixz2v5mxzy++) {
                                        $V5ymvwogwh5yidths[] = 0;
                                    }
                                }

                                $Vr31otg5kji1 = $Vdiqkcy1hsm4harNum;
                            }

                            if (isset($Vfsinbbqzbga['C'][$Vdiqkcy1hsm4harName])) {
                                $V5ymvwogwh5yidths[$Vdiqkcy1hsm4harNum - $Vqicu5kp3ypq] = $Vfsinbbqzbga['C'][$Vdiqkcy1hsm4harName];
                                if ($Vfsinbbqzbga['isUnicode']) {
                                    $Vn4yxa1pskaa[$Vdiqkcy1hsm4harName] = $Vfsinbbqzbga['C'][$Vdiqkcy1hsm4harName];
                                }
                            }
                        }
                    }

                    if ($Vfsinbbqzbga['isUnicode']) {
                        $Vfsinbbqzbga['CIDWidths'] = $Vn4yxa1pskaa;
                    }

                    $Vvkqsaecgfirhis->addMessage('selectFont: FirstChar = ' . $Vqicu5kp3ypq);
                    $Vvkqsaecgfirhis->addMessage('selectFont: LastChar = ' . $Vr31otg5kji1);

                    $V5ymvwogwh5yidthid = -1;

                    if (!$Vfsinbbqzbga['isUnicode']) {
                        

                        $Vvkqsaecgfirhis->numObj++;
                        $Vvkqsaecgfirhis->o_contents($Vvkqsaecgfirhis->numObj, 'new', 'raw');
                        $Vvkqsaecgfirhis->objects[$Vvkqsaecgfirhis->numObj]['c'] .= '[' . implode(' ', $V5ymvwogwh5yidths) . ']';
                        $V5ymvwogwh5yidthid = $Vvkqsaecgfirhis->numObj;
                    }

                    $Vbnkqh1pyufh = 500;
                    $V31xnxucw0o4 = 70;

                    if (isset($Vfsinbbqzbga['MissingWidth'])) {
                        $Vbnkqh1pyufh = $Vfsinbbqzbga['MissingWidth'];
                    }
                    if (isset($Vfsinbbqzbga['StdVW'])) {
                        $V31xnxucw0o4 = $Vfsinbbqzbga['StdVW'];
                    } else {
                        if (isset($Vfsinbbqzbga['Weight']) && preg_match('!(bold|black)!i', $Vfsinbbqzbga['Weight'])) {
                            $V31xnxucw0o4 = 120;
                        }
                    }

                    
                    
                    
                    
                    if (!$Vvkqsaecgfirhis->isUnicode || $Vsqo1hwhyl1b !== 'ttf' || empty($Vvkqsaecgfirhis->stringSubsets)) {
                        $V3o5lzcfvwzz = file_get_contents($Vit1vhtmie0t);
                    } else {
                        $Vvkqsaecgfirhis->stringSubsets[$VfsinbbqzbgaName][] = 32; 

                        $Vc2pexddbgmh = $Vvkqsaecgfirhis->stringSubsets[$VfsinbbqzbgaName];
                        sort($Vc2pexddbgmh);

                        
                        $Vfsinbbqzbga_obj = Font::load($Vit1vhtmie0t);
                        $Vfsinbbqzbga_obj->parse();

                        
                        $Vfsinbbqzbga_obj->setSubset($Vc2pexddbgmh);
                        $Vfsinbbqzbga_obj->reduce();

                        
                        $Vj0eqma35tbv_name = "$Vit1vhtmie0t.tmp." . uniqid();
                        $Vfsinbbqzbga_obj->open($Vj0eqma35tbv_name, Font_Binary_Stream::modeWrite);
                        $Vfsinbbqzbga_obj->encode(array("OS/2"));
                        $Vfsinbbqzbga_obj->close();

                        
                        $Vfsinbbqzbga_obj = Font::load($Vj0eqma35tbv_name);

                        
                        $Vxd4s5gofbp5 = null;
                        foreach ($Vfsinbbqzbga_obj->getData("cmap", "subtables") as $Vosvsokzeg25) {
                            if ($Vosvsokzeg25["platformID"] == 0 || $Vosvsokzeg25["platformID"] == 3 && $Vosvsokzeg25["platformSpecificID"] == 1) {
                                $Vxd4s5gofbp5 = $Vosvsokzeg25;
                                break;
                            }
                        }

                        if ($Vxd4s5gofbp5) {
                            $VllkwhuxxhtbIndexArray = $Vxd4s5gofbp5["glyphIndexArray"];
                            $Vpb4vmo2kh0h = $Vfsinbbqzbga_obj->getData("hmtx");

                            unset($VllkwhuxxhtbIndexArray[0xFFFF]);

                            $Vonrbka2saaqtogid = str_pad('', max(array_keys($VllkwhuxxhtbIndexArray)) * 2 + 1, "\x00");
                            $Vfsinbbqzbga['CIDWidths'] = array();
                            foreach ($VllkwhuxxhtbIndexArray as $Vonrbka2saaq => $V2hwvubg2icz) {
                                if ($Vonrbka2saaq >= 0 && $Vonrbka2saaq < 0xFFFF && $V2hwvubg2icz) {
                                    $Vonrbka2saaqtogid[$Vonrbka2saaq * 2] = chr($V2hwvubg2icz >> 8);
                                    $Vonrbka2saaqtogid[$Vonrbka2saaq * 2 + 1] = chr($V2hwvubg2icz & 0xFF);
                                }

                                $V5ymvwogwh5yidth = $Vfsinbbqzbga_obj->normalizeFUnit(isset($Vpb4vmo2kh0h[$V2hwvubg2icz]) ? $Vpb4vmo2kh0h[$V2hwvubg2icz][0] : $Vpb4vmo2kh0h[0][0]);
                                $Vfsinbbqzbga['CIDWidths'][$Vonrbka2saaq] = $V5ymvwogwh5yidth;
                            }

                            $Vfsinbbqzbga['CIDtoGID'] = base64_encode(gzcompress($Vonrbka2saaqtogid));
                            $Vfsinbbqzbga['CIDtoGID_Compressed'] = true;

                            $V3o5lzcfvwzz = file_get_contents($Vj0eqma35tbv_name);
                        } else {
                            $V3o5lzcfvwzz = file_get_contents($Vit1vhtmie0t);
                        }

                        $Vfsinbbqzbga_obj->close();
                        unlink($Vj0eqma35tbv_name);
                    }

                    
                    $Vvkqsaecgfirhis->numObj++;
                    $VfsinbbqzbgaDescriptorId = $Vvkqsaecgfirhis->numObj;

                    $Vvkqsaecgfirhis->numObj++;
                    $V2d1s45w0hjofbid = $Vvkqsaecgfirhis->numObj;

                    
                    $V1d5qg5z2u4i = 0;

                    if ($Vfsinbbqzbga['ItalicAngle'] != 0) {
                        $V1d5qg5z2u4i += pow(2, 6);
                    }

                    if ($Vfsinbbqzbga['IsFixedPitch'] === 'true') {
                        $V1d5qg5z2u4i += 1;
                    }

                    $V1d5qg5z2u4i += pow(2, 5); 
                    $Vpwkm1lt1nvs = array(
                        'Ascent'       => 'Ascender',
                        'CapHeight'    => 'CapHeight',
                        'MissingWidth' => 'MissingWidth',
                        'Descent'      => 'Descender',
                        'FontBBox'     => 'FontBBox',
                        'ItalicAngle'  => 'ItalicAngle'
                    );
                    $V0igzx4tm4ay = array(
                        'Flags'    => $V1d5qg5z2u4i,
                        'FontName' => $V4dkbhpdu11qdobeFontName,
                        'StemV'    => $V31xnxucw0o4
                    );

                    foreach ($Vpwkm1lt1nvs as $Vawllmnnfede => $Vfanetclug4s) {
                        if (isset($Vfsinbbqzbga[$Vfanetclug4s])) {
                            $V0igzx4tm4ay[$Vawllmnnfede] = $Vfsinbbqzbga[$Vfanetclug4s];
                        }
                    }

                    if ($Vsqo1hwhyl1b === 'pfb') {
                        $V0igzx4tm4ay['FontFile'] = $V2d1s45w0hjofbid;
                    } else {
                        if ($Vsqo1hwhyl1b === 'ttf') {
                            $V0igzx4tm4ay['FontFile2'] = $V2d1s45w0hjofbid;
                        }
                    }

                    $Vvkqsaecgfirhis->o_fontDescriptor($VfsinbbqzbgaDescriptorId, 'new', $V0igzx4tm4ay);

                    
                    $Vvkqsaecgfirhis->o_contents($Vvkqsaecgfirhis->numObj, 'new');
                    $Vvkqsaecgfirhis->objects[$V2d1s45w0hjofbid]['c'] .= $V3o5lzcfvwzz;

                    
                    if ($Vsqo1hwhyl1b === 'pfb') {
                        $Vlxvv11iz3yr = strpos($V3o5lzcfvwzz, 'eexec') + 6;
                        $Vuk5rugwiv1v = strpos($V3o5lzcfvwzz, '00000000') - $Vlxvv11iz3yr;
                        $Voqw3o5l5adx = mb_strlen($V3o5lzcfvwzz, '8bit') - $Vuk5rugwiv1v - $Vlxvv11iz3yr;
                        $Vvkqsaecgfirhis->o_contents(
                            $Vvkqsaecgfirhis->numObj,
                            'add',
                            array('Length1' => $Vlxvv11iz3yr, 'Length2' => $Vuk5rugwiv1v, 'Length3' => $Voqw3o5l5adx)
                        );
                    } else {
                        if ($Vsqo1hwhyl1b == 'ttf') {
                            $Vlxvv11iz3yr = mb_strlen($V3o5lzcfvwzz, '8bit');
                            $Vvkqsaecgfirhis->o_contents($Vvkqsaecgfirhis->numObj, 'add', array('Length1' => $Vlxvv11iz3yr));
                        }
                    }

                    
                    $Vj0eqma35tbv = array(
                        'BaseFont'       => $V4dkbhpdu11qdobeFontName,
                        'MissingWidth'   => $Vbnkqh1pyufh,
                        'Widths'         => $V5ymvwogwh5yidthid,
                        'FirstChar'      => $Vqicu5kp3ypq,
                        'LastChar'       => $Vr31otg5kji1,
                        'FontDescriptor' => $VfsinbbqzbgaDescriptorId
                    );

                    if ($Vsqo1hwhyl1b === 'ttf') {
                        $Vj0eqma35tbv['SubType'] = 'TrueType';
                    }

                    $Vvkqsaecgfirhis->addMessage("adding extra info to font.($VfsinbbqzbgaObj)");

                    foreach ($Vj0eqma35tbv as $V31qylvyzefz => $V3ys3chl0ev0) {
                        $Vvkqsaecgfirhis->addMessage("$V31qylvyzefz : $V3ys3chl0ev0");
                    }

                    $Vvkqsaecgfirhis->o_font($VfsinbbqzbgaObj, 'add', $Vj0eqma35tbv);
                } else {
                    $Vvkqsaecgfirhis->addMessage(
                        'selectFont: pfb or ttf file not found, ok if this is one of the 14 standard fonts'
                    );
                }

                
                
                if (isset($V3vmzyblbtdy['differences'])) {
                    $Vfsinbbqzbga['differences'] = $V3vmzyblbtdy['differences'];
                }
            }
        }

        if ($Vzftygch2mns && isset($Vvkqsaecgfirhis->fonts[$VfsinbbqzbgaName])) {
            
            $Vvkqsaecgfirhis->currentBaseFont = $VfsinbbqzbgaName;

            
            
            $Vvkqsaecgfirhis->currentFont = $Vvkqsaecgfirhis->currentBaseFont;
            $Vvkqsaecgfirhis->currentFontNum = $Vvkqsaecgfirhis->fonts[$Vvkqsaecgfirhis->currentFont]['fontNum'];

            
        }

        return $Vvkqsaecgfirhis->currentFontNum;
        
    }

    
    private function setCurrentFont()
    {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        $Vvkqsaecgfirhis->currentFont = $Vvkqsaecgfirhis->currentBaseFont;
        $Vvkqsaecgfirhis->currentFontNum = $Vvkqsaecgfirhis->fonts[$Vvkqsaecgfirhis->currentFont]['fontNum'];
        
    }

    
    function getFirstPageId()
    {
        return $Vvkqsaecgfirhis->firstPageId;
    }

    
    private function addContent($Vdiqkcy1hsm4ontent)
    {
        $Vvkqsaecgfirhis->objects[$Vvkqsaecgfirhis->currentContents]['c'] .= $Vdiqkcy1hsm4ontent;
    }

    
    function setColor($Vdiqkcy1hsm4olor, $Vrle1ugwagfk = false)
    {
        $Vu440l53e414ew_color = array($Vdiqkcy1hsm4olor[0], $Vdiqkcy1hsm4olor[1], $Vdiqkcy1hsm4olor[2], isset($Vdiqkcy1hsm4olor[3]) ? $Vdiqkcy1hsm4olor[3] : null);

        if (!$Vrle1ugwagfk && $Vvkqsaecgfirhis->currentColor == $Vu440l53e414ew_color) {
            return;
        }

        if (isset($Vu440l53e414ew_color[3])) {
            
            $Vvkqsaecgfirhis->addContent(vsprintf("\n%.3F %.3F %.3F %.3F k", $Vvkqsaecgfirhis->currentColor));
        } else {
            if (isset($Vu440l53e414ew_color[2])) {
                
                $Vvkqsaecgfirhis->addContent(vsprintf("\n%.3F %.3F %.3F rg", $Vu440l53e414ew_color));
            }
        }
    }

    
    function setFillRule($Vhrrdmbfdnur)
    {
        if (!in_array($Vhrrdmbfdnur, array("nonzero", "evenodd"))) {
            return;
        }

        $Vvkqsaecgfirhis->fillRule = $Vhrrdmbfdnur;
    }

    
    function setStrokeColor($Vdiqkcy1hsm4olor, $Vrle1ugwagfk = false)
    {
        $Vu440l53e414ew_color = array($Vdiqkcy1hsm4olor[0], $Vdiqkcy1hsm4olor[1], $Vdiqkcy1hsm4olor[2], isset($Vdiqkcy1hsm4olor[3]) ? $Vdiqkcy1hsm4olor[3] : null);

        if (!$Vrle1ugwagfk && $Vvkqsaecgfirhis->currentStrokeColor == $Vu440l53e414ew_color) {
            return;
        }

        if (isset($Vu440l53e414ew_color[3])) {
            
            $Vvkqsaecgfirhis->addContent(vsprintf("\n%.3F %.3F %.3F %.3F K", $Vvkqsaecgfirhis->currentStrokeColor));
        } else {
            if (isset($Vu440l53e414ew_color[2])) {
                
                $Vvkqsaecgfirhis->addContent(vsprintf("\n%.3F %.3F %.3F RG", $Vu440l53e414ew_color));
            }
        }
    }

    
    function setGraphicsState($V2d1s45w0hjoarameters)
    {
        
        
        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_extGState($Vvkqsaecgfirhis->numObj, 'new', $V2d1s45w0hjoarameters);
        $Vvkqsaecgfirhis->addContent("\n/GS$Vvkqsaecgfirhis->numStates gs");
    }

    
    function setLineTransparency($V4rgua51nlxl, $Vyea2e2tvrvzpacity)
    {
        static $Vkbvefdrfvxhlend_modes = array(
            "Normal",
            "Multiply",
            "Screen",
            "Overlay",
            "Darken",
            "Lighten",
            "ColorDogde",
            "ColorBurn",
            "HardLight",
            "SoftLight",
            "Difference",
            "Exclusion"
        );

        if (!in_array($V4rgua51nlxl, $Vkbvefdrfvxhlend_modes)) {
            $V4rgua51nlxl = "Normal";
        }

        
        if ($V4rgua51nlxl === $Vvkqsaecgfirhis->currentLineTransparency["mode"] &&
            $Vyea2e2tvrvzpacity == $Vvkqsaecgfirhis->currentLineTransparency["opacity"]
        ) {
            return;
        }

        $Vvkqsaecgfirhis->currentLineTransparency["mode"] = $V4rgua51nlxl;
        $Vvkqsaecgfirhis->currentLineTransparency["opacity"] = $Vyea2e2tvrvzpacity;

        $V3vmzyblbtdy = array(
            "BM" => "/$V4rgua51nlxl",
            "CA" => (float)$Vyea2e2tvrvzpacity
        );

        $Vvkqsaecgfirhis->setGraphicsState($V3vmzyblbtdy);
    }

    
    function setFillTransparency($V4rgua51nlxl, $Vyea2e2tvrvzpacity)
    {
        static $Vkbvefdrfvxhlend_modes = array(
            "Normal",
            "Multiply",
            "Screen",
            "Overlay",
            "Darken",
            "Lighten",
            "ColorDogde",
            "ColorBurn",
            "HardLight",
            "SoftLight",
            "Difference",
            "Exclusion"
        );

        if (!in_array($V4rgua51nlxl, $Vkbvefdrfvxhlend_modes)) {
            $V4rgua51nlxl = "Normal";
        }

        if ($V4rgua51nlxl === $Vvkqsaecgfirhis->currentFillTransparency["mode"] &&
            $Vyea2e2tvrvzpacity == $Vvkqsaecgfirhis->currentFillTransparency["opacity"]
        ) {
            return;
        }

        $Vvkqsaecgfirhis->currentFillTransparency["mode"] = $V4rgua51nlxl;
        $Vvkqsaecgfirhis->currentFillTransparency["opacity"] = $Vyea2e2tvrvzpacity;

        $V3vmzyblbtdy = array(
            "BM" => "/$V4rgua51nlxl",
            "ca" => (float)$Vyea2e2tvrvzpacity,
        );

        $Vvkqsaecgfirhis->setGraphicsState($V3vmzyblbtdy);
    }

    function lineTo($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $Vvkqsaecgfirhis->addContent(sprintf("\n%.3F %.3F l", $Vmm2pe5l4str, $Vuua0v2znlr5));
    }

    function moveTo($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $Vvkqsaecgfirhis->addContent(sprintf("\n%.3F %.3F m", $Vmm2pe5l4str, $Vuua0v2znlr5));
    }

    
    function curveTo($V4wnp2r2nst5, $V2e3azycubv1, $Vmm2pe5l4str2, $Vuua0v2znlr52, $Vmm2pe5l4str3, $Vuua0v2znlr53)
    {
        $Vvkqsaecgfirhis->addContent(sprintf("\n%.3F %.3F %.3F %.3F %.3F %.3F c", $V4wnp2r2nst5, $V2e3azycubv1, $Vmm2pe5l4str2, $Vuua0v2znlr52, $Vmm2pe5l4str3, $Vuua0v2znlr53));
    }

    
    function quadTo($Vdiqkcy1hsm4px, $Vdiqkcy1hsm4py, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $Vvkqsaecgfirhis->addContent(sprintf("\n%.3F %.3F %.3F %.3F v", $Vdiqkcy1hsm4px, $Vdiqkcy1hsm4py, $Vmm2pe5l4str, $Vuua0v2znlr5));
    }

    function closePath()
    {
        $Vvkqsaecgfirhis->addContent(' h');
    }

    function endPath()
    {
        $Vvkqsaecgfirhis->addContent(' n');
    }

    
    function ellipse(
        $Vo0naudmyq00,
        $Viibdokojojj,
        $Vapguowxhnfz,
        $V1wjrukdrpg5 = 0,
        $V4dkbhpdu11qngle = 0,
        $Vu440l53e414Seg = 8,
        $V4dkbhpdu11qstart = 0,
        $V4dkbhpdu11qfinish = 360,
        $Vdiqkcy1hsm4lose = true,
        $Vbopclc0ksnj = false,
        $Vleb2mixglzb = true,
        $V0ixz2v5mxzyncomplete = false
    ) {
        if ($Vapguowxhnfz == 0) {
            return;
        }

        if ($V1wjrukdrpg5 == 0) {
            $V1wjrukdrpg5 = $Vapguowxhnfz;
        }

        if ($Vu440l53e414Seg < 2) {
            $Vu440l53e414Seg = 2;
        }

        $V4dkbhpdu11qstart = deg2rad((float)$V4dkbhpdu11qstart);
        $V4dkbhpdu11qfinish = deg2rad((float)$V4dkbhpdu11qfinish);
        $VvkqsaecgfirotalAngle = $V4dkbhpdu11qfinish - $V4dkbhpdu11qstart;

        $Vngrhfhlmiygt = $VvkqsaecgfirotalAngle / $Vu440l53e414Seg;
        $Vngrhfhlmiygtm = $Vngrhfhlmiygt / 3;

        if ($V4dkbhpdu11qngle != 0) {
            $V4dkbhpdu11q = -1 * deg2rad((float)$V4dkbhpdu11qngle);

            $Vvkqsaecgfirhis->addContent(
                sprintf("\n q %.3F %.3F %.3F %.3F %.3F %.3F cm", cos($V4dkbhpdu11q), -sin($V4dkbhpdu11q), sin($V4dkbhpdu11q), cos($V4dkbhpdu11q), $Vo0naudmyq00, $Viibdokojojj)
            );

            $Vo0naudmyq00 = 0;
            $Viibdokojojj = 0;
        }

        $Vvkqsaecgfir1 = $V4dkbhpdu11qstart;
        $V4dkbhpdu11q0 = $Vo0naudmyq00 + $Vapguowxhnfz * cos($Vvkqsaecgfir1);
        $Vkbvefdrfvxh0 = $Viibdokojojj + $V1wjrukdrpg5 * sin($Vvkqsaecgfir1);
        $Vdiqkcy1hsm40 = -$Vapguowxhnfz * sin($Vvkqsaecgfir1);
        $Vngrhfhlmiyg0 = $V1wjrukdrpg5 * cos($Vvkqsaecgfir1);

        if (!$V0ixz2v5mxzyncomplete) {
            $Vvkqsaecgfirhis->addContent(sprintf("\n%.3F %.3F m ", $V4dkbhpdu11q0, $Vkbvefdrfvxh0));
        }

        for ($V0ixz2v5mxzy = 1; $V0ixz2v5mxzy <= $Vu440l53e414Seg; $V0ixz2v5mxzy++) {
            
            $Vvkqsaecgfir1 = $V0ixz2v5mxzy * $Vngrhfhlmiygt + $V4dkbhpdu11qstart;
            $V4dkbhpdu11q1 = $Vo0naudmyq00 + $Vapguowxhnfz * cos($Vvkqsaecgfir1);
            $Vkbvefdrfvxh1 = $Viibdokojojj + $V1wjrukdrpg5 * sin($Vvkqsaecgfir1);
            $Vdiqkcy1hsm41 = -$Vapguowxhnfz * sin($Vvkqsaecgfir1);
            $Vngrhfhlmiyg1 = $V1wjrukdrpg5 * cos($Vvkqsaecgfir1);

            $Vvkqsaecgfirhis->addContent(
                sprintf(
                    "\n%.3F %.3F %.3F %.3F %.3F %.3F c",
                    ($V4dkbhpdu11q0 + $Vdiqkcy1hsm40 * $Vngrhfhlmiygtm),
                    ($Vkbvefdrfvxh0 + $Vngrhfhlmiyg0 * $Vngrhfhlmiygtm),
                    ($V4dkbhpdu11q1 - $Vdiqkcy1hsm41 * $Vngrhfhlmiygtm),
                    ($Vkbvefdrfvxh1 - $Vngrhfhlmiyg1 * $Vngrhfhlmiygtm),
                    $V4dkbhpdu11q1,
                    $Vkbvefdrfvxh1
                )
            );

            $V4dkbhpdu11q0 = $V4dkbhpdu11q1;
            $Vkbvefdrfvxh0 = $Vkbvefdrfvxh1;
            $Vdiqkcy1hsm40 = $Vdiqkcy1hsm41;
            $Vngrhfhlmiyg0 = $Vngrhfhlmiyg1;
        }

        if (!$V0ixz2v5mxzyncomplete) {
            if ($Vbopclc0ksnj) {
                $Vvkqsaecgfirhis->addContent(' f');
            }

            if ($Vleb2mixglzb) {
                if ($Vdiqkcy1hsm4lose) {
                    $Vvkqsaecgfirhis->addContent(' s'); 
                } else {
                    $Vvkqsaecgfirhis->addContent(' S');
                }
            }
        }

        if ($V4dkbhpdu11qngle != 0) {
            $Vvkqsaecgfirhis->addContent(' Q');
        }
    }

    
    function setLineStyle($V5ymvwogwh5yidth = 1, $Vdiqkcy1hsm4ap = '', $Vy4wtqjehnh5oin = '', $Vngrhfhlmiygash = '', $V2d1s45w0hjohase = 0)
    {
        
        $Vo3pamb05rqg = '';

        if ($V5ymvwogwh5yidth > 0) {
            $Vo3pamb05rqg .= sprintf("%.3F w", $V5ymvwogwh5yidth);
        }

        $Vdiqkcy1hsm4a = array('butt' => 0, 'round' => 1, 'square' => 2);

        if (isset($Vdiqkcy1hsm4a[$Vdiqkcy1hsm4ap])) {
            $Vo3pamb05rqg .= " $Vdiqkcy1hsm4a[$Vdiqkcy1hsm4ap] J";
        }

        $Vy4wtqjehnh5a = array('miter' => 0, 'round' => 1, 'bevel' => 2);

        if (isset($Vy4wtqjehnh5a[$Vy4wtqjehnh5oin])) {
            $Vo3pamb05rqg .= " $Vy4wtqjehnh5a[$Vy4wtqjehnh5oin] j";
        }

        if (is_array($Vngrhfhlmiygash)) {
            $Vo3pamb05rqg .= ' [ ' . implode(' ', $Vngrhfhlmiygash) . " ] $V2d1s45w0hjohase d";
        }

        $Vvkqsaecgfirhis->currentLineStyle = $Vo3pamb05rqg;
        $Vvkqsaecgfirhis->addContent("\n$Vo3pamb05rqg");
    }

    function rect($V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5yidth, $Vxtfrabd3i5r)
    {
        $Vvkqsaecgfirhis->addContent(sprintf("\n%.3F %.3F %.3F %.3F re", $V4wnp2r2nst5, $V2e3azycubv1, $V5ymvwogwh5yidth, $Vxtfrabd3i5r));
    }

    function stroke()
    {
        $Vvkqsaecgfirhis->addContent("\nS");
    }

    function fill()
    {
        $Vvkqsaecgfirhis->addContent("\nf".($Vvkqsaecgfirhis->fillRule === "evenodd" ? "*" : ""));
    }

    function fillStroke()
    {
        $Vvkqsaecgfirhis->addContent("\nb".($Vvkqsaecgfirhis->fillRule === "evenodd" ? "*" : ""));
    }

    
    function save()
    {
        $Vvkqsaecgfirhis->addContent("\nq");
    }

    
    function restore()
    {
        $Vvkqsaecgfirhis->addContent("\nQ");
    }

    
    function scale($Vb01jpbrlun1, $Vt5g1id0c1cp, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $Vuua0v2znlr5 = $Vvkqsaecgfirhis->currentPageSize["height"] - $Vuua0v2znlr5;

        $Vvkqsaecgfirm = array(
            $Vb01jpbrlun1,            0,
            0,               $Vt5g1id0c1cp,
            $Vmm2pe5l4str * (1 - $Vb01jpbrlun1), $Vuua0v2znlr5 * (1 - $Vt5g1id0c1cp)
        );

        $Vvkqsaecgfirhis->transform($Vvkqsaecgfirm);
    }

    
    function translate($Vvkqsaecgfir_x, $Vvkqsaecgfir_y)
    {
        $Vvkqsaecgfirm = array(
            1,    0,
            0,    1,
            $Vvkqsaecgfir_x, -$Vvkqsaecgfir_y
        );

        $Vvkqsaecgfirhis->transform($Vvkqsaecgfirm);
    }

    
    function rotate($V4dkbhpdu11qngle, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $Vuua0v2znlr5 = $Vvkqsaecgfirhis->currentPageSize["height"] - $Vuua0v2znlr5;

        $V4dkbhpdu11q = deg2rad($V4dkbhpdu11qngle);
        $Vdiqkcy1hsm4os_a = cos($V4dkbhpdu11q);
        $V5xfoxteciyj = sin($V4dkbhpdu11q);

        $Vvkqsaecgfirm = array(
            $Vdiqkcy1hsm4os_a,                         -$V5xfoxteciyj,
            $V5xfoxteciyj,                         $Vdiqkcy1hsm4os_a,
            $Vmm2pe5l4str - $V5xfoxteciyj * $Vuua0v2znlr5 - $Vdiqkcy1hsm4os_a * $Vmm2pe5l4str, $Vuua0v2znlr5 - $Vdiqkcy1hsm4os_a * $Vuua0v2znlr5 + $V5xfoxteciyj * $Vmm2pe5l4str,
        );

        $Vvkqsaecgfirhis->transform($Vvkqsaecgfirm);
    }

    
    function skew($V4dkbhpdu11qngle_x, $V4dkbhpdu11qngle_y, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        $Vuua0v2znlr5 = $Vvkqsaecgfirhis->currentPageSize["height"] - $Vuua0v2znlr5;

        $Vvkqsaecgfiran_x = tan(deg2rad($V4dkbhpdu11qngle_x));
        $Vvkqsaecgfiran_y = tan(deg2rad($V4dkbhpdu11qngle_y));

        $Vvkqsaecgfirm = array(
            1,           -$Vvkqsaecgfiran_y,
            -$Vvkqsaecgfiran_x,     1,
            $Vvkqsaecgfiran_x * $Vuua0v2znlr5, $Vvkqsaecgfiran_y * $Vmm2pe5l4str,
        );

        $Vvkqsaecgfirhis->transform($Vvkqsaecgfirm);
    }

    
    function transform($Vvkqsaecgfirm)
    {
        $Vvkqsaecgfirhis->addContent(vsprintf("\n %.3F %.3F %.3F %.3F %.3F %.3F cm", $Vvkqsaecgfirm));
    }

    
    function newPage($V0ixz2v5mxzynsert = 0, $Vawfntrfsy4f = 0, $V2d1s45w0hjoos = 'after')
    {
        
        

        if ($Vvkqsaecgfirhis->nStateStack) {
            for ($V0ixz2v5mxzy = $Vvkqsaecgfirhis->nStateStack; $V0ixz2v5mxzy >= 1; $V0ixz2v5mxzy--) {
                $Vvkqsaecgfirhis->restoreState($V0ixz2v5mxzy);
            }
        }

        $Vvkqsaecgfirhis->numObj++;

        if ($V0ixz2v5mxzynsert) {
            
            
            $Vklcdm0ycthb = $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['onPage'];
            $Vyea2e2tvrvzpt = array('rid' => $Vklcdm0ycthb, 'pos' => $V2d1s45w0hjoos);
            $Vvkqsaecgfirhis->o_page($Vvkqsaecgfirhis->numObj, 'new', $Vyea2e2tvrvzpt);
        } else {
            $Vvkqsaecgfirhis->o_page($Vvkqsaecgfirhis->numObj, 'new');
        }

        
        if ($Vvkqsaecgfirhis->nStateStack) {
            for ($V0ixz2v5mxzy = 1; $V0ixz2v5mxzy <= $Vvkqsaecgfirhis->nStateStack; $V0ixz2v5mxzy++) {
                $Vvkqsaecgfirhis->saveState($V0ixz2v5mxzy);
            }
        }

        
        if (isset($Vvkqsaecgfirhis->currentColor)) {
            $Vvkqsaecgfirhis->setColor($Vvkqsaecgfirhis->currentColor, true);
        }

        if (isset($Vvkqsaecgfirhis->currentStrokeColor)) {
            $Vvkqsaecgfirhis->setStrokeColor($Vvkqsaecgfirhis->currentStrokeColor, true);
        }

        
        if (mb_strlen($Vvkqsaecgfirhis->currentLineStyle, '8bit')) {
            $Vvkqsaecgfirhis->addContent("\n$Vvkqsaecgfirhis->currentLineStyle");
        }

        
        return $Vvkqsaecgfirhis->currentContents;
    }

    
    function stream($V3vmzyblbtdy = '')
    {
        
        
        
        
        
        
        
        
        
        if (!is_array($V3vmzyblbtdy)) {
            $V3vmzyblbtdy = array();
        }

        if (headers_sent()) {
            die("Unable to stream pdf: headers already sent");
        }

        $V5hve4hi5ntx = empty($V3vmzyblbtdy['compression']);
        $Vj0eqma35tbv = ltrim($Vvkqsaecgfirhis->output($V5hve4hi5ntx));

        header("Cache-Control: private");
        header("Content-type: application/pdf");

        
        header("Content-Length: " . mb_strlen($Vj0eqma35tbv, '8bit'));
        $Voheucoc3jxvName = (isset($V3vmzyblbtdy['Content-Disposition']) ? $V3vmzyblbtdy['Content-Disposition'] : 'file.pdf');

        if (!isset($V3vmzyblbtdy["Attachment"])) {
            $V3vmzyblbtdy["Attachment"] = true;
        }

        $V4dkbhpdu11qttachment = $V3vmzyblbtdy["Attachment"] ? "attachment" : "inline";

        
        $Vpxiihrwof30 = mb_detect_encoding($Voheucoc3jxvName);
        $Vjnduidtzzbp = mb_convert_encoding($Voheucoc3jxvName, "ISO-8859-1", $Vpxiihrwof30);
        $Vh2e1rjkiw05 = rawurlencode($Vjnduidtzzbp);
        $Vmm1r0at23av = rawurlencode($Voheucoc3jxvName);

        header(
            "Content-Disposition: $V4dkbhpdu11qttachment; filename=" . $Vh2e1rjkiw05 . "; filename*=UTF-8''$Vmm1r0at23av"
        );

        if (isset($V3vmzyblbtdy['Accept-Ranges']) && $V3vmzyblbtdy['Accept-Ranges'] == 1) {
            
            header("Accept-Ranges: " . mb_strlen($Vj0eqma35tbv, '8bit'));
        }

        echo $Vj0eqma35tbv;
        flush();
    }

    
    function getFontHeight($Vkgj34o34uaw)
    {
        if (!$Vvkqsaecgfirhis->numFonts) {
            $Vvkqsaecgfirhis->selectFont($Vvkqsaecgfirhis->defaultFont);
        }

        $Vfsinbbqzbga = $Vvkqsaecgfirhis->fonts[$Vvkqsaecgfirhis->currentFont];

        
        if (isset($Vfsinbbqzbga['Ascender']) && isset($Vfsinbbqzbga['Descender'])) {
            $V2pgp3ppbjsi = $Vfsinbbqzbga['Ascender'] - $Vfsinbbqzbga['Descender'];
        } else {
            $V2pgp3ppbjsi = $Vfsinbbqzbga['FontBBox'][3] - $Vfsinbbqzbga['FontBBox'][1];
        }

        
        
        if (isset($Vfsinbbqzbga['FontHeightOffset'])) {
            
            
            
            
            
            
            
            $V2pgp3ppbjsi += (int)$Vfsinbbqzbga['FontHeightOffset'];
        }

        return $Vkgj34o34uaw * $V2pgp3ppbjsi / 1000;
    }

    function getFontXHeight($Vkgj34o34uaw)
    {
        if (!$Vvkqsaecgfirhis->numFonts) {
            $Vvkqsaecgfirhis->selectFont($Vvkqsaecgfirhis->defaultFont);
        }

        $Vfsinbbqzbga = $Vvkqsaecgfirhis->fonts[$Vvkqsaecgfirhis->currentFont];

        
        if (isset($Vfsinbbqzbga['XHeight'])) {
            $Vmm2pe5l4strh = $Vfsinbbqzbga['Ascender'] - $Vfsinbbqzbga['Descender'];
        } else {
            $Vmm2pe5l4strh = $Vvkqsaecgfirhis->getFontHeight($Vkgj34o34uaw) / 2;
        }

        return $Vkgj34o34uaw * $Vmm2pe5l4strh / 1000;
    }

    
    function getFontDescender($Vkgj34o34uaw)
    {
        
        if (!$Vvkqsaecgfirhis->numFonts) {
            $Vvkqsaecgfirhis->selectFont($Vvkqsaecgfirhis->defaultFont);
        }

        
        $V2pgp3ppbjsi = $Vvkqsaecgfirhis->fonts[$Vvkqsaecgfirhis->currentFont]['Descender'];

        return $Vkgj34o34uaw * $V2pgp3ppbjsi / 1000;
    }

    
    function filterText($Vvkqsaecgfirext, $Vkbvefdrfvxhom = true, $Vdiqkcy1hsm4onvert_encoding = true)
    {
        if (!$Vvkqsaecgfirhis->numFonts) {
            $Vvkqsaecgfirhis->selectFont($Vvkqsaecgfirhis->defaultFont);
        }

        if ($Vdiqkcy1hsm4onvert_encoding) {
            $Vdiqkcy1hsm4f = $Vvkqsaecgfirhis->currentFont;
            if (isset($Vvkqsaecgfirhis->fonts[$Vdiqkcy1hsm4f]) && $Vvkqsaecgfirhis->fonts[$Vdiqkcy1hsm4f]['isUnicode']) {
                
                $Vvkqsaecgfirext = $Vvkqsaecgfirhis->utf8toUtf16BE($Vvkqsaecgfirext, $Vkbvefdrfvxhom);
            } else {
                
                $Vvkqsaecgfirext = mb_convert_encoding($Vvkqsaecgfirext, self::$Vot44mazdlom, 'UTF-8');
            }
        }

        
        return strtr($Vvkqsaecgfirext, array(')' => '\\)', '(' => '\\(', '\\' => '\\\\', chr(13) => '\r'));
    }

    
    private function getTextPosition($Vmm2pe5l4str, $Vuua0v2znlr5, $V4dkbhpdu11qngle, $Vkgj34o34uaw, $V5ymvwogwh5ya, $Vvkqsaecgfirext)
    {
        
        $V5ymvwogwh5y = $Vvkqsaecgfirhis->getTextWidth($Vkgj34o34uaw, $Vvkqsaecgfirext);

        
        $V5ymvwogwh5yords = explode(' ', $Vvkqsaecgfirext);
        $Vu440l53e414spaces = count($V5ymvwogwh5yords) - 1;
        $V5ymvwogwh5y += $V5ymvwogwh5ya * $Vu440l53e414spaces;
        $V4dkbhpdu11q = deg2rad((float)$V4dkbhpdu11qngle);

        return array(cos($V4dkbhpdu11q) * $V5ymvwogwh5y + $Vmm2pe5l4str, -sin($V4dkbhpdu11q) * $V5ymvwogwh5y + $Vuua0v2znlr5);
    }

    
    function toUpper($Vmms5wlre01jes)
    {
        return mb_strtoupper($Vmms5wlre01jes[0]);
    }

    function concatMatches($Vmms5wlre01jes)
    {
        $Vu5vpgek1hmh = "";
        foreach ($Vmms5wlre01jes as $Vmms5wlre01j) {
            $Vu5vpgek1hmh .= $Vmms5wlre01j[0];
        }

        return $Vu5vpgek1hmh;
    }

    
    function registerText($Vfsinbbqzbga, $Vvkqsaecgfirext)
    {
        if (!$Vvkqsaecgfirhis->isUnicode || in_array(mb_strtolower(basename($Vfsinbbqzbga)), self::$Vjtfix3mp15d)) {
            return;
        }

        if (!isset($Vvkqsaecgfirhis->stringSubsets[$Vfsinbbqzbga])) {
            $Vvkqsaecgfirhis->stringSubsets[$Vfsinbbqzbga] = array();
        }

        $Vvkqsaecgfirhis->stringSubsets[$Vfsinbbqzbga] = array_unique(
            array_merge($Vvkqsaecgfirhis->stringSubsets[$Vfsinbbqzbga], $Vvkqsaecgfirhis->utf8toCodePointsArray($Vvkqsaecgfirext))
        );
    }

    
    function addText($Vmm2pe5l4str, $Vuua0v2znlr5, $Vkgj34o34uaw, $Vvkqsaecgfirext, $V4dkbhpdu11qngle = 0, $Vb4t3wdrzwyn = 0, $Vx4imetagn3p = 0, $Vggrmzwbpvrk = false)
    {
        if (!$Vvkqsaecgfirhis->numFonts) {
            $Vvkqsaecgfirhis->selectFont($Vvkqsaecgfirhis->defaultFont);
        }

        $Vvkqsaecgfirext = str_replace(array("\r", "\n"), "", $Vvkqsaecgfirext);

        if ($Vggrmzwbpvrk) {
            preg_match_all("/(\P{Ll}+)/u", $Vvkqsaecgfirext, $Vmms5wlre01jes, PREG_SET_ORDER);
            $Vyhc0qglkxvu = $Vvkqsaecgfirhis->concatMatches($Vmms5wlre01jes);
            d($Vyhc0qglkxvu);

            preg_match_all("/(\p{Ll}+)/u", $Vvkqsaecgfirext, $Vmms5wlre01jes, PREG_SET_ORDER);
            $Vyea2e2tvrvzther = $Vvkqsaecgfirhis->concatMatches($Vmms5wlre01jes);
            d($Vyea2e2tvrvzther);

            
        }

        
        if ($Vvkqsaecgfirhis->nCallback > 0) {
            for ($V0ixz2v5mxzy = $Vvkqsaecgfirhis->nCallback; $V0ixz2v5mxzy > 0; $V0ixz2v5mxzy--) {
                
                $V0ixz2v5mxzynfo = array(
                    'x'         => $Vmm2pe5l4str,
                    'y'         => $Vuua0v2znlr5,
                    'angle'     => $V4dkbhpdu11qngle,
                    'status'    => 'sol',
                    'p'         => $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['p'],
                    'nCallback' => $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['nCallback'],
                    'height'    => $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['height'],
                    'descender' => $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['descender']
                );

                $Vla2pizivviu = $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['f'];
                $Vvkqsaecgfirhis->$Vla2pizivviu($V0ixz2v5mxzynfo);
            }
        }

        if ($V4dkbhpdu11qngle == 0) {
            $Vvkqsaecgfirhis->addContent(sprintf("\nBT %.3F %.3F Td", $Vmm2pe5l4str, $Vuua0v2znlr5));
        } else {
            $V4dkbhpdu11q = deg2rad((float)$V4dkbhpdu11qngle);
            $Vvkqsaecgfirhis->addContent(
                sprintf("\nBT %.3F %.3F %.3F %.3F %.3F %.3F Tm", cos($V4dkbhpdu11q), -sin($V4dkbhpdu11q), sin($V4dkbhpdu11q), cos($V4dkbhpdu11q), $Vmm2pe5l4str, $Vuua0v2znlr5)
            );
        }

        if ($Vb4t3wdrzwyn != 0 || $Vb4t3wdrzwyn != $Vvkqsaecgfirhis->wordSpaceAdjust) {
            $Vvkqsaecgfirhis->wordSpaceAdjust = $Vb4t3wdrzwyn;
            $Vvkqsaecgfirhis->addContent(sprintf(" %.3F Tw", $Vb4t3wdrzwyn));
        }

        if ($Vx4imetagn3p != 0 || $Vx4imetagn3p != $Vvkqsaecgfirhis->charSpaceAdjust) {
            $Vvkqsaecgfirhis->charSpaceAdjust = $Vx4imetagn3p;
            $Vvkqsaecgfirhis->addContent(sprintf(" %.3F Tc", $Vx4imetagn3p));
        }

        $Vukikbvg40ol = mb_strlen($Vvkqsaecgfirext);
        $Vyaw1hu5o3zh = 0;

        if ($Vyaw1hu5o3zh < $Vukikbvg40ol) {
            $V2d1s45w0hjoart = $Vvkqsaecgfirext; 
            $V2d1s45w0hjolace_text = $Vvkqsaecgfirhis->filterText($V2d1s45w0hjoart, false);
            
            $Vdiqkcy1hsm4f = $Vvkqsaecgfirhis->currentFont;
            if ($Vvkqsaecgfirhis->fonts[$Vdiqkcy1hsm4f]['isUnicode'] && $Vb4t3wdrzwyn != 0) {
                $Vi4gp4mepwcf = 1000 / $Vkgj34o34uaw;
                
                $V2d1s45w0hjolace_text = str_replace(' ', ' ) ' . (-round($Vi4gp4mepwcf * $Vb4t3wdrzwyn)) . ' (', $V2d1s45w0hjolace_text);
            }
            $Vvkqsaecgfirhis->addContent(" /F$Vvkqsaecgfirhis->currentFontNum " . sprintf('%.1F Tf ', $Vkgj34o34uaw));
            $Vvkqsaecgfirhis->addContent(" [($V2d1s45w0hjolace_text)] TJ");
        }

        $Vvkqsaecgfirhis->addContent(' ET');

        
        if ($Vvkqsaecgfirhis->nCallback > 0) {
            for ($V0ixz2v5mxzy = $Vvkqsaecgfirhis->nCallback; $V0ixz2v5mxzy > 0; $V0ixz2v5mxzy--) {
                
                $Vj0eqma35tbv = $Vvkqsaecgfirhis->getTextPosition($Vmm2pe5l4str, $Vuua0v2znlr5, $V4dkbhpdu11qngle, $Vkgj34o34uaw, $Vb4t3wdrzwyn, $Vvkqsaecgfirext);
                $V0ixz2v5mxzynfo = array(
                    'x'         => $Vj0eqma35tbv[0],
                    'y'         => $Vj0eqma35tbv[1],
                    'angle'     => $V4dkbhpdu11qngle,
                    'status'    => 'eol',
                    'p'         => $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['p'],
                    'nCallback' => $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['nCallback'],
                    'height'    => $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['height'],
                    'descender' => $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['descender']
                );
                $Vla2pizivviu = $Vvkqsaecgfirhis->callback[$V0ixz2v5mxzy]['f'];
                $Vvkqsaecgfirhis->$Vla2pizivviu($V0ixz2v5mxzynfo);
            }
        }
    }

    
    function getTextWidth($Vkgj34o34uaw, $Vvkqsaecgfirext, $V5ymvwogwh5yord_spacing = 0, $Vdiqkcy1hsm4har_spacing = 0)
    {
        static $Vyea2e2tvrvzrd_cache = array();

        
        
        
        $Vz3or1iejm3x = $Vvkqsaecgfirhis->currentTextState;

        if (!$Vvkqsaecgfirhis->numFonts) {
            $Vvkqsaecgfirhis->selectFont($Vvkqsaecgfirhis->defaultFont);
        }

        $Vvkqsaecgfirext = str_replace(array("\r", "\n"), "", $Vvkqsaecgfirext);

        
        $Vvkqsaecgfirext = "$Vvkqsaecgfirext";

        
        
        $V5ymvwogwh5y = 0;
        $Vdiqkcy1hsm4f = $Vvkqsaecgfirhis->currentFont;
        $Vdiqkcy1hsm4urrent_font = $Vvkqsaecgfirhis->fonts[$Vdiqkcy1hsm4f];
        $Vi4gp4mepwcf = 1000 / ($Vkgj34o34uaw > 0 ? $Vkgj34o34uaw : 1);
        $Vu440l53e414_spaces = 0;

        if ($Vdiqkcy1hsm4urrent_font['isUnicode']) {
            
            
            $Vs5izqjhzanz = $Vvkqsaecgfirhis->utf8toCodePointsArray($Vvkqsaecgfirext);

            foreach ($Vs5izqjhzanz as $Vdiqkcy1hsm4har) {
                
                if (isset($Vdiqkcy1hsm4urrent_font['differences'][$Vdiqkcy1hsm4har])) {
                    $Vdiqkcy1hsm4har = $Vdiqkcy1hsm4urrent_font['differences'][$Vdiqkcy1hsm4har];
                }

                if (isset($Vdiqkcy1hsm4urrent_font['C'][$Vdiqkcy1hsm4har])) {
                    $Vdiqkcy1hsm4har_width = $Vdiqkcy1hsm4urrent_font['C'][$Vdiqkcy1hsm4har];

                    
                    $V5ymvwogwh5y += $Vdiqkcy1hsm4har_width;

                    
                    if (isset($Vdiqkcy1hsm4urrent_font['codeToName'][$Vdiqkcy1hsm4har]) && $Vdiqkcy1hsm4urrent_font['codeToName'][$Vdiqkcy1hsm4har] === 'space') {  
                        $V5ymvwogwh5y += $V5ymvwogwh5yord_spacing * $Vi4gp4mepwcf;
                        $Vu440l53e414_spaces++;
                    }
                }
            }

            
            if ($Vdiqkcy1hsm4har_spacing != 0) {
                $V5ymvwogwh5y += $Vdiqkcy1hsm4har_spacing * $Vi4gp4mepwcf * (count($Vs5izqjhzanz) + $Vu440l53e414_spaces);
            }

        } else {
            
            if ($Vvkqsaecgfirhis->isUnicode) {
                $Vvkqsaecgfirext = mb_convert_encoding($Vvkqsaecgfirext, 'Windows-1252', 'UTF-8');
            }

            $Vukikbvg40ol = mb_strlen($Vvkqsaecgfirext, 'Windows-1252');

            for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vukikbvg40ol; $V0ixz2v5mxzy++) {
                $Vdiqkcy1hsm4 = $Vvkqsaecgfirext[$V0ixz2v5mxzy];
                $Vdiqkcy1hsm4har = isset($Vyea2e2tvrvzrd_cache[$Vdiqkcy1hsm4]) ? $Vyea2e2tvrvzrd_cache[$Vdiqkcy1hsm4] : ($Vyea2e2tvrvzrd_cache[$Vdiqkcy1hsm4] = ord($Vdiqkcy1hsm4));

                
                if (isset($Vdiqkcy1hsm4urrent_font['differences'][$Vdiqkcy1hsm4har])) {
                    $Vdiqkcy1hsm4har = $Vdiqkcy1hsm4urrent_font['differences'][$Vdiqkcy1hsm4har];
                }

                if (isset($Vdiqkcy1hsm4urrent_font['C'][$Vdiqkcy1hsm4har])) {
                    $Vdiqkcy1hsm4har_width = $Vdiqkcy1hsm4urrent_font['C'][$Vdiqkcy1hsm4har];

                    
                    $V5ymvwogwh5y += $Vdiqkcy1hsm4har_width;

                    
                    if (isset($Vdiqkcy1hsm4urrent_font['codeToName'][$Vdiqkcy1hsm4har]) && $Vdiqkcy1hsm4urrent_font['codeToName'][$Vdiqkcy1hsm4har] === 'space') {  
                        $V5ymvwogwh5y += $V5ymvwogwh5yord_spacing * $Vi4gp4mepwcf;
                        $Vu440l53e414_spaces++;
                    }
                }
            }

            
            if ($Vdiqkcy1hsm4har_spacing != 0) {
                $V5ymvwogwh5y += $Vdiqkcy1hsm4har_spacing * $Vi4gp4mepwcf * ($Vukikbvg40ol + $Vu440l53e414_spaces);
            }
        }

        $Vvkqsaecgfirhis->currentTextState = $Vz3or1iejm3x;
        $Vvkqsaecgfirhis->setCurrentFont();

        return $V5ymvwogwh5y * $Vkgj34o34uaw / 1000;
    }

    
    function saveState($V2d1s45w0hjoageEnd = 0)
    {
        if ($V2d1s45w0hjoageEnd) {
            
            
            
            $Vyea2e2tvrvzpt = $Vvkqsaecgfirhis->stateStack[$V2d1s45w0hjoageEnd];
            
            $Vvkqsaecgfirhis->setColor($Vyea2e2tvrvzpt['col'], true);
            $Vvkqsaecgfirhis->setStrokeColor($Vyea2e2tvrvzpt['str'], true);
            $Vvkqsaecgfirhis->addContent("\n" . $Vyea2e2tvrvzpt['lin']);
            
        } else {
            $Vvkqsaecgfirhis->nStateStack++;
            $Vvkqsaecgfirhis->stateStack[$Vvkqsaecgfirhis->nStateStack] = array(
                'col' => $Vvkqsaecgfirhis->currentColor,
                'str' => $Vvkqsaecgfirhis->currentStrokeColor,
                'lin' => $Vvkqsaecgfirhis->currentLineStyle
            );
        }

        $Vvkqsaecgfirhis->save();
    }

    
    function restoreState($V2d1s45w0hjoageEnd = 0)
    {
        if (!$V2d1s45w0hjoageEnd) {
            $Vu440l53e414 = $Vvkqsaecgfirhis->nStateStack;
            $Vvkqsaecgfirhis->currentColor = $Vvkqsaecgfirhis->stateStack[$Vu440l53e414]['col'];
            $Vvkqsaecgfirhis->currentStrokeColor = $Vvkqsaecgfirhis->stateStack[$Vu440l53e414]['str'];
            $Vvkqsaecgfirhis->addContent("\n" . $Vvkqsaecgfirhis->stateStack[$Vu440l53e414]['lin']);
            $Vvkqsaecgfirhis->currentLineStyle = $Vvkqsaecgfirhis->stateStack[$Vu440l53e414]['lin'];
            $Vvkqsaecgfirhis->stateStack[$Vu440l53e414] = null;
            unset($Vvkqsaecgfirhis->stateStack[$Vu440l53e414]);
            $Vvkqsaecgfirhis->nStateStack--;
        }

        $Vvkqsaecgfirhis->restore();
    }

    
    function openObject()
    {
        $Vvkqsaecgfirhis->nStack++;
        $Vvkqsaecgfirhis->stack[$Vvkqsaecgfirhis->nStack] = array('c' => $Vvkqsaecgfirhis->currentContents, 'p' => $Vvkqsaecgfirhis->currentPage);
        
        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_contents($Vvkqsaecgfirhis->numObj, 'new');
        $Vvkqsaecgfirhis->currentContents = $Vvkqsaecgfirhis->numObj;
        $Vvkqsaecgfirhis->looseObjects[$Vvkqsaecgfirhis->numObj] = 1;

        return $Vvkqsaecgfirhis->numObj;
    }

    
    function reopenObject($Vawfntrfsy4f)
    {
        $Vvkqsaecgfirhis->nStack++;
        $Vvkqsaecgfirhis->stack[$Vvkqsaecgfirhis->nStack] = array('c' => $Vvkqsaecgfirhis->currentContents, 'p' => $Vvkqsaecgfirhis->currentPage);
        $Vvkqsaecgfirhis->currentContents = $Vawfntrfsy4f;

        
        if (isset($Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['onPage'])) {
            $Vvkqsaecgfirhis->currentPage = $Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]['onPage'];
        }
    }

    
    function closeObject()
    {
        
        
        if ($Vvkqsaecgfirhis->nStack > 0) {
            $Vvkqsaecgfirhis->currentContents = $Vvkqsaecgfirhis->stack[$Vvkqsaecgfirhis->nStack]['c'];
            $Vvkqsaecgfirhis->currentPage = $Vvkqsaecgfirhis->stack[$Vvkqsaecgfirhis->nStack]['p'];
            $Vvkqsaecgfirhis->nStack--;
            
            
        }
    }

    
    function stopObject($Vawfntrfsy4f)
    {
        
        
        if (isset($Vvkqsaecgfirhis->addLooseObjects[$Vawfntrfsy4f])) {
            $Vvkqsaecgfirhis->addLooseObjects[$Vawfntrfsy4f] = '';
        }
    }

    
    function addObject($Vawfntrfsy4f, $V3vmzyblbtdy = 'add')
    {
        
        if (isset($Vvkqsaecgfirhis->looseObjects[$Vawfntrfsy4f]) && $Vvkqsaecgfirhis->currentContents != $Vawfntrfsy4f) {
            
            switch ($V3vmzyblbtdy) {
                case 'all':
                    
                    
                    $Vvkqsaecgfirhis->addLooseObjects[$Vawfntrfsy4f] = 'all';

                case 'add':
                    if (isset($Vvkqsaecgfirhis->objects[$Vvkqsaecgfirhis->currentContents]['onPage'])) {
                        
                        
                        $Vvkqsaecgfirhis->o_page($Vvkqsaecgfirhis->objects[$Vvkqsaecgfirhis->currentContents]['onPage'], 'content', $Vawfntrfsy4f);
                    }
                    break;

                case 'even':
                    $Vvkqsaecgfirhis->addLooseObjects[$Vawfntrfsy4f] = 'even';
                    $V2d1s45w0hjoageObjectId = $Vvkqsaecgfirhis->objects[$Vvkqsaecgfirhis->currentContents]['onPage'];
                    if ($Vvkqsaecgfirhis->objects[$V2d1s45w0hjoageObjectId]['info']['pageNum'] % 2 == 0) {
                        $Vvkqsaecgfirhis->addObject($Vawfntrfsy4f);
                        
                    }
                    break;

                case 'odd':
                    $Vvkqsaecgfirhis->addLooseObjects[$Vawfntrfsy4f] = 'odd';
                    $V2d1s45w0hjoageObjectId = $Vvkqsaecgfirhis->objects[$Vvkqsaecgfirhis->currentContents]['onPage'];
                    if ($Vvkqsaecgfirhis->objects[$V2d1s45w0hjoageObjectId]['info']['pageNum'] % 2 == 1) {
                        $Vvkqsaecgfirhis->addObject($Vawfntrfsy4f);
                        
                    }
                    break;

                case 'next':
                    $Vvkqsaecgfirhis->addLooseObjects[$Vawfntrfsy4f] = 'all';
                    break;

                case 'nexteven':
                    $Vvkqsaecgfirhis->addLooseObjects[$Vawfntrfsy4f] = 'even';
                    break;

                case 'nextodd':
                    $Vvkqsaecgfirhis->addLooseObjects[$Vawfntrfsy4f] = 'odd';
                    break;
            }
        }
    }

    
    function serializeObject($Vawfntrfsy4f)
    {
        if (array_key_exists($Vawfntrfsy4f, $Vvkqsaecgfirhis->objects)) {
            return serialize($Vvkqsaecgfirhis->objects[$Vawfntrfsy4f]);
        }
    }

    
    function restoreSerializedObject($Vyea2e2tvrvzbj)
    {
        $Vyea2e2tvrvzbj_id = $Vvkqsaecgfirhis->openObject();
        $Vvkqsaecgfirhis->objects[$Vyea2e2tvrvzbj_id] = unserialize($Vyea2e2tvrvzbj);
        $Vvkqsaecgfirhis->closeObject();

        return $Vyea2e2tvrvzbj_id;
    }

    
    function addInfo($Vovi5zubtdii, $Vfanetclug4salue = 0)
    {
        
        
        
        
        if (is_array($Vovi5zubtdii)) {
            foreach ($Vovi5zubtdii as $V3fvqcsh5wgl => $Vfanetclug4s) {
                $Vvkqsaecgfirhis->o_info($Vvkqsaecgfirhis->infoObject, $V3fvqcsh5wgl, $Vfanetclug4s);
            }
        } else {
            $Vvkqsaecgfirhis->o_info($Vvkqsaecgfirhis->infoObject, $Vovi5zubtdii, $Vfanetclug4salue);
        }
    }

    
    function setPreferences($Vovi5zubtdii, $Vfanetclug4salue = 0)
    {
        
        if (is_array($Vovi5zubtdii)) {
            foreach ($Vovi5zubtdii as $V3fvqcsh5wgl => $Vfanetclug4s) {
                $Vvkqsaecgfirhis->o_catalog($Vvkqsaecgfirhis->catalogId, 'viewerPreferences', array($V3fvqcsh5wgl => $Vfanetclug4s));
            }
        } else {
            $Vvkqsaecgfirhis->o_catalog($Vvkqsaecgfirhis->catalogId, 'viewerPreferences', array($Vovi5zubtdii => $Vfanetclug4salue));
        }
    }

    
    private function getBytes(&$V3o5lzcfvwzz, $V2d1s45w0hjoos, $Vaucqj0hftp5)
    {
        
        $Vaamzcof1atz = 0;
        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $Vaucqj0hftp5; $V0ixz2v5mxzy++) {
            $Vaamzcof1atz *= 256;
            $Vaamzcof1atz += ord($V3o5lzcfvwzz[$V2d1s45w0hjoos + $V0ixz2v5mxzy]);
        }

        return $Vaamzcof1atz;
    }

    
    function image_iscached($V0ixz2v5mxzymgname)
    {
        return isset($Vvkqsaecgfirhis->imagelist[$V0ixz2v5mxzymgname]);
    }

    
    function addImagePng($Voheucoc3jxv, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y = 0.0, $V2pgp3ppbjsi = 0.0, &$V0ixz2v5mxzymg, $V0ixz2v5mxzys_mask = false, $V3fofr5b1pdf = null)
    {
        if (!function_exists("imagepng")) {
            throw new Exception("The PHP GD extension is required, but is not installed.");
        }

        
        if (isset($Vvkqsaecgfirhis->imagelist[$Voheucoc3jxv])) {
            $V3o5lzcfvwzz = null;
        } else {
            
            
            
            
            
            
            
            
            
            

            
            imagesavealpha($V0ixz2v5mxzymg, false);

            $Vropiebcst33 = 0;

            ob_start();
            @imagepng($V0ixz2v5mxzymg);
            $V3o5lzcfvwzz = ob_get_clean();

            if ($V3o5lzcfvwzz == '') {
                $Vropiebcst33 = 1;
                $Vropiebcst33msg = 'trouble writing file from GD';
            }

            if ($Vropiebcst33) {
                $Vvkqsaecgfirhis->addMessage('PNG error - (' . $Voheucoc3jxv . ') ' . $Vropiebcst33msg);

                return;
            }
        }  

        $Vvkqsaecgfirhis->addPngFromBuf($Voheucoc3jxv, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V3o5lzcfvwzz, $V0ixz2v5mxzys_mask, $V3fofr5b1pdf);
    }

    protected function addImagePngAlpha($Voheucoc3jxv, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vkbvefdrfvxhyte)
    {
        
        $V0ixz2v5mxzymg = imagecreatefrompng($Voheucoc3jxv);

        if ($V0ixz2v5mxzymg === false) {
            return;
        }

        
        $Vvtnk1sopduy = ($Vkbvefdrfvxhyte & 4) !== 4;

        $V5ymvwogwh5ypx = imagesx($V0ixz2v5mxzymg);
        $V2pgp3ppbjsipx = imagesy($V0ixz2v5mxzymg);

        imagesavealpha($V0ixz2v5mxzymg, false);

        
        $Vvkqsaecgfirempfile_alpha = tempnam($Vvkqsaecgfirhis->tmp, "cpdf_img_");
        @unlink($Vvkqsaecgfirempfile_alpha);
        $Vvkqsaecgfirempfile_alpha = "$Vvkqsaecgfirempfile_alpha.png";

        
        $Vvkqsaecgfirempfile_plain = tempnam($Vvkqsaecgfirhis->tmp, "cpdf_img_");
        @unlink($Vvkqsaecgfirempfile_plain);
        $Vvkqsaecgfirempfile_plain = "$Vvkqsaecgfirempfile_plain.png";

        $V0ixz2v5mxzymgalpha = imagecreate($V5ymvwogwh5ypx, $V2pgp3ppbjsipx);
        imagesavealpha($V0ixz2v5mxzymgalpha, false);

        
        for ($Vdiqkcy1hsm4 = 0; $Vdiqkcy1hsm4 < 256; ++$Vdiqkcy1hsm4) {
            imagecolorallocate($V0ixz2v5mxzymgalpha, $Vdiqkcy1hsm4, $Vdiqkcy1hsm4, $Vdiqkcy1hsm4);
        }

        
        if (extension_loaded("gmagick")) {
            $V5v2j00b2sjl = new Gmagick($Voheucoc3jxv);
            $V5v2j00b2sjl->setimageformat('png');

            
            $V4dkbhpdu11qlpha_channel_neg = clone $V5v2j00b2sjl;
            $V4dkbhpdu11qlpha_channel_neg->separateimagechannel(Gmagick::CHANNEL_OPACITY);

            
            $V4dkbhpdu11qlpha_channel = new Gmagick();
            $V4dkbhpdu11qlpha_channel->newimage($V5ymvwogwh5ypx, $V2pgp3ppbjsipx, "#FFFFFF", "png");
            $V4dkbhpdu11qlpha_channel->compositeimage($V4dkbhpdu11qlpha_channel_neg, Gmagick::COMPOSITE_DIFFERENCE, 0, 0);
            $V4dkbhpdu11qlpha_channel->separateimagechannel(Gmagick::CHANNEL_RED);
            $V4dkbhpdu11qlpha_channel->writeimage($Vvkqsaecgfirempfile_alpha);

            
            $V0ixz2v5mxzymgalpha_ = imagecreatefrompng($Vvkqsaecgfirempfile_alpha);
            imagecopy($V0ixz2v5mxzymgalpha, $V0ixz2v5mxzymgalpha_, 0, 0, 0, 0, $V5ymvwogwh5ypx, $V2pgp3ppbjsipx);
            imagedestroy($V0ixz2v5mxzymgalpha_);
            imagepng($V0ixz2v5mxzymgalpha, $Vvkqsaecgfirempfile_alpha);

            
            $Vdiqkcy1hsm4olor_channels = new Gmagick();
            $Vdiqkcy1hsm4olor_channels->newimage($V5ymvwogwh5ypx, $V2pgp3ppbjsipx, "#FFFFFF", "png");
            $Vdiqkcy1hsm4olor_channels->compositeimage($V5v2j00b2sjl, Gmagick::COMPOSITE_COPYRED, 0, 0);
            $Vdiqkcy1hsm4olor_channels->compositeimage($V5v2j00b2sjl, Gmagick::COMPOSITE_COPYGREEN, 0, 0);
            $Vdiqkcy1hsm4olor_channels->compositeimage($V5v2j00b2sjl, Gmagick::COMPOSITE_COPYBLUE, 0, 0);
            $Vdiqkcy1hsm4olor_channels->writeimage($Vvkqsaecgfirempfile_plain);

            $V0ixz2v5mxzymgplain = imagecreatefrompng($Vvkqsaecgfirempfile_plain);
        } 
        elseif (extension_loaded("imagick")) {
            
            
            static $V0ixz2v5mxzymagickClonable = null;
            if ($V0ixz2v5mxzymagickClonable === null) {
                $V0ixz2v5mxzymagickClonable = version_compare(phpversion('imagick'), '3.0.1rc1') > 0;
            }

            $V0ixz2v5mxzymagick = new Imagick($Voheucoc3jxv);
            $V0ixz2v5mxzymagick->setFormat('png');

            
            $V4dkbhpdu11qlpha_channel = $V0ixz2v5mxzymagickClonable ? clone $V0ixz2v5mxzymagick : $V0ixz2v5mxzymagick->clone();
            $V4dkbhpdu11qlpha_channel->separateImageChannel(Imagick::CHANNEL_ALPHA);
            $V4dkbhpdu11qlpha_channel->negateImage(true);
            $V4dkbhpdu11qlpha_channel->writeImage($Vvkqsaecgfirempfile_alpha);

            
            $V0ixz2v5mxzymgalpha_ = imagecreatefrompng($Vvkqsaecgfirempfile_alpha);
            imagecopy($V0ixz2v5mxzymgalpha, $V0ixz2v5mxzymgalpha_, 0, 0, 0, 0, $V5ymvwogwh5ypx, $V2pgp3ppbjsipx);
            imagedestroy($V0ixz2v5mxzymgalpha_);
            imagepng($V0ixz2v5mxzymgalpha, $Vvkqsaecgfirempfile_alpha);

            
            $Vdiqkcy1hsm4olor_channels = new Imagick();
            $Vdiqkcy1hsm4olor_channels->newImage($V5ymvwogwh5ypx, $V2pgp3ppbjsipx, "#FFFFFF", "png");
            $Vdiqkcy1hsm4olor_channels->compositeImage($V0ixz2v5mxzymagick, Imagick::COMPOSITE_COPYRED, 0, 0);
            $Vdiqkcy1hsm4olor_channels->compositeImage($V0ixz2v5mxzymagick, Imagick::COMPOSITE_COPYGREEN, 0, 0);
            $Vdiqkcy1hsm4olor_channels->compositeImage($V0ixz2v5mxzymagick, Imagick::COMPOSITE_COPYBLUE, 0, 0);
            $Vdiqkcy1hsm4olor_channels->writeImage($Vvkqsaecgfirempfile_plain);

            $V0ixz2v5mxzymgplain = imagecreatefrompng($Vvkqsaecgfirempfile_plain);
        } else {
            
            $V4dkbhpdu11qllocated_colors = array();

            
            for ($Vmm2pe5l4strpx = 0; $Vmm2pe5l4strpx < $V5ymvwogwh5ypx; ++$Vmm2pe5l4strpx) {
                for ($Vuua0v2znlr5px = 0; $Vuua0v2znlr5px < $V2pgp3ppbjsipx; ++$Vuua0v2znlr5px) {
                    $Vdiqkcy1hsm4olor = imagecolorat($V0ixz2v5mxzymg, $Vmm2pe5l4strpx, $Vuua0v2znlr5px);
                    $Vdiqkcy1hsm4ol = imagecolorsforindex($V0ixz2v5mxzymg, $Vdiqkcy1hsm4olor);
                    $V4dkbhpdu11qlpha = $Vdiqkcy1hsm4ol['alpha'];

                    if ($Vvtnk1sopduy) {
                        
                        $Vwvyy45o4jh2 = 2.2;
                        $V2d1s45w0hjoixel = pow((((127 - $V4dkbhpdu11qlpha) * 255 / 127) / 255), $Vwvyy45o4jh2) * 255;
                    } else {
                        
                        $V2d1s45w0hjoixel = (127 - $V4dkbhpdu11qlpha) * 2;

                        $Vawllmnnfedeey = $Vdiqkcy1hsm4ol['red'] . $Vdiqkcy1hsm4ol['green'] . $Vdiqkcy1hsm4ol['blue'];

                        if (!isset($V4dkbhpdu11qllocated_colors[$Vawllmnnfedeey])) {
                            $V2d1s45w0hjoixel_img = imagecolorallocate($V0ixz2v5mxzymg, $Vdiqkcy1hsm4ol['red'], $Vdiqkcy1hsm4ol['green'], $Vdiqkcy1hsm4ol['blue']);
                            $V4dkbhpdu11qllocated_colors[$Vawllmnnfedeey] = $V2d1s45w0hjoixel_img;
                        } else {
                            $V2d1s45w0hjoixel_img = $V4dkbhpdu11qllocated_colors[$Vawllmnnfedeey];
                        }

                        imagesetpixel($V0ixz2v5mxzymg, $Vmm2pe5l4strpx, $Vuua0v2znlr5px, $V2d1s45w0hjoixel_img);
                    }

                    imagesetpixel($V0ixz2v5mxzymgalpha, $Vmm2pe5l4strpx, $Vuua0v2znlr5px, $V2d1s45w0hjoixel);
                }
            }

            
            $V0ixz2v5mxzymgplain = imagecreatetruecolor($V5ymvwogwh5ypx, $V2pgp3ppbjsipx);
            imagecopy($V0ixz2v5mxzymgplain, $V0ixz2v5mxzymg, 0, 0, 0, 0, $V5ymvwogwh5ypx, $V2pgp3ppbjsipx);
            imagedestroy($V0ixz2v5mxzymg);

            imagepng($V0ixz2v5mxzymgalpha, $Vvkqsaecgfirempfile_alpha);
            imagepng($V0ixz2v5mxzymgplain, $Vvkqsaecgfirempfile_plain);
        }

        
        $Vvkqsaecgfirhis->addImagePng($Vvkqsaecgfirempfile_alpha, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V0ixz2v5mxzymgalpha, true);
        imagedestroy($V0ixz2v5mxzymgalpha);

        
        $Vvkqsaecgfirhis->addImagePng($Vvkqsaecgfirempfile_plain, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V0ixz2v5mxzymgplain, false, true);
        imagedestroy($V0ixz2v5mxzymgplain);

        
        unlink($Vvkqsaecgfirempfile_alpha);
        unlink($Vvkqsaecgfirempfile_plain);
    }

    
    function addPngFromFile($Voheucoc3jxv, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y = 0, $V2pgp3ppbjsi = 0)
    {
        if (!function_exists("imagecreatefrompng")) {
            throw new Exception("The PHP GD extension is required, but is not installed.");
        }

        
        if (isset($Vvkqsaecgfirhis->imagelist[$Voheucoc3jxv])) {
            $V0ixz2v5mxzymg = null;
        } else {
            $V0ixz2v5mxzynfo = file_get_contents($Voheucoc3jxv, false, null, 24, 5);
            $Vazzeshtjq43 = unpack("CbitDepth/CcolorType/CcompressionMethod/CfilterMethod/CinterlaceMethod", $V0ixz2v5mxzynfo);
            $Vkbvefdrfvxhit_depth = $Vazzeshtjq43["bitDepth"];
            $Vdiqkcy1hsm4olor_type = $Vazzeshtjq43["colorType"];

            
            
            
            
            $V0ixz2v5mxzys_alpha = in_array($Vdiqkcy1hsm4olor_type, array(4, 6)) || ($Vdiqkcy1hsm4olor_type == 3 && $Vkbvefdrfvxhit_depth != 4);

            if ($V0ixz2v5mxzys_alpha) { 
                return $Vvkqsaecgfirhis->addImagePngAlpha($Voheucoc3jxv, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vdiqkcy1hsm4olor_type);
            }

            
            
            
            
            
            
            
            
            
            
            $V0ixz2v5mxzymgtmp = @imagecreatefrompng($Voheucoc3jxv);
            if (!$V0ixz2v5mxzymgtmp) {
                return;
            }
            $V30sf4kzdv2b = imagesx($V0ixz2v5mxzymgtmp);
            $Vgd1odlz3me2 = imagesy($V0ixz2v5mxzymgtmp);
            $V0ixz2v5mxzymg = imagecreatetruecolor($V30sf4kzdv2b, $Vgd1odlz3me2);
            imagealphablending($V0ixz2v5mxzymg, true);

            
            $Vvkqsaecgfiri = imagecolortransparent($V0ixz2v5mxzymgtmp);
            if ($Vvkqsaecgfiri >= 0) {
                $Vvkqsaecgfirc = imagecolorsforindex($V0ixz2v5mxzymgtmp, $Vvkqsaecgfiri);
                $Vvkqsaecgfiri = imagecolorallocate($V0ixz2v5mxzymg, $Vvkqsaecgfirc['red'], $Vvkqsaecgfirc['green'], $Vvkqsaecgfirc['blue']);
                imagefill($V0ixz2v5mxzymg, 0, 0, $Vvkqsaecgfiri);
                imagecolortransparent($V0ixz2v5mxzymg, $Vvkqsaecgfiri);
            } else {
                imagefill($V0ixz2v5mxzymg, 1, 1, imagecolorallocate($V0ixz2v5mxzymg, 255, 255, 255));
            }

            imagecopy($V0ixz2v5mxzymg, $V0ixz2v5mxzymgtmp, 0, 0, 0, 0, $V30sf4kzdv2b, $Vgd1odlz3me2);
            imagedestroy($V0ixz2v5mxzymgtmp);
        }
        $Vvkqsaecgfirhis->addImagePng($Voheucoc3jxv, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V0ixz2v5mxzymg);

        if ($V0ixz2v5mxzymg) {
            imagedestroy($V0ixz2v5mxzymg);
        }
    }

    
    function addPngFromBuf($Voheucoc3jxv, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y = 0.0, $V2pgp3ppbjsi = 0.0, &$V3o5lzcfvwzz, $V0ixz2v5mxzys_mask = false, $V3fofr5b1pdf = null)
    {
        if (isset($Vvkqsaecgfirhis->imagelist[$Voheucoc3jxv])) {
            $V3o5lzcfvwzz = null;
            $V0ixz2v5mxzynfo['width'] = $Vvkqsaecgfirhis->imagelist[$Voheucoc3jxv]['w'];
            $V0ixz2v5mxzynfo['height'] = $Vvkqsaecgfirhis->imagelist[$Voheucoc3jxv]['h'];
            $Vovi5zubtdii = $Vvkqsaecgfirhis->imagelist[$Voheucoc3jxv]['label'];
        } else {
            if ($V3o5lzcfvwzz == null) {
                $Vvkqsaecgfirhis->addMessage('addPngFromBuf error - data not present!');

                return;
            }

            $Vropiebcst33 = 0;

            if (!$Vropiebcst33) {
                $V2pgp3ppbjsieader = chr(137) . chr(80) . chr(78) . chr(71) . chr(13) . chr(10) . chr(26) . chr(10);

                if (mb_substr($V3o5lzcfvwzz, 0, 8, '8bit') != $V2pgp3ppbjsieader) {
                    $Vropiebcst33 = 1;

                    $Vropiebcst33msg = 'this file does not have a valid header';
                }
            }

            if (!$Vropiebcst33) {
                
                $V2d1s45w0hjo = 8;
                $Vukikbvg40ol = mb_strlen($V3o5lzcfvwzz, '8bit');

                
                $V2pgp3ppbjsiaveHeader = 0;
                $V0ixz2v5mxzynfo = array();
                $Vawfntrfsy4fata = '';
                $V2d1s45w0hjodata = '';

                while ($V2d1s45w0hjo < $Vukikbvg40ol) {
                    $Vdiqkcy1hsm4hunkLen = $Vvkqsaecgfirhis->getBytes($V3o5lzcfvwzz, $V2d1s45w0hjo, 4);
                    $Vdiqkcy1hsm4hunkType = mb_substr($V3o5lzcfvwzz, $V2d1s45w0hjo + 4, 4, '8bit');

                    switch ($Vdiqkcy1hsm4hunkType) {
                        case 'IHDR':
                            
                            $V0ixz2v5mxzynfo['width'] = $Vvkqsaecgfirhis->getBytes($V3o5lzcfvwzz, $V2d1s45w0hjo + 8, 4);
                            $V0ixz2v5mxzynfo['height'] = $Vvkqsaecgfirhis->getBytes($V3o5lzcfvwzz, $V2d1s45w0hjo + 12, 4);
                            $V0ixz2v5mxzynfo['bitDepth'] = ord($V3o5lzcfvwzz[$V2d1s45w0hjo + 16]);
                            $V0ixz2v5mxzynfo['colorType'] = ord($V3o5lzcfvwzz[$V2d1s45w0hjo + 17]);
                            $V0ixz2v5mxzynfo['compressionMethod'] = ord($V3o5lzcfvwzz[$V2d1s45w0hjo + 18]);
                            $V0ixz2v5mxzynfo['filterMethod'] = ord($V3o5lzcfvwzz[$V2d1s45w0hjo + 19]);
                            $V0ixz2v5mxzynfo['interlaceMethod'] = ord($V3o5lzcfvwzz[$V2d1s45w0hjo + 20]);

                            
                            $V2pgp3ppbjsiaveHeader = 1;
                            if ($V0ixz2v5mxzynfo['compressionMethod'] != 0) {
                                $Vropiebcst33 = 1;

                                
                                if (DEBUGPNG) {
                                    print '[addPngFromFile unsupported compression method ' . $Voheucoc3jxv . ']';
                                }

                                $Vropiebcst33msg = 'unsupported compression method';
                            }

                            if ($V0ixz2v5mxzynfo['filterMethod'] != 0) {
                                $Vropiebcst33 = 1;

                                
                                if (DEBUGPNG) {
                                    print '[addPngFromFile unsupported filter method ' . $Voheucoc3jxv . ']';
                                }

                                $Vropiebcst33msg = 'unsupported filter method';
                            }
                            break;

                        case 'PLTE':
                            $V2d1s45w0hjodata .= mb_substr($V3o5lzcfvwzz, $V2d1s45w0hjo + 8, $Vdiqkcy1hsm4hunkLen, '8bit');
                            break;

                        case 'IDAT':
                            $Vawfntrfsy4fata .= mb_substr($V3o5lzcfvwzz, $V2d1s45w0hjo + 8, $Vdiqkcy1hsm4hunkLen, '8bit');
                            break;

                        case 'tRNS':
                            
                            
                            $Vswcdcl1pznz = array();

                            switch ($V0ixz2v5mxzynfo['colorType']) {
                                
                                case 3:
                                    
                                    
                                    
                                    $Vswcdcl1pznz['type'] = 'indexed';
                                    $Vvkqsaecgfirrans = 0;

                                    for ($V0ixz2v5mxzy = $Vdiqkcy1hsm4hunkLen; $V0ixz2v5mxzy >= 0; $V0ixz2v5mxzy--) {
                                        if (ord($V3o5lzcfvwzz[$V2d1s45w0hjo + 8 + $V0ixz2v5mxzy]) == 0) {
                                            $Vvkqsaecgfirrans = $V0ixz2v5mxzy;
                                        }
                                    }

                                    $Vswcdcl1pznz['data'] = $Vvkqsaecgfirrans;
                                    break;

                                
                                case 0:
                                    
                                    
                                    $Vswcdcl1pznz['type'] = 'indexed';
                                    $Vswcdcl1pznz['data'] = ord($V3o5lzcfvwzz[$V2d1s45w0hjo + 8 + 1]);
                                    break;

                                
                                case 2:
                                    
                                    $Vswcdcl1pznz['r'] = $Vvkqsaecgfirhis->getBytes($V3o5lzcfvwzz, $V2d1s45w0hjo + 8, 2);
                                    
                                    $Vswcdcl1pznz['g'] = $Vvkqsaecgfirhis->getBytes($V3o5lzcfvwzz, $V2d1s45w0hjo + 10, 2);
                                    
                                    $Vswcdcl1pznz['b'] = $Vvkqsaecgfirhis->getBytes($V3o5lzcfvwzz, $V2d1s45w0hjo + 12, 2);
                                    

                                    $Vswcdcl1pznz['type'] = 'color-key';
                                    break;

                                
                                default:
                                    if (DEBUGPNG) {
                                        print '[addPngFromFile unsupported transparency type ' . $Voheucoc3jxv . ']';
                                    }
                                    break;
                            }

                            
                            break;

                        default:
                            break;
                    }

                    $V2d1s45w0hjo += $Vdiqkcy1hsm4hunkLen + 12;
                }

                if (!$V2pgp3ppbjsiaveHeader) {
                    $Vropiebcst33 = 1;

                    
                    if (DEBUGPNG) {
                        print '[addPngFromFile information header is missing ' . $Voheucoc3jxv . ']';
                    }

                    $Vropiebcst33msg = 'information header is missing';
                }

                if (isset($V0ixz2v5mxzynfo['interlaceMethod']) && $V0ixz2v5mxzynfo['interlaceMethod']) {
                    $Vropiebcst33 = 1;

                    
                    if (DEBUGPNG) {
                        print '[addPngFromFile no support for interlaced images in pdf ' . $Voheucoc3jxv . ']';
                    }

                    $Vropiebcst33msg = 'There appears to be no support for interlaced images in pdf.';
                }
            }

            if (!$Vropiebcst33 && $V0ixz2v5mxzynfo['bitDepth'] > 8) {
                $Vropiebcst33 = 1;

                
                if (DEBUGPNG) {
                    print '[addPngFromFile bit depth of 8 or less is supported ' . $Voheucoc3jxv . ']';
                }

                $Vropiebcst33msg = 'only bit depth of 8 or less is supported';
            }

            if (!$Vropiebcst33) {
                switch ($V0ixz2v5mxzynfo['colorType']) {
                    case 3:
                        $Vdiqkcy1hsm4olor = 'DeviceRGB';
                        $Vu440l53e414color = 1;
                        break;

                    case 2:
                        $Vdiqkcy1hsm4olor = 'DeviceRGB';
                        $Vu440l53e414color = 3;
                        break;

                    case 0:
                        $Vdiqkcy1hsm4olor = 'DeviceGray';
                        $Vu440l53e414color = 1;
                        break;

                    default:
                        $Vropiebcst33 = 1;

                        
                        if (DEBUGPNG) {
                            print '[addPngFromFile alpha channel not supported: ' . $V0ixz2v5mxzynfo['colorType'] . ' ' . $Voheucoc3jxv . ']';
                        }

                        $Vropiebcst33msg = 'transparancey alpha channel not supported, transparency only supported for palette images.';
                }
            }

            if ($Vropiebcst33) {
                $Vvkqsaecgfirhis->addMessage('PNG error - (' . $Voheucoc3jxv . ') ' . $Vropiebcst33msg);

                return;
            }

            
            
            $Vvkqsaecgfirhis->numImages++;
            $V0ixz2v5mxzym = $Vvkqsaecgfirhis->numImages;
            $Vovi5zubtdii = "I$V0ixz2v5mxzym";
            $Vvkqsaecgfirhis->numObj++;

            
            $V3vmzyblbtdy = array(
                'label'            => $Vovi5zubtdii,
                'data'             => $Vawfntrfsy4fata,
                'bitsPerComponent' => $V0ixz2v5mxzynfo['bitDepth'],
                'pdata'            => $V2d1s45w0hjodata,
                'iw'               => $V0ixz2v5mxzynfo['width'],
                'ih'               => $V0ixz2v5mxzynfo['height'],
                'type'             => 'png',
                'color'            => $Vdiqkcy1hsm4olor,
                'ncolor'           => $Vu440l53e414color,
                'masked'           => $V3fofr5b1pdf,
                'isMask'           => $V0ixz2v5mxzys_mask
            );

            if (isset($Vswcdcl1pznz)) {
                $V3vmzyblbtdy['transparency'] = $Vswcdcl1pznz;
            }

            $Vvkqsaecgfirhis->o_image($Vvkqsaecgfirhis->numObj, 'new', $V3vmzyblbtdy);
            $Vvkqsaecgfirhis->imagelist[$Voheucoc3jxv] = array('label' => $Vovi5zubtdii, 'w' => $V0ixz2v5mxzynfo['width'], 'h' => $V0ixz2v5mxzynfo['height']);
        }

        if ($V0ixz2v5mxzys_mask) {
            return;
        }

        if ($V5ymvwogwh5y <= 0 && $V2pgp3ppbjsi <= 0) {
            $V5ymvwogwh5y = $V0ixz2v5mxzynfo['width'];
            $V2pgp3ppbjsi = $V0ixz2v5mxzynfo['height'];
        }

        if ($V5ymvwogwh5y <= 0) {
            $V5ymvwogwh5y = $V2pgp3ppbjsi / $V0ixz2v5mxzynfo['height'] * $V0ixz2v5mxzynfo['width'];
        }

        if ($V2pgp3ppbjsi <= 0) {
            $V2pgp3ppbjsi = $V5ymvwogwh5y * $V0ixz2v5mxzynfo['height'] / $V0ixz2v5mxzynfo['width'];
        }

        $Vvkqsaecgfirhis->addContent(sprintf("\nq\n%.3F 0 0 %.3F %.3F %.3F cm /%s Do\nQ", $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vovi5zubtdii));
    }

    
    function addJpegFromFile($V0ixz2v5mxzymg, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y = 0, $V2pgp3ppbjsi = 0)
    {
        
        

        if (!file_exists($V0ixz2v5mxzymg)) {
            return;
        }

        if ($Vvkqsaecgfirhis->image_iscached($V0ixz2v5mxzymg)) {
            $V3o5lzcfvwzz = null;
            $V0ixz2v5mxzymageWidth = $Vvkqsaecgfirhis->imagelist[$V0ixz2v5mxzymg]['w'];
            $V0ixz2v5mxzymageHeight = $Vvkqsaecgfirhis->imagelist[$V0ixz2v5mxzymg]['h'];
            $Vdiqkcy1hsm4hannels = $Vvkqsaecgfirhis->imagelist[$V0ixz2v5mxzymg]['c'];
        } else {
            $Vj0eqma35tbv = getimagesize($V0ixz2v5mxzymg);
            $V0ixz2v5mxzymageWidth = $Vj0eqma35tbv[0];
            $V0ixz2v5mxzymageHeight = $Vj0eqma35tbv[1];

            if (isset($Vj0eqma35tbv['channels'])) {
                $Vdiqkcy1hsm4hannels = $Vj0eqma35tbv['channels'];
            } else {
                $Vdiqkcy1hsm4hannels = 3;
            }

            $V3o5lzcfvwzz = file_get_contents($V0ixz2v5mxzymg);
        }

        if ($V5ymvwogwh5y <= 0 && $V2pgp3ppbjsi <= 0) {
            $V5ymvwogwh5y = $V0ixz2v5mxzymageWidth;
        }

        if ($V5ymvwogwh5y == 0) {
            $V5ymvwogwh5y = $V2pgp3ppbjsi / $V0ixz2v5mxzymageHeight * $V0ixz2v5mxzymageWidth;
        }

        if ($V2pgp3ppbjsi == 0) {
            $V2pgp3ppbjsi = $V5ymvwogwh5y * $V0ixz2v5mxzymageHeight / $V0ixz2v5mxzymageWidth;
        }

        $Vvkqsaecgfirhis->addJpegImage_common($V3o5lzcfvwzz, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $V0ixz2v5mxzymageWidth, $V0ixz2v5mxzymageHeight, $Vdiqkcy1hsm4hannels, $V0ixz2v5mxzymg);
    }

    
    private function addJpegImage_common(
        &$V3o5lzcfvwzz,
        $Vmm2pe5l4str,
        $Vuua0v2znlr5,
        $V5ymvwogwh5y = 0,
        $V2pgp3ppbjsi = 0,
        $V0ixz2v5mxzymageWidth,
        $V0ixz2v5mxzymageHeight,
        $Vdiqkcy1hsm4hannels = 3,
        $V0ixz2v5mxzymgname
    ) {
        if ($Vvkqsaecgfirhis->image_iscached($V0ixz2v5mxzymgname)) {
            $Vovi5zubtdii = $Vvkqsaecgfirhis->imagelist[$V0ixz2v5mxzymgname]['label'];
            
            

        } else {
            if ($V3o5lzcfvwzz == null) {
                $Vvkqsaecgfirhis->addMessage('addJpegImage_common error - (' . $V0ixz2v5mxzymgname . ') data not present!');

                return;
            }

            
            
            $Vvkqsaecgfirhis->numImages++;
            $V0ixz2v5mxzym = $Vvkqsaecgfirhis->numImages;
            $Vovi5zubtdii = "I$V0ixz2v5mxzym";
            $Vvkqsaecgfirhis->numObj++;

            $Vvkqsaecgfirhis->o_image(
                $Vvkqsaecgfirhis->numObj,
                'new',
                array(
                    'label'    => $Vovi5zubtdii,
                    'data'     => &$V3o5lzcfvwzz,
                    'iw'       => $V0ixz2v5mxzymageWidth,
                    'ih'       => $V0ixz2v5mxzymageHeight,
                    'channels' => $Vdiqkcy1hsm4hannels
                )
            );

            $Vvkqsaecgfirhis->imagelist[$V0ixz2v5mxzymgname] = array(
                'label' => $Vovi5zubtdii,
                'w'     => $V0ixz2v5mxzymageWidth,
                'h'     => $V0ixz2v5mxzymageHeight,
                'c'     => $Vdiqkcy1hsm4hannels
            );
        }

        $Vvkqsaecgfirhis->addContent(sprintf("\nq\n%.3F 0 0 %.3F %.3F %.3F cm /%s Do\nQ ", $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vmm2pe5l4str, $Vuua0v2znlr5, $Vovi5zubtdii));
    }

    
    function openHere($Vkvw5zjrwkdm, $V4dkbhpdu11q = 0, $Vkbvefdrfvxh = 0, $Vdiqkcy1hsm4 = 0)
    {
        
        
        
        
        
        
        
        
        
        
        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_destination(
            $Vvkqsaecgfirhis->numObj,
            'new',
            array('page' => $Vvkqsaecgfirhis->currentPage, 'type' => $Vkvw5zjrwkdm, 'p1' => $V4dkbhpdu11q, 'p2' => $Vkbvefdrfvxh, 'p3' => $Vdiqkcy1hsm4)
        );
        $Vawfntrfsy4f = $Vvkqsaecgfirhis->catalogId;
        $Vvkqsaecgfirhis->o_catalog($Vawfntrfsy4f, 'openHere', $Vvkqsaecgfirhis->numObj);
    }

    
    function addJavascript($Vlrwwrp5keo0)
    {
        $Vvkqsaecgfirhis->javascript .= $Vlrwwrp5keo0;
    }

    
    function addDestination($Vovi5zubtdii, $Vkvw5zjrwkdm, $V4dkbhpdu11q = 0, $Vkbvefdrfvxh = 0, $Vdiqkcy1hsm4 = 0)
    {
        
        
        
        $Vvkqsaecgfirhis->numObj++;
        $Vvkqsaecgfirhis->o_destination(
            $Vvkqsaecgfirhis->numObj,
            'new',
            array('page' => $Vvkqsaecgfirhis->currentPage, 'type' => $Vkvw5zjrwkdm, 'p1' => $V4dkbhpdu11q, 'p2' => $Vkbvefdrfvxh, 'p3' => $Vdiqkcy1hsm4)
        );
        $Vawfntrfsy4f = $Vvkqsaecgfirhis->numObj;

        
        $Vvkqsaecgfirhis->destinations["$Vovi5zubtdii"] = $Vawfntrfsy4f;
    }

    
    function setFontFamily($V2jlfa3zutex, $V3vmzyblbtdy = '')
    {
        if (!is_array($V3vmzyblbtdy)) {
            if ($V2jlfa3zutex === 'init') {
                
                
                
                $Vvkqsaecgfirhis->fontFamilies['Helvetica.afm'] =
                    array(
                        'b'  => 'Helvetica-Bold.afm',
                        'i'  => 'Helvetica-Oblique.afm',
                        'bi' => 'Helvetica-BoldOblique.afm',
                        'ib' => 'Helvetica-BoldOblique.afm'
                    );

                $Vvkqsaecgfirhis->fontFamilies['Courier.afm'] =
                    array(
                        'b'  => 'Courier-Bold.afm',
                        'i'  => 'Courier-Oblique.afm',
                        'bi' => 'Courier-BoldOblique.afm',
                        'ib' => 'Courier-BoldOblique.afm'
                    );

                $Vvkqsaecgfirhis->fontFamilies['Times-Roman.afm'] =
                    array(
                        'b'  => 'Times-Bold.afm',
                        'i'  => 'Times-Italic.afm',
                        'bi' => 'Times-BoldItalic.afm',
                        'ib' => 'Times-BoldItalic.afm'
                    );
            }
        } else {

            
            
            if (mb_strlen($V2jlfa3zutex)) {
                $Vvkqsaecgfirhis->fontFamilies[$V2jlfa3zutex] = $V3vmzyblbtdy;
            }
        }
    }

    
    function addMessage($V1ocy1gakxau)
    {
        $Vvkqsaecgfirhis->messages .= $V1ocy1gakxau . "\n";
    }

    
    function transaction($Vxkdu2igbqng)
    {
        switch ($Vxkdu2igbqng) {
            case 'start':
                
                $V3o5lzcfvwzz = get_object_vars($Vvkqsaecgfirhis);
                $Vvkqsaecgfirhis->checkpoint = $V3o5lzcfvwzz;
                unset($V3o5lzcfvwzz);
                break;

            case 'commit':
                if (is_array($Vvkqsaecgfirhis->checkpoint) && isset($Vvkqsaecgfirhis->checkpoint['checkpoint'])) {
                    $Vj0eqma35tbv = $Vvkqsaecgfirhis->checkpoint['checkpoint'];
                    $Vvkqsaecgfirhis->checkpoint = $Vj0eqma35tbv;
                    unset($Vj0eqma35tbv);
                } else {
                    $Vvkqsaecgfirhis->checkpoint = '';
                }
                break;

            case 'rewind':
                
                if (is_array($Vvkqsaecgfirhis->checkpoint)) {
                    
                    $Vj0eqma35tbv = $Vvkqsaecgfirhis->checkpoint;

                    foreach ($Vj0eqma35tbv as $Vawllmnnfede => $Vfanetclug4s) {
                        if ($Vawllmnnfede !== 'checkpoint') {
                            $Vvkqsaecgfirhis->$Vawllmnnfede = $Vfanetclug4s;
                        }
                    }
                    unset($Vj0eqma35tbv);
                }
                break;

            case 'abort':
                if (is_array($Vvkqsaecgfirhis->checkpoint)) {
                    
                    $Vj0eqma35tbv = $Vvkqsaecgfirhis->checkpoint;
                    foreach ($Vj0eqma35tbv as $Vawllmnnfede => $Vfanetclug4s) {
                        $Vvkqsaecgfirhis->$Vawllmnnfede = $Vfanetclug4s;
                    }
                    unset($Vj0eqma35tbv);
                }
                break;
        }
    }
}
