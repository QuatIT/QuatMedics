<?php


namespace Svg\Surface;

use Svg\Document;
use Svg\Style;

class SurfaceCpdf implements SurfaceInterface
{
    const DEBUG = false;

    
    private $Vecmn4cx3vag;

    private $Vtt4kvdwuqqh;
    private $Vxtfrabd3i5r;

    
    private $Vkvw5zjrwkdm;

    public function __construct(Document $Vn53dg3q25ot, $Vecmn4cx3vag = null)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $Vhcmoq1fgvta = $Vn53dg3q25ot->getDimensions();
        $V5ymvwogwh5y = $Vhcmoq1fgvta["width"];
        $V2pgp3ppbjsi = $Vhcmoq1fgvta["height"];

        if (!$Vecmn4cx3vag) {
            $Vecmn4cx3vag = new \CPdf\CPdf(array(0, 0, $V5ymvwogwh5y, $V2pgp3ppbjsi));
            $Vh1hn0uco5jo = new \ReflectionClass($Vecmn4cx3vag);
            $Vecmn4cx3vag->fontcache = realpath(dirname($Vh1hn0uco5jo->getFileName()) . "/../../fonts/")."/";
        }

        
        
        $Vecmn4cx3vag->transform(array(
            1,  0,
            0, -1,
            0, $V2pgp3ppbjsi
        ));

        $this->width  = $V5ymvwogwh5y;
        $this->height = $V2pgp3ppbjsi;

        $this->canvas = $Vecmn4cx3vag;
    }

    function out()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        return $this->canvas->output();
    }

    public function save()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->save();
    }

    public function restore()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->restore();
    }

    public function scale($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $this->transform($Vmm2pe5l4str, 0, 0, $Vuua0v2znlr5, 0, 0);
    }

    public function rotate($Vvb4ibm25tpf)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $V4dkbhpdu11q = deg2rad($Vvb4ibm25tpf);
        $Vuz20sqd4rib = cos($V4dkbhpdu11q);
        $V5xfoxteciyj = sin($V4dkbhpdu11q);

        $this->transform(
            $Vuz20sqd4rib,                         $V5xfoxteciyj,
            -$V5xfoxteciyj,                         $Vuz20sqd4rib,
            0, 0
        );
    }

    public function translate($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $this->transform(
            1,  0,
            0,  1,
            $Vmm2pe5l4str, $Vuua0v2znlr5
        );
    }

    public function transform($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $this->canvas->transform(array($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1));
    }

    public function beginPath()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        
    }

    public function closePath()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->closePath();
    }

    public function fillStroke()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->fillStroke();
    }

    public function clip()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->clip();
    }

    public function fillText($Vnjapcj4bkpc, $Vmm2pe5l4str, $Vuua0v2znlr5, $Voqn2ztf5uzl = null)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->addText($Vmm2pe5l4str, $Vuua0v2znlr5, $this->style->fontSize, $Vnjapcj4bkpc);
    }

    public function strokeText($Vnjapcj4bkpc, $Vmm2pe5l4str, $Vuua0v2znlr5, $Voqn2ztf5uzl = null)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->addText($Vmm2pe5l4str, $Vuua0v2znlr5, $this->style->fontSize, $Vnjapcj4bkpc);
    }

    public function drawImage($Vsc2xappb1ws, $V30sf4kzdv2b, $Vgd1odlz3me2, $Vzpffdqrlqug = null, $V42oss4ur1nw = null, $Vngrhfhlmiygx = null, $Vngrhfhlmiygy = null, $Vngrhfhlmiygw = null, $Vngrhfhlmiygh = null)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        if (strpos($Vsc2xappb1ws, "data:") === 0) {
            $Vrra0vtlxofn = explode(',', $Vsc2xappb1ws, 2);

            $Vngrhfhlmiygata = $Vrra0vtlxofn[1];
            $Vkbvefdrfvxhase64 = false;

            $Vm2khic0bixb = strtok($Vrra0vtlxofn[0], ';');
            while ($Vm2khic0bixb !== false) {
                if ($Vm2khic0bixb == 'base64') {
                    $Vkbvefdrfvxhase64 = true;
                }

                $Vm2khic0bixb = strtok(';');
            }

            if ($Vkbvefdrfvxhase64) {
                $Vngrhfhlmiygata = base64_decode($Vngrhfhlmiygata);
            }
        }
        else {
            $Vngrhfhlmiygata = file_get_contents($Vsc2xappb1ws);
        }

        $Vsc2xappb1ws = tempnam("", "svg");
        file_put_contents($Vsc2xappb1ws, $Vngrhfhlmiygata);

        $Vz1jukgekuy3 = $this->image($Vsc2xappb1ws, $V30sf4kzdv2b, $Vgd1odlz3me2, $Vzpffdqrlqug, $V42oss4ur1nw, "normal");


        unlink($Vsc2xappb1ws);
    }

    public static function getimagesize($Vtmlsxxw3ne1ilename)
    {
        static $Vdiqkcy1hsm4ache = array();

        if (isset($Vdiqkcy1hsm4ache[$Vtmlsxxw3ne1ilename])) {
            return $Vdiqkcy1hsm4ache[$Vtmlsxxw3ne1ilename];
        }

        list($Vtt4kvdwuqqh, $Vxtfrabd3i5r, $Vky1xzjrvbn4) = getimagesize($Vtmlsxxw3ne1ilename);

        if ($Vtt4kvdwuqqh == null || $Vxtfrabd3i5r == null) {
            $Vngrhfhlmiygata = file_get_contents($Vtmlsxxw3ne1ilename, null, null, 0, 26);

            if (substr($Vngrhfhlmiygata, 0, 2) === "BM") {
                $Vazzeshtjq43 = unpack('vtype/Vfilesize/Vreserved/Voffset/Vheadersize/Vwidth/Vheight', $Vngrhfhlmiygata);
                $Vtt4kvdwuqqh = (int)$Vazzeshtjq43['width'];
                $Vxtfrabd3i5r = (int)$Vazzeshtjq43['height'];
                $Vky1xzjrvbn4 = IMAGETYPE_BMP;
            }
        }

        return $Vdiqkcy1hsm4ache[$Vtmlsxxw3ne1ilename] = array($Vtt4kvdwuqqh, $Vxtfrabd3i5r, $Vky1xzjrvbn4);
    }

    function image($Vz1jukgekuy3, $Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Vbjhyqj5trxb = "normal")
    {
        list($Vtt4kvdwuqqh, $Vxtfrabd3i5r, $Vky1xzjrvbn4) = $this->getimagesize($Vz1jukgekuy3);

        switch ($Vky1xzjrvbn4) {
            case IMAGETYPE_JPEG:
                $this->canvas->addJpegFromFile($Vz1jukgekuy3, $Vmm2pe5l4str, $Vuua0v2znlr5 - $V2pgp3ppbjsi, $V5ymvwogwh5y, $V2pgp3ppbjsi);
                break;

            case IMAGETYPE_GIF:
            case IMAGETYPE_BMP:
                
                $Vz1jukgekuy3 = $this->_convert_gif_bmp_to_png($Vz1jukgekuy3, $Vky1xzjrvbn4);

            case IMAGETYPE_PNG:
                $this->canvas->addPngFromFile($Vz1jukgekuy3, $Vmm2pe5l4str, $Vuua0v2znlr5 - $V2pgp3ppbjsi, $V5ymvwogwh5y, $V2pgp3ppbjsi);
                break;

            default:
        }
    }

    public function lineTo($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->lineTo($Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function moveTo($Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->moveTo($Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function quadraticCurveTo($Vdiqkcy1hsm4px, $Vdiqkcy1hsm4py, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        
        $this->canvas->quadTo($Vdiqkcy1hsm4px, $Vdiqkcy1hsm4py, $Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function bezierCurveTo($Vdiqkcy1hsm4p1x, $Vdiqkcy1hsm4p1y, $Vdiqkcy1hsm4p2x, $Vdiqkcy1hsm4p2y, $Vmm2pe5l4str, $Vuua0v2znlr5)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->curveTo($Vdiqkcy1hsm4p1x, $Vdiqkcy1hsm4p1y, $Vdiqkcy1hsm4p2x, $Vdiqkcy1hsm4p2y, $Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    public function arcTo($Vmm2pe5l4str1, $Vuua0v2znlr51, $Vmm2pe5l4str2, $Vuua0v2znlr52, $Vc4ozih12zue)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
    }

    public function arc($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue, $Vm3t2pidpc0a, $VqfltxpxjekkndAngle, $V4dkbhpdu11qnticlockwise = false)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->ellipse($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue, $Vc4ozih12zue, 0, 8, $Vm3t2pidpc0a, $VqfltxpxjekkndAngle, false, false, false, true);
    }

    public function circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->ellipse($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue, $Vc4ozih12zue, 0, 8, 0, 360, true, false, false, false);
    }

    public function ellipse($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zueX, $Vc4ozih12zueY, $Vzq3npyo4slb, $Vm3t2pidpc0a, $VqfltxpxjekkndAngle, $V4dkbhpdu11qnticlockwise)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->ellipse($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zueX, $Vc4ozih12zueY, 0, 8, 0, 360, false, false, false, false);
    }

    public function fillRect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->rect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        $this->fill();
    }

    public function rect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Ved15tbp0gam = 0, $Vud2tyg4u1vh = 0)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $Vecmn4cx3vag = $this->canvas;

        if ($Ved15tbp0gam <= 0.000001) {
            $Vecmn4cx3vag->rect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);

            return;
        }

        $Ved15tbp0gam = min($Ved15tbp0gam, $V5ymvwogwh5y / 2);
        $Ved15tbp0gam = min($Ved15tbp0gam, $V2pgp3ppbjsi / 2);

        
        $this->moveTo($Vmm2pe5l4str + $Ved15tbp0gam, $Vuua0v2znlr5);

        
        $this->lineTo($Vmm2pe5l4str + $V5ymvwogwh5y - $Ved15tbp0gam, $Vuua0v2znlr5);

        
        $this->arc($Vmm2pe5l4str + $V5ymvwogwh5y - $Ved15tbp0gam, $Vuua0v2znlr5 + $Ved15tbp0gam, $Ved15tbp0gam, 270, 360);

        
        $this->lineTo($Vmm2pe5l4str + $V5ymvwogwh5y, $Vuua0v2znlr5 + $V2pgp3ppbjsi - $Ved15tbp0gam );

        
        $this->arc($Vmm2pe5l4str + $V5ymvwogwh5y - $Ved15tbp0gam, $Vuua0v2znlr5 + $V2pgp3ppbjsi - $Ved15tbp0gam, $Ved15tbp0gam, 0, 90);

        
        $this->lineTo($Vmm2pe5l4str + $Ved15tbp0gam, $Vuua0v2znlr5 + $V2pgp3ppbjsi);

        
        $this->arc($Vmm2pe5l4str + $Ved15tbp0gam, $Vuua0v2znlr5 + $V2pgp3ppbjsi - $Ved15tbp0gam, $Ved15tbp0gam, 90, 180);

        
        $this->lineTo($Vmm2pe5l4str , $Vuua0v2znlr5 + $Ved15tbp0gam);

        
        $this->arc($Vmm2pe5l4str + $Ved15tbp0gam, $Vuua0v2znlr5 + $Ved15tbp0gam, $Ved15tbp0gam, 180, 270);
    }

    public function fill()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->fill();
    }

    public function strokeRect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->rect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);
        $this->stroke();
    }

    public function stroke()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->stroke();
    }

    public function endPath()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $this->canvas->endPath();
    }

    public function measureText($Vnjapcj4bkpc)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        $Vkvw5zjrwkdm = $this->getStyle();
        $this->setFont($Vkvw5zjrwkdm->fontFamily, $Vkvw5zjrwkdm->fontStyle, $Vkvw5zjrwkdm->fontWeight);

        return $this->canvas->getTextWidth($this->getStyle()->fontSize, $Vnjapcj4bkpc);
    }

    public function getStyle()
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";
        return $this->style;
    }

    public function setStyle(Style $Vkvw5zjrwkdm)
    {
        if (self::DEBUG) echo __FUNCTION__ . "\n";

        $this->style = $Vkvw5zjrwkdm;
        $Vecmn4cx3vag = $this->canvas;

        if (is_array($Vkvw5zjrwkdm->stroke) && $Vleb2mixglzb = $Vkvw5zjrwkdm->stroke) {
            $Vecmn4cx3vag->setStrokeColor(array((float)$Vleb2mixglzb[0]/255, (float)$Vleb2mixglzb[1]/255, (float)$Vleb2mixglzb[2]/255), true);
        }

        if (is_array($Vkvw5zjrwkdm->fill) && $Vtmlsxxw3ne1ill = $Vkvw5zjrwkdm->fill) {
            $Vecmn4cx3vag->setColor(array((float)$Vtmlsxxw3ne1ill[0]/255, (float)$Vtmlsxxw3ne1ill[1]/255, (float)$Vtmlsxxw3ne1ill[2]/255), true);
        }

        if ($Vtmlsxxw3ne1illRule = strtolower($Vkvw5zjrwkdm->fillRule)) {
            $Vecmn4cx3vag->setFillRule($Vtmlsxxw3ne1illRule);
        }

        $Vhrfbgup2xix = $Vkvw5zjrwkdm->opacity;
        if ($Vhrfbgup2xix !== null && $Vhrfbgup2xix < 1.0) {
            $Vecmn4cx3vag->setLineTransparency("Normal", $Vhrfbgup2xix);
            $Vecmn4cx3vag->currentLineTransparency = null;

            $Vecmn4cx3vag->setFillTransparency("Normal", $Vhrfbgup2xix);
            $Vecmn4cx3vag->currentFillTransparency = null;
        }
        else {
            $Vtmlsxxw3ne1illOpacity = $Vkvw5zjrwkdm->fillOpacity;
            if ($Vtmlsxxw3ne1illOpacity !== null && $Vtmlsxxw3ne1illOpacity < 1.0) {
                $Vecmn4cx3vag->setFillTransparency("Normal", $Vtmlsxxw3ne1illOpacity);
                $Vecmn4cx3vag->currentFillTransparency = null;
            }

            $Vleb2mixglzbOpacity = $Vkvw5zjrwkdm->strokeOpacity;
            if ($Vleb2mixglzbOpacity !== null && $Vleb2mixglzbOpacity < 1.0) {
                $Vecmn4cx3vag->setLineTransparency("Normal", $Vleb2mixglzbOpacity);
                $Vecmn4cx3vag->currentLineTransparency = null;
            }
        }

        $VngrhfhlmiygashArray = null;
        if ($Vkvw5zjrwkdm->strokeDasharray) {
            $VngrhfhlmiygashArray = preg_split('/\s*,\s*/', $Vkvw5zjrwkdm->strokeDasharray);
        }

        $Vecmn4cx3vag->setLineStyle(
            $Vkvw5zjrwkdm->strokeWidth,
            $Vkvw5zjrwkdm->strokeLinecap,
            $Vkvw5zjrwkdm->strokeLinejoin,
            $VngrhfhlmiygashArray
        );

        $this->setFont($Vkvw5zjrwkdm->fontFamily, $Vkvw5zjrwkdm->fontStyle, $Vkvw5zjrwkdm->fontWeight);
    }

    public function setFont($Vtmlsxxw3ne1amily, $Vkvw5zjrwkdm, $V5ymvwogwh5yeight)
    {
        $Vgxq50e2jnhe = array(
            "serif"      => "Times",
            "sans-serif" => "Helvetica",
            "fantasy"    => "Symbol",
            "cursive"    => "Times",
            "monospace"  => "Courier",

            "arial"      => "Helvetica",
            "verdana"    => "Helvetica",
        );

        $Vkvw5zjrwkdmMap = array(
            'Helvetica' => array(
                'b'  => 'Helvetica-Bold',
                'i'  => 'Helvetica-Oblique',
                'bi' => 'Helvetica-BoldOblique',
            ),
            'Courier' => array(
                'b'  => 'Courier-Bold',
                'i'  => 'Courier-Oblique',
                'bi' => 'Courier-BoldOblique',
            ),
            'Times' => array(
                ''   => 'Times-Roman',
                'b'  => 'Times-Bold',
                'i'  => 'Times-Italic',
                'bi' => 'Times-BoldItalic',
            ),
        );

        $Vtmlsxxw3ne1amily = strtolower($Vtmlsxxw3ne1amily);
        $Vkvw5zjrwkdm  = strtolower($Vkvw5zjrwkdm);
        $V5ymvwogwh5yeight = strtolower($V5ymvwogwh5yeight);

        if (isset($Vgxq50e2jnhe[$Vtmlsxxw3ne1amily])) {
            $Vtmlsxxw3ne1amily = $Vgxq50e2jnhe[$Vtmlsxxw3ne1amily];
        }

        if (isset($Vkvw5zjrwkdmMap[$Vtmlsxxw3ne1amily])) {
            $Vbd2mxirzq2d = "";

            if ($V5ymvwogwh5yeight === "bold" || $V5ymvwogwh5yeight === "bolder" || (is_numeric($V5ymvwogwh5yeight) && $V5ymvwogwh5yeight >= 600)) {
                $Vbd2mxirzq2d .= "b";
            }

            if ($Vkvw5zjrwkdm === "italic" || $Vkvw5zjrwkdm === "oblique") {
                $Vbd2mxirzq2d .= "i";
            }

            if (isset($Vkvw5zjrwkdmMap[$Vtmlsxxw3ne1amily][$Vbd2mxirzq2d])) {
                $Vtmlsxxw3ne1amily = $Vkvw5zjrwkdmMap[$Vtmlsxxw3ne1amily][$Vbd2mxirzq2d];
            }
        }

        $this->canvas->selectFont("$Vtmlsxxw3ne1amily.afm");
    }
}
