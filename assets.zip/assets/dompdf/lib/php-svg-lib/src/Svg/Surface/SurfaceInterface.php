<?php


namespace Svg\Surface;

use Svg\Style;


interface SurfaceInterface
{
    public function save();

    public function restore();

    
    public function scale($Vmm2pe5l4str, $Vuua0v2znlr5);

    public function rotate($Vvb4ibm25tpf);

    public function translate($Vmm2pe5l4str, $Vuua0v2znlr5);

    public function transform($V4dkbhpdu11q, $Vkbvefdrfvxh, $Vdiqkcy1hsm4, $Vngrhfhlmiyg, $Vqfltxpxjekk, $Vtmlsxxw3ne1);

    
    public function beginPath();

    public function closePath();

    public function fill();

    public function stroke();

    public function endPath();

    public function fillStroke();

    public function clip();

    
    public function fillText($Vnjapcj4bkpc, $Vmm2pe5l4str, $Vuua0v2znlr5, $Voqn2ztf5uzl = null);

    public function strokeText($Vnjapcj4bkpc, $Vmm2pe5l4str, $Vuua0v2znlr5, $Voqn2ztf5uzl = null);

    public function measureText($Vnjapcj4bkpc);

    
    public function drawImage($Vsc2xappb1ws, $V30sf4kzdv2b, $Vgd1odlz3me2, $Vzpffdqrlqug = null, $V42oss4ur1nw = null, $Vngrhfhlmiygx = null, $Vngrhfhlmiygy = null, $Vngrhfhlmiygw = null, $Vngrhfhlmiygh = null);

    
    public function lineTo($Vmm2pe5l4str, $Vuua0v2znlr5);

    public function moveTo($Vmm2pe5l4str, $Vuua0v2znlr5);

    public function quadraticCurveTo($Vdiqkcy1hsm4px, $Vdiqkcy1hsm4py, $Vmm2pe5l4str, $Vuua0v2znlr5);

    public function bezierCurveTo($Vdiqkcy1hsm4p1x, $Vdiqkcy1hsm4p1y, $Vdiqkcy1hsm4p2x, $Vdiqkcy1hsm4p2y, $Vmm2pe5l4str, $Vuua0v2znlr5);

    public function arcTo($Vmm2pe5l4str1, $Vuua0v2znlr51, $Vmm2pe5l4str2, $Vuua0v2znlr52, $Vc4ozih12zue);

    public function circle($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue);

    public function arc($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zue, $Vm3t2pidpc0a, $VqfltxpxjekkndAngle, $V4dkbhpdu11qnticlockwise = false);

    public function ellipse($Vmm2pe5l4str, $Vuua0v2znlr5, $Vc4ozih12zueX, $Vc4ozih12zueY, $Vzq3npyo4slb, $Vm3t2pidpc0a, $VqfltxpxjekkndAngle, $V4dkbhpdu11qnticlockwise);

    
    public function rect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi, $Ved15tbp0gam = 0, $Vud2tyg4u1vh = 0);

    public function fillRect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);

    public function strokeRect($Vmm2pe5l4str, $Vuua0v2znlr5, $V5ymvwogwh5y, $V2pgp3ppbjsi);

    public function setStyle(Style $Vkvw5zjrwkdm);

    
    public function getStyle();

    public function setFont($Vtmlsxxw3ne1amily, $Vkvw5zjrwkdm, $V5ymvwogwh5yeight);
}
