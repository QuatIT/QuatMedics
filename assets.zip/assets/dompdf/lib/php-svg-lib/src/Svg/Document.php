<?php


namespace Svg;

use Svg\Surface\SurfaceInterface;
use Svg\Tag\AbstractTag;
use Svg\Tag\Anchor;
use Svg\Tag\Circle;
use Svg\Tag\Ellipse;
use Svg\Tag\Group;
use Svg\Tag\ClipPath;
use Svg\Tag\Image;
use Svg\Tag\Line;
use Svg\Tag\LinearGradient;
use Svg\Tag\Path;
use Svg\Tag\Polygon;
use Svg\Tag\Polyline;
use Svg\Tag\Rect;
use Svg\Tag\Stop;
use Svg\Tag\Text;
use Svg\Tag\StyleTag;
use Svg\Tag\UseTag;

class Document extends AbstractTag
{
    protected $Vnbqjwe42int;
    public $V5gjmlat3d1j = false;

    protected $Vmm2pe5l4str;
    protected $Vuua0v2znlr5;
    protected $Vtt4kvdwuqqh;
    protected $Vxtfrabd3i5r;

    protected $Vx2gtieahohe;
    protected $Vunynljxawtw;
    protected $Vpimj11snadh;

    
    protected $Voguw0q5rps1;

    
    protected $V2xyj3rpykim;

    
    protected $Vo1vhygcjja1 = array();

    
    protected $Vbnrpf1dsgef = array();

    
    protected $Vittr0s3acsd = array();

    public function loadFile($Vnbqjwe42int)
    {
        $this->filename = $Vnbqjwe42int;
    }

    protected function initParser() {
        $Voguw0q5rps1 = xml_parser_create("utf-8");
        xml_parser_set_option($Voguw0q5rps1, XML_OPTION_CASE_FOLDING, false);
        xml_set_element_handler(
            $Voguw0q5rps1,
            array($this, "_tagStart"),
            array($this, "_tagEnd")
        );
        xml_set_character_data_handler(
            $Voguw0q5rps1,
            array($this, "_charData")
        );

        return $this->parser = $Voguw0q5rps1;
    }

    public function __construct() {

    }

    
    public function getSurface()
    {
        return $this->surface;
    }

    public function getStack()
    {
        return $this->stack;
    }

    public function getWidth()
    {
        return $this->width;
    }

    public function getHeight()
    {
        return $this->height;
    }

    public function getDimensions() {
        $Vcggqjboc4l5 = null;

        $Voguw0q5rps1 = xml_parser_create("utf-8");
        xml_parser_set_option($Voguw0q5rps1, XML_OPTION_CASE_FOLDING, false);
        xml_set_element_handler(
            $Voguw0q5rps1,
            function ($Voguw0q5rps1, $Vreuchxnm2nm, $V04clwkrmt3d) use (&$Vcggqjboc4l5) {
                if ($Vreuchxnm2nm === "svg" && $Vcggqjboc4l5 === null) {
                    $V04clwkrmt3d = array_change_key_case($V04clwkrmt3d, CASE_LOWER);

                    $Vcggqjboc4l5 = $V04clwkrmt3d;
                }
            },
            function ($Voguw0q5rps1, $Vreuchxnm2nm) {}
        );

        $Vugzuamwr2xd = fopen($this->filename, "r");
        while ($V4dr003jf14h = fread($Vugzuamwr2xd, 8192)) {
            xml_parse($Voguw0q5rps1, $V4dr003jf14h, false);

            if ($Vcggqjboc4l5 !== null) {
                break;
            }
        }

        xml_parser_free($Voguw0q5rps1);

        return $this->handleSizeAttributes($Vcggqjboc4l5);
    }

    public function handleSizeAttributes($V04clwkrmt3d){
        if ($this->width === null) {
            if (isset($V04clwkrmt3d["width"])) {
                $Vtt4kvdwuqqh = Style::convertSize($V04clwkrmt3d["width"], 400);
                $this->width  = $Vtt4kvdwuqqh;
            }

            if (isset($V04clwkrmt3d["height"])) {
                $Vxtfrabd3i5r = Style::convertSize($V04clwkrmt3d["height"], 300);
                $this->height = $Vxtfrabd3i5r;
            }

            if (isset($V04clwkrmt3d['viewbox'])) {
                $Vpimj11snadh = preg_split('/[\s,]+/is', trim($V04clwkrmt3d['viewbox']));
                if (count($Vpimj11snadh) == 4) {
                    $this->x = $Vpimj11snadh[0];
                    $this->y = $Vpimj11snadh[1];

                    if (!$this->width) {
                        $this->width = $Vpimj11snadh[2];
                    }
                    if (!$this->height) {
                        $this->height = $Vpimj11snadh[3];
                    }
                }
            }
        }

        return array(
            0        => $this->width,
            1        => $this->height,

            "width"  => $this->width,
            "height" => $this->height,
        );
    }

    public function getDocument(){
        return $this;
    }

    
    public function appendStyleSheet($Vh0djujchlkk) {
        $this->styleSheets[] = $Vh0djujchlkk;
    }

    
    public function getStyleSheets() {
        return $this->styleSheets;
    }

    protected function before($V04clwkrmt3d)
    {
        $V2xyj3rpykim = $this->getSurface();

        $Vkvw5zjrwkdm = new DefaultStyle();
        $Vkvw5zjrwkdm->inherit($this);
        $Vkvw5zjrwkdm->fromAttributes($V04clwkrmt3d);

        $this->setStyle($Vkvw5zjrwkdm);

        $V2xyj3rpykim->setStyle($Vkvw5zjrwkdm);
    }

    public function render(SurfaceInterface $V2xyj3rpykim)
    {
        $this->inDefs = false;
        $this->surface = $V2xyj3rpykim;

        $Voguw0q5rps1 = $this->initParser();

        if ($this->x || $this->y) {
            $V2xyj3rpykim->translate(-$this->x, -$this->y);
        }

        $Vugzuamwr2xd = fopen($this->filename, "r");
        while ($V4dr003jf14h = fread($Vugzuamwr2xd, 8192)) {
            xml_parse($Voguw0q5rps1, $V4dr003jf14h, false);
        }

        xml_parse($Voguw0q5rps1, "", true);

        xml_parser_free($Voguw0q5rps1);
    }

    protected function svgOffset($V04clwkrmt3d)
    {
        $this->attributes = $V04clwkrmt3d;

        $this->handleSizeAttributes($V04clwkrmt3d);
    }

    public function getDef($Vawfntrfsy4f) {
        $Vawfntrfsy4f = ltrim($Vawfntrfsy4f, "#");

        return isset($this->defs[$Vawfntrfsy4f]) ? $this->defs[$Vawfntrfsy4f] : null;
    }

    private function _tagStart($Voguw0q5rps1, $Vreuchxnm2nm, $V04clwkrmt3d)
    {
        $this->x = 0;
        $this->y = 0;

        $Vgvunyxfpvcq = null;

        $V04clwkrmt3d = array_change_key_case($V04clwkrmt3d, CASE_LOWER);

        switch (strtolower($Vreuchxnm2nm)) {
            case 'defs':
                $this->inDefs = true;
                return;

            case 'svg':
                if (count($this->attributes)) {
                    $Vgvunyxfpvcq = new Group($this, $Vreuchxnm2nm);
                }
                else {
                    $Vgvunyxfpvcq = $this;
                    $this->svgOffset($V04clwkrmt3d);
                }
                break;

            case 'path':
                $Vgvunyxfpvcq = new Path($this, $Vreuchxnm2nm);
                break;

            case 'rect':
                $Vgvunyxfpvcq = new Rect($this, $Vreuchxnm2nm);
                break;

            case 'circle':
                $Vgvunyxfpvcq = new Circle($this, $Vreuchxnm2nm);
                break;

            case 'ellipse':
                $Vgvunyxfpvcq = new Ellipse($this, $Vreuchxnm2nm);
                break;

            case 'image':
                $Vgvunyxfpvcq = new Image($this, $Vreuchxnm2nm);
                break;

            case 'line':
                $Vgvunyxfpvcq = new Line($this, $Vreuchxnm2nm);
                break;

            case 'polyline':
                $Vgvunyxfpvcq = new Polyline($this, $Vreuchxnm2nm);
                break;

            case 'polygon':
                $Vgvunyxfpvcq = new Polygon($this, $Vreuchxnm2nm);
                break;

            case 'lineargradient':
                $Vgvunyxfpvcq = new LinearGradient($this, $Vreuchxnm2nm);
                break;

            case 'radialgradient':
                $Vgvunyxfpvcq = new LinearGradient($this, $Vreuchxnm2nm);
                break;

            case 'stop':
                $Vgvunyxfpvcq = new Stop($this, $Vreuchxnm2nm);
                break;

            case 'style':
                $Vgvunyxfpvcq = new StyleTag($this, $Vreuchxnm2nm);
                break;

            case 'a':
                $Vgvunyxfpvcq = new Anchor($this, $Vreuchxnm2nm);
                break;

            case 'g':
            case 'symbol':
                $Vgvunyxfpvcq = new Group($this, $Vreuchxnm2nm);
                break;

            case 'clippath':
                $Vgvunyxfpvcq = new ClipPath($this, $Vreuchxnm2nm);
                break;

            case 'use':
                $Vgvunyxfpvcq = new UseTag($this, $Vreuchxnm2nm);
                break;

            case 'text':
                $Vgvunyxfpvcq = new Text($this, $Vreuchxnm2nm);
                break;
        }

        if ($Vgvunyxfpvcq) {
            if (isset($V04clwkrmt3d["id"])) {
                $this->defs[$V04clwkrmt3d["id"]] = $Vgvunyxfpvcq;
            }
            else {
                
                $Vzn5k4lefp5v = end($this->stack);
                if ($Vzn5k4lefp5v && $Vzn5k4lefp5v != $Vgvunyxfpvcq) {
                    $Vzn5k4lefp5v->children[] = $Vgvunyxfpvcq;
                }
            }

            $this->stack[] = $Vgvunyxfpvcq;

            $Vgvunyxfpvcq->handle($V04clwkrmt3d);
        } else {
            echo "Unknown: '$Vreuchxnm2nm'\n";
        }
    }

    function _charData($Voguw0q5rps1, $V3o5lzcfvwzz)
    {
        $Vo1vhygcjja1_top = end($this->stack);

        if ($Vo1vhygcjja1_top instanceof Text || $Vo1vhygcjja1_top instanceof StyleTag) {
            $Vo1vhygcjja1_top->appendText($V3o5lzcfvwzz);
        }
    }

    function _tagEnd($Voguw0q5rps1, $Vreuchxnm2nm)
    {
        
        $Vgvunyxfpvcq = null;
        switch (strtolower($Vreuchxnm2nm)) {
            case 'defs':
                $this->inDefs = false;
                return;

            case 'svg':
            case 'path':
            case 'rect':
            case 'circle':
            case 'ellipse':
            case 'image':
            case 'line':
            case 'polyline':
            case 'polygon':
            case 'radialgradient':
            case 'lineargradient':
            case 'stop':
            case 'style':
            case 'text':
            case 'g':
            case 'symbol':
            case 'clippath':
            case 'use':
            case 'a':
                $Vgvunyxfpvcq = array_pop($this->stack);
                break;
        }

        if (!$this->inDefs && $Vgvunyxfpvcq) {
            $Vgvunyxfpvcq->handleEnd();
        }
    }
}
