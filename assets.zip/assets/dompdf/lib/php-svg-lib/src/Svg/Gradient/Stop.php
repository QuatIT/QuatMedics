<?php


namespace Svg\Gradient;

class Stop
{
    public $Veatxxxrhqpk;
    public $V3poxlnogtlh;
    public $Vhrfbgup2xix = 1.0;
}
