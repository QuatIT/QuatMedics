<?php


namespace Svg\Tag;

class Text extends Shape
{
    protected $Vmm2pe5l4str = 0;
    protected $Vuua0v2znlr5 = 0;
    protected $Vnjapcj4bkpc = "";

    public function start($V04clwkrmt3d)
    {
        $Vhmtdpzvfg2y = $this->document;
        $Vxtfrabd3i5r = $this->document->getHeight();
        $this->y = $Vxtfrabd3i5r;

        if (isset($V04clwkrmt3d['x'])) {
            $this->x = $V04clwkrmt3d['x'];
        }
        if (isset($V04clwkrmt3d['y'])) {
            $this->y = $Vxtfrabd3i5r - $V04clwkrmt3d['y'];
        }

        $Vhmtdpzvfg2y->getSurface()->transform(1, 0, 0, -1, 0, $Vxtfrabd3i5r);
    }

    public function end()
    {
        $V2xyj3rpykim = $this->document->getSurface();
        $Vmm2pe5l4str = $this->x;
        $Vuua0v2znlr5 = $this->y;
        $Vkvw5zjrwkdm = $V2xyj3rpykim->getStyle();
        $V2xyj3rpykim->setFont($Vkvw5zjrwkdm->fontFamily, $Vkvw5zjrwkdm->fontStyle, $Vkvw5zjrwkdm->fontWeight);

        switch ($Vkvw5zjrwkdm->textAnchor) {
            case "middle":
                $Vtt4kvdwuqqh = $V2xyj3rpykim->measureText($this->text);
                $Vmm2pe5l4str -= $Vtt4kvdwuqqh / 2;
                break;

            case "end":
                $Vtt4kvdwuqqh = $V2xyj3rpykim->measureText($this->text);
                $Vmm2pe5l4str -= $Vtt4kvdwuqqh;
                break;
        }

        $V2xyj3rpykim->fillText($this->getText(), $Vmm2pe5l4str, $Vuua0v2znlr5);
    }

    protected function after()
    {
        $this->document->getSurface()->restore();
    }

    public function appendText($Vnjapcj4bkpc)
    {
        $this->text .= $Vnjapcj4bkpc;
    }

    public function getText()
    {
        return trim($this->text);
    }
}
