<?php


namespace Svg\Tag;

class UseTag extends AbstractTag
{
    protected $Vmm2pe5l4str = 0;
    protected $Vuua0v2znlr5 = 0;
    protected $Vtt4kvdwuqqh;
    protected $Vxtfrabd3i5r;

    
    protected $Vfgx4mhvbuou;

    protected function before($V04clwkrmt3d)
    {
        if (isset($V04clwkrmt3d['x'])) {
            $this->x = $V04clwkrmt3d['x'];
        }
        if (isset($V04clwkrmt3d['y'])) {
            $this->y = $V04clwkrmt3d['y'];
        }

        if (isset($V04clwkrmt3d['width'])) {
            $this->width = $V04clwkrmt3d['width'];
        }
        if (isset($V04clwkrmt3d['height'])) {
            $this->height = $V04clwkrmt3d['height'];
        }

        parent::before($V04clwkrmt3d);

        $Vhmtdpzvfg2y = $this->getDocument();

        $V54fvgfte1hp = $V04clwkrmt3d["xlink:href"];
        $this->reference = $Vhmtdpzvfg2y->getDef($V54fvgfte1hp);

        if ($this->reference) {
            $this->reference->before($V04clwkrmt3d);
        }

        $V2xyj3rpykim = $Vhmtdpzvfg2y->getSurface();
        $V2xyj3rpykim->save();

        $V2xyj3rpykim->translate($this->x, $this->y);
    }

    protected function after() {
        parent::after();

        if ($this->reference) {
            $this->reference->after();
        }

        $this->getDocument()->getSurface()->restore();
    }

    public function handle($V04clwkrmt3d)
    {
        parent::handle($V04clwkrmt3d);

        if (!$this->reference) {
            return;
        }

        $V04clwkrmt3d = array_merge($this->reference->attributes, $V04clwkrmt3d);

        $this->reference->handle($V04clwkrmt3d);

        foreach ($this->reference->children as $Vex1mulnruda) {
            $Vlxehxs5gfba = array_merge($Vex1mulnruda->attributes, $V04clwkrmt3d);
            $Vex1mulnruda->handle($Vlxehxs5gfba);
        }
    }

    public function handleEnd()
    {
        parent::handleEnd();

        if (!$this->reference) {
            return;
        }

        $this->reference->handleEnd();

        foreach ($this->reference->children as $Vex1mulnruda) {
            $Vex1mulnruda->handleEnd();
        }
    }
}
