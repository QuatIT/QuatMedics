<?php


namespace Svg\Tag;

use Svg\Document;
use Svg\Style;

abstract class AbstractTag
{
    
    protected $Vhmtdpzvfg2y;

    public $Vo3ie2oakgaa;

    
    protected $Vkvw5zjrwkdm;

    protected $V04clwkrmt3d;

    protected $Vvfkyahkgg1x = true;

    
    protected $Vzi1s4z0nu10 = array();

    public function __construct(Document $Vhmtdpzvfg2y, $Vo3ie2oakgaa)
    {
        $Vvkqsaecgfirhis->document = $Vhmtdpzvfg2y;
        $Vvkqsaecgfirhis->tagName = $Vo3ie2oakgaa;
    }

    public function getDocument(){
        return $Vvkqsaecgfirhis->document;
    }

    
    public function getParentGroup() {
        $Vo1vhygcjja1 = $Vvkqsaecgfirhis->getDocument()->getStack();
        for ($V0ixz2v5mxzy = count($Vo1vhygcjja1)-2; $V0ixz2v5mxzy >= 0; $V0ixz2v5mxzy--) {
            $Vgvunyxfpvcq = $Vo1vhygcjja1[$V0ixz2v5mxzy];

            if ($Vgvunyxfpvcq instanceof Group || $Vgvunyxfpvcq instanceof Document) {
                return $Vgvunyxfpvcq;
            }
        }

        return null;
    }

    public function handle($V04clwkrmt3d)
    {
        $Vvkqsaecgfirhis->attributes = $V04clwkrmt3d;

        if (!$Vvkqsaecgfirhis->getDocument()->inDefs) {
            $Vvkqsaecgfirhis->before($V04clwkrmt3d);
            $Vvkqsaecgfirhis->start($V04clwkrmt3d);
        }
    }

    public function handleEnd()
    {
        if (!$Vvkqsaecgfirhis->getDocument()->inDefs) {
            $Vvkqsaecgfirhis->end();
            $Vvkqsaecgfirhis->after();
        }
    }

    protected function before($V04clwkrmt3d)
    {
    }

    protected function start($V04clwkrmt3d)
    {
    }

    protected function end()
    {
    }

    protected function after()
    {
    }

    public function getAttributes()
    {
        return $Vvkqsaecgfirhis->attributes;
    }

    protected function setStyle(Style $Vkvw5zjrwkdm)
    {
        $Vvkqsaecgfirhis->style = $Vkvw5zjrwkdm;

        if ($Vkvw5zjrwkdm->display === "none") {
            $Vvkqsaecgfirhis->hasShape = false;
        }
    }

    
    public function getStyle()
    {
        return $Vvkqsaecgfirhis->style;
    }

    
    protected function makeStyle($V04clwkrmt3d) {
        $Vkvw5zjrwkdm = new Style();
        $Vkvw5zjrwkdm->inherit($Vvkqsaecgfirhis);
        $Vkvw5zjrwkdm->fromStyleSheets($Vvkqsaecgfirhis, $V04clwkrmt3d);
        $Vkvw5zjrwkdm->fromAttributes($V04clwkrmt3d);

        return $Vkvw5zjrwkdm;
    }

    protected function applyTransform($V04clwkrmt3d)
    {

        if (isset($V04clwkrmt3d["transform"])) {
            $V2xyj3rpykim = $Vvkqsaecgfirhis->document->getSurface();

            $Vrwc0twf3nir = $V04clwkrmt3d["transform"];

            $Vmms5wlre01j = array();
            preg_match_all(
                '/(matrix|translate|scale|rotate|skewX|skewY)\((.*?)\)/is',
                $Vrwc0twf3nir,
                $Vmms5wlre01j,
                PREG_SET_ORDER
            );

            $Vrwc0twf3nirations = array();
            if (count($Vmms5wlre01j[0])) {
                foreach ($Vmms5wlre01j as $Vq0zujcg5gll) {
                    $Vy25n5xi3zp3 = preg_split('/[ ,]+/', $Vq0zujcg5gll[2]);
                    array_unshift($Vy25n5xi3zp3, $Vq0zujcg5gll[1]);
                    $Vrwc0twf3nirations[] = $Vy25n5xi3zp3;
                }
            }

            foreach ($Vrwc0twf3nirations as $Vvkqsaecgfir) {
                switch ($Vvkqsaecgfir[0]) {
                    case "matrix":
                        $V2xyj3rpykim->transform($Vvkqsaecgfir[1], $Vvkqsaecgfir[2], $Vvkqsaecgfir[3], $Vvkqsaecgfir[4], $Vvkqsaecgfir[5], $Vvkqsaecgfir[6]);
                        break;

                    case "translate":
                        $V2xyj3rpykim->translate($Vvkqsaecgfir[1], isset($Vvkqsaecgfir[2]) ? $Vvkqsaecgfir[2] : 0);
                        break;

                    case "scale":
                        $V2xyj3rpykim->scale($Vvkqsaecgfir[1], isset($Vvkqsaecgfir[2]) ? $Vvkqsaecgfir[2] : $Vvkqsaecgfir[1]);
                        break;

                    case "rotate":
                        $V2xyj3rpykim->rotate($Vvkqsaecgfir[1]);
                        break;

                    case "skewX":
                        $V2xyj3rpykim->skewX($Vvkqsaecgfir[1]);
                        break;

                    case "skewY":
                        $V2xyj3rpykim->skewY($Vvkqsaecgfir[1]);
                        break;
                }
            }
        }
    }
}
