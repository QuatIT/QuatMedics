<?php


namespace Svg\Tag;

use Svg\Surface\SurfaceInterface;

class Path extends Shape
{
    static $Vetdymhym2gz = array(
        'm' => 2,
        'l' => 2,
        'h' => 1,
        'v' => 1,
        'c' => 6,
        's' => 4,
        'q' => 4,
        't' => 2,
        'a' => 7,
    );

    static $Vp3wwca1hcfl = array(
        'm' => 'l',
        'M' => 'L',
    );

    public function start($V04clwkrmt3d)
    {
        if (!isset($V04clwkrmt3d['d'])) {
            $Vvkqsaecgfirhis->hasShape = false;

            return;
        }

        $Vczj5wl5ggo5 = array();
        preg_match_all('/([MZLHVCSQTAmzlhvcsqta])([eE ,\-.\d]+)*/', $V04clwkrmt3d['d'], $Vczj5wl5ggo5, PREG_SET_ORDER);

        $Vt321vu1jwdw = array();
        foreach ($Vczj5wl5ggo5 as $Vdiqkcy1hsm4) {
            if (count($Vdiqkcy1hsm4) == 3) {
                $Vy25n5xi3zp3 = array();
                preg_match_all('/([-+]?((\d+\.\d+)|((\d+)|(\.\d+)))(?:e[-+]?\d+)?)/i', $Vdiqkcy1hsm4[2], $Vy25n5xi3zp3, PREG_PATTERN_ORDER);
                $Viktzykgxifw = $Vy25n5xi3zp3[0];
                $Vdiqkcy1hsm4ommandLower = strtolower($Vdiqkcy1hsm4[1]);

                if (
                    isset(self::$Vetdymhym2gz[$Vdiqkcy1hsm4ommandLower]) &&
                    ($Vdiqkcy1hsm4ommandLength = self::$Vetdymhym2gz[$Vdiqkcy1hsm4ommandLower]) &&
                    count($Viktzykgxifw) > $Vdiqkcy1hsm4ommandLength
                ) {
                    $V24drspw5vfr = isset(self::$Vp3wwca1hcfl[$Vdiqkcy1hsm4[1]]) ? self::$Vp3wwca1hcfl[$Vdiqkcy1hsm4[1]] : $Vdiqkcy1hsm4[1];
                    $Vdiqkcy1hsm4ommand = $Vdiqkcy1hsm4[1];

                    for ($Vawllmnnfede = 0, $Vawllmnnfedelen = count($Viktzykgxifw); $Vawllmnnfede < $Vawllmnnfedelen; $Vawllmnnfede += $Vdiqkcy1hsm4ommandLength) {
                        $Vxxepds5dbu5 = array_slice($Viktzykgxifw, $Vawllmnnfede, $Vawllmnnfede + $Vdiqkcy1hsm4ommandLength);
                        array_unshift($Vxxepds5dbu5, $Vdiqkcy1hsm4ommand);
                        $Vt321vu1jwdw[] = $Vxxepds5dbu5;

                        $Vdiqkcy1hsm4ommand = $V24drspw5vfr;
                    }
                } else {
                    array_unshift($Viktzykgxifw, $Vdiqkcy1hsm4[1]);
                    $Vt321vu1jwdw[] = $Viktzykgxifw;
                }

            } else {
                $Viktzykgxifw = array($Vdiqkcy1hsm4[1]);

                $Vt321vu1jwdw[] = $Viktzykgxifw;
            }
        }

        $V2xyj3rpykim = $Vvkqsaecgfirhis->document->getSurface();

        
        $Vdiqkcy1hsm4urrent = null; 
        $Vfx5jpw32ymn = null;
        $Vr0rvq2j5ign = 0;
        $Vhif3h1td1dd = 0;
        $Vmm2pe5l4str = 0; 
        $Vuua0v2znlr5 = 0; 
        $Vdiqkcy1hsm4ontrolX = 0; 
        $Vdiqkcy1hsm4ontrolY = 0; 
        $Vg1ioor3znny = null;
        $Vdq2lzqz12jr = null;
        $Vift325wkeex = null;
        $Vcmeshyopc30 = null;
        $V3fvqcsh5wgl = 0; 
        $Vvkqsaecgfir = 0; 
        $V4a0x3ebky3h = null;

        foreach ($Vt321vu1jwdw as $Vdiqkcy1hsm4urrent) {
            switch ($Vdiqkcy1hsm4urrent[0]) { 
                case 'l': 
                    $Vmm2pe5l4str += $Vdiqkcy1hsm4urrent[1];
                    $Vuua0v2znlr5 += $Vdiqkcy1hsm4urrent[2];
                    $V2xyj3rpykim->lineTo($Vmm2pe5l4str + $V3fvqcsh5wgl, $Vuua0v2znlr5 + $Vvkqsaecgfir);
                    break;

                case 'L': 
                    $Vmm2pe5l4str = $Vdiqkcy1hsm4urrent[1];
                    $Vuua0v2znlr5 = $Vdiqkcy1hsm4urrent[2];
                    $V2xyj3rpykim->lineTo($Vmm2pe5l4str + $V3fvqcsh5wgl, $Vuua0v2znlr5 + $Vvkqsaecgfir);
                    break;

                case 'h': 
                    $Vmm2pe5l4str += $Vdiqkcy1hsm4urrent[1];
                    $V2xyj3rpykim->lineTo($Vmm2pe5l4str + $V3fvqcsh5wgl, $Vuua0v2znlr5 + $Vvkqsaecgfir);
                    break;

                case 'H': 
                    $Vmm2pe5l4str = $Vdiqkcy1hsm4urrent[1];
                    $V2xyj3rpykim->lineTo($Vmm2pe5l4str + $V3fvqcsh5wgl, $Vuua0v2znlr5 + $Vvkqsaecgfir);
                    break;

                case 'v': 
                    $Vuua0v2znlr5 += $Vdiqkcy1hsm4urrent[1];
                    $V2xyj3rpykim->lineTo($Vmm2pe5l4str + $V3fvqcsh5wgl, $Vuua0v2znlr5 + $Vvkqsaecgfir);
                    break;

                case 'V': 
                    $Vuua0v2znlr5 = $Vdiqkcy1hsm4urrent[1];
                    $V2xyj3rpykim->lineTo($Vmm2pe5l4str + $V3fvqcsh5wgl, $Vuua0v2znlr5 + $Vvkqsaecgfir);
                    break;

                case 'm': 
                    $Vmm2pe5l4str += $Vdiqkcy1hsm4urrent[1];
                    $Vuua0v2znlr5 += $Vdiqkcy1hsm4urrent[2];
                    $Vr0rvq2j5ign = $Vmm2pe5l4str;
                    $Vhif3h1td1dd = $Vuua0v2znlr5;
                    $V2xyj3rpykim->moveTo($Vmm2pe5l4str + $V3fvqcsh5wgl, $Vuua0v2znlr5 + $Vvkqsaecgfir);
                    break;

                case 'M': 
                    $Vmm2pe5l4str = $Vdiqkcy1hsm4urrent[1];
                    $Vuua0v2znlr5 = $Vdiqkcy1hsm4urrent[2];
                    $Vr0rvq2j5ign = $Vmm2pe5l4str;
                    $Vhif3h1td1dd = $Vuua0v2znlr5;
                    $V2xyj3rpykim->moveTo($Vmm2pe5l4str + $V3fvqcsh5wgl, $Vuua0v2znlr5 + $Vvkqsaecgfir);
                    break;

                case 'c': 
                    $Vg1ioor3znny = $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[5];
                    $Vdq2lzqz12jr = $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[6];
                    $Vdiqkcy1hsm4ontrolX = $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[3];
                    $Vdiqkcy1hsm4ontrolY = $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[4];
                    $V2xyj3rpykim->bezierCurveTo(
                        $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[1] + $V3fvqcsh5wgl, 
                        $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[2] + $Vvkqsaecgfir, 
                        $Vdiqkcy1hsm4ontrolX + $V3fvqcsh5wgl, 
                        $Vdiqkcy1hsm4ontrolY + $Vvkqsaecgfir, 
                        $Vg1ioor3znny + $V3fvqcsh5wgl,
                        $Vdq2lzqz12jr + $Vvkqsaecgfir
                    );
                    $Vmm2pe5l4str = $Vg1ioor3znny;
                    $Vuua0v2znlr5 = $Vdq2lzqz12jr;
                    break;

                case 'C': 
                    $Vmm2pe5l4str = $Vdiqkcy1hsm4urrent[5];
                    $Vuua0v2znlr5 = $Vdiqkcy1hsm4urrent[6];
                    $Vdiqkcy1hsm4ontrolX = $Vdiqkcy1hsm4urrent[3];
                    $Vdiqkcy1hsm4ontrolY = $Vdiqkcy1hsm4urrent[4];
                    $V2xyj3rpykim->bezierCurveTo(
                        $Vdiqkcy1hsm4urrent[1] + $V3fvqcsh5wgl,
                        $Vdiqkcy1hsm4urrent[2] + $Vvkqsaecgfir,
                        $Vdiqkcy1hsm4ontrolX + $V3fvqcsh5wgl,
                        $Vdiqkcy1hsm4ontrolY + $Vvkqsaecgfir,
                        $Vmm2pe5l4str + $V3fvqcsh5wgl,
                        $Vuua0v2znlr5 + $Vvkqsaecgfir
                    );
                    break;

                case 's': 

                    
                    $Vg1ioor3znny = $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[3];
                    $Vdq2lzqz12jr = $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[4];

                    if (!preg_match('/[CcSs]/', $Vfx5jpw32ymn[0])) {
                        
                        
                        $Vdiqkcy1hsm4ontrolX = $Vmm2pe5l4str;
                        $Vdiqkcy1hsm4ontrolY = $Vuua0v2znlr5;
                    } else {
                        
                        $Vdiqkcy1hsm4ontrolX = 2 * $Vmm2pe5l4str - $Vdiqkcy1hsm4ontrolX;
                        $Vdiqkcy1hsm4ontrolY = 2 * $Vuua0v2znlr5 - $Vdiqkcy1hsm4ontrolY;
                    }

                    $V2xyj3rpykim->bezierCurveTo(
                        $Vdiqkcy1hsm4ontrolX + $V3fvqcsh5wgl,
                        $Vdiqkcy1hsm4ontrolY + $Vvkqsaecgfir,
                        $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[1] + $V3fvqcsh5wgl,
                        $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[2] + $Vvkqsaecgfir,
                        $Vg1ioor3znny + $V3fvqcsh5wgl,
                        $Vdq2lzqz12jr + $Vvkqsaecgfir
                    );
                    
                    
                    
                    
                    $Vdiqkcy1hsm4ontrolX = $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[1];
                    $Vdiqkcy1hsm4ontrolY = $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[2];

                    $Vmm2pe5l4str = $Vg1ioor3znny;
                    $Vuua0v2znlr5 = $Vdq2lzqz12jr;
                    break;

                case 'S': 
                    $Vg1ioor3znny = $Vdiqkcy1hsm4urrent[3];
                    $Vdq2lzqz12jr = $Vdiqkcy1hsm4urrent[4];

                    if (!preg_match('/[CcSs]/', $Vfx5jpw32ymn[0])) {
                        
                        
                        $Vdiqkcy1hsm4ontrolX = $Vmm2pe5l4str;
                        $Vdiqkcy1hsm4ontrolY = $Vuua0v2znlr5;
                    } else {
                        
                        $Vdiqkcy1hsm4ontrolX = 2 * $Vmm2pe5l4str - $Vdiqkcy1hsm4ontrolX;
                        $Vdiqkcy1hsm4ontrolY = 2 * $Vuua0v2znlr5 - $Vdiqkcy1hsm4ontrolY;
                    }

                    $V2xyj3rpykim->bezierCurveTo(
                        $Vdiqkcy1hsm4ontrolX + $V3fvqcsh5wgl,
                        $Vdiqkcy1hsm4ontrolY + $Vvkqsaecgfir,
                        $Vdiqkcy1hsm4urrent[1] + $V3fvqcsh5wgl,
                        $Vdiqkcy1hsm4urrent[2] + $Vvkqsaecgfir,
                        $Vg1ioor3znny + $V3fvqcsh5wgl,
                        $Vdq2lzqz12jr + $Vvkqsaecgfir
                    );
                    $Vmm2pe5l4str = $Vg1ioor3znny;
                    $Vuua0v2znlr5 = $Vdq2lzqz12jr;

                    
                    
                    
                    
                    $Vdiqkcy1hsm4ontrolX = $Vdiqkcy1hsm4urrent[1];
                    $Vdiqkcy1hsm4ontrolY = $Vdiqkcy1hsm4urrent[2];

                    break;

                case 'q': 
                    
                    $Vg1ioor3znny = $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[3];
                    $Vdq2lzqz12jr = $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[4];

                    $Vdiqkcy1hsm4ontrolX = $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[1];
                    $Vdiqkcy1hsm4ontrolY = $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[2];

                    $V2xyj3rpykim->quadraticCurveTo(
                        $Vdiqkcy1hsm4ontrolX + $V3fvqcsh5wgl,
                        $Vdiqkcy1hsm4ontrolY + $Vvkqsaecgfir,
                        $Vg1ioor3znny + $V3fvqcsh5wgl,
                        $Vdq2lzqz12jr + $Vvkqsaecgfir
                    );
                    $Vmm2pe5l4str = $Vg1ioor3znny;
                    $Vuua0v2znlr5 = $Vdq2lzqz12jr;
                    break;

                case 'Q': 
                    $Vg1ioor3znny = $Vdiqkcy1hsm4urrent[3];
                    $Vdq2lzqz12jr = $Vdiqkcy1hsm4urrent[4];

                    $V2xyj3rpykim->quadraticCurveTo(
                        $Vdiqkcy1hsm4urrent[1] + $V3fvqcsh5wgl,
                        $Vdiqkcy1hsm4urrent[2] + $Vvkqsaecgfir,
                        $Vg1ioor3znny + $V3fvqcsh5wgl,
                        $Vdq2lzqz12jr + $Vvkqsaecgfir
                    );
                    $Vmm2pe5l4str = $Vg1ioor3znny;
                    $Vuua0v2znlr5 = $Vdq2lzqz12jr;
                    $Vdiqkcy1hsm4ontrolX = $Vdiqkcy1hsm4urrent[1];
                    $Vdiqkcy1hsm4ontrolY = $Vdiqkcy1hsm4urrent[2];
                    break;

                case 't': 

                    
                    $Vg1ioor3znny = $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[1];
                    $Vdq2lzqz12jr = $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[2];

                    if (preg_match("/[QqTt]/", $Vfx5jpw32ymn[0])) {
                        
                        
                        $Vdiqkcy1hsm4ontrolX = $Vmm2pe5l4str;
                        $Vdiqkcy1hsm4ontrolY = $Vuua0v2znlr5;
                    } else {
                        if ($Vfx5jpw32ymn[0] === 't') {
                            
                            $Vdiqkcy1hsm4ontrolX = 2 * $Vmm2pe5l4str - $Vift325wkeex;
                            $Vdiqkcy1hsm4ontrolY = 2 * $Vuua0v2znlr5 - $Vcmeshyopc30;
                        } else {
                            if ($Vfx5jpw32ymn[0] === 'q') {
                                
                                $Vdiqkcy1hsm4ontrolX = 2 * $Vmm2pe5l4str - $Vdiqkcy1hsm4ontrolX;
                                $Vdiqkcy1hsm4ontrolY = 2 * $Vuua0v2znlr5 - $Vdiqkcy1hsm4ontrolY;
                            }
                        }
                    }

                    $Vift325wkeex = $Vdiqkcy1hsm4ontrolX;
                    $Vcmeshyopc30 = $Vdiqkcy1hsm4ontrolY;

                    $V2xyj3rpykim->quadraticCurveTo(
                        $Vdiqkcy1hsm4ontrolX + $V3fvqcsh5wgl,
                        $Vdiqkcy1hsm4ontrolY + $Vvkqsaecgfir,
                        $Vg1ioor3znny + $V3fvqcsh5wgl,
                        $Vdq2lzqz12jr + $Vvkqsaecgfir
                    );
                    $Vmm2pe5l4str = $Vg1ioor3znny;
                    $Vuua0v2znlr5 = $Vdq2lzqz12jr;
                    $Vdiqkcy1hsm4ontrolX = $Vmm2pe5l4str + $Vdiqkcy1hsm4urrent[1];
                    $Vdiqkcy1hsm4ontrolY = $Vuua0v2znlr5 + $Vdiqkcy1hsm4urrent[2];
                    break;

                case 'T':
                    $Vg1ioor3znny = $Vdiqkcy1hsm4urrent[1];
                    $Vdq2lzqz12jr = $Vdiqkcy1hsm4urrent[2];

                    
                    $Vdiqkcy1hsm4ontrolX = 2 * $Vmm2pe5l4str - $Vdiqkcy1hsm4ontrolX;
                    $Vdiqkcy1hsm4ontrolY = 2 * $Vuua0v2znlr5 - $Vdiqkcy1hsm4ontrolY;
                    $V2xyj3rpykim->quadraticCurveTo(
                        $Vdiqkcy1hsm4ontrolX + $V3fvqcsh5wgl,
                        $Vdiqkcy1hsm4ontrolY + $Vvkqsaecgfir,
                        $Vg1ioor3znny + $V3fvqcsh5wgl,
                        $Vdq2lzqz12jr + $Vvkqsaecgfir
                    );
                    $Vmm2pe5l4str = $Vg1ioor3znny;
                    $Vuua0v2znlr5 = $Vdq2lzqz12jr;
                    break;

                case 'a':
                    
                    $Vvkqsaecgfirhis->drawArc(
                        $V2xyj3rpykim,
                        $Vmm2pe5l4str + $V3fvqcsh5wgl,
                        $Vuua0v2znlr5 + $Vvkqsaecgfir,
                        array(
                            $Vdiqkcy1hsm4urrent[1],
                            $Vdiqkcy1hsm4urrent[2],
                            $Vdiqkcy1hsm4urrent[3],
                            $Vdiqkcy1hsm4urrent[4],
                            $Vdiqkcy1hsm4urrent[5],
                            $Vdiqkcy1hsm4urrent[6] + $Vmm2pe5l4str + $V3fvqcsh5wgl,
                            $Vdiqkcy1hsm4urrent[7] + $Vuua0v2znlr5 + $Vvkqsaecgfir
                        )
                    );
                    $Vmm2pe5l4str += $Vdiqkcy1hsm4urrent[6];
                    $Vuua0v2znlr5 += $Vdiqkcy1hsm4urrent[7];
                    break;

                case 'A':
                    
                    $Vvkqsaecgfirhis->drawArc(
                        $V2xyj3rpykim,
                        $Vmm2pe5l4str + $V3fvqcsh5wgl,
                        $Vuua0v2znlr5 + $Vvkqsaecgfir,
                        array(
                            $Vdiqkcy1hsm4urrent[1],
                            $Vdiqkcy1hsm4urrent[2],
                            $Vdiqkcy1hsm4urrent[3],
                            $Vdiqkcy1hsm4urrent[4],
                            $Vdiqkcy1hsm4urrent[5],
                            $Vdiqkcy1hsm4urrent[6] + $V3fvqcsh5wgl,
                            $Vdiqkcy1hsm4urrent[7] + $Vvkqsaecgfir
                        )
                    );
                    $Vmm2pe5l4str = $Vdiqkcy1hsm4urrent[6];
                    $Vuua0v2znlr5 = $Vdiqkcy1hsm4urrent[7];
                    break;

                case 'z':
                case 'Z':
                    $Vmm2pe5l4str = $Vr0rvq2j5ign;
                    $Vuua0v2znlr5 = $Vhif3h1td1dd;
                    $V2xyj3rpykim->closePath();
                    break;
            }
            $Vfx5jpw32ymn = $Vdiqkcy1hsm4urrent;
        }
    }

    function drawArc(SurfaceInterface $V2xyj3rpykim, $Vvbyccesmikp, $Vie5jd04nx5m, $Vdiqkcy1hsm4oords)
    {
        $Ved15tbp0gam = $Vdiqkcy1hsm4oords[0];
        $Vud2tyg4u1vh = $Vdiqkcy1hsm4oords[1];
        $V2erz0gcwlou = $Vdiqkcy1hsm4oords[2];
        $V3fvqcsh5wglarge = $Vdiqkcy1hsm4oords[3];
        $Vxpnsusxjy3m = $Vdiqkcy1hsm4oords[4];
        $Vvkqsaecgfirx = $Vdiqkcy1hsm4oords[5];
        $Vvkqsaecgfiry = $Vdiqkcy1hsm4oords[6];
        $V5s3shxou2oi = array(
            array(),
            array(),
            array(),
            array(),
        );

        $V5s3shxou2oiNorm = $Vvkqsaecgfirhis->arcToSegments($Vvkqsaecgfirx - $Vvbyccesmikp, $Vvkqsaecgfiry - $Vie5jd04nx5m, $Ved15tbp0gam, $Vud2tyg4u1vh, $V3fvqcsh5wglarge, $Vxpnsusxjy3m, $V2erz0gcwlou);

        for ($V0ixz2v5mxzy = 0, $V3fvqcsh5wglen = count($V5s3shxou2oiNorm); $V0ixz2v5mxzy < $V3fvqcsh5wglen; $V0ixz2v5mxzy++) {
            $V5s3shxou2oi[$V0ixz2v5mxzy][0] = $V5s3shxou2oiNorm[$V0ixz2v5mxzy][0] + $Vvbyccesmikp;
            $V5s3shxou2oi[$V0ixz2v5mxzy][1] = $V5s3shxou2oiNorm[$V0ixz2v5mxzy][1] + $Vie5jd04nx5m;
            $V5s3shxou2oi[$V0ixz2v5mxzy][2] = $V5s3shxou2oiNorm[$V0ixz2v5mxzy][2] + $Vvbyccesmikp;
            $V5s3shxou2oi[$V0ixz2v5mxzy][3] = $V5s3shxou2oiNorm[$V0ixz2v5mxzy][3] + $Vie5jd04nx5m;
            $V5s3shxou2oi[$V0ixz2v5mxzy][4] = $V5s3shxou2oiNorm[$V0ixz2v5mxzy][4] + $Vvbyccesmikp;
            $V5s3shxou2oi[$V0ixz2v5mxzy][5] = $V5s3shxou2oiNorm[$V0ixz2v5mxzy][5] + $Vie5jd04nx5m;

            call_user_func_array(array($V2xyj3rpykim, "bezierCurveTo"), $V5s3shxou2oi[$V0ixz2v5mxzy]);
        }
    }

    function arcToSegments($VvkqsaecgfiroX, $VvkqsaecgfiroY, $Ved15tbp0gam, $Vud2tyg4u1vh, $V3fvqcsh5wglarge, $Vxpnsusxjy3m, $V2erz0gcwlouateX)
    {
        $Vvkqsaecgfirh = $V2erz0gcwlouateX * M_PI / 180;
        $Vcp2q5ectp02 = sin($Vvkqsaecgfirh);
        $Vdiqkcy1hsm4osTh = cos($Vvkqsaecgfirh);
        $Vga2khn2bg4d = 0;
        $Vciq1vz1mqh1 = 0;

        $Ved15tbp0gam = abs($Ved15tbp0gam);
        $Vud2tyg4u1vh = abs($Vud2tyg4u1vh);

        $Vi0t4wv11rmq = -$Vdiqkcy1hsm4osTh * $VvkqsaecgfiroX * 0.5 - $Vcp2q5ectp02 * $VvkqsaecgfiroY * 0.5;
        $Vwueukzlxh1e = -$Vdiqkcy1hsm4osTh * $VvkqsaecgfiroY * 0.5 + $Vcp2q5ectp02 * $VvkqsaecgfiroX * 0.5;
        $Ved15tbp0gam2 = $Ved15tbp0gam * $Ved15tbp0gam;
        $Vud2tyg4u1vh2 = $Vud2tyg4u1vh * $Vud2tyg4u1vh;
        $Vwueukzlxh1e2 = $Vwueukzlxh1e * $Vwueukzlxh1e;
        $Vi0t4wv11rmq2 = $Vi0t4wv11rmq * $Vi0t4wv11rmq;
        $Vwbyfevy1rop = $Ved15tbp0gam2 * $Vud2tyg4u1vh2 - $Ved15tbp0gam2 * $Vwueukzlxh1e2 - $Vud2tyg4u1vh2 * $Vi0t4wv11rmq2;
        $Vfqvundqbe4u = 0;

        if ($Vwbyfevy1rop < 0) {
            $V500t5q0ulgs = sqrt(1 - $Vwbyfevy1rop / ($Ved15tbp0gam2 * $Vud2tyg4u1vh2));
            $Ved15tbp0gam *= $V500t5q0ulgs;
            $Vud2tyg4u1vh *= $V500t5q0ulgs;
        } else {
            $Vfqvundqbe4u = ($V3fvqcsh5wglarge == $Vxpnsusxjy3m ? -1.0 : 1.0) * sqrt($Vwbyfevy1rop / ($Ved15tbp0gam2 * $Vwueukzlxh1e2 + $Vud2tyg4u1vh2 * $Vi0t4wv11rmq2));
        }

        $Vdiqkcy1hsm4x = $Vfqvundqbe4u * $Ved15tbp0gam * $Vwueukzlxh1e / $Vud2tyg4u1vh;
        $Vdiqkcy1hsm4y = -$Vfqvundqbe4u * $Vud2tyg4u1vh * $Vi0t4wv11rmq / $Ved15tbp0gam;
        $Vdiqkcy1hsm4x1 = $Vdiqkcy1hsm4osTh * $Vdiqkcy1hsm4x - $Vcp2q5ectp02 * $Vdiqkcy1hsm4y + $VvkqsaecgfiroX * 0.5;
        $Vdiqkcy1hsm4y1 = $Vcp2q5ectp02 * $Vdiqkcy1hsm4x + $Vdiqkcy1hsm4osTh * $Vdiqkcy1hsm4y + $VvkqsaecgfiroY * 0.5;
        $Vi4u32qwsuw2 = $Vvkqsaecgfirhis->calcVectorAngle(1, 0, ($Vi0t4wv11rmq - $Vdiqkcy1hsm4x) / $Ved15tbp0gam, ($Vwueukzlxh1e - $Vdiqkcy1hsm4y) / $Vud2tyg4u1vh);
        $Vxqlt4jotvph = $Vvkqsaecgfirhis->calcVectorAngle(($Vi0t4wv11rmq - $Vdiqkcy1hsm4x) / $Ved15tbp0gam, ($Vwueukzlxh1e - $Vdiqkcy1hsm4y) / $Vud2tyg4u1vh, (-$Vi0t4wv11rmq - $Vdiqkcy1hsm4x) / $Ved15tbp0gam, (-$Vwueukzlxh1e - $Vdiqkcy1hsm4y) / $Vud2tyg4u1vh);

        if ($Vxpnsusxjy3m == 0 && $Vxqlt4jotvph > 0) {
            $Vxqlt4jotvph -= 2 * M_PI;
        } else {
            if ($Vxpnsusxjy3m == 1 && $Vxqlt4jotvph < 0) {
                $Vxqlt4jotvph += 2 * M_PI;
            }
        }

        
        $V500t5q0ulgsegments = ceil(abs($Vxqlt4jotvph / M_PI * 2));
        $Vji4j1ie4mwl = array();
        $Vk3odr5hhprz = $Vxqlt4jotvph / $V500t5q0ulgsegments;
        $Vmk4ogpwtupu = 8 / 3 * sin($Vk3odr5hhprz / 4) * sin($Vk3odr5hhprz / 4) / sin($Vk3odr5hhprz / 2);
        $Vvkqsaecgfirh3 = $Vi4u32qwsuw2 + $Vk3odr5hhprz;

        for ($V0ixz2v5mxzy = 0; $V0ixz2v5mxzy < $V500t5q0ulgsegments; $V0ixz2v5mxzy++) {
            $Vji4j1ie4mwl[$V0ixz2v5mxzy] = $Vvkqsaecgfirhis->segmentToBezier(
                $Vi4u32qwsuw2,
                $Vvkqsaecgfirh3,
                $Vdiqkcy1hsm4osTh,
                $Vcp2q5ectp02,
                $Ved15tbp0gam,
                $Vud2tyg4u1vh,
                $Vdiqkcy1hsm4x1,
                $Vdiqkcy1hsm4y1,
                $Vmk4ogpwtupu,
                $Vga2khn2bg4d,
                $Vciq1vz1mqh1
            );
            $Vga2khn2bg4d = $Vji4j1ie4mwl[$V0ixz2v5mxzy][4];
            $Vciq1vz1mqh1 = $Vji4j1ie4mwl[$V0ixz2v5mxzy][5];
            $Vi4u32qwsuw2 = $Vvkqsaecgfirh3;
            $Vvkqsaecgfirh3 += $Vk3odr5hhprz;
        }

        return $Vji4j1ie4mwl;
    }

    function segmentToBezier($Vvkqsaecgfirh2, $Vvkqsaecgfirh3, $Vdiqkcy1hsm4osTh, $Vcp2q5ectp02, $Ved15tbp0gam, $Vud2tyg4u1vh, $Vdiqkcy1hsm4x1, $Vdiqkcy1hsm4y1, $Vmk4ogpwtupu, $Vga2khn2bg4d, $Vciq1vz1mqh1)
    {
        $Vdiqkcy1hsm4osth2 = cos($Vvkqsaecgfirh2);
        $V500t5q0ulgsinth2 = sin($Vvkqsaecgfirh2);
        $Vdiqkcy1hsm4osth3 = cos($Vvkqsaecgfirh3);
        $V500t5q0ulgsinth3 = sin($Vvkqsaecgfirh3);
        $VvkqsaecgfiroX = $Vdiqkcy1hsm4osTh * $Ved15tbp0gam * $Vdiqkcy1hsm4osth3 - $Vcp2q5ectp02 * $Vud2tyg4u1vh * $V500t5q0ulgsinth3 + $Vdiqkcy1hsm4x1;
        $VvkqsaecgfiroY = $Vcp2q5ectp02 * $Ved15tbp0gam * $Vdiqkcy1hsm4osth3 + $Vdiqkcy1hsm4osTh * $Vud2tyg4u1vh * $V500t5q0ulgsinth3 + $Vdiqkcy1hsm4y1;
        $Vdiqkcy1hsm4p1X = $Vga2khn2bg4d + $Vmk4ogpwtupu * (-$Vdiqkcy1hsm4osTh * $Ved15tbp0gam * $V500t5q0ulgsinth2 - $Vcp2q5ectp02 * $Vud2tyg4u1vh * $Vdiqkcy1hsm4osth2);
        $Vdiqkcy1hsm4p1Y = $Vciq1vz1mqh1 + $Vmk4ogpwtupu * (-$Vcp2q5ectp02 * $Ved15tbp0gam * $V500t5q0ulgsinth2 + $Vdiqkcy1hsm4osTh * $Vud2tyg4u1vh * $Vdiqkcy1hsm4osth2);
        $Vdiqkcy1hsm4p2X = $VvkqsaecgfiroX + $Vmk4ogpwtupu * ($Vdiqkcy1hsm4osTh * $Ved15tbp0gam * $V500t5q0ulgsinth3 + $Vcp2q5ectp02 * $Vud2tyg4u1vh * $Vdiqkcy1hsm4osth3);
        $Vdiqkcy1hsm4p2Y = $VvkqsaecgfiroY + $Vmk4ogpwtupu * ($Vcp2q5ectp02 * $Ved15tbp0gam * $V500t5q0ulgsinth3 - $Vdiqkcy1hsm4osTh * $Vud2tyg4u1vh * $Vdiqkcy1hsm4osth3);

        return array(
            $Vdiqkcy1hsm4p1X,
            $Vdiqkcy1hsm4p1Y,
            $Vdiqkcy1hsm4p2X,
            $Vdiqkcy1hsm4p2Y,
            $VvkqsaecgfiroX,
            $VvkqsaecgfiroY
        );
    }

    function calcVectorAngle($Vk03taunz0ac, $Vew52udcac3q, $Vj2dohx2djeb, $Vsdnhxtdtaww)
    {
        $Vvkqsaecgfira = atan2($Vew52udcac3q, $Vk03taunz0ac);
        $Vvkqsaecgfirb = atan2($Vsdnhxtdtaww, $Vj2dohx2djeb);
        if ($Vvkqsaecgfirb >= $Vvkqsaecgfira) {
            return $Vvkqsaecgfirb - $Vvkqsaecgfira;
        } else {
            return 2 * M_PI - ($Vvkqsaecgfira - $Vvkqsaecgfirb);
        }
    }
}
