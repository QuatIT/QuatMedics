<?php


namespace Svg\Tag;

class Image extends AbstractTag
{
    protected $Vmm2pe5l4str = 0;
    protected $Vuua0v2znlr5 = 0;
    protected $Vtt4kvdwuqqh = 0;
    protected $Vxtfrabd3i5r = 0;
    protected $Vewvemwwfucj = null;

    protected function before($V04clwkrmt3d)
    {
        parent::before($V04clwkrmt3d);

        $V2xyj3rpykim = $this->document->getSurface();
        $V2xyj3rpykim->save();

        $this->applyTransform($V04clwkrmt3d);
    }

    public function start($V04clwkrmt3d)
    {
        $Vhmtdpzvfg2y = $this->document;
        $Vxtfrabd3i5r = $this->document->getHeight();
        $this->y = $Vxtfrabd3i5r;

        if (isset($V04clwkrmt3d['x'])) {
            $this->x = $V04clwkrmt3d['x'];
        }
        if (isset($V04clwkrmt3d['y'])) {
            $this->y = $Vxtfrabd3i5r - $V04clwkrmt3d['y'];
        }

        if (isset($V04clwkrmt3d['width'])) {
            $this->width = $V04clwkrmt3d['width'];
        }
        if (isset($V04clwkrmt3d['height'])) {
            $this->height = $V04clwkrmt3d['height'];
        }

        if (isset($V04clwkrmt3d['xlink:href'])) {
            $this->href = $V04clwkrmt3d['xlink:href'];
        }

        $Vhmtdpzvfg2y->getSurface()->transform(1, 0, 0, -1, 0, $Vxtfrabd3i5r);

        $Vhmtdpzvfg2y->getSurface()->drawImage($this->href, $this->x, $this->y, $this->width, $this->height);
    }

    protected function after()
    {
        $this->document->getSurface()->restore();
    }
}
