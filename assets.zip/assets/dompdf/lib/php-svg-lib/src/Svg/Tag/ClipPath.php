<?php


namespace Svg\Tag;

use Svg\Style;

class ClipPath extends AbstractTag
{
    protected function before($V04clwkrmt3d)
    {
        $V2xyj3rpykim = $this->document->getSurface();

        $V2xyj3rpykim->save();

        $Vkvw5zjrwkdm = $this->makeStyle($V04clwkrmt3d);

        $this->setStyle($Vkvw5zjrwkdm);
        $V2xyj3rpykim->setStyle($Vkvw5zjrwkdm);

        $this->applyTransform($V04clwkrmt3d);
    }

    protected function after()
    {
        $this->document->getSurface()->restore();
    }
}
