<?php


namespace Svg\Tag;

use Svg\Style;

class Shape extends AbstractTag
{
    protected function before($V04clwkrmt3d)
    {
        $V2xyj3rpykim = $this->document->getSurface();

        $V2xyj3rpykim->save();

        $Vkvw5zjrwkdm = $this->makeStyle($V04clwkrmt3d);

        $this->setStyle($Vkvw5zjrwkdm);
        $V2xyj3rpykim->setStyle($Vkvw5zjrwkdm);

        $this->applyTransform($V04clwkrmt3d);
    }

    protected function after()
    {
        $V2xyj3rpykim = $this->document->getSurface();

        if ($this->hasShape) {
            $Vkvw5zjrwkdm = $V2xyj3rpykim->getStyle();

            $Vbopclc0ksnj   = $Vkvw5zjrwkdm->fill   && is_array($Vkvw5zjrwkdm->fill);
            $Vleb2mixglzb = $Vkvw5zjrwkdm->stroke && is_array($Vkvw5zjrwkdm->stroke);

            if ($Vbopclc0ksnj) {
                if ($Vleb2mixglzb) {
                    $V2xyj3rpykim->fillStroke();
                } else {







                    $V2xyj3rpykim->fill();
                }
            }
            elseif ($Vleb2mixglzb) {
                $V2xyj3rpykim->stroke();
            }
            else {
                $V2xyj3rpykim->endPath();
            }
        }

        $V2xyj3rpykim->restore();
    }
}
