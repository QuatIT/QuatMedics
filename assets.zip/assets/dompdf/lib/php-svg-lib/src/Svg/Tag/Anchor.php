<?php


namespace Svg\Tag;

class Anchor extends Group
{

}
