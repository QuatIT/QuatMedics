<?php


namespace Svg\Tag;

class Circle extends Shape
{
    protected $Vub5quddvkgj = 0;
    protected $Ve4gg4sz2gxf = 0;
    protected $Vapkwgsb3w3r;

    public function start($V04clwkrmt3d)
    {
        if (isset($V04clwkrmt3d['cx'])) {
            $this->cx = $V04clwkrmt3d['cx'];
        }
        if (isset($V04clwkrmt3d['cy'])) {
            $this->cy = $V04clwkrmt3d['cy'];
        }
        if (isset($V04clwkrmt3d['r'])) {
            $this->r = $V04clwkrmt3d['r'];
        }

        $this->document->getSurface()->circle($this->cx, $this->cy, $this->r);
    }
}
