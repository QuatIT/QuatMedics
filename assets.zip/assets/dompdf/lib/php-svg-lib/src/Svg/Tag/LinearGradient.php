<?php


namespace Svg\Tag;


use Svg\Gradient\Stop;
use Svg\Style;

class LinearGradient extends AbstractTag
{
    protected $V4wnp2r2nst5;
    protected $V2e3azycubv1;
    protected $V2kam3hj2q41;
    protected $Vg1v0wo0w4jj;

    
    protected $Vwljzztrdyci = array();

    public function start($V04clwkrmt3d)
    {
        parent::start($V04clwkrmt3d);

        if (isset($V04clwkrmt3d['x1'])) {
            $this->x1 = $V04clwkrmt3d['x1'];
        }
        if (isset($V04clwkrmt3d['y1'])) {
            $this->y1 = $V04clwkrmt3d['y1'];
        }
        if (isset($V04clwkrmt3d['x2'])) {
            $this->x2 = $V04clwkrmt3d['x2'];
        }
        if (isset($V04clwkrmt3d['y2'])) {
            $this->y2 = $V04clwkrmt3d['y2'];
        }
    }

    public function getStops() {
        if (empty($this->stops)) {
            foreach ($this->children as $Vex1mulnruda) {
                if ($Vex1mulnruda->tagName != "stop") {
                    continue;
                }

                $Vbvrmjtjzbsn = new Stop();
                $Vlxehxs5gfba = $Vex1mulnruda->attributes;

                
                if (isset($Vlxehxs5gfba["style"])) {
                    $Vnymdfwn02z4 = Style::parseCssStyle($Vlxehxs5gfba["style"]);

                    if (isset($Vnymdfwn02z4["stop-color"])) {
                        $Vbvrmjtjzbsn->color = Style::parseColor($Vnymdfwn02z4["stop-color"]);
                    }

                    if (isset($Vnymdfwn02z4["stop-opacity"])) {
                        $Vbvrmjtjzbsn->opacity = max(0, min(1.0, $Vnymdfwn02z4["stop-opacity"]));
                    }
                }

                
                if (isset($Vlxehxs5gfba["offset"])) {
                    $Vbvrmjtjzbsn->offset = $Vlxehxs5gfba["offset"];
                }
                if (isset($Vlxehxs5gfba["stop-color"])) {
                    $Vbvrmjtjzbsn->color = Style::parseColor($Vlxehxs5gfba["stop-color"]);
                }
                if (isset($Vlxehxs5gfba["stop-opacity"])) {
                    $Vbvrmjtjzbsn->opacity = max(0, min(1.0, $Vlxehxs5gfba["stop-opacity"]));
                }

                $this->stops[] = $Vbvrmjtjzbsn;
            }
        }

        return $this->stops;
    }
}
