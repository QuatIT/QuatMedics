<?php


namespace Svg\Tag;

use Sabberworm\CSS;

class StyleTag extends AbstractTag
{
    protected $Vnjapcj4bkpc = "";

    public function end()
    {
        $Voguw0q5rps1 = new CSS\Parser($this->text);
        $this->document->appendStyleSheet($Voguw0q5rps1->parse());
    }

    public function appendText($Vnjapcj4bkpc)
    {
        $this->text .= $Vnjapcj4bkpc;
    }
}
