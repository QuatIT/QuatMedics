<?php


namespace Svg\Tag;

class Polyline extends Shape
{
    public function start($V04clwkrmt3d)
    {
        $Vj0eqma35tbv = array();
        preg_match_all('/([\-]*[0-9\.]+)/', $V04clwkrmt3d['points'], $Vj0eqma35tbv);

        $Vz0kp11gbnu4 = $Vj0eqma35tbv[0];
        $V4wukmcy3ij2 = count($Vz0kp11gbnu4);

        $V2xyj3rpykim = $this->document->getSurface();
        list($Vmm2pe5l4str, $Vuua0v2znlr5) = $Vz0kp11gbnu4;
        $V2xyj3rpykim->moveTo($Vmm2pe5l4str, $Vuua0v2znlr5);

        for ($V0ixz2v5mxzy = 2; $V0ixz2v5mxzy < $V4wukmcy3ij2; $V0ixz2v5mxzy += 2) {
            $Vmm2pe5l4str = $Vz0kp11gbnu4[$V0ixz2v5mxzy];
            $Vuua0v2znlr5 = $Vz0kp11gbnu4[$V0ixz2v5mxzy + 1];
            $V2xyj3rpykim->lineTo($Vmm2pe5l4str, $Vuua0v2znlr5);
        }
    }
}
