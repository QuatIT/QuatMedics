<?php


namespace Svg\Tag;

class Stop extends AbstractTag
{
    public function start($V04clwkrmt3d)
    {

    }
}
