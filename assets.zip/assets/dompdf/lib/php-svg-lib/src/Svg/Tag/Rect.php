<?php


namespace Svg\Tag;

class Rect extends Shape
{
    protected $Vmm2pe5l4str = 0;
    protected $Vuua0v2znlr5 = 0;
    protected $Vtt4kvdwuqqh = 0;
    protected $Vxtfrabd3i5r = 0;
    protected $Ved15tbp0gam = 0;
    protected $Vud2tyg4u1vh = 0;

    public function start($V04clwkrmt3d)
    {
        if (isset($V04clwkrmt3d['x'])) {
            $this->x = $V04clwkrmt3d['x'];
        }
        if (isset($V04clwkrmt3d['y'])) {
            $this->y = $V04clwkrmt3d['y'];
        }

        if (isset($V04clwkrmt3d['width'])) {
            $this->width = $V04clwkrmt3d['width'];
        }
        if (isset($V04clwkrmt3d['height'])) {
            $this->height = $V04clwkrmt3d['height'];
        }

        if (isset($V04clwkrmt3d['rx'])) {
            $this->rx = $V04clwkrmt3d['rx'];
        }
        if (isset($V04clwkrmt3d['ry'])) {
            $this->ry = $V04clwkrmt3d['ry'];
        }

        $this->document->getSurface()->rect($this->x, $this->y, $this->width, $this->height, $this->rx, $this->ry);
    }
}
