<?php


namespace Svg\Tag;

class Ellipse extends Shape
{
    protected $Vub5quddvkgj = 0;
    protected $Ve4gg4sz2gxf = 0;
    protected $Ved15tbp0gam = 0;
    protected $Vud2tyg4u1vh = 0;

    public function start($V04clwkrmt3d)
    {
        parent::start($V04clwkrmt3d);

        if (isset($V04clwkrmt3d['cx'])) {
            $this->cx = $V04clwkrmt3d['cx'];
        }
        if (isset($V04clwkrmt3d['cy'])) {
            $this->cy = $V04clwkrmt3d['cy'];
        }
        if (isset($V04clwkrmt3d['rx'])) {
            $this->rx = $V04clwkrmt3d['rx'];
        }
        if (isset($V04clwkrmt3d['ry'])) {
            $this->ry = $V04clwkrmt3d['ry'];
        }

        $this->document->getSurface()->ellipse($this->cx, $this->cy, $this->rx, $this->ry, 0, 0, 360, false);
    }
}
