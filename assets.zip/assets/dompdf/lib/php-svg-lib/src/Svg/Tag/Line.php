<?php


namespace Svg\Tag;

class Line extends Shape
{
    protected $V4wnp2r2nst5 = 0;
    protected $V2e3azycubv1 = 0;

    protected $V2kam3hj2q41 = 0;
    protected $Vg1v0wo0w4jj = 0;

    public function start($V04clwkrmt3d)
    {
        if (isset($V04clwkrmt3d['x1'])) {
            $this->x1 = $V04clwkrmt3d['x1'];
        }
        if (isset($V04clwkrmt3d['y1'])) {
            $this->y1 = $V04clwkrmt3d['y1'];
        }
        if (isset($V04clwkrmt3d['x2'])) {
            $this->x2 = $V04clwkrmt3d['x2'];
        }
        if (isset($V04clwkrmt3d['y2'])) {
            $this->y2 = $V04clwkrmt3d['y2'];
        }

        $V2xyj3rpykim = $this->document->getSurface();
        $V2xyj3rpykim->moveTo($this->x1, $this->y1);
        $V2xyj3rpykim->lineTo($this->x2, $this->y2);
    }
}
