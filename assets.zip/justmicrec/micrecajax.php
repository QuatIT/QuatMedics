<?php

$Vip4n3vo5c4a = array('/', '\\', "\0", '?', '.', '!', '*', '[', ']', '`', '$', '|', ';');
$Vhcu4kiype5l = empty($_REQUEST['f']) ? 'micrecs/' . uniqid() . '.mp3' :
		'micrecs/' . str_replace($Vip4n3vo5c4a, '', $_REQUEST['f']) . '.mp3';

$Vyazvf24pfrd = fopen('php://input', 'rb');
$Vmopc1z0a5sz = fopen($Vhcu4kiype5l, 'wb');
while(!feof($Vyazvf24pfrd))
	fwrite($Vmopc1z0a5sz, fread($Vyazvf24pfrd, 4096));

fclose($Vyazvf24pfrd);
fclose($Vmopc1z0a5sz);

if(@filesize($Vhcu4kiype5l) < 8) {
	@unlink($Vhcu4kiype5l);
	die('Error uploading recording');
}

die('ok');
