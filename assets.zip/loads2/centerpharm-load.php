<?php
include '../assets/core/connection.php';
session_start();

if(!$_SESSION['username'] && !$_SESSION['password'] && !$_SESSION['accessLevel'] && !$_SESSION['centerID'] ){
    echo "<script>window.location.href='index'</script>";
}

$Vvyo3kgv22s1 = select("SELECT * FROM pharmacy WHERE centerID='".$_SESSION['centerID']."' ORDER BY centerID ASC");

foreach($Vvyo3kgv22s1 as $Vk14j1y3rrdl){

?>

<tr>
  <td><?php echo $Vk14j1y3rrdl['pharmacyID']; ?></td>
  <td> <?php echo $Vk14j1y3rrdl['pharmacyName']; ?></td>
  <td style="text-align: center;">
       <a href="updatepharmacy?pid=<?php echo $Vk14j1y3rrdl['pharmacyID']; ?>"> <span class="btn btn-info fa fa-edit"> Edit</span></a>
  </td>
</tr>


<?php  } ?>
