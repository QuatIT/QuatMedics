
<?php
include '../assets/core/connection.php';
session_start();

if(!$_SESSION['username'] && !$_SESSION['password'] && !$_SESSION['accessLevel'] && !$_SESSION['centerID'] ){
    echo "<script>window.location.href='index'</script>";
}


$Vsw2kuekeu5v = $_REQUEST['id'];
$Vqw0mzuejanc = $_GET['pid'];

if($Vsw2kuekeu5v == 'NHIS'){

  $Vvpropt1mzt2 = select("select * from patient where patientID='$Vqw0mzuejanc' ");
  foreach($Vvpropt1mzt2 as $Vcqwpvcjcqxw){
    $_SESSION['exp_date'] = $Vcqwpvcjcqxw['insurance_number'];
  }

?>

          <div class="control-group">
            <label class="control-label">CC Number:</label>
            <div class="controls">
              <input type="text" class="span11" placeholder="CC Number" name="ccNumber" required />
            </div>
          </div>

          <div class="control-group">
            <label class="control-label">Insurance Number:</label>
            <div class="controls">
              <input type="text" class="span11" placeholder="Insurance Number" value="<?php echo $_SESSION['exp_date']; ?>" name="insuranceNumber" required />
            </div>
          </div>
<?php
 }else{

?>

  <div class="control-group">
    <label class="control-label">Insurance Number:</label>
    <div class="controls">
      <input type="text" class="span11" placeholder="Insurance Number" name="insuranceNumber" value="<?php echo @$_SESSION['exp_date']; ?>" required />
    </div>
  </div>

<?php
}




?>
